import React, { useState } from 'react';
import styles from './checkbox.module.scss'; // Make sure to replace with the correct path to your CSS module
import classNames from 'classnames';


const Checkbox = ({ isChecked,id,htmlFor, label, onChange }:any) => {
    const handleCheckboxChange = (event:any) => {
        if (onChange) {
            onChange(event.target.checked);
        }
    };

    return (
        <td className={classNames(styles["form-check-checkbox"], 'd-flex')}>
            <input
                className={styles["form-check-input"]}
                type="checkbox"
                value=""
                id={id}
                // id="nologstopover"
                checked={isChecked}
                onChange={handleCheckboxChange}
            />
            <label className={styles["form-check-label"]} htmlFor={htmlFor}>
                {label}
            </label>
        </td>
    );
};

export default Checkbox;

