import classNames from 'classnames';
import { useState } from "react";
import styles from "../../lib/oneway.module.scss";
import { useSelector } from 'react-redux';
import { RootState } from '@mfa-travel-app/store';

const TravellersClass = ({ onAllTravellers }: any) => {
  const { searchPayload } = useSelector((state: RootState) => state.flight);
  const [istravellersClass, setIsTravellersClass] = useState(false);
  const [adults, setAdults] = useState(
    searchPayload?.adultCount ? searchPayload?.adultCount : 1
  );
  const [children, setChildren] = useState(
    searchPayload?.childCount ? searchPayload?.childCount : 0
  );
  const [infants, setInfants] = useState(
    searchPayload?.infantCount   ? searchPayload?.infantCount  : 0
  );
  const [selectedOption, setSelectedOption] = useState('Economy');
  const openTravellersClass = () => {
    setIsTravellersClass(!istravellersClass);
    onAllTravellers({
      adults: adults,
      children: children,
      infants: infants,
      selectedOption: selectedOption,
    });
  };

  const handleIncrement = (type: any) => {
    switch (type) {
      case 'adults':
        setAdults(adults + 1);
        break;
      case 'children':
        setChildren(children + 1);
        break;
      case 'infants':
        setInfants(infants + 1);
        break;
      default:
        break;
    }
  };

  const handleDecrement = (type: any) => {
    switch (type) {
      case 'adults':
        setAdults(adults > 0 ? adults - 1 : 0);
        break;
      case 'children':
        setChildren(children > 0 ? children - 1 : 0);
        break;
      case 'infants':
        setInfants(infants > 0 ? infants - 1 : 0);
        break;
      default:
        break;
    }
  };
  const handleRadioChange = (event: any) => {
    setSelectedOption(event.target.value);
  };
  const TravellersDone = () => {
    setIsTravellersClass(!istravellersClass);
    onAllTravellers({
      adults: adults,
      children: children,
      infants: infants,
      selectedOption: selectedOption,
    });
  };

  return (

      <div className="row">
      <div className="col-12">
      <div className="frwrapper position-relative">        
      <table className='flightheadertbl'>
            <thead>
              <tr>
                <td>
                  Travellers & Class <i className="fa-solid fa-caret-down"></i>
                </td>
              </tr>
            </thead>
            <tbody></tbody>
          </table>


  <div id="selectflightpax" className="srchCon" onClick={openTravellersClass}> 
    <div className="srchRow">
      <div className="srchCol"> 
        <div className="mb-1"> 
          <span className="srchsml"> Travellers &amp; Class{' '} <i className="fa-solid fa-angle-down"></i></span>      
        </div>
        <div><span className="srchTitle"> 
        <input className='inpflightpax' 
                  style={{border: 'none', backgroundColor: 'transparent', textAlign: 'center', fontWeight: 700}}
                  type="text"
                  id="totalpaxflightinp"
                  name="totalpaxflightinp"
                  value={adults + children + infants}
                  disabled={true}
                />
          
        </span>{' '} <span className="srchLabel">Travellers</span> 
      
            </div>
            
        <div>
         
          
          <span id="getcabinval" className="srchsml textTrim"> {selectedOption}</span>{' '}  
          
          </div>
      </div>
    </div>

  </div>



  
   


        <div
          id="div_flightPax"
          className={classNames(
            styles['travelersFlight'],
            `${istravellersClass ? 'd-block' : 'd-none'}`
          )}
        >

          <div className='fpaxWrap'> 
          <div className="row align-items-center mb-1">
            <div className="col-6">Adults (12+)</div>
            <div className="col-6">
              <div className={classNames(styles['input-group'], 'input-group')}>
                <button
                  className={classNames(
                    styles['input-group-text'],
                    styles['dec-btn']
                  )}
                  onClick={() => handleDecrement('adults')}
                  disabled={adults === 0}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                    <path d="M432 256c0 17.7-14.3 32-32 32L48 288c-17.7 0-32-14.3-32-32s14.3-32 32-32l352 0c17.7 0 32 14.3 32 32z" />
                  </svg>
                </button>
                <input
                  type="text"
                  className={classNames(styles['form-control'], 'text-center')}
                  value={adults}
                  disabled
                />
                <button
                  className={classNames(
                    styles['input-group-text'],
                    styles['inc-btn']
                  )}
                  onClick={() => handleIncrement('adults')}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                    <path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z" />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          <div className="row align-items-center mb-1">
            <div className="col-6">Children (2 - 11) </div>
            <div className="col-6">
              <div className={classNames(styles['input-group'], 'input-group')}>
                <button
                  className={classNames(
                    styles['input-group-text'],
                    styles['dec-btn']
                  )}
                  onClick={() => handleDecrement('children')}
                  disabled={children === 0}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                    <path d="M432 256c0 17.7-14.3 32-32 32L48 288c-17.7 0-32-14.3-32-32s14.3-32 32-32l352 0c17.7 0 32 14.3 32 32z" />
                  </svg>
                </button>
                <input
                  type="text"
                  className={classNames(styles['form-control'], 'text-center')}
                  value={children}
                  disabled
                />
                <button
                  className={classNames(
                    styles['input-group-text'],
                    styles['inc-btn']
                  )}
                  onClick={() => handleIncrement('children')}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                    <path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z" />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          <div className="row align-items-center mb-1">
            <div className="col-6">Infants(0-2) </div>
            <div className="col-6">
              <div className={classNames(styles['input-group'], 'input-group')}>
                <button
                  className={classNames(
                    styles['input-group-text'],
                    styles['dec-btn']
                  )}
                  onClick={() => handleDecrement('infants')}
                  disabled={infants === 0}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                    <path d="M432 256c0 17.7-14.3 32-32 32L48 288c-17.7 0-32-14.3-32-32s14.3-32 32-32l352 0c17.7 0 32 14.3 32 32z" />
                  </svg>
                </button>
                <input
                  type="text"
                  className={classNames(styles['form-control'], 'text-center')}
                  value={infants}
                  disabled
                />
                <button
                  className={classNames(
                    styles['input-group-text'],
                    styles['inc-btn']
                  )}
                  onClick={() => handleIncrement('infants')}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                    <path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z" />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          <div className="row mt-3">
            <div className="col-lg-12">
              <label htmlFor="selcabin">
                <strong>Travel Class</strong>
              </label>
              <div className={styles['travel-class']}>
                <span>
                  <input
                    type="radio"
                    name="travelClass"
                    id="any"
                    value="Any"
                    checked={selectedOption === 'any'}
                    onChange={handleRadioChange}
                  />
                  <label htmlFor="any">Any</label>
                </span>

                <span>
                  <input
                    type="radio"
                    name="travelClass"
                    id="economy"
                    value="Economy"
                    checked={selectedOption === 'economy'}
                    onChange={handleRadioChange}
                  />
                  <label
                    htmlFor="economy"
                    className={
                      styles[
                        selectedOption === 'economy' ? 'default-radio' : ''
                      ]
                    }
                  >
                    Economy
                  </label>
                </span>

                <span>
                  <input
                    type="radio"
                    name="travelClass"
                    id="firstClass"
                    value="FirstClass"
                    checked={selectedOption === 'firstClass'}
                    onChange={handleRadioChange}
                  />
                  <label
                    htmlFor="firstClass"
                    className={
                      styles[
                        selectedOption === 'firstClass' ? 'default-radio' : ''
                      ]
                    }
                  >
                    First Class
                  </label>
                </span>

                <span>
                  <input
                    type="radio"
                    name="travelClass"
                    id="premiumEconomy"
                    value="PremiumEconomy"
                    checked={selectedOption === 'premiumEconomy'}
                    onChange={handleRadioChange}
                  />
                  <label
                    htmlFor="premiumEconomy"
                    className={
                      styles[
                        selectedOption === 'premiumEconomy'
                          ? 'default-radio'
                          : ''
                      ]
                    }
                  >
                    Premium Economy
                  </label>
                </span>

                <span>
                  <input
                    type="radio"
                    name="travelClass"
                    id="business"
                    value="Business"
                    checked={selectedOption === 'business'}
                    onChange={handleRadioChange}
                  />
                  <label
                    htmlFor="business"
                    className={
                      styles[
                        selectedOption === 'business' ? 'default-radio' : ''
                      ]
                    }
                  >
                    Business
                  </label>
                </span>
              </div>
            </div>
          </div>

          <div className="row mt-3 mb-2">
            <div className={classNames('col-lg-2')}>
              <button
                className={classNames(
                  styles['btn'],
                  styles['btn-primary'],
                  styles['btn-primarys'],
                  styles['close_div_flightPax']
                )}
                onClick={TravellersDone}
              >
                Done
              </button>
            </div>
          </div>
          </div>

        </div>
      </div>

    </div>
    </div>
  );
};
export default TravellersClass;
