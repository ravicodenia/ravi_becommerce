import classNames from "classnames";
import styles from './findbestaboutairlines.module.scss'

const FindBestAboutAirlines = ({ cheapestFlights, quckestFlight, bestFlight ,handleSelectChange}: any) => {

  return (
    <div className="col-12">
      <div className={styles["shortFlightData"]}>
        <div className="row align-items-center">
          <div className={classNames(styles["borderContainer"], "col-lg-3 col-4")}>
           
            <a className={styles["CheapestAnchor rounded ms-2"]}> 
              <div>Cheapest</div>
               
               <span className="d-block fare_cheapest_flight">{cheapestFlights?.fare?.toFixed(2)} &gt; {cheapestFlights?.duration}</span>
                </a>
                 </div>
         
          <div className={classNames(styles["borderContainer"], "col-lg-3 col-3 d-none d-lg-block")}>
            <a className={styles["CheapestAnchor"]}> 
              <div>Best</div>
              
              <span className="d-block fare_cheapest_flight">{bestFlight?.totalFare?.toFixed(2)} &gt; {quckestFlight?.flights[0][0].duration}</span> </a> </div>
        
          <div className={classNames(styles["borderContainer"], "col-lg-3 col-4")}>
            <a className={styles["CheapestAnchor"]}> Quickest 
              
              <span className="d-block fare_cheapest_flight">{quckestFlight?.totalFare?.toFixed(2)} &gt;  {quckestFlight?.flights[0][0].duration}</span> 
              
              
              </a> 
              </div>   

          <div className="col-lg-3 col-4 text-end">
            <div className={styles["input-group"]}>
              <div className={styles["input-group-prepend"]}>
                <span className={classNames(styles["sortlist"], 'me-1')}>
                  <i className="fa-solid fa-arrow-down-short-wide"></i> Sort By:</span>
              </div>
              <select aria-label="Sort By" id="sortbycombination" onChange = {handleSelectChange}>
                <option value="Price"> Price</option>
                <option value="Departure">Departure</option>
                <option value="Arrival">Arrival</option>
                <option value="Duration">Duration</option>
                <option value= "Airline">Airline</option>
              </select>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
export default FindBestAboutAirlines;