import React, { useEffect, useState, useRef } from 'react';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import 'bootstrap/dist/js/bootstrap.bundle.min';
import styles from './aboutflight.module.scss';
import classNames from 'classnames';
import { IoSearchSharp } from 'react-icons/io5';
import { useSelector } from 'react-redux';
import { RootState } from '@mfa-travel-app/store';
import Checkbox from '../Checkbox/checkbox';
import { FiSunrise } from 'react-icons/fi';
import FlightTimeContainer from '../FlightTimeContainer/flightTimeContainer';
import { IoSunnyOutline } from 'react-icons/io5';
import { FiSunset } from 'react-icons/fi';
import { FaRegMoon } from 'react-icons/fa';
import RangeSlider from '../RangeSlider/rangeSlider';
import Accordion from '../Accordion/accordion';

const SearchFilter = ({
  Itenaryfilter,
  NonStopMinimumFare,
  OneStopMinimumFare,
  MultiStopMinimumFare,
  maximumTotalFare,
  minimumTotalFare,
  filteredSearchItenary,
  allSearchItenary,
  allSearchDatafunc,
}: any) => {
  const [showAll, setShowAll] = React.useState(false);
  const [flightNumberInput, setFlightNumbeInput] = useState<any>();
  const [showAllAirportName, setShowAllAirportName] = useState<any>(false);
  const [range, setRange] = useState([1, 100]);
  const [allSearchData, setAllSearchData] = useState<any>({
    stop: {
      zeroStop: false,
      oneStop: false,
      twoStop: false,
    },
    airlines: [],
    flightExperience: {
      overnight: false,
      noLongStop: false,
    },
    farePolicy: {
      refundable: false,
      nonrefundable: false,
    },
    priceRange: [],
    flightNumber: '',
    flightTime: {
      onward: {
        departure: {
          sunset: false,
          morning: false,
          midnoon: false,
          night: false,
        },
        arrival: {
          sunset: false,
          morning: false,
          midnoon: false,
          night: false,
        },
      },
      return: {
        departure: {
          sunset: false,
          morning: false,
          midnoon: false,
          night: false,
        },
        arrival: {
          sunset: false,
          morning: false,
          midnoon: false,
          night: false,
        },
      },
    },
    layoverAirports: [],
  });

  const getLowestFareFlights = (flights: any) => {
    const uniqueFlights: any = {};
    flights.forEach((flight: any) => {
      if (
        !uniqueFlights[flight.airline] ||
        flight.totalFare < uniqueFlights[flight.airline].totalFare
      ) {
        uniqueFlights[flight.airline] = flight;
      }
    });

    return Object.values(uniqueFlights);
  };
  const [selectedFlights, setSelectedFlights] = useState<any>([]);
  const [selectedLayOverAirport, setSelectedLayOverAirport] = useState<any>([]);
  const filteredFlights = getLowestFareFlights([
    ...Itenaryfilter.zero,
    ...Itenaryfilter.one,
    ...Itenaryfilter.two,
  ]);
  const [accordionExpand, setAccordionExpand] = useState<any>({
    first: false,
    second: false,
    third: false,
    forth: false,
    fifth: false,
    sixth: false,
    seventh: false,
  });
  const [allChecked, setAllChecked] = useState(false);
  const [priceRangeMin, setPriceRangeMin] = useState<any>(minimumTotalFare);
  const [priceRangeMax, setPriceRangeMax] = useState<any>(maximumTotalFare);
  const [allCheckedLayOverAirport, setAllCheckedLayOverAirport] = useState<any>();
  const prevRangeRef = useRef(range);
  const getCityData = (flights: any) => {
    const cityData: any = {};
    flights.forEach((flight: any) => {
      const { cityName, totalFare, stopOver, isStopOver } = flight;


      if (stopOver || isStopOver) {
        if (!cityData[cityName]) {
          // If the city is not yet in cityData, add it with the current flight details
          cityData[cityName] = { cityName: cityName, totalFare, count: 1 };
        } else {
          // If the city is already in cityData
          if (totalFare < cityData[cityName].totalFare) {
            // If the current flight's fare is less, update the totalFare
            cityData[cityName].totalFare = totalFare;
          }
          // Increment the count of flights to this city
          cityData[cityName].count += 1;
        }
      }
    });
    return Object.values(cityData);
  };

  const displayLayOverAirport = () => {
    const allCityData = getCityData([
      ...Itenaryfilter.zero,
      ...Itenaryfilter.one,
      ...Itenaryfilter.two,
    ]);
    if (!showAll) {
      return allCityData.slice(0, 5);
    }
    return allCityData;
  };

  const handleToggle = () => {
    setShowAll(!showAll);
  };
  const handleOverngihtFlightChange = (isChecked: any) => {
    setAllSearchData((prev: any) => {
      return {
        ...prev, // spread the previous state
        flightExperience: {
          ...prev?.overnight,
          overnight: !prev.flightExperience.overnight,
        },
      };
    });
  };
  const handleNoLongStopOverChange = () => {
    setAllSearchData((prev: any) => {
      return {
        ...prev, // spread the previous state
        flightExperience: {
          ...prev?.noLongStop,
          noLongStop: !prev.flightExperience.noLongStop,
        },
      };
    });
  };
  const handleRefundableChange = (e: any) => {
    setAllSearchData((prev: any) => {
      return {
        ...prev, // spread the previous state
        farePolicy: {
          ...prev?.refundable,
          refundable: !prev.farePolicy.refundable,
        },
      };
    });
  };
  const handleNonRefundableChange = (isChecked: any) => {
    setAllSearchData((prev: any) => {
      return {
        ...prev, // spread the previous state
        farePolicy: {
          ...prev?.nonrefundable,
          nonrefundable: !prev.farePolicy.nonrefundable,
        },
      };
    });
  };

  const handleCheckboxChange = (time: any) => {
    setAllSearchData((prev: any) => {
      return {
        ...prev,
        flightTime: {
          ...prev.flightTime,
          onward: {
            ...prev.flightTime.onward,
            departure: {
              ...prev.flightTime.onward.departure,
              [time]: !prev.flightTime.onward.departure[time],
            },
          },
        },
      };
    });
  };

  const handleArrivalCheckboxChange = (time: any) => {
    setAllSearchData((prev: any) => ({
      ...prev,
      flightTime: {
        ...prev.flightTime,
        onward: {
          ...prev.flightTime.onward,
          arrival: {
            ...prev.flightTime.onward.arrival,
            [time]: !prev.flightTime.onward.arrival[time],
          },
        },
      },
    }));
  };

  const handleReturnArrivalCheckboxChange = () => {
    // setAllSearchData((prev: any) => ({
    //     ...prev,
    //     flightTime: {
    //         ...prev.flightTime,
    //         onward: {
    //             ...prev.flightTime.onward,
    //             arrival: {
    //                 ...prev.flightTime.onward.arrival,
    //                 [time]: !prev.flightTime.return.arrival[time],
    //             },
    //         },
    //     },
    // }));
  };
  const handleReturnDepartureCheckboxChange = () => { };

  const OnNonStopMinimumFare = (e: any) => {
    setAllSearchData((prev: any) => {
      return {
        ...prev, // spread the previous state
        stop: {
          ...prev?.stop, // spread the stop object, handling cases where it might be undefined
          zeroStop: !prev?.stop?.zeroStop, // toggle the zeroStop value
        },
      };
    });
  };
  const OnOneStopMinimumFare = (e: any) => {
    setAllSearchData((prev: any) => {
      return {
        ...prev, // spread the previous state
        stop: {
          ...prev?.stop, // spread the stop object, handling cases where it might be undefined
          oneStop: !prev?.stop?.oneStop, // toggle the zeroStop value
        },
      };
    });
  };
  const OnMultuStopMinimumFare = (e: any) => {
    setAllSearchData((prev: any) => {
      return {
        ...prev, // spread the previous state
        stop: {
          ...prev?.stop, // spread the stop object, handling cases where it might be undefined
          twoStop: !prev?.stop?.twoStop, // toggle the zeroStop value
        },
      };
    });
  };

  const SearchFilterFunc = (e: any) => {
    setFlightNumbeInput(e.target.value);
    if (e.target.value == '') {
      setAllSearchData((prev: any) => {
        return {
          ...prev,
          flightNumber: '',
        };
      });
    }
  };

  useEffect(() => {
    allSearchDatafunc(allSearchData);
  }, [allSearchData]);
  useEffect(() => {
    setPriceRangeMin(minimumTotalFare);
    setPriceRangeMax(maximumTotalFare);
  }, [minimumTotalFare, maximumTotalFare]);

  const flightNumberButtonfunc = () => {
    setAllSearchData((prev: any) => {
      return {
        ...prev,
        flightNumber: flightNumberInput,
      };
    });
  };

  const handleAirLinesChange = (event: any, item: any) => {
    const isChecked = event.target.checked;
    const updatedSelectedFlights = isChecked
      ? [...selectedFlights, item]
      : selectedFlights.filter((flight: any) => flight !== item);

    setSelectedFlights(updatedSelectedFlights);
    setAllChecked(updatedSelectedFlights.length === filteredFlights.length);
    setAllSearchData((pre: any) => ({
      ...pre,
      airlines: updatedSelectedFlights,
    }));
  };

  const handleLayOverAirportChange = (event: any, item: any) => {
    let layOverFlight: any = [];
    if (event?.target?.checked) {
      layOverFlight = [...selectedLayOverAirport, item];
    } else {
      layOverFlight = selectedLayOverAirport?.filter(
        (flight: any) => flight?.cityName !== item?.cityName
      ) || [];
    }
    setSelectedLayOverAirport(layOverFlight);
    setAllSearchData((prev: any) => {
      return {
        ...prev,
        layoverAirports: layOverFlight,
      };
    });
  };

  useEffect(() => {
    let resultForMinimum: any = minimumTotalFare;
    let resultForMaximum: any = maximumTotalFare;
    const prevRange = prevRangeRef.current;

    let diffMaximumMinimumTotalFare =
      Number(maximumTotalFare) - Number(minimumTotalFare);
    let ratio = diffMaximumMinimumTotalFare / 100;
    if (prevRange[0] !== range[0]) {
      resultForMinimum = Number(minimumTotalFare) + ratio * range[0];
      setPriceRangeMin(resultForMinimum);
    } else {
      setPriceRangeMin(minimumTotalFare);
    }
    if (prevRange[1] !== range[1]) {
      resultForMaximum = maximumTotalFare - ratio * (100 - range[1]);
      setPriceRangeMax(resultForMaximum);
    }
    else {
      setPriceRangeMax(maximumTotalFare);
    }
    setAllSearchData({
      ...allSearchData,
      priceRange: [resultForMinimum, resultForMaximum],
    });
  }, [range]);

  const handleToggleAirports = () => {
    setShowAllAirportName(!showAllAirportName);
  };

  const toggleAccordion = (accordionId: any) => {
    setAccordionExpand((prevState: any) => ({
      ...prevState,
      [accordionId]: !prevState[accordionId],
    }));
  };

  const handleSelectAll = () => {
    const allSelected = !allChecked;
    setAllChecked(allSelected);
    setSelectedFlights(allSelected ? filteredFlights : []);
    setAllSearchData((pre: any) => ({
      ...pre,
      airlines: allSelected ? filteredFlights : [],
    }));
  };

  const selectAllLayOverAirport = () => {
    const allSelected = !allCheckedLayOverAirport;
    setAllCheckedLayOverAirport(allSelected);

    let allSelectedLayoverAirport: any = [];
    if (allSelected) {
      allSelectedLayoverAirport = displayLayOverAirport();
    }

    setSelectedLayOverAirport(allSelectedLayoverAirport);
    setAllSearchData((prev: any) => {
      return {
        ...prev,
        layoverAirports: allSelectedLayoverAirport,
      };
    });
  };

  const handleClearAll = () => {
    setSelectedFlights([]);
    setAllSearchData((prev: any) => ({
      ...prev,
      airlines: [],
    }));
  };
  const clearAllLayOverAirport = () => {
    setSelectedLayOverAirport([])
    setAllSearchData((prev: any) => {
      return {
        ...prev,
        layoverAirports: [],
      };
    });
  }
  const onClearAllFilter = () => {
    clearAllLayOverAirport();
    handleClearAll();
    setAllSearchData((prev: any) => {
      return {
        ...prev, // spread the previous state
        flightExperience: {
          ...prev?.overnight,
          overnight: false,
        },
      };
    });
    setAllSearchData({
      stop: {
        zeroStop: false,
        oneStop: false,
        twoStop: false,
      },
      airlines: [],
      flightExperience: {
        overnight: false,
        noLongStop: false,
      },
      farePolicy: {
        refundable: false,
        nonrefundable: false,
      },
      priceRange: [],
      flightNumber: '',
      flightTime: {
        onward: {
          departure: {
            sunset: false,
            morning: false,
            midnoon: false,
            night: false,
          },
          arrival: {
            sunset: false,
            morning: false,
            midnoon: false,
            night: false,
          },
        },
      }
    })
  }


  //show hide filter
  const [isFilter, setIsFilter] = useState(false)
  const showFilterBlock = () => {
    setIsFilter(true)
  }

  const hideFilterBlock = () => {
    setIsFilter(false)
  }



  return (
    <div className="col-lg-3">

<div id="filterFRMb" className="row show_mobile">
    <div className="col-12 mb-3">
      <button onClick={showFilterBlock}
      
      id="filterFRlink" className="btn btn-sm btn-outline-secondary" type="button"> 
        <small><i className="fa-solid fa-filter"></i> Filters</small></button>
    </div>
  </div>


<div className={isFilter ? '' : 'hide_mobile'}>


      <div className='filterLeft'>
        <div className='filterWrapper'>
          <div className="row d-lg-none align-items-center mb-3">
            <div className="col-6">
              <span className='filtertitle'>Filters</span>
            </div>
            <div className="col-6">
              <div className="col-12 text-end">
                <button onClick={hideFilterBlock}
                  id="filtercllink"
                  className="btn btn-lg cursor_pointer"
                  type="button"
                >
                  <small>
                    <i className="fa-solid fa-xmark"></i>
                  </small>
                </button>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-12">
              <div className='filterDarkBlock'>
                <div className='total_result text-center'>
                  <span>{allSearchItenary.length}</span> of{' '}
                  {filteredSearchItenary.length} flights
                </div>

                <div className='filcil'>
                  <div className="row">
                    <div className="col-5">
                      <a >Filter By</a>
                    </div>
                    <div className="col-2">|</div>
                    <div className="col-5">
                      <a onClick={onClearAllFilter} className='text-primary cursor_pointer' >Clear All</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className='borderedBlock'>
            <div className="row">
              <div className="col-12">
                <div className="accordion" id="accordionFilter">
                  <Accordion
                    accordionId={'accordion1'}
                    onClick={() => toggleAccordion('first')}
                    ariaExpanded={!accordionExpand.first}
                    accordionButton={'Stops'}
                    accordianText={
                      <div className="row">
                        <div className="col-lg-12 mb-3">
                          { NonStopMinimumFare &&
                            <div
                              className={classNames(
                                styles['stopcontainer'],
                                'd-inline float-start'
                              )}
                            >
                              <button 
                                className={classNames(
                                  styles['btn'],
                                  styles['btn-primary'],
                                  'me-2',
                                  {
                                    [styles['btn-active']]:
                                      allSearchData.stop.zeroStop,
                                  } // Apply "btn-active" style when zeroStop is true
                                )}
                              
                                value="nonStop"
                                onClick={OnNonStopMinimumFare}
                              >
                                NON STOP
                              </button>
                              <br />
                              <span>{NonStopMinimumFare?.toFixed(2)}</span>
                            </div>
                          }
                          { OneStopMinimumFare &&
                            <div
                              className={classNames(
                                styles['stopcontainer'],
                                'd-inline float-start'
                              )}
                            >
                              <button
                                className={classNames(
                                  styles['btn'],
                                  styles['btn-primary'],
                                  'me-2',
                                  {
                                    [styles['btn-active']]:
                                      allSearchData.stop.oneStop,
                                  }
                                )}
                              
                                value="oneStop"
                                onClick={OnOneStopMinimumFare}
                              >
                                1 STOP
                              </button>
                              <br />
                              <span>{OneStopMinimumFare?.toFixed(2)}</span>
                            </div>
                          }
                          { MultiStopMinimumFare &&
                            <div
                              className={classNames(
                                styles['stopcontainer'],
                                'd-inline float-start'
                              )}
                              
                            >
                              <button
                                className={classNames(
                                  styles['btn'],
                                  styles['btn-primary'],
                                  'me-2',
                                  {
                                    [styles['btn-active']]:
                                      allSearchData.stop.twoStop,
                                  } // Apply "btn-active" style when zeroStop is true
                                )}
                                value="multiStop"
                                onClick={OnMultuStopMinimumFare}
                              >
                                2+ STOP
                              </button>
                              <br />
                              <span>
                                {MultiStopMinimumFare ? MultiStopMinimumFare?.toFixed(2) : 0}
                              </span>
                            </div>
                          }
                        </div>
                      </div>
                    }
                  />

                  <Accordion
                    accordionId={'accordion2'}
                    ariaExpanded={!accordionExpand.second}
                    accordionButton={'Airlines'}
                    accordianText={
                      <div className="chk_filter_tbl">
                        <table className="table table-borderless">
                          <thead>
                            <tr>
                              <th>
                                <span className='subitle'
                               
                                  onClick={handleSelectAll}
                                >
                                  Select all
                                </span>
                              </th>
                              <th className="text-end">
                                <a className='text-primary cursor_pointer'
                                 
                                  onClick={handleClearAll}
                                >
                                  Clear all
                                </a>
                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            {filteredFlights
                              .slice(0, showAll ? filteredFlights.length : 5)
                              .map((item: any, index) => (
                                <tr key={index}>
                                  <td>
                                    <div className={styles['form-check']}>
                                      <input
                                        className={styles['form-check-input']}
                                        type="checkbox"
                                        value=""
                                        id={`AI-${index}`}
                                        defaultChecked={false}
                                        checked={selectedFlights.includes(item)}
                                        onChange={(event) =>
                                          handleAirLinesChange(event, item)
                                        }
                                      />
                                      <label
                                        className={styles['form-check-label']}
                                        htmlFor={`AI-${index}`}
                                      >
                                        {item?.name}
                                      </label>
                                    </div>
                                  </td>
                                  <td className="text-end">
                                    {item?.totalFare.toFixed(2)}
                                  </td>
                                </tr>
                              ))}
                            {filteredFlights.length > 5 && (
                              <tr>
                                <td colSpan={2} className="text-center">
                                  <div className='text-primary cursor_pointer'
                                  
                                    onClick={handleToggle}
                                  >
                                    {showAll ? 'Show less' : `  ${filteredFlights.length - 5} + more`}
                                  </div>
                                </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                    }
                  />

                  <Accordion
                    accordionId={'accordion3'}
                    ariaExpanded={!accordionExpand.third}
                    accordionButton={'Flight Experience'}
                    accordianText={
                      <div className="chk_filter_tbl">
                        <table className="table table-borderless">
                          <tbody>
                            <tr>
                              <Checkbox
                                isChecked={allSearchData.flightExperience.overnight}
                                label="No Overnight Flights"
                                id='overNight'
                                htmlFor='overNight'
                                onChange={handleOverngihtFlightChange}
                              />
                            </tr>
                            <tr>
                              <Checkbox
                                id='noLongStopOvers'
                                htmlFor='noLongStopOvers'
                                isChecked={allSearchData.flightExperience.noLongStop}
                                label="No long stop-overs (up to 4hrs)"
                                onChange={handleNoLongStopOverChange}
                              />
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    }
                  />

                  <Accordion
                    accordionId={'accordion4'}
                    ariaExpanded={!accordionExpand.fourth}
                    accordionButton={'Fare Policy'}
                    accordianText={
                      <div className="chk_filter_tbl">
                        <table className="table table-borderless">
                          <tbody>
                            <tr>
                              <Checkbox
                                isChecked={allSearchData.farePolicy.refundable}
                                id='refundable'
                                htmlFor='refundable'
                                label=" Refundable"
                                onChange={handleRefundableChange}
                              />
                            </tr>

                            <tr>
                              <Checkbox
                                isChecked={allSearchData?.farePolicy?.nonrefundable}
                                id='nonrefundable'
                                htmlFor='nonrefundable'
                                label="  Non Refundable"
                                onChange={handleNonRefundableChange}
                              />
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    }
                  />

                  <Accordion
                    accordionId={'accordion5'}
                    ariaExpanded={!accordionExpand.fifth}
                    accordionButton={'Price'}
                    accordianText={
                      <div className="price_slider mt-2">
                        <div
                          id="slider-range"
                          className="ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                        >
                          <div
                            className="ui-slider-range ui-corner-all ui-widget-header"
                            style={{ left: '15%', width: '45%' }}
                          ></div>
                          <span
                            className="ui-slider-handle ui-corner-all ui-state-default"
                            style={{ left: '15%' }}
                          ></span>
                          <span
                            className="ui-slider-handle ui-corner-all ui-state-default"
                            style={{ left: '60%' }}
                          ></span>
                        </div>

                        <div className="mt-2 mb-3">
                          <label htmlFor="amount"></label>
                          <input
                            type="text"
                            value=""
                            id="amount"
                            style={{ border: '0' }}
                          />
                          <RangeSlider range={range} setRange={setRange} />
                          <div className='row'>
                            <div className='col-6 text-start mt-2'> <small>{priceRangeMin?.toFixed(2)}</small> </div>
                            <div className='col-6 text-end mt-2'> <small> {priceRangeMax?.toFixed(2)}</small> </div>

                          </div>



                        </div>
                      </div>
                    }
                  />

                  <Accordion
                    accordionId={'accordion6'}
                    ariaExpanded={!accordionExpand.sixth}
                    accordionButton={'Flight Number'}
                    accordianText={
                      <div className="row">
                        <div className="col-12">
                          <div className="input-group mb-4 mt-2">
                            <input
                              type="text"
                              className="form-control"
                              placeholder="Search"
                              aria-describedby="button-addon"
                              id="byflightno"
                              value={flightNumberInput}
                              onChange={(e) => SearchFilterFunc(e)}
                            />

                            <button
                              className="btn btn-outline-secondary"
                              type="button"
                              id="button-addon"
                              onClick={flightNumberButtonfunc}
                            >
                              <span>
                                <IoSearchSharp />
                              </span>
                            </button>
                          </div>
                        </div>
                      </div>
                    }
                  />

                  <Accordion
                    accordionId={'accordion7'}
                    ariaExpanded={!accordionExpand.seventh}
                    accordionButton={'Layover Airports '}
                    accordianText={
                      <table className="table table-borderless">
                        <thead>
                          <tr>
                            <th>
                              <span className={styles['subitle']} onClick={selectAllLayOverAirport}>
                                Select all
                              </span>
                            </th>
                            <th className="text-end">
                              <a className='text-primary cursor_pointer' onClick={clearAllLayOverAirport}>
                                Clear all
                              </a>
                            </th>
                          </tr>
                        </thead>

                        <tbody>
                          {displayLayOverAirport().map(
                            (item: any, index: any) => (
                              <tr key={index}>
                                <td>
                                  <div className={styles['form-check']}>
                                    <input
                                      className={styles['form-check-input']}
                                      type="checkbox"
                                      value=""
                                      id={`AI-${index}`}
                                      checked={selectedLayOverAirport.some(
                                        (selectedItem: any) => {
                                          return selectedItem.cityName === item.cityName
                                        }
                                      )}
                                      onChange={(event: any) => handleLayOverAirportChange(event, item)}
                                    />

                                    <span>{item.cityName}</span>
                                  </div>
                                </td>
                                <td className="text-end">{item?.totalFare?.toFixed(2)}</td>
                              </tr>
                            )
                          )}

                          {(
                            <tr>
                              <td colSpan={2} className="text-center">
                                <div className='text-primary cursor_pointer'
                                
                                  onClick={handleToggle}
                                >
                                  {  getCityData([
                                      ...Itenaryfilter.zero,
                                      ...Itenaryfilter.one,
                                      ...Itenaryfilter.two,
                                    ]).length > 5 &&
                                  (showAll
                                    ? 'Show less'
                                    : `${getCityData([
                                      ...Itenaryfilter.zero,
                                      ...Itenaryfilter.one,
                                      ...Itenaryfilter.two,
                                    ]).length - 5
                                    }+ more`)}
                                </div>
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    }
                  />
                </div>{' '}
                {/* End of accordion */}
              </div>
            </div>
          </div>
        </div>
      </div>

      </div>

    </div>
  );
};

export default SearchFilter;
