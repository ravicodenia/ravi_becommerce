import styles from './bestprice.module.scss';
import React, { useEffect } from 'react';
import classNames from 'classnames';
import { useSelector } from 'react-redux';
import { useStore, RootState } from '@mfa-travel-app/store';

const BestPrice = ({ onSendDateObject }: any) => {
  const { searchPayload } = useSelector((state: RootState) => state.flight);
  const [dateDeparture, setDateDeparture] = React.useState(new Date());
  const [dateReturn, setDateReturn] = React.useState(new Date());

  useEffect(() => {
    if (searchPayload && searchPayload?.segments) {
      setDateDeparture(searchPayload?.segments[0]?.preferredDepartureTime);
      setDateReturn(searchPayload?.segments[1]?.preferredArrivalTime);
    }
  }, [searchPayload]);
  const changeDate = async (type: any, action: any) => {
    // Extracting dateStringDeparture and dateStringReturn arrays

    const dateStringDeparture =
      searchPayload &&
      searchPayload?.segments &&
      searchPayload?.segments[0]?.preferredDepartureTime;
    const dateStringReturn =
      searchPayload &&
      searchPayload?.segments &&
      searchPayload?.segments[1]?.preferredDepartureTime;
    // Creating new Date objects from dateStringDeparture and dateStringReturn
    let newDateDeparture = new Date(
      dateStringDeparture && dateStringDeparture.length > 0
        ? dateStringDeparture[0]
        : new Date()
    );
    let newDateReturn = new Date(
      dateStringReturn
        ? dateStringReturn[Number(searchPayload?.type) - 1]
        : new Date()
    );

    if (type === 1) {
      newDateDeparture = await new Promise<Date>((resolve) => {
        setDateDeparture((prevDate: any) => {
          const updatedDate = new Date(prevDate);
          updatedDate.setDate(
            updatedDate?.getDate() + (action === 'add' ? 1 : -1)
          );
          resolve(updatedDate);
          return updatedDate;
        });
      });
      await onSendDateObject(type, newDateDeparture);
    } else if (type === 2) {
      newDateReturn = await new Promise<Date>((resolve) => {
        setDateReturn((prevDate: any) => {
          const updatedDate = new Date(prevDate);
          updatedDate.setDate(
            updatedDate.getDate() + (action === 'add' ? 1 : -1)
          );
          resolve(updatedDate);
          return updatedDate;
        });
      });
      await onSendDateObject(type, newDateReturn);
    }
  };

  return (
    <div className="col-lg-4 hide_mobile">
      <div className="col-lg-12">
        <div style={{ height: '177px' }} className="borderedBlock">
          <div className={styles['findBestprice']}>
            <div className={styles['wrapper']}>
              <div className={styles['title']}>Find the best price</div>
              <div className="row align-items-center">
                <div className="col-4">
                  <button
                    className={classNames(
                      styles['btn'],
                      styles['btn_bordered']
                    )}
                    onClick={() => changeDate(1, 'remove')}
                  >
                    -1 Day
                  </button>
                </div>
                <div className="col-4 text-center">
                  <div className={styles['departure']}>Departure</div>
                  <div>
                    <small>{new Date(dateDeparture)?.toDateString()}</small>
                  </div>
                </div>
                <div className="col-4 text-end">
                  <button
                    className={classNames(
                      styles['btn'],
                      styles['btn_bordered']
                    )}
                    onClick={() => changeDate(1, 'add')}
                  >
                    +1 Day
                  </button>
                </div>
              </div>
            </div>

            {searchPayload?.type === 2 && (
              <>
                <div className="border-top">
                  <div className={styles['wrapper']}>
                    <div className="row">
                      <div className="col-4">
                        <button
                          className={classNames(
                            styles['btn'],
                            styles['btn_bordered']
                          )}
                          onClick={() => changeDate(2, 'remove')}
                        >
                          -1 Day
                        </button>
                      </div>
                      <div className="col-4 text-center">
                        <div className={styles['departure']}>Return</div>
                        <div>
                          <small>{new Date(dateReturn)?.toDateString()}</small>
                        </div>
                      </div>
                      <div className="col-4 text-end">
                        <button
                          className={classNames(
                            styles['btn'],
                            styles['btn_bordered']
                          )}
                          onClick={() => changeDate(2, 'add')}
                        >
                          +1 Day
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BestPrice;
