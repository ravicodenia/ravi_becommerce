import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { findAirlineLogo } from '@mfa-travel-app/shared';

const AirticketSlider = ({ filtersearchData ,onFilterSearchData}: any) => {
    const settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 6,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 3000,
    };
    const uniqueByFareAndAirline = (arr: any) => {
        const seen = new Set();
        return arr.filter((item: any) => {
            const key = `${item.totalFare}-${item.airline}`;
            if (seen.has(key)) {
                return false;
            }
            seen.add(key);
            return true;
        });
    }

    return (
        <>
            <div className="borderedBlock hide_mobile">
                <div className="row">
                    <div className="col-2">
                        <table className="tblfareslider">
                            <tbody>
                                <tr key='logo'>
                                    <td className="airlinelogo"></td>
                                </tr>
                                <tr key='non-stop'>
                                    <td>Non-Stop</td>
                                </tr>
                                <tr key='stop1'>
                                    <td>1 Stop</td>
                                </tr>
                                <tr key='stop2'>
                                    <td>2 Stop</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div className="col-10">
                        <Slider {...settings}>
                            {
                                uniqueByFareAndAirline([...filtersearchData?.zero, ...filtersearchData?.one, ...filtersearchData?.two]).map((item: any, index: any) => (
                                    <table className="tblfareslider" onClick={() => onFilterSearchData(item)}>
                                        <tbody>
                                            <tr className="text-center">
                                                <td className="airlinelogo">
                                                    <div> {item?.airline && <img
                                                        src={findAirlineLogo(item?.airline)}
                                                        alt={item?.airline}
                                                        style={{ margin: 'auto' }}

                                                    />}</div>
                                                    <div className="textTrimAirlinename"> {item?.name}</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>{item.stop == 0 ? item?.totalFare.toFixed(2) : '--'}</td>
                                            </tr>
                                            <tr>
                                                <td>{item.stop == 1 ? item?.totalFare.toFixed(2) : '--'}</td>
                                            </tr>
                                            <tr>
                                                <td>{item.stop > 1 ? item?.totalFare.toFixed(2) : '--'}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                )
                                )}
                        </Slider>
                    </div>
                </div>
            </div>
        </>
    );
}

export default AirticketSlider;
