import { useState } from 'react';

export default function PaymentControl() {


    const [trCash, setTRCash] = useState(false);
    const [trBank, setTRBank] = useState(false);
    const [trCredit, setTRCredit] = useState(false);
    const [trPos, setTRPos] = useState(false);
    const [trRemark, setTrRemark] = useState(false);
    const [trBalance, setTrBalance] = useState(false);
    const [trOnAccount, setTrOnAccount] = useState(true);


    const handleTrCash = () => {
        setTRCash(!trCash);
        setTrRemark(!trRemark);
        setTrBalance(!trBalance);
        setTrOnAccount(!trOnAccount);
      };
    
      const handleTrBank = () => {
        setTRBank(!trBank);
        setTrRemark(!trRemark);
        setTrBalance(!trBalance);
        setTrOnAccount(!trOnAccount);
      };
    
      const handleTrCredit = () => {
        setTRCredit(!trCredit);
        setTrRemark(!trRemark);
        setTrBalance(!trBalance);
        setTrOnAccount(!trOnAccount);
      };
    
      const handleTrPos = () => {
        setTRPos(!trPos);
        setTrRemark(!trRemark);
        setTrBalance(!trBalance);
        setTrOnAccount(!trOnAccount);
      };


  return (
    

<>
<div className="row">
                        <div className="col-12 mt-4 mb-4">
                          <div className="chkFlightPayCon mb-4">
                            <label
                              className="chkpleft me-3"
                              htmlFor="onAccount"
                            >
                              <div className="input-group">
                                <div className="input-group-prepend">
                                  <span className="iconholder mt-2">
                                    <i className="fa-regular fa-user"></i>
                                  </span>
                                </div>
                                <span className="title">On Account </span>
                              </div>
                              <input
                                type="checkbox"
                                id="onAccount"
                                name="onAccount"
                                checked
                                disabled
                              />
                              <span className="checkmark"></span>
                            </label>

                            <label
                              className="chkpleft me-3"
                              htmlFor="paybycash"
                            >
                              <div className="input-group">
                                <div className="input-group-prepend">
                                  <span className="iconholder mt-2">
                                    <i className="fa-solid fa-dollar-sign"></i>
                                  </span>
                                </div>
                                <span className="title">Pay By Cash</span>
                              </div>
                              <input
                                type="checkbox"
                                id="paybycash"
                                name="paybycash"
                                onChange={handleTrCash}
                              />
                              <span className="checkmark"></span>
                            </label>

                            <label
                              className="chkpleft me-3"
                              htmlFor="banktransfer"
                            >
                              <div className="input-group">
                                <div className="input-group-prepend">
                                  <span className="iconholder mt-2">
                                    <i className="fa-solid fa-dollar-sign"></i>
                                  </span>
                                </div>
                                <span className="title">Bank Transfer</span>
                              </div>
                              <input
                                type="checkbox"
                                id="banktransfer"
                                name="banktransfer"
                                onChange={handleTrBank}
                              />
                              <span className="checkmark"></span>
                            </label>

                            <label
                              className="chkpleft me-3"
                              htmlFor="paybycredit"
                            >
                              <div className="input-group">
                                <div className="input-group-prepend">
                                  <span className="iconholder mt-2">
                                    <i className="fa-solid fa-dollar-sign"></i>
                                  </span>
                                </div>
                                <span className="title">Credit</span>
                              </div>
                              <input
                                type="checkbox"
                                id="paybycredit"
                                name="paybycredit"
                                onChange={handleTrCredit}
                              />
                              <span className="checkmark"></span>
                            </label>

                            <label className="chkpleft me-3" htmlFor="ccpos">
                              <div className="input-group">
                                <div className="input-group-prepend">
                                  <span className="iconholder mt-2">
                                    <i className="fa-solid fa-dollar-sign"></i>
                                  </span>
                                </div>
                                <span className="title">CC POS</span>
                              </div>
                              <input
                                type="checkbox"
                                id="ccpos"
                                name="ccpos"
                                onChange={handleTrPos}
                              />
                              <span className="checkmark"></span>
                            </label>

                            <label className="chkpleft" htmlFor="paybycard">
                              <div className="input-group">
                                <div className="input-group-prepend">
                                  <span className="iconholder mt-2">
                                    <i className="fa-solid fa-credit-card"></i>
                                  </span>
                                </div>
                                <span className="title">Pay By Card</span>
                              </div>
                              <input type="checkbox" id="paybycard" />
                              <span className="checkmark"></span>
                            </label>
                          </div>

                          <div className="col-12">
                            <div className="flightPayTbl">
                              <table className="table table-bordered mb-0">
                                <tbody>
                                  {trCash && (
                                    <tr id="tr_Cash">
                                      <td className="align-middle">Cash</td>
                                      <td>
                                        <div className="row">
                                          <div className="col-lg-3">
                                            <div className="input-group">
                                              <div className="input-group-append me-2">
                                                <small className="color-muted">
                                                  USD{' '}
                                                </small>
                                              </div>

                                              <input
                                                type="text"
                                                className="form-control"
                                                value="320"
                                              />
                                            </div>
                                          </div>
                                        </div>
                                      </td>
                                    </tr>
                                  )}

                                  {trBank && (
                                    <tr id="tr_bankTransfer">
                                      <td className="align-middle">
                                        Bank Transfer
                                      </td>
                                      <td>
                                        <div className="row">
                                          <div className="col-lg-3">
                                            <div className="input-group">
                                              <div className="input-group-append me-2">
                                                <small className="color-muted">
                                                  USD{' '}
                                                </small>
                                              </div>

                                              <input
                                                type="text"
                                                className="form-control"
                                                value="320"
                                              />
                                            </div>
                                          </div>

                                          <div className="col-lg-4">
                                            <div className="group_input_flight_pc">
                                              <div className="input-group">
                                                <div className="input-group-prepend p-0">
                                                  <span className="input-group-text">
                                                    Ref. No.
                                                  </span>
                                                </div>
                                                <input
                                                  type="text"
                                                  className="form-control"
                                                />
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </td>
                                    </tr>
                                  )}

                                  {trPos && (
                                    <tr id="tr_CCPOS">
                                      <td className="align-middle">CC POS</td>
                                      <td>
                                        <div className="row">
                                          <div className="col-lg-3">
                                            <div className="input-group">
                                              <div className="input-group-append me-2">
                                                <small className="color-muted">
                                                  USD{' '}
                                                </small>
                                              </div>

                                              <input
                                                type="text"
                                                className="form-control"
                                                value="320"
                                              />
                                            </div>
                                          </div>

                                          <div className="col-lg-3">
                                            <div className="group_input_flight_pc">
                                              <div className="input-group">
                                                <select className="form-select">
                                                  <option value="">
                                                    Card Type
                                                  </option>
                                                  <option value="">---</option>
                                                  <option value="">---</option>
                                                </select>
                                              </div>
                                            </div>
                                          </div>

                                          <div className="col-lg-6">
                                            <div className="group_input_flight_pc">
                                              <div className="input-group">
                                                <div className="input-group-prepend p-0">
                                                  <span className="input-group-text">
                                                    Card No.
                                                  </span>
                                                </div>
                                                <input
                                                  type="text"
                                                  className="form-control"
                                                />
                                              </div>
                                            </div>
                                          </div>

                                          <div className="col-lg-6">
                                            <div className="group_input_flight_pc">
                                              <div className="input-group mt-2">
                                                <div className="input-group-prepend p-0">
                                                  <span className="input-group-text">
                                                    Auth Code
                                                  </span>
                                                </div>
                                                <input
                                                  type="text"
                                                  className="form-control"
                                                />
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </td>
                                    </tr>
                                  )}

                                  {trCredit && (
                                    <tr id="tr_Credit">
                                      <td className="align-middle">Credit</td>
                                      <td>
                                        <div className="row">
                                          <div className="col-lg-3">
                                            <div className="input-group">
                                              <div className="input-group-append me-2">
                                                <small className="color-muted">
                                                  USD{' '}
                                                </small>
                                              </div>

                                              <input
                                                type="text"
                                                className="form-control"
                                                value="320"
                                              />
                                            </div>
                                          </div>

                                          <div className="col-lg-3">
                                            <div className="input-group">
                                              <select className="form-select">
                                                <option value="">
                                                  Customer
                                                </option>
                                                <option value="">---</option>
                                                <option value="">---</option>
                                              </select>
                                            </div>
                                          </div>
                                        </div>
                                      </td>
                                    </tr>
                                  )}

                                  {trRemark && (
                                    <tr id="remarks_TRN">
                                      <td className="align-middle"></td>
                                      <td>
                                        <div className="row">
                                          <div className="col-lg-6">
                                            <div className="group_input_flight_pc">
                                              <div className="input-group">
                                                <div className="input-group-prepend p-0">
                                                  <span className="input-group-text">
                                                    TRN No.
                                                  </span>
                                                </div>
                                                <input
                                                  type="text"
                                                  className="form-control"
                                                />
                                              </div>
                                            </div>
                                          </div>

                                          <div className="col-lg-6">
                                            <div className="group_input_flight_pc">
                                              <div className="input-group">
                                                <div className="input-group-prepend p-0">
                                                  <span className="input-group-text">
                                                    Remarks
                                                  </span>
                                                </div>
                                                <input
                                                  type="text"
                                                  className="form-control"
                                                />
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </td>
                                    </tr>
                                  )}

                                  {trBalance && (
                                    <tr id="TrBalance2">
                                      <td className="align-middle">Balance</td>
                                      <td>
                                        <small className="color-muted">
                                          USD{' '}
                                        </small>{' '}
                                        <strong>0.00</strong>
                                      </td>
                                    </tr>
                                  )}
                                </tbody>
                              </table>

                              {trOnAccount && (
                                <table className="table table-bordered mb-0">
                                  <tbody>
                                    <tr>
                                      <td className="align-middle">
                                        Available Balance
                                      </td>
                                      <td>
                                        <small className="color-muted">
                                          USD{' '}
                                        </small>{' '}
                                        <strong>9890</strong>
                                      </td>
                                    </tr>

                                    <tr>
                                      <td className="align-middle">
                                        Order Amount
                                      </td>
                                      <td>
                                        <small className="color-muted">
                                          USD{' '}
                                        </small>{' '}
                                        <strong>20</strong>
                                      </td>
                                    </tr>

                                    <tr>
                                      <td className="align-middle">
                                        Remaining Balance
                                      </td>
                                      <td>
                                        <small className="color-muted">
                                          USD{' '}
                                        </small>{' '}
                                        <strong>9910</strong>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>

</>


  )
}
