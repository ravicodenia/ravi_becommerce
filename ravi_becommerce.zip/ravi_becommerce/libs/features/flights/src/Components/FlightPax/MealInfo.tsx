import { ListBox, CustomInputMuted } from '@mfa-travel-app/ui';
import { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { getFlightMealsDetails } from '../../lib/service/flightApi';
import { RootState } from '@mfa-travel-app/store';
import { useStore } from '@mfa-travel-app/store';
import { Loader } from '@mfa-travel-app/ui';

export default function MealInfo({ data, onChange }: any) {
  const { selectedItinerary, mealsList, passengerList } = useSelector(
    (state: RootState) => state.flight
  );
  const { saveMealsListDetails, savePassengerDetails } = useStore();

  const [loader, setLoader] = useState(false);
  const [selectedMealInfo, setSelectedMealInfo] = useState<any>({});
  const [mealOptions, setMealOptions] = useState<any>({});

  useEffect(() => {
    if (selectedItinerary) {
      if (typeof mealsList == 'object' && mealsList?.length == 0) {
        getMealInfo();
      } else if (typeof mealsList == 'object' && mealsList?.length !== 0) {
        let mealsData: any = {};
        mealsList?.forEach((meal: any) => {
          const key = meal.mealCode;
          mealsData[key] = meal;
        });
        saveMealsListDetails(Object.values(mealsData));
        if (selectedItinerary?.flights?.length === 1) {
          setMealOptions({ onwardMealOptions: Object.values(mealsData) });
          // setSelectedMealInfo({ onwardMeal: Object.values(mealsData)[0]});
          if (data?.onwardMeal !== null) {
            setSelectedMealInfo({ onwardMeal: data?.onwardMeal });
          } else {
            setSelectedMealInfo({ onwardMeal: { mealCharge: 0 } });
          }
        } else {
          // const onwardMealOptions = meals?.filter(
          //   (meal: any) =>
          //     meal?.segmentId == selectedItinerary?.flights[0][0]?.fareInfoKey
          // );
          // const returnMealOptions = meals?.filter(
          //   (meal: any) =>
          //     meal?.segmentId == selectedItinerary?.flights[1][0]?.fareInfoKey
          // );
          const mealOptionsObj = {
            onwardMealOptions: Object.values(mealsData),
            returnMealOptions: Object.values(mealsData),
          };
          setMealOptions(mealOptionsObj);
          // setSelectedMealInfo({
          //   onwardMeal: mealOptionsObj?.onwardMealOptions[0],
          //   returnMeal: mealOptionsObj?.returnMealOptions[0],
          // });
          if (data?.onwardMeal !== null && data?.returnMeal !== null) {
            setSelectedMealInfo({
              onwardMeal: data?.onwardMeal,
              returnMeal: data?.returnMeal,
            });
          } else {
            setSelectedMealInfo({
              onwardMeal: { mealCharge: 0 },
              returnMeal: { mealCharge: 0 },
            });
          }
        }
      }
    }
  }, [selectedItinerary]);

  const getMealInfo = async () => {
    setLoader(true);
    const response: any = await getFlightMealsDetails(
      selectedItinerary?.sessionId,
      selectedItinerary?.flightGuId
    );
    setLoader(false);
    if (response?.status == 200) {
      if (response?.data?.length == 0) {
        saveMealsListDetails('No meal options available');
      } else {
        let mealsData: any = {};
        response?.data?.forEach((meal: any) => {
          const key = meal.mealCode;
          mealsData[key] = meal;
        });
        saveMealsListDetails(Object.values(mealsData));
        if (selectedItinerary?.flights?.length === 1) {
          setMealOptions({ onwardMealOptions: Object.values(mealsData) });
          // setSelectedMealInfo({ onwardMeal: Object.values(mealsData)[0]});
          setSelectedMealInfo({ onwardMeal: { mealCharge: 0 } });
        } else {
          // const onwardMealOptions = meals?.filter(
          //   (meal: any) =>
          //     meal?.segmentId == selectedItinerary?.flights[0][0]?.fareInfoKey
          // );
          // const returnMealOptions = meals?.filter(
          //   (meal: any) =>
          //     meal?.segmentId == selectedItinerary?.flights[1][0]?.fareInfoKey
          // );
          const mealOptionsObj = {
            onwardMealOptions: Object.values(mealsData),
            returnMealOptions: Object.values(mealsData),
          };
          setMealOptions(mealOptionsObj);
          // setSelectedMealInfo({
          //   onwardMeal: mealOptionsObj?.onwardMealOptions[0],
          //   returnMeal: mealOptionsObj?.returnMealOptions[0],
          // });
          setSelectedMealInfo({
            onwardMeal: { mealCharge: 0 },
            returnMeal: { mealCharge: 0 },
          });
        }
      }
    }
  };

  const handleSelectChange = (e: any) => {
    const { name, value } = e.target;
    let updatedMealInfo;
    if (name == 'onwardMeal') {
      const selectedMealOption = mealOptions?.onwardMealOptions?.filter(
        (option: any) => option?.mealCode === value
      )[0];
      updatedMealInfo = {
        ...selectedMealInfo,
        onwardMeal: selectedMealOption,
      };
      setSelectedMealInfo(updatedMealInfo);
    } else {
      const selectedMealOption = mealOptions?.returnMealOptions?.filter(
        (option: any) => option?.mealCode === value
      )[0];
      updatedMealInfo = {
        ...selectedMealInfo,
        returnMeal: selectedMealOption,
      };
      setSelectedMealInfo(updatedMealInfo);
    }
    onChange(updatedMealInfo);
  };

  return (
    <>
      <div className="border p-2 bg-light">
        <div className="row">
          <div className="col-lg-12">
            <i className="fa-solid fa-caret-down"></i> Meal Information
          </div>
          <div className="col-lg-6">
            <div className="mb-2 row">
              <div className="col-sm-8 d-flex align-items-center w-100">
                {mealOptions?.onwardMealOptions ?
                <>
                 <label className="col-sm-4 col-form-label">Onward Meal:</label>
                  <div className="row align-items-center">
                    <div className="col-8">
                      {' '}
                      <ListBox
                        name="onwardMeal"
                        id="onward-meal"
                        defaultValue={
                          selectedMealInfo?.onwardMeal?.mealCode ? selectedMealInfo?.onwardMeal?.mealCode : ''
                        }
                        options={mealOptions?.onwardMealOptions?.map(
                          (option: any) => ({
                            label: `${option?.mealCode} - ${option?.mealDescription}`,
                            value: option?.mealCode,
                          })
                        )}
                        handleChange={(e) => handleSelectChange(e)}
                      />

                    </div>
                    <div className="col-4">
                      <CustomInputMuted
                        id="onward-inp"
                        value={`${selectedMealInfo?.onwardMeal?.currencyCode} ${selectedMealInfo?.onwardMeal?.mealCharge
                          ? selectedMealInfo?.onwardMeal?.mealCharge
                          : 0
                          }`}
                      />
                    </div>
                  </div>
                  </>
                  : (
                    // <span>No meal options available</span>
                    ''
                  )}
              </div>
            </div>
          </div>

          <div className="col-lg-6">
            <div className="mb-2 row">
              <div className="col-sm-8 d-flex align-items-center">
                {mealOptions?.returnMealOptions ?
                <>
                 <label className="col-sm-4 col-form-label">Return Meal:</label>
                  <div className="row align-items-center">
                    <div className="col-8">
                      {' '}

                      <ListBox
                        name="returnMeal"
                        id="return-meal"
                        defaultValue={
                         selectedMealInfo?.returnMeal?.mealCode ? selectedMealInfo?.returnMeal?.mealCode : ''
                        }
                        options={mealOptions?.returnMealOptions?.map(
                          (option: any) => ({
                            label: `${option?.mealCode} - ${option?.mealDescription}`,
                            value: option?.mealCode
                          })
                        )}
                        handleChange={(e) => handleSelectChange(e)}
                      />
                    </div>
                    <div className="col-4">
                      <CustomInputMuted
                        id="return-inp"
                        value={`${selectedMealInfo?.returnMeal?.currencyCode} ${selectedMealInfo?.returnMeal?.mealCharge
                          ? selectedMealInfo?.returnMeal?.mealCharge
                          : 0
                          }`}
                      />
                    </div>
                  </div>
                  </>
                  : (
                    // <span>No meal options available</span>
                    ''
                  )}
              </div>
            </div>
          </div>
        </div>
      </div>
      {loader && <Loader />}
    </>
  );
}
