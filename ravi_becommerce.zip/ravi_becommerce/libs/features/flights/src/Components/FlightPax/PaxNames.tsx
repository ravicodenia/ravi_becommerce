export default function PaxNames({ pax }: any) {
  return (
    <>
      <table className="table tbl_pax_payment">
        <thead>
          <tr>
            <th scope="col">Sl</th>
            <th scope="col">Passenger Names </th>
            <th scope="col">Type</th>
            <th scope="col"></th>
          </tr>
        </thead>
        <tbody>
          {pax?.map((passenger: any, index:any) => (
            <tr key={index}>
              <td>{index + 1}</td>
              <td>{passenger?.paxInfo?.title === '01' ? 'Mr.' : 'Mrs.'} {passenger?.paxInfo?.firstName} {passenger?.paxInfo?.lastName}</td>
              <td>{passenger?.type === 1 ? 'Adult' : passenger?.type === 2 ? 'Child' : 'Infant'}</td>
              <td>
                {' '}
                <a href="#">
                  {' '}
                  <i className="fa-regular fa-pen-to-square"></i>{' '}
                </a>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
