import { CustomInput1, ListBox } from '@mfa-travel-app/ui';
import { useState } from 'react';
import { days, months, dobyears } from '@mfa-travel-app/assets';

export default function AdultPax({data, onChange}:any) {
  const [showFF, setshowFF] = useState(false);
  const [showReward, setshowReward] = useState(false);
  const [paxData, setPaxData] = useState(data);

  const handleSelectChange = (e: any) => {
    const { name, value } = e.target;
    const updatedPaxData = { ...paxData, [name]: value }
    setPaxData(updatedPaxData);
    onChange(updatedPaxData)
  };

  const handleInputChange = (e: any) => {
    const { name, value } = e.target;
    const updatedPaxData = { ...paxData, [name]: value }
    setPaxData(updatedPaxData);
    onChange(updatedPaxData)
  };

  const toggleFFandReward = (button:string) => {
    if (button == 'FF') {
      setshowFF(!showFF)
    } else {
      setshowReward(!showReward)
    }
  }

  return (
    <>
      <div className="row">
        <div className="col-lg-2">
          <div className="mb-2 row">
            <label className="col-sm-4 col-form-label">
              Title:<i className="text-danger">*</i>
            </label>
            <div className="col-sm-8">
              <ListBox
                name="title"
                id="Title"
                defaultValue={paxData?.title}
                options={[
                  { label: 'Mr.', value: '01' },
                  { label: 'Mrs.', value: '02' },
                ]}
                handleChange={(e) => handleSelectChange(e)}
              />
            </div>
          </div>
        </div>

        <div className="col-lg-5">
          <div className="mb-2 row">
            <label className="col-sm-4 col-form-label">
              {' '}
              First Name:<i className="text-danger">*</i>
            </label>
            <div className="col-sm-8">
              <CustomInput1
                id="firstname"
                placeholder="First Name"
                name="firstName"
                value={paxData?.firstName}
                handleChange={(e) => handleInputChange(e)}
              />
            </div>
          </div>
        </div>

        <div className="col-lg-5">
          <div className="mb-2 row">
            <label className="col-sm-4 col-form-label">
              Last Name:<i className="text-danger">*</i>
            </label>
            <div className="col-sm-8">
              <CustomInput1
                id="lastname"
                placeholder="Last Name"
                name="lastName"
                value={paxData?.lastName}
                handleChange={(e) => handleInputChange(e)}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="row">
        <div className="col-lg-3">
          <div className="mb-2 row">
            <label className="col-sm-4 col-form-label">
              Gender:<i className="text-danger">*</i>
            </label>
            <div className="col-sm-8">
              <ListBox
                name="gender"
                id="gender"
                defaultValue={paxData?.gender}
                options={[
                  { label: 'Male', value: '01' },
                  { label: 'Female', value: '02' },
                ]}
                handleChange={(e) => handleSelectChange(e)}
              />
            </div>
          </div>
        </div>

        <div className="col-lg-5">
          <div className="mb-2 row">
            <label className="col-sm-4 col-md-3 col-form-label">
              {' '}
              DOB:<i className="text-danger">*</i>
            </label>
            <div className="col-sm-8 col-md-9">
              <div className="d-flex">
                <div className="flex-fill me-2">
                  <ListBox
                    name="dobdate"
                    id="dobdate"
                    defaultValue={paxData?.dobdate}
                    options={days}
                    handleChange={(e) => handleSelectChange(e)}
                  />{' '}
                </div>
                <div className="flex-fill me-2">
                  {' '}
                  <ListBox
                    name="dobmonth"
                    id="dobmonth"
                    defaultValue={paxData?.dobmonth}
                    options={months}
                    handleChange={(e) => handleSelectChange(e)}
                  />{' '}
                </div>
                <div className="flex-fill">
                  {' '}
                  <ListBox
                    name="dobyear"
                    id="dobyear"
                    defaultValue={paxData?.dobyear}
                    options={dobyears}
                    handleChange={(e) => handleSelectChange(e)}
                  />{' '}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="col-lg-4 text-end">
          <button
            type="button"
            onClick={() => toggleFFandReward('FF')}
            className="btn btn-sm text-primary"
          >
            <i className="fa-solid fa-plus"></i> Add FF
          </button>

          <button
            type="button"
            onClick={() => toggleFFandReward('RewardNo')}
            className="btn btn-sm text-primary"
          >
            <i className="fa-solid fa-plus"></i> Add Reward No.
          </button>
        </div>

        <div
          style={{ display: 'none' }}
          className={`col-lg-6 animate slideInDown ${showFF ? 'd-block' : ''}`}
        >
          <div className="input-group mb-3 align-items-center">
            <div className="input-group-prepend me-2">Add FF:</div>
            <CustomInput1
              id="maxinpt"
              placeholder="Max |"
              name="maxinp1"
              disabled={true}
              value={paxData?.maxinp1}
              handleChange={(e) => handleInputChange(e)}
            />
            <div className="input-group-append ms-2">
              <CustomInput1
                id="maxinpt2"
                placeholder="Max Lenghth 10"
                name="maxinp2"
                value={paxData?.maxinp2}
                handleChange={(e) => handleInputChange(e)}
              />
            </div>
          </div>
        </div>

        <div
          style={{ display: 'none' }}
          className={`col-lg-6 animate slideInDown ${
            showReward ? 'd-block' : ''
          }`}
        >
          <div className="input-group mb-3 align-items-center">
            <div className="input-group-prepend me-2">Add Reward No:</div>
            <CustomInput1
              id="addrewardinp"
              placeholder="Max Lenghth 100"
              name="addrewardinp"
              value={paxData?.addrewardinp}
              handleChange={(e) => handleInputChange(e)}
            />
          </div>
        </div>
      </div>
    </>
  );
}
