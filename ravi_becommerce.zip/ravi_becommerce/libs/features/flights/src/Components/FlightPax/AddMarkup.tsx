import { RootState } from '@mfa-travel-app/store';
import { RadioInput, CustomInput1 } from '@mfa-travel-app/ui';
import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';

export default function AddMarkup({ totalFare, onChange }: any) {
  const [markupType, setMarkupType] = useState('');
  const [markupValue, setMarkupValue] = useState('');
  const [markupUnit, setMarkupUnit] = useState('');
  const { selectedItinerary } = useSelector((state: RootState) => state.flight);

  useEffect(() => {
    if (markupValue == '' && markupType != '' && markupUnit != '') {
      calculateMarkup();
      return;
    } else if (markupType === '' || markupUnit === '' || markupValue === '') {
      return;
    } else {
      calculateMarkup();
    }
  }, [markupType, markupValue, markupUnit]);

  const checkedLabel = (e: any) => {
    const selectedLabel = e.target.name;
    if (selectedLabel !== markupType) {
      setMarkupType(selectedLabel);
    }
  };

  const checkedUnit = (e: any) => {
    const selectedUnit = e.target.name;
    if (selectedUnit !== markupUnit) {
      setMarkupUnit(selectedUnit);
    }
  };

  const markupInput = (e: any) => {
    setMarkupValue(e.target.value);
  };

  // handlingFeeValue + markup - discount

  const calculateMarkup = () => {
    if (markupValue == '') {
      onChange({
        markupType: markupType,
        markupValue: Number(markupValue),
        markupUnit: markupUnit,
      });
      return;
    } else if (markupUnit === 'F') {
      onChange({
        markupType: markupType,
        markupValue: Number(markupValue),
        markupUnit: markupUnit,
      });
      return;
    } else {
      let value;
      if (markupType === 'BF') {
        value = ((Number(markupValue) / 100) * totalFare).toFixed(2);
      } else {
        let totalTax = 0;
        selectedItinerary?.fareBreakdown?.forEach((pax: any) => {
          totalTax = totalTax + pax?.tax;
        });
        value = ((Number(markupValue) / 100) * totalTax).toFixed(2);
      }
      onChange({
        markupType: markupType,
        markupValue: value,
        markupUnit: markupUnit,
      });
    }
  };

  return (
    <>
      <div className="markup">
        <div className="row">
          <div className="col-12">
            <div className="input-group">
              <div className="input-group-prepend me-2">Add Markup on</div>
              <div className="form-check-inline me-3">
                <RadioInput
                  onClick={(e) => checkedLabel(e)}
                  id="fare"
                  name="BF"
                  checked={markupType === 'BF'}
                />
                <label htmlFor="fare">Fare</label>
              </div>
              <div className="form-check-inline">
                <RadioInput
                  onClick={(e) => checkedLabel(e)}
                  id="tax"
                  name="TF"
                  checked={markupType === 'TF'}
                />
                <label htmlFor="tax">Tax</label>
              </div>
            </div>
          </div>
          <div className="col-12">
            <div className="input-group mt-3 align-items-center">
              <div className="form-check-inline">
                <div className="d-flex align-items-center">
                  <div className="me-2">
                    <label htmlFor="valueinnum">Value</label>
                  </div>
                  <div style={{ width: '100px' }}>
                    <CustomInput1
                      id="valueinnum"
                      placeholder=""
                      value={markupValue}
                      handleChange={(e) => markupInput(e)}
                    />
                  </div>
                </div>
              </div>
              <div className="form-check-inline">
                <RadioInput
                  onClick={(e) => checkedUnit(e)}
                  id="valueper"
                  name="P"
                  checked={markupUnit === 'P'}
                />
                <label htmlFor="valueper">%</label>
              </div>
              <div className="form-check-inline">
                <RadioInput
                  onClick={(e) => checkedUnit(e)}
                  id="valueamo"
                  name="F"
                  checked={markupUnit === 'F'}
                />
                <label htmlFor="valueamo">Amount</label>
              </div>
            </div>
          </div>
          <div className="col-12 mt-2 text-end">
            <button
              type="button"
              className="btn btn-primary"
              onClick={() => calculateMarkup()}
            >
              APPLY
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
