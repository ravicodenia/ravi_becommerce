import { useState } from 'react';
import { Modal } from 'react-bootstrap';
import Baggage from '../../lib/pages/baggage';

export default function BaggagePolicyPopup({ itinerary }: any) {
  const [baggageModal, setBaggageModal] = useState(false);

  return (
    <>
      <div className="btnflbag">
        <button
          onClick={() => setBaggageModal(true)}
          className="btn btn-secondary w-100"
        >
          BAGGAGE POLICY
        </button>
      </div>

      <Modal
        size="lg"
        centered
        show={baggageModal}
        onHide={() => setBaggageModal(false)}
      >
        <Modal.Header closeButton>
          <Modal.Title>Baggage Policy </Modal.Title>
        </Modal.Header>
        {/* <div className="row">
            <div className="col-12">
              <table className="table">
                <thead>
                  <tr>
                    <th>Sector / Flight</th>
                    <th>Checkin Baggage</th>
                    <th>Hand Baggage</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>DXB to DELHI</td>
                    <td>DEL to BOMBAY</td>
                    <td>BOM to DXB</td>
                  </tr>
                  <tr>
                    <td>30 Kgs - 1 Piece</td>
                    <td>30 Kgs - 1 Piece</td>
                    <td>30 Kgs - 1 Piece</td>
                  </tr>
                  <tr>
                    <td>7 Kgs</td>
                    <td>7 Kgs</td>
                    <td>7 Kgs</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div> */}
        <Baggage itinerary={itinerary} />
      </Modal>
    </>
  );
}
