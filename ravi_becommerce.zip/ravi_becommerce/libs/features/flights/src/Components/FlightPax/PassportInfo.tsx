import { CustomInput1, ListBox } from '@mfa-travel-app/ui';
import { useEffect, useState } from 'react';
import { days, months, passptExpYears } from '@mfa-travel-app/assets';
import { getNationalities, getCountries } from '../../lib/service/homeApi';
import { useSelector } from 'react-redux';
import { RootState, useStore } from '@mfa-travel-app/store';
import { Loader } from '@mfa-travel-app/ui';

export default function PassportInfo({data, onChange}:any) {
  const [passportInfo, setPassportInfo] = useState(data);
  const [countryList, setCountryList] = useState<any>([])
  const [nationalitiesList, setNationalitiesList] = useState<any>([])
  const [loader, setLoader] = useState(false)

  const { saveNationalitiesDetails, saveCountriesDetails } = useStore()

  useEffect(() => {
    getCountriesList()
    // getNationalitiesList()
  }, [])

  const getCountriesList = async () => {
    setLoader(true);
    setLoader(true)
    const response: any = await getCountries();
    // const response:any = await getNationalities()
    setLoader(false);
    if (response?.status == 200) {
      const countries = response?.data?.map((country: any) => {
        return {
          label: country?.text,
          value: country?.value,
        };
      });
      const nationalities = response?.data?.map((nationality:any) => {
        return {
          label: nationality?.text,
          value: nationality?.value
        }
      })
      setNationalitiesList(nationalities)
      saveNationalitiesDetails(response?.data)
      setCountryList(countries);
      saveCountriesDetails(response?.data);
    }
  };

  // const getNationalitiesList = async () => {
  //   const response:any = await getNationalities()
  //   if (response?.status == 200) {
  //     console.log(response?.data)
  //     const nationalities = response?.data?.map((nationality:any) => {
  //       return {
  //         label: nationality?.name,
  //         value: nationality?.code
  //       }
  //     })
  //     setNationalitiesList(nationalities)
  //     saveNationalitiesDetails(response?.data)
  //   } else {
  //     console.error(response)
  //   }
  // }

  const handleSelectChange = (e: any) => {
    const { name, value } = e.target;
    const updatedPassportInfo = {
      ...passportInfo,
      [name]: value,
    }
    setPassportInfo(updatedPassportInfo);
    onChange(updatedPassportInfo)
  };

  const handleInputChange = (e: any) => {
    const { name, value } = e.target;
    const updatedPassportInfo = {
      ...passportInfo,
      [name]: value,
    }
    setPassportInfo(updatedPassportInfo);
    onChange(updatedPassportInfo)
  };

  return (
    <>
      <div className="row">
        <div className="col-lg-6">
          <div className="mb-1 row">
            <label className="col-sm-4 col-form-label">
              Passport No:<i className="text-danger">*</i>
            </label>
            <div className="col-sm-8 ">
              <CustomInput1
                id="passportno"
                placeholder="Passport no."
                name="passportNo"
                value={passportInfo?.passportNo}
                handleChange={(e) => handleInputChange(e)}
              />
            </div>
          </div>
        </div>

        <div className="col-lg-6">
          <div className="mb-2 row">
            <label className="col-sm-4 col-form-label">
              {' '}
              Passport Exp:<i className="text-danger">*</i>
            </label>
            <div className="col-sm-8">
              <div className="d-flex">
                <div className="flex-fill me-2">
                  <ListBox
                    name="passportDate"
                    id="passport-date"
                    defaultValue={passportInfo?.passportDate}
                    options={days}
                    handleChange={(e) => handleSelectChange(e)}
                  />{' '}
                </div>
                <div className="flex-fill me-2">
                  {' '}
                  <ListBox
                    name="passportMonth"
                    id="passport-month"
                    defaultValue={passportInfo?.passportMonth}
                    options={months}
                    handleChange={(e) => handleSelectChange(e)}
                  />{' '}
                </div>
                <div className="flex-fill">
                  {' '}
                  <ListBox
                    name="passportYear"
                    id="passport-year"
                    defaultValue={passportInfo?.passportYear}
                    options={passptExpYears}
                    handleChange={(e) => handleSelectChange(e)}
                  />{' '}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="col-lg-6">
          <div className="mb-1 row">
            <label className="col-sm-4 col-form-label">
              Nationality:<i className="text-danger">*</i>
            </label>
            <div className="col-sm-8">
              <ListBox
                name="nationality"
                id="nationality"
                defaultValue={passportInfo?.nationality}
                options={nationalitiesList}
                handleChange={(e) => handleSelectChange(e)}
              />
            </div>
          </div>
        </div>

        <div className="col-lg-6">
          <div className="mb-1 row">
            <label className="col-sm-4 col-form-label">
              Country of issue:<i className="text-danger">*</i>
            </label>
            <div className="col-sm-8">
              <ListBox
                name="country"
                id="country"
                defaultValue={passportInfo?.country}
                options={countryList}
                handleChange={(e) => handleSelectChange(e)}
              />
            </div>
          </div>
        </div>

        <div className="col-lg-6">
          <div className="mb-1 row">
            <label className="col-sm-4 col-form-label">
              Address<i className="text-danger">*</i>
            </label>
            <div className="col-sm-8 ">
              <CustomInput1
                id="address"
                placeholder="Address"
                name="address1"
                value={passportInfo?.address1}
                handleChange={(e) => handleInputChange(e)}
              />
            </div>
          </div>
        </div>

        <div className="col-lg-6">
          <div className="mb-1 row">
            <div className="col-sm-12">
              <CustomInput1
                id="address2"
                placeholder="Address2"
                name="address2"
                value={passportInfo?.address2}
                handleChange={(e) => handleInputChange(e)}
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
