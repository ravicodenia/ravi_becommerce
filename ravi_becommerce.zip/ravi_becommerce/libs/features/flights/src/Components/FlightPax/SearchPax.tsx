

import { useState } from "react";
import { Modal } from 'react-bootstrap';

import {  CustomInput1 } from '@mfa-travel-app/ui';

export default function SearchPax() {

    const [searchPaxModal, setSearchPaxModal] = useState(false);


  return (
    
   

    <>

            <button onClick={() => setSearchPaxModal(true)} type="button" className="search_pax_link"> 
            <i className="fa-solid fa-magnifying-glass"></i> Search Pax
            </button>

         



        <Modal size="lg" 
        centered
        show={searchPaxModal}
        onHide={() => setSearchPaxModal(false)} >

<Modal.Header closeButton>
          <Modal.Title>Search Passenger </Modal.Title>
        </Modal.Header>
        <Modal.Body>
  
        <div className="row"> 
                        <div className="col-lg-3">    

                            <div className="form-group">
                                <label htmlFor="passportno">Passport Number</label>
                                <CustomInput1  id="passportno" placeholder='Passport Number'/>       
                        
                            </div>
                        </div>
                    
                        <div className="col-lg-3">    

                            <div className="form-group">
                            <label htmlFor="firstname">First Name</label>
                            <CustomInput1  id="firstname" placeholder="First Name" />      

                        </div>

                    </div>

                    <div className="col-lg-3">    
                        <div className="form-group">
                        <label htmlFor="lastname">Last Name</label>
                        <CustomInput1   id="lastname" placeholder="Last Name" />      

                    </div>

                    </div>

                    <div className="col-lg-3">    

                        <div className="form-group">
                        <label htmlFor="searchpaxemail">Email</label>
                        <CustomInput1 id="searchpaxemail" placeholder="Email" />      
                        
                    </div>

                </div>




                        </div>

                        <div className="row">
                        <div className="col-12 text-end mt-3 mb-2">

                            <button className="btn btn-secondary"> Search</button>
                        </div>
                        </div>


        </Modal.Body>
       </Modal>



     
    </>



  )
}
