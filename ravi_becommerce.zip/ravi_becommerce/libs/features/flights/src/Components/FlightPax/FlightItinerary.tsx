import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { RootState } from '@mfa-travel-app/store';
import { ailogo } from '../../../../../assets/src';

export default function FlightItinerary() {

  const { selectedItinerary, airlines,passengerList } = useSelector((state: RootState) => state.flight);

  const getAirlineData = (airlineCode: string) => {
    const airline = airlines?.filter((airline:any) => airline?.code === airlineCode)
    return airline[0]
  };

  const getPassengerData = (data:any,passengerData:any,index:any) =>{
const uniquePassenger = index == 0  ? passengerData?.onwardFlights : passengerData?.returnFlights
const uniquePassengerData =  uniquePassenger?.find((item:any)=>{
return data == item.flightNo;
})
return uniquePassengerData 
  }

  return (
    <>
      {/* <div className="row">
        <div className="col-12">
          <div className="itrbg">
            <div className="row">
              <div className="col-6">
                <strong>
                  <i className="fa-solid fa-plane-departure"></i> DXB to Delhi
                </strong>
              </div>

              <div className="col-6 text-end">
                <strong>
                  <i className="fa-solid fa-calendar-days"></i> Wed Nov 15 2023
                </strong>
              </div>
            </div>
          </div>
        </div>

        <div className="col-12 mb-3 mt-3">
          <img
            src={ailogo}
            alt=""
            className="img-fluid rounded me-2"
            style={{ width: '40px' }}
          />
          <strong>Air India Express</strong> <small>AE-908 Airbus 321</small>
        </div>

        <div className="col-12 mb-4">
          <div className="row align-items-center">
            <div className="col-5 text-end">
              <div>
                <strong>4:20 AM</strong>
              </div>
              <div>Wed Nov 15 2023</div>
              <div>
                <small className="text-muted">Dubai (DXB)</small>
              </div>
            </div>
            <div className="col-2 text-center">
              <span className="text-muted">
                <i className="fa-solid fa-plane-departure"></i>
              </span>{' '}
            </div>
            <div className="col-5">
              <div>
                <strong>4:20 AM</strong>
              </div>
              <div>Wed Nov 15 2023</div>
              <div>
                <small className="text-muted">Dubai (DXB)</small>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="row">
        <div className="col-12">
          <div className="itrbg">
            <div className="row">
              <div className="col-6">
                <strong>
                  <i className="fa-solid fa-calendar-days"></i> Delhi to DXB
                </strong>
              </div>

              <div className="col-6 text-end">
                <strong>
                  <i className="fa-solid fa-plane-departure"></i> Wed Nov 15
                  2023
                </strong>
              </div>
            </div>
          </div>
        </div>

        <div className="col-12 mb-3 mt-3">
          <img
            src={ailogo}
            alt=""
            className="img-fluid rounded me-2"
            style={{ width: '40px' }}
          />
          <strong>Air India Express</strong> <small>AE-908 Airbus 321</small>
        </div>

        <div className="col-12 mb-4">
          <div className="row align-items-center">
            <div className="col-5 text-end">
              <div>
                <strong>4:20 AM</strong>
              </div>
              <div>Wed Nov 15 2023</div>
              <div>
                <small className="text-muted">Dubai (DXB)</small>
              </div>
            </div>
            <div className="col-2 text-center">
              <span className="text-muted">
                <i className="fa-solid fa-plane-departure"></i>
              </span>{' '}
            </div>
            <div className="col-5">
              <div>
                <strong>4:20 AM</strong>
              </div>
              <div>Wed Nov 15 2023</div>
              <div>
                <small className="text-muted">Dubai (DXB)</small>
              </div>
            </div>
          </div>
        </div>
      </div> */}
      {selectedItinerary?.flights?.map((journey: any, index:any) => (
        <div className="row">
          <div className="col-12">
            <div className="itrbg">
              <div className="row">
                <div className="col-6">
                  <strong>
                    <i className="fa-solid fa-plane-departure"></i>{' '}
                    {journey[0]?.origin?.cityName} to{' '}
                    {journey[journey.length - 1]?.destination?.cityName}
                  </strong>
                </div>

                <div className="col-6 text-end">
                  <strong>
                    <i className="fa-solid fa-calendar-days"></i>{' '}
                    {new Date(journey[0]?.departureTime)?.toLocaleDateString(
                      'en-US',
                      {
                        weekday: 'short',
                        month: 'short',
                        day: '2-digit',
                        year: 'numeric',
                      }
                    )}
                  </strong>
                </div>
              </div>
            </div>
          </div>

          <div className="col-12 mb-3 mt-3">
            <img
              src={getAirlineData(journey && journey[0]?.airline)?.logoFile}
              alt=""
              className="img-fluid rounded me-2"
              style={{ width: '40px' }}
            />
            <strong>{getAirlineData(journey && journey[0]?.airline)?.name}</strong>{' '}
            <small>
              {journey[0]?.airline}-{journey[0]?.flightNumber} Airbus{' '}
              {journey[0]?.craft}
            </small>
          </div>
          <div className="col-12 mb-4">
            <div className="row align-items-center">
              <div className="col-5 text-end">
                <div>
                  <strong>
                    {new Date(journey[0]?.departureTime)?.toLocaleTimeString(
                      'en-US',
                      { timeStyle: 'short' }
                    )}
                  </strong>
                </div>
                <div>
                  {new Date(journey[0]?.departureTime)?.toLocaleDateString(
                    'en-US',
                    {
                      weekday: 'short',
                      month: 'short',
                      day: '2-digit',
                      year: 'numeric',
                    }
                  )}
                </div>
                <div>
                  <small className="text-muted">{`${journey[0]?.origin?.cityName} (${journey[0]?.origin?.cityCode})`}</small>
                </div>
              </div>
              <div className="col-2 text-center">
                <span className="text-muted">
                  <i className="fa-solid fa-plane-departure"></i>
                </span>{' '}
              </div>
              <div className="col-5">
                <div>
                  <strong>
                    {new Date(
                      journey[journey?.length - 1]?.arrivalTime
                    ).toLocaleTimeString('en-US', { timeStyle: 'short' })}
                  </strong>
                </div>
                <div>
                  {new Date(
                    journey[journey?.length - 1]?.arrivalTime
                  ).toLocaleDateString('en-US', {
                    weekday: 'short',
                    month: 'short',
                    day: '2-digit',
                    year: 'numeric',
                  })}
                </div>
                <div>
                  <small className="text-muted">{`${
                    journey[journey?.length - 1]?.destination?.cityName
                  } (${
                    journey[journey?.length - 1]?.destination?.cityCode
                  })`}</small>
                </div>
              </div>
            </div>
          </div>
          {passengerList.map((passenger: any) => {
  return (
    <div>
     Name- {getPassengerData(journey[0].flightNumber, passenger.seatInfo, index)?.name}{" "} SeatNo -
      {getPassengerData(journey[0].flightNumber, passenger.seatInfo, index)?.seatNo}
    </div>
  );
})}
        </div>
      ))}
      
      <div className="col-12">
        <table className="table tbl_itenerary">
          <tbody>
            <tr>
              {/* <td>
                <strong>Check In:</strong>{' '}
                { selectedItinerary?.flights[0][0] && selectedItinerary?.flights[0][0]?.defaultBaggage ? `${ selectedItinerary?.flights[0][0] && selectedItinerary?.flights[0][0]?.defaultBaggage}/person` : 'As per Airline Policy'}
              </td> */}
              <td>
  <strong>Check In:</strong>{' '}
  {Array.isArray(selectedItinerary?.flights) && selectedItinerary?.flights.length > 0 && 
    selectedItinerary?.flights[0].length > 0 && selectedItinerary?.flights[0][0]?.defaultBaggage 
    ? `${selectedItinerary.flights[0][0]?.defaultBaggage}/person` 
    : 'As per Airline Policy'}
</td>

              {/* <td className="text-end">
                <strong>Cabin:</strong>{' '}
                {selectedItinerary?.flights[0][0]?.carryOnBaggage === null
                  ? 'As per Airline Policy'
                  : selectedItinerary?.flights[0][0]?.carryOnBaggage}
              </td> */}

              <td className="text-end">
  <strong>Cabin:</strong>{' '}
  {Array.isArray(selectedItinerary?.flights) && selectedItinerary?.flights.length > 0 &&
    selectedItinerary?.flights[0].length > 0 && selectedItinerary?.flights[0][0]?.carryOnBaggage !== null 
    ? selectedItinerary.flights[0][0]?.carryOnBaggage 
    : 'As per Airline Policy'}
</td>

            </tr>
            <tr>
              <td></td>
              <td className="text-end">
                {' '}
                <span className="text-uppercase text-success">
                  {' '}
                  <small>
                    {selectedItinerary?.nonRefundable === false
                      ? 'REFUNDABLE'
                      : 'NON-REFUNDABLE'}
                  </small>
                </span>{' '}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </>
  );
}
