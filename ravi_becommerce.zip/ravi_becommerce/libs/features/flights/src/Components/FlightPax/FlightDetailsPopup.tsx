import { useState } from 'react';
import { Modal } from 'react-bootstrap';
import FlightDetails from '../../lib/pages/flightDetails';

export default function FlightDetailsPopup({ itinerary }: any) {
  const [flightDetailsModal, setFlightDetailsModal] = useState(false);
  return (
    <>
      <div className="btnflbag">
        <button
          onClick={() => setFlightDetailsModal(true)}
          className="btn btn-secondary w-100"
        >
          FLIGHT DETAILS
        </button>
      </div>

      <Modal
        size="xl"
        centered
        show={flightDetailsModal}
        onHide={() => setFlightDetailsModal(false)}
      >
        <Modal.Header closeButton>
          <Modal.Title>Flight Details</Modal.Title>
        </Modal.Header>
        <FlightDetails itinerary={itinerary} />
      </Modal>
    </>
  );
}
