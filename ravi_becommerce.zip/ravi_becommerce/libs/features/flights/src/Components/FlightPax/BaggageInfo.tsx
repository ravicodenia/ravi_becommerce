import { RootState } from '@mfa-travel-app/store';
import { ListBox, CustomInputMuted } from '@mfa-travel-app/ui';
import { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { getFlightBaggageInformation } from '../../lib/service/flightApi';
import { useStore } from '@mfa-travel-app/store';
import { Loader } from '@mfa-travel-app/ui';

export default function BaggageInfo({ data, onChange }: any) {
  const { selectedItinerary, baggageInfo } = useSelector(
    (state: RootState) => state.flight
  );
  const { saveBaggageInfoDetails } = useStore();

  const [loader, setLoader] = useState(false);
  const [selectedBaggageInfo, setSelectedBaggageInfo] = useState<any>({});
  const [baggageOptions, setBaggageOptions] = useState<any>({});

  useEffect(() => {
    // if (selectedItinerary) {
    //   if (selectedItinerary?.flights?.length === 1) {
    //     setBaggageOptions({ onwardBaggageOptions: baggageInfo });
    //     setSelectedBaggageInfo({ onwardBaggage: baggageInfo[0] });
    //   } else {
    //     const onwardBaggageOptions = baggageInfo?.filter(
    //       (baggage: any) =>
    //         baggage?.segmentId == selectedItinerary?.flights[0][0]?.fareInfoKey
    //     );
    //     const returnBaggageOptions = baggageInfo?.filter(
    //       (baggage: any) =>
    //         baggage?.segmentId == selectedItinerary?.flights[1][0]?.fareInfoKey
    //     );
    //     const baggageOptionsObj = {
    //       onwardBaggageOptions: onwardBaggageOptions,
    //       returnBaggageOptions: returnBaggageOptions,
    //     };
    //     setBaggageOptions(baggageOptionsObj);
    //     setSelectedBaggageInfo({
    //       onwardBaggage: baggageOptionsObj?.onwardBaggageOptions[0],
    //       returnBaggage: baggageOptionsObj?.returnBaggageOptions[0],
    //     });
    //     const baggageOptionsObj = {
    //       onwardBaggageOptions: baggageInfo,
    //       returnBaggageOptions: baggageInfo
    //     }
    //     setBaggageOptions(baggageOptionsObj)
    //     setSelectedBaggageInfo({
    //       onwardBaggage: baggageOptionsObj?.onwardBaggageOptions[0],
    //       returnBaggage: baggageOptionsObj?.returnBaggageOptions[0]
    //     })
    //   }
    // }
    if (selectedItinerary) {
      if (typeof baggageInfo == 'object' && baggageInfo?.length == 0) {
        getBaggageInfo();
      } else if (typeof baggageInfo == 'object' && baggageInfo?.length !== 0) {
        let baggageData: any = {};
        baggageInfo?.forEach((baggage: any) => {
          const key = baggage.baggageCode;
          baggageData[key] = baggage;
        });
        // saveBaggageInfoDetails(Object.values(baggageData));
        if (selectedItinerary?.flights?.length === 1) {
          setBaggageOptions({
            onwardBaggageOptions: Object.values(baggageData),
          });
          if (data?.onwardBaggage !== null) {
            setSelectedBaggageInfo({ onwardBaggage: data?.onwardBaggage });
            (data?.onwardBaggage);
          } else {
            setSelectedBaggageInfo({ onwardBaggage: 0 });
          }
        } else {
          // const onwardBaggageOptions = baggage?.filter(
          //   (baggage: any) =>
          //     baggage?.segmentId == selectedItinerary?.flights[0][0]?.fareInfoKey
          // );
          // const returnBaggageOptions = baggage?.filter(
          //   (baggage: any) =>
          //     baggage?.segmentId == selectedItinerary?.flights[1][0]?.fareInfoKey
          // );
          const baggageOptionsObj = {
            onwardBaggageOptions: Object.values(baggageData),
            returnBaggageOptions: Object.values(baggageData),
          };
          setBaggageOptions(baggageOptionsObj);
          // setSelectedBaggageInfo({
          //   onwardBaggage: baggageOptionsObj?.onwardBaggageOptions[0],
          //   returnBaggage: baggageOptionsObj?.returnBaggageOptions[0],
          // });
          if (data?.onwardBaggage !== null && data?.returnBaggage !== null) {
            setSelectedBaggageInfo({
              onwardBaggage: data?.onwardBaggage,
              returnBaggage: data?.returnBaggage,
            });
          } else {
            setSelectedBaggageInfo({
              onwardBaggage: 0,
              returnBaggage: 0,
            });
          }
        }
      }
    }
  }, [selectedItinerary]);

  const getBaggageInfo = async () => {
    setLoader(true);
    const response: any = await getFlightBaggageInformation(
      selectedItinerary?.sessionId,
      selectedItinerary?.flightGuId
    );
    setLoader(false);
    // console.log('baggageInfo', response);
    if (response?.status == 200) {
      if (response?.data?.length == 0) {
        saveBaggageInfoDetails('No baggage details available');
      } else {
        let baggageData: any = {};
        response?.data?.forEach((baggage: any) => {
          const key = baggage.baggageCode;
          baggageData[key] = baggage;
        });
        saveBaggageInfoDetails(Object.values(baggageData));
        if (selectedItinerary?.flights?.length === 1) {
          setBaggageOptions({
            onwardBaggageOptions: Object.values(baggageData),
          });
          setSelectedBaggageInfo({ onwardBaggage: 0 });
        } else {
          // const onwardBaggageOptions = baggage?.filter(
          //   (baggage: any) =>
          //     baggage?.segmentId == selectedItinerary?.flights[0][0]?.fareInfoKey
          // );
          // const returnBaggageOptions = baggage?.filter(
          //   (baggage: any) =>
          //     baggage?.segmentId == selectedItinerary?.flights[1][0]?.fareInfoKey
          // );
          const baggageOptionsObj = {
            onwardBaggageOptions: Object.values(baggageData),
            returnBaggageOptions: Object.values(baggageData),
          };
          setBaggageOptions(baggageOptionsObj);
          setSelectedBaggageInfo({
            onwardBaggage: baggageOptionsObj?.onwardBaggageOptions[0],
            returnBaggage: baggageOptionsObj?.returnBaggageOptions[0],
          });
          setSelectedBaggageInfo({
            onwardBaggage: 0,
            returnBaggage: 0,
          });
        }
      }
    }
  };

  const handleSelectChange = (e: any) => {
    const { name, value } = e.target;
    let updatedBaggageInfo;
    if (name == 'onwardBaggage') {
      const selectedBaggageOption =
        baggageOptions?.onwardBaggageOptions?.filter(
          (option: any) => option?.baggageCode === value
        )[0];
      updatedBaggageInfo = {
        ...selectedBaggageInfo,
        onwardBaggage: selectedBaggageOption,
      };
      setSelectedBaggageInfo(updatedBaggageInfo);
    } else {
      const selectedBaggageOption =
        baggageOptions?.returnBaggageOptions?.filter(
          (option: any) => option?.baggageCode === value
        )[0];
      updatedBaggageInfo = {
        ...selectedBaggageInfo,
        returnBaggage: selectedBaggageOption,
      };
      setSelectedBaggageInfo(updatedBaggageInfo);
    }
    onChange(updatedBaggageInfo);
  };

  return (
    <>
      <div className="border p-2 bg-light">
        <div className="row">
          <div className="col-lg-12">
            <i className="fa-solid fa-caret-down"></i> Baggage Information
          </div>

            <div className="col-lg-6">
              <div className="mb-2 row">
                <div className="col-sm-9 d-flex align-items-center">
                  { baggageOptions?.onwardBaggageOptions && baggageOptions?.onwardBaggageOptions?.length !== 0 ? (
                    <>
                    <label className="col-sm-3 col-form-label">Onward:</label>
                   <div className="row align-items-center">
                      <div className="col-8">
                        <ListBox
                          name="onwardBaggage"
                          id="onward"
                          defaultValue={
                            selectedBaggageInfo?.onwardBaggage?.baggageCode ? selectedBaggageInfo?.onwardBaggage?.baggageCode : ''
                          }
                          options={baggageOptions?.onwardBaggageOptions?.map(
                            (option: any) => ({
                              label: option?.baggageDescription,
                              value: option?.baggageCode,
                            })
                          )}
                          handleChange={(e) => handleSelectChange(e)}
                        />
                      </div>
                      <div className="col-4">
                        <CustomInputMuted
                          id="onward-inp"
                          value={`${
                            selectedBaggageInfo?.onwardBaggage?.currencyCode
                          } ${
                            selectedBaggageInfo?.onwardBaggage?.baggageCharge
                              ? selectedBaggageInfo?.onwardBaggage
                                  ?.baggageCharge
                              : 0
                          }`}
                        />
                      </div>
                    </div>
                    </>
                  ) : (
                    ''
                    // <span className='fs-6'>No baggage options available</span>
                  )}
                </div>
              </div>
            </div>

            <div className="col-lg-6">
              <div className="mb-2 row">
                <div className="col-sm-9  d-flex align-items-center">
                  {baggageOptions?.returnBaggageOptions && baggageOptions?.returnBaggageOptions?.length !== 0 ? (
                    <>
                     <label className="col-sm-3 col-form-label">Return:</label>
                    <div className="row d-flex align-items-center">
                      <div className="col-8">
                        <ListBox
                          name="returnBaggage"
                          id="return"
                          defaultValue={
                            selectedBaggageInfo?.returnBaggage?.baggageCode ? selectedBaggageInfo?.returnBaggage?.baggageCode : ''
                          }
                          options={baggageOptions?.returnBaggageOptions?.map(
                            (option: any) => ({
                              label: option?.baggageDescription,
                              value: option?.baggageCode,
                            })
                          )}
                          handleChange={(e) => handleSelectChange(e)}
                        />
                      </div>
                      <div className="col-4">
                        <CustomInputMuted
                          id="return-inp"
                          value={`${
                            selectedBaggageInfo?.returnBaggage?.currencyCode
                          } ${
                            selectedBaggageInfo?.returnBaggage?.baggageCharge
                              ? selectedBaggageInfo?.returnBaggage
                                  ?.baggageCharge
                              : 0
                          }`}
                        />
                      </div>
                    </div>
                    </>
                  ) : (
                    // <span className='fs-6'>No baggage options available</span>
                    ''
                  )}
                </div>
              </div>
            </div>
        </div>
      </div>
      {loader && <Loader />}
    </>
  );
}
