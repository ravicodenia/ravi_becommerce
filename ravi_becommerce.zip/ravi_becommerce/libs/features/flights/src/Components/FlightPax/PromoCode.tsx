
import {  CustomInput1 } from '@mfa-travel-app/ui';

export default function PromoCode() {
  return (


<> 
<div className='row'>

<div className='col-12'>
<div className='promoBlock'>
<div className="input-group">

<CustomInput1 id="promocode" placeholder='Promo Code'/>     
<div className="input-group-append">
<button className="btn btn-primary" type="button">APPLY</button>
</div>
</div>

</div>
</div>
</div>

</>



  )
}
