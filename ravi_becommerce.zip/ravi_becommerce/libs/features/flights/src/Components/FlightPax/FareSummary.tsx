import { RootState } from '@mfa-travel-app/store';
import { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';

export default function FareSummary({ passengerDetails }: any) {
  const { selectedItinerary } = useSelector((state: RootState) => state.flight);
  const [baggageFee, setBaggageFee] = useState(0);
  const [mealFee, setMealFee] = useState(0);
  const [seatFee, setSeatFee] = useState(0);
  const [serviceFee, setServiceFee] = useState(0);


  useEffect(() => {
    let baggageFee = 0;
    passengerDetails?.forEach((passenger: any) => {
      if (passenger?.baggageInfo?.onwardBaggage) {
        baggageFee =
          baggageFee + Number(passenger?.baggageInfo?.onwardBaggage?.baggageCharge);
      }
      if (passenger?.baggageInfo?.returnBaggage) {
        baggageFee =
          baggageFee + Number(passenger?.baggageInfo?.returnBaggage?.baggageCharge);
      }
    });
    setBaggageFee(baggageFee);

    let mealFee = 0;
    passengerDetails?.forEach((passenger: any) => {
      if (passenger?.mealInfo?.onwardMeal) {
        mealFee = mealFee + Number(passenger?.mealInfo?.onwardMeal?.mealCharge);
      }
      if (passenger?.mealInfo?.returnMeal) {
        mealFee = mealFee + Number(passenger?.mealInfo?.returnMeal?.mealCharge);
      }
    });
    setMealFee(mealFee);

    let passenSeatFee = 0;
    passengerDetails?.forEach((passenger: any) => {
      if (passenger?.seatInfo?.onwardFlights) {
        passenger?.seatInfo?.onwardFlights.forEach((p: any) => {
          passenSeatFee = passenSeatFee + Number(p?.price);
        });
      }
      if (passenger?.seatInfo?.returnFlights) {
        passenger?.seatInfo?.returnFlights.forEach((p: any) => {
          passenSeatFee = passenSeatFee + Number(p?.price);
        });
      }
    });
    setSeatFee(passenSeatFee);

    if (passengerDetails[0]?.markup) {
      let serviceFee =
        selectedItinerary?.price?.handlingFeeValue +
        Number(passengerDetails[0]?.markup?.markupValue) -
        selectedItinerary?.price?.discount;
      // console.log(
      //   selectedItinerary?.price?.handlingFeeValue,
      //   Number(passengerDetails[0]?.markup),
      //   selectedItinerary?.price?.discount
      // );
      setServiceFee(serviceFee);
    }
  }, [passengerDetails]);

  return (
    <>
      <div className="fare_details">
        <div className="tbl_fare_summary">
          <table className="table">
            <tbody>
              {selectedItinerary?.fareBreakdown?.map((passengers: any, index:any) => (
                <tr key={index}>
                  <td>
                    {passengers?.passengerType == 1
                      ? 'Adult'
                      : passengers?.passengerType == 2
                      ? 'Child'
                      : 'Infant'}{' '}
                    x {passengers?.passengerCount}
                  </td>
                  <td className="text-end">{passengers?.totalFare?.toFixed(2)}</td>
                </tr>
              ))}
              <tr>
                <td>Baggage Free</td>
                <td className="text-end">{baggageFee?.toFixed(2)}</td>
              </tr>
              <tr>
                <td>Meal Fee</td>
                <td className="text-end">{mealFee?.toFixed(2)}</td>
              </tr>
              <tr>
                <td>Seat Fee</td>
                <td className="text-end">{seatFee?.toFixed(2)}</td>
              </tr>
              <tr>
                <td>Promo Discount</td>
                <td className="text-end">
                  {selectedItinerary?.price?.discount?.toFixed(2)}
                </td>
              </tr>
              <tr>
                <td>Service Fee</td>
                <td className="text-end">{serviceFee?.toFixed(2)}</td>
              </tr>
              <tr className="grandTotal">
                <td className="border-bottom-0">
                  <strong>Grand Total</strong>
                </td>
                <td className="border-bottom-0 font-weight-bold text-end">
                  <strong>
                    {(selectedItinerary?.totalFare +
                      Number(baggageFee) +
                      Number(mealFee) +
                      Number(seatFee) +
                      Number(selectedItinerary?.price?.discount) +
                      Number(serviceFee))}
                  </strong>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
