import { CustomInput1, MobileNo } from '@mfa-travel-app/ui';
import { useState } from 'react';

export default function ContactInfo({data, onChange}:any) {
  const [contactInfo, setContactInfo] = useState(data)

  const handleInputChange = (e:any) => {
    const { name, value } = e.target
    const updatedInfo = {
      ...contactInfo,
      [name]:value
    }
    setContactInfo(updatedInfo)
    onChange(updatedInfo)
  }

  return (
    <>
      <div className="row">
        <div className="col-lg-6">
          <div className="mb-1 row">
            <label className="col-sm-4 col-lg-5 col-form-label">
              Email Address:<i className="text-danger">*</i>
            </label>
            <div className="col-sm-8 col-lg-7">
              <CustomInput1 id="email" placeholder="Email" name='email' value={contactInfo.email} handleChange={handleInputChange}/>
            </div>
          </div>
        </div>

        <div className="col-lg-6">
          <div className="mb-1 row">
            <label className="col-sm-4 col-lg-5 col-form-label">
              Mobile Phone:<i className="text-danger">*</i>
            </label>

            <div className="col-sm-8 col-lg-7">
              <MobileNo id="mobileno" placeholder="" name='mobileNo' value={contactInfo.mobileNo} handleChange={handleInputChange}/>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}