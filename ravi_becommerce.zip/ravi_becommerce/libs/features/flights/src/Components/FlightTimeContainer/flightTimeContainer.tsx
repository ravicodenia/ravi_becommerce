import classNames from "classnames";
import styles from "./flightTime.module.scss";
import { FiSunrise } from "react-icons/fi";

const FlightTimeContainer = ({ icon, time, checked, onChange }: any) => {
    return (
        <label className={classNames(styles["chkpic"], "me-2")} htmlFor={`chkpic${time}`}>
            {icon}
            <span className={styles["time"]}>{time}</span>
            <input
                type="checkbox"
                id={`chkpic${time}`}
                checked={checked}
                onChange={() => onChange(time)}
            />
            <span className={styles["checkmark"]}></span>
        </label>
    );
};

export default FlightTimeContainer;