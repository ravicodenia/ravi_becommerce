import { FaCalendarAlt } from 'react-icons/fa';
import { useState, useEffect, useRef } from 'react';
import TwoMonthSingleDatePicker from '../../lib/pages/hotal-datepickers';

const SelectedDate = ({ onAirportSelectDate, departureReturn, text, datePayload, updateFlightTypeToReturn, initialDate, showPopup=false, setShowPopup=null }:any) => {

  const formatDate = (dateString:any) => {
    const date = new Date(dateString);
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    const day = date.getDate();
    const month = monthNames[date.getMonth()];
    const year = date.getFullYear().toString().slice(-2);
    const weekday = dayNames[date.getDay()];

    return `${day} ${month}'${year} ${weekday}`;
  };
  const [departure, setDeparture] = useState(false);
  const [selectedDate, setSelectedDate] = useState(datePayload || new Date());
  const [selectedDateText, setSelectedDateText] = useState(formatDate(datePayload));
  const datePickerRef = useRef<any>(null);
  const [isOpen, setIsOpen] = useState(false);

  const updateDate = (e:any) => {
    const newDate = new Date(e);
    setSelectedDate(e);
    const inputDate = formatDate(e);
    if (inputDate) {
      onAirportSelectDate(inputDate, newDate.toISOString());
    }
    setSelectedDateText(inputDate);
  };

  const toggleDatePicker = () => {
    if (!departureReturn) {
      updateFlightTypeToReturn();
    }
    setDeparture((prev) => !prev);
    setIsOpen((prev) => !prev);
  };

  useEffect(() => {
    if (showPopup) {
      toggleDatePicker();
      if (setShowPopup) setShowPopup(false);
    }
  }, [showPopup]);

  useEffect(() => {
    setSelectedDate(datePayload);
    setSelectedDateText(formatDate(datePayload));
  }, [datePayload]);

  const handleClickOutside = (event:any) => {
    if (datePickerRef.current && !datePickerRef.current.contains(event.target)) {
      setDeparture(false);
      setIsOpen(false);
    }
  };

  useEffect(() => {
    document.addEventListener('click', handleClickOutside, true);
    return () => {
      document.removeEventListener('click', handleClickOutside, true);
    };
  }, []);

  return (
    <div id="div_calendar_oneway_return">
     <div className='row g-2'>
        <div className="col-12">
          <table className="flightheadertbl">
            <tbody>
              <tr>
                <td>
                  <select defaultValue="Any Time" name="pickdeparture">
                    <option value="Any Time">Any Time</option>
                    <option value="Morning">Morning</option>
                  </select>
                </td>
              </tr>
            </tbody>
          </table>

          <div className="srchCon notranslate" onClick={() => toggleDatePicker()}>
            <div>
              <div className="srchRow">
                <div className="srchCol">
                  <div className="mb-1">
                    <span className="srchsml">
                      {text} <i className="fa-solid fa-angle-down"></i>
                    </span>
                  </div>
                  {departureReturn ? (
                    <span>
                      <FaCalendarAlt /> {selectedDateText}
                    </span>
                  ) : (
                    <div
                      style={{
                        fontSize: '0.8rem',
                        lineHeight: '16px',
                        color: 'gray',
                        fontWeight: '600',
                        textDecoration: 'none',
                      }}
                    >
                      Tap to add a return for bigger discount
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="row material-calendar" ref={datePickerRef}>
            {departureReturn && departure && (
              <TwoMonthSingleDatePicker
                selectedDate={selectedDate}
                setSelectedDate={updateDate}
                minDate={initialDate}
                isOpen={isOpen}
                setIsOpen={setIsOpen}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SelectedDate;
