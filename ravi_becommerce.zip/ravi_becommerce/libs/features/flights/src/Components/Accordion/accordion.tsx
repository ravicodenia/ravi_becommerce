const Accordion = ({ accordionButton, accordianText,accordionId,ariaExpanded }: any) =>
(

    <div className="accordion" id={accordionId}>
        <div className="accordion-item">
            <h2 className="accordion-header">
                <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded={ariaExpanded} aria-controls="collapseOne">
                  {accordionButton}
                </button>
            </h2>
            <div id="collapseOne" className="accordion-collapse collapse show" data-bs-parent={`#${accordionId}`}>
                <div className="accordion-body">
                {accordianText}
                </div>
            </div>
        </div>
    </div>

)



export default Accordion;
