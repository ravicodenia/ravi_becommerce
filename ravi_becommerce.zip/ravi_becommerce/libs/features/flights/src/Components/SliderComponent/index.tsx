import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

const SliderComponent = ({ ImageData }: any) => {
  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    // autoplay: true, 
    // autoplaySpeed: 3000,
    arrows: false,
  };
  return (
    <Slider {...settings} className="first-slider">
      {ImageData.map((item: any) => (
        <div key={item.id}>
          <a href={item.imageReturnUrl} target="_blank" rel="noopener noreferrer">
          <img src={item.imageFilePath} alt={item.imageLabel} />
          </a>
        </div>
      ))}
    </Slider>
  )
}
export default SliderComponent;