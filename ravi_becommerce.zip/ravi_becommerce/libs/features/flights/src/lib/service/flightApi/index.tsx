import { getGatewayAPI, postGatewayAPI } from '@mfa-travel-app/services';
import {
    GET_AIRPORT_LIST,
    GET_AIRLINE_LIST,
    FLIGHT_SEARCH_API,
    FLIGHT_FARE_RULES,
    FLIGHT_RE_PRICE,
    FLIGHT_MEALS_LIST,
    FLIGHT_BAGGAGE_INFO,
    FLIGHT_SEAT,
    FLIGHT_FLIGHTBOOK,
    FLIGHT_UAPIBOOK,
    FLIGHT_BOOK_SSR
} from '../constants';

export const getAllAirlinesList = async () => {
    try {
        const response = await getGatewayAPI(GET_AIRLINE_LIST);
        return response;
    } catch (error) {
        return error;
    }
}

export const getAllAirportsList = async (agentId: number | string) => {
    try {
        const response = await getGatewayAPI(GET_AIRPORT_LIST, {
            params: {
                agentId: agentId,
            },
        });
        return response;
    } catch (error) {
        return error;
    }
}

export const searchFlights = async (searchPayload: any) => {
    try {
        const response = await postGatewayAPI(FLIGHT_SEARCH_API, {
            ...searchPayload
        });
        return response;
    } catch (error) {
        return error;
    }
}

export const getFareRuleDetails = async (sessionId: string, flightGuId: string) => {
    try {
        const response = await postGatewayAPI(FLIGHT_FARE_RULES, {
            sessionId, flightGuId,
        });
        return response;
    } catch (error) {
        return error;
    }
}

export const getFlightRePrice = async (sessionId: string, flightGuId: string) => {
    try {
        const response = await postGatewayAPI(FLIGHT_RE_PRICE, {
            sessionId, flightGuId,
        });
        return response;
    } catch (error) {
        return error;
    }
}

export const getFlightMealsDetails = async (sessionId: string, flightGuId: string) => {
    try {
        const response = await postGatewayAPI(FLIGHT_MEALS_LIST, {
            sessionId, flightGuId,
        });
        return response;
    } catch (error) {
        return error;
    }
}

export const getFlightBaggageInformation = async (sessionId: string, flightGuId: string) => {
    try {
        const response = await postGatewayAPI(FLIGHT_BAGGAGE_INFO, {
            sessionId, flightGuId,
        });
        return response;
    } catch (error) {
        return error;
    }
}

export const getSeatAvailable = async (
    sessionId: string,
    flightGuId: string,
    origin: string,
    destination: string,
    passengers: string
) => {
    try {
        const response = await postGatewayAPI(FLIGHT_SEAT, {
            sessionId, flightGuId, origin, destination, passengers,
        });
        return response;
    } catch (error) {
        return error;
    }
}

export const getFlightBookInfo = async (data: any) => {
    try {
        const response = await postGatewayAPI(FLIGHT_FLIGHTBOOK, {
            ...data
        });
        return response;
    } catch (error) {
        return error;
    }
}

export const getUapiFlightBookInfo = async (data:any) => {
    try {
        const response = await postGatewayAPI(FLIGHT_UAPIBOOK, {
            ...data
        });
        return response;
    } catch (error) {
        return error
    }
}

export const getBookSSR = async (data:any) => {
    try {
        const response = await postGatewayAPI(FLIGHT_BOOK_SSR, {
            ...data
        });
        return response;
    } catch (error) {
        return error
    }
}
