// Home APIs
export const GET_AGENT_BANK_DETAILS = "common/Home/GetBankDetailsByAgentId";
export const GET_AGENT_TRANSACTIONS = "aggregator/Home/GetLatestTransactionsByAgentId";
export const GET_AGENT_SUPPORT_DETAILS = "common/Home/GetSupportDetailsByAgentId";
export const GET_AGENT_RECENT_SEARCH = "airline/SearchHistory/GetSearchHistoryListByAgentd";
export const GET_SLIDER_IMAGES = "common/Home/GetSliderByAgentId";
export const GET_AGENT_NOTIFICATION_SEARCH = "common/Home/GetNotificationsByUserId";
export const GET_COUNTRIES = "common/Country/GetCountries";
export const GET_NATIONALITIES = "common/Nationality/GetAll";
export const GET_CONTACT_DETAILS = 'common/Home/GetContactDetails'

// AIRPORT APIs
export const GET_AIRPORT_LIST = "airline/Airport/GetAirportsList";

// AIRLINE APIs
// export const GET_AIRLINE_LIST = "aggregator/Airline/GetAirlinesList";
// export const GET_AIRLINE_LIST = "airline/Airline/GetAll";
export const GET_AIRLINE_LIST = "airline/Airline/GetAirlinesList";

// FLIGHTS
export const FLIGHT_SEARCH_API = "airline/Flight/GetSearchResults";
export const FLIGHT_FARE_RULES = "airline/Flight/GetFareRules";
export const FLIGHT_RE_PRICE = "airline/Flight/FlightRePrice";
export const FLIGHT_BAGGAGE_INFO = "airline/Flight/GetBaggageDetails";
export const FLIGHT_MEALS_LIST = "airline/Flight/GetMealDetails";
export const FLIGHT_SEAT = "airline/Flight/GetSeatAvailableSSR";
export const FLIGHT_FLIGHTBOOK  = "airline/Flight/FlightBook";
export const FLIGHT_UAPIBOOK = "airline/Flight/FlightTicket";
export const FLIGHT_BOOK_SSR = 'airline/Flight/BookSSR '