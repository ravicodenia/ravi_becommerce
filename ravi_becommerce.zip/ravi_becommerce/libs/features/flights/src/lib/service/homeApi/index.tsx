import { getGatewayAPI } from '@mfa-travel-app/services';
import {
  GET_AGENT_BANK_DETAILS,
  GET_AGENT_TRANSACTIONS,
  GET_AGENT_SUPPORT_DETAILS,
  GET_AGENT_RECENT_SEARCH,
  GET_AGENT_NOTIFICATION_SEARCH,
  GET_SLIDER_IMAGES,
  GET_NATIONALITIES,
  GET_COUNTRIES,
  GET_CONTACT_DETAILS
} from '../constants';

export const getBankDetails = async (agentId: number | string) => {
  try {
    const response = await getGatewayAPI(GET_AGENT_BANK_DETAILS, {
      params: {
        agentId: agentId,
      },
    });
    return response;
  } catch (error) {
    return error;
  }
};

export const getSupportDetails = async (agentId: number | string) => {
  try {
    const response = await getGatewayAPI(GET_AGENT_SUPPORT_DETAILS, {
      params: {
        agentId: agentId,
      },
    });
    return response;
  } catch (error) {
    return error;
  }
};

export const getContactDetails = async (agentId: number | string) => {
  try {
    const response = await getGatewayAPI(GET_CONTACT_DETAILS, {
      params: {
        agentId: agentId,
      },
    });
    return response;
  } catch (error) {
    return error;
  }
};

export const getRecentSearch = async (agentId: number | string) => {
  try {
    const response = await getGatewayAPI(
      `${GET_AGENT_RECENT_SEARCH}/${agentId}`
    );
    return response;
  } catch (error) {
    return error;
  }
};

export const getAllTransaction = async (userId: number | string) => {
  try {
    const response = await getGatewayAPI(GET_AGENT_TRANSACTIONS, {
      params: {
        userId: userId,
      },
    });
    return response;
  } catch (error) {
    return error;
  }
};

export const getNotificationSearch = async (agentId: number | string) => {
  try {
    const response = await getGatewayAPI(GET_AGENT_NOTIFICATION_SEARCH, {
      params: {
        agentId: agentId,
      },
    });
    return response;
  } catch (error) {
    return error;
  }
};

export const getSliderImages = async (agentId: number | string) => {
  try {
    const response = await getGatewayAPI(GET_SLIDER_IMAGES, {
      params: {
        agentId: agentId,
      },
    });
    return response;
  } catch (error) {
    return error;
  }
};

export const getNationalities = async () => {
  try {
    const response = await getGatewayAPI(GET_NATIONALITIES);
    return response;
  } catch (error) {
    return error;
  }
};

export const getCountries = async () => {
  try {
    const response = await getGatewayAPI(GET_COUNTRIES);
    return response;
  } catch (error) {
    return error;
  }
};
