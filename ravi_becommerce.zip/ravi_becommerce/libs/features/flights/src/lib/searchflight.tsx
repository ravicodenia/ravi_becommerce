import { useEffect, useState } from 'react';
import { MainLayout } from '@mfa-travel-app/layout';
import BestPrice from '../Components/BestPrice';
import AirticketSlider from '../Components/AirTicketSlider';
import SearchFilter from '../Components/SearchFilter';
import { useSelector } from 'react-redux';
import { useStore, RootState } from '@mfa-travel-app/store';
import FindBestAboutAirlines from '../Components/FindBestAboutAirlines';
import Itinerary from './pages/itinerary';
import { searchFlights } from '../lib/service/flightApi';
import { toast } from 'react-toastify';
import { Loader } from '@mfa-travel-app/ui';
import FlightSearchBox from './pages/flightSearchBox';
import styles from '../Components/AirTicketSlider/flightstop.module.scss';
import { Link } from 'react-router-dom';
import Skeleton, { SkeletonTheme } from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css';


const SearchFlight = () => {
  const { airports, airlines, searchPayload, searchResults } = useSelector(
    (state: RootState) => state.flight
  );
  const {
    saveFlightSearchResults,
    saveSearchPayloadResults,
    refreshAirlineData,
  } = useStore();

  const [allSearchItenary, setAllSearchItenary] = useState<any[]>([]);
  const [filteredSearchItenary, setFilteredSearchItenary] = useState<any[]>([]);
  const [Itenaryfilter, setItenaryfilter] = useState<any>({
    zero: [],
    one: [],
    two: [],
  });
  const [cheapestFlights, setChepestFlight] = useState<any>();
  const [quckestFlight, setQuckestFlight] = useState<any>();
  const [bestFlight, setBestFlight] = useState<any>();
  const [loader, setLoader] = useState(false);
const [sliderScrolldata,setSliderScrollData] = useState([]);
  useEffect(() => {
    setFilteredSearchItenary(searchResults);
    setAllSearchItenary(searchResults);

  }, [searchResults]);

  useEffect(() => {
    searchFlightsOnLoad();
  }, [searchPayload]);

  const searchFlightsOnLoad = async () => {
    setLoader(true);
    const response: any = await searchFlights(searchPayload);
    setLoader(false);
    try {
      if (response.status == 200 && response?.data) {
        refreshAirlineData();
        saveFlightSearchResults(response?.data);
      } else {
        refreshAirlineData();
        saveFlightSearchResults([]);
        toast.error(response?.data.error.message);
      }
    } catch {
      toast.error('An error occurred. Please try again later.');
    }
  };

  const sumOFHoursWorked = (time1: any, time2: any) => {
    const time1Arr = time1?.split(':');
    const time2Arr = time2?.split(':');

    let secondSum: any =
      time1Arr && time1Arr[2] && time2Arr && time2Arr[2]
        ? Number(time1Arr[2]) + Number(time2Arr[2])
        : 0;
    let minSum: any =
      time1Arr && time1Arr[1] && time2Arr && time2Arr[1]
        ? Number(time1Arr[1]) + Number(time2Arr[1])
        : 0;
    let hourSum: any =
      time1Arr && time1Arr[0] && time2Arr && time2Arr[0]
        ? Number(time1Arr[0]) + Number(time2Arr[0])
        : 0;
    if (secondSum > 59) {
      secondSum = Math.abs(60 - secondSum);
      minSum += 1;
    }
    if (secondSum < 10) {
      secondSum = '0' + secondSum;
    }
    if (minSum > 59) {
      minSum = Math.abs(60 - minSum);
      hourSum += 1;
    }

    if (minSum < 10) {
      minSum = `0${minSum}`;
    }
    if (hourSum < 10) {
      hourSum = `0${hourSum}`;
    }

    return `${hourSum}:${minSum}:${secondSum}`;
  };

  useEffect(() => {
    if (filteredSearchItenary) {
      let allAvailableFlights: any = [];
      filteredSearchItenary.forEach((flightDetail) => {
        flightDetail.flights.forEach((flightArr: any) => {
          const flights = flightArr.map((item: any, i: number) => ({
            ...item,
            totalFare: flightDetail.totalFare,
            isStopOver: i + 1 !== flightArr?.length,
          }));
          allAvailableFlights = [...allAvailableFlights, ...flights];
        });
      });

      const getFlightsByStops = (stops: any) =>
        allAvailableFlights
          .filter((flight: any) => flight.stops === stops)
          .map((flight: any) => ({
            airline: flight.airline,
            totalFare: flight.totalFare,
            ...mapAirLineCode(flight.airline),
            ...mapAirportCode(
              flight.destination,
              flight.origin,
              flight.stopOver
            ),
            time: calculateTime(flight.arrivalTime, flight.departureTime),
            stop: stops,
          }));

      setItenaryfilter({
        zero: getFlightsByStops(0),
        one: getFlightsByStops(1),
        two: getFlightsByStops(2),
      });

      let sortedAllSearchItenary = [...filteredSearchItenary];
      let cheapItinerarySlice: any = [];
      const cheapItinerary = sortedAllSearchItenary.sort(
        (a, b) => a.totalFare - b.totalFare
      );
      let totalDuration = '0:0:0';
      totalDuration = sumOFHoursWorked(
        totalDuration,
        cheapItinerary && cheapItinerary[0]?.flights[0][0]?.duration
      );
      cheapItinerarySlice.push({
        fare: cheapItinerary[0]?.totalFare,
        duration: totalDuration,
      });

      const parseDurationToSeconds = (duration: any) => {
        const [hours, minutes, seconds] = duration.split(':').map(Number);
        return hours * 3600 + minutes * 60 + (seconds || 0);
      };

      const sortFlightsByDuration = (sortedAllSearchItenary: any) => {
        return sortedAllSearchItenary.sort((a: any, b: any) => {
          const durationA = parseDurationToSeconds(a.flights[0][0].duration);
          const durationB = parseDurationToSeconds(b.flights[0][0].duration);
          return durationA - durationB;
        });
      };

      const quickItinerary = sortFlightsByDuration(sortedAllSearchItenary);
      let shortestItinerary = [...quickItinerary].sort(
        (a: any, b: any) => a.totalFare - b.totalFare
      );
      let totalDurations = '0:0:0';
      totalDurations = sumOFHoursWorked(
        totalDuration,
        cheapItinerary && cheapItinerary[0]?.flights[0][0]?.duration
      );
      cheapItinerarySlice.push({
        fare: cheapItinerary[0]?.totalFare,
        duration: totalDurations,
      });

      setChepestFlight(cheapItinerarySlice[0]);
      setQuckestFlight(quickItinerary[0]);
      setBestFlight(shortestItinerary[0]);
    }
  }, [filteredSearchItenary]);

  const mapAirLineCode = (name: string) => {
    const mappingAirLine = airlines.filter(
      (airline: any) => airline.code === name
    )[0];
    return { name: mappingAirLine?.name, logoFile: mappingAirLine?.logoFile };
  };
  const mapAirportCode = (destination: any, origin: any, stopOver: any) => {
    const mappingAirportCode = airports.filter(
      (airport: any) => airport.airportCode === destination.airportCode
    )[0];
    return {
      airportCode: mappingAirportCode?.airportCode,
      cityName: mappingAirportCode?.cityName,
      stopOver: stopOver,
    };
  };

  // arrivalTime:  DeprtureTime
  const calculateTime = (arrivalTime: any, DepartureTime: any) => {
    const departureDate: any = new Date(DepartureTime);
    const arrivalDate: any = new Date(arrivalTime);

    // Calculate the difference in milliseconds
    const timeDifference = arrivalDate - departureDate;
    // Convert the difference to minutes and hours
    const diffMinutes = Math.floor(timeDifference / (1000 * 60)) % 60;
    const diffHours = Math.floor(timeDifference / (1000 * 60 * 60));
    return { hours: diffHours, minutes: diffMinutes };
  };

  const allSearchDatafunc = (data: any) => {
    const getFilterData = getFilterFlights(data, filteredSearchItenary);
    setAllSearchItenary(getFilterData);
  };


   const filterItinerary = (filterItenery:any, item:any)=> {
    return filterItenery.filter((itinerary:any) => {
      return itinerary.flights.some((flight:any) => {
        return flight.some((segment:any) => {
          const airlineMatch = segment.airline === item.airline;
          const fareMatch = itinerary.totalFare === item.totalFare;
          return airlineMatch && fareMatch;
        });
      });
    });
  };

   const onFilterSearchData  =(item:any)=>{
    const getFilterData = filterItinerary( filteredSearchItenary,item);
    setSliderScrollData(getFilterData)
  }
  // Find the minimum totalFare
  const minFare = [
    ...Itenaryfilter.zero,
    ...Itenaryfilter.one,
    ...Itenaryfilter.two,
  ].reduce((min: any, flight: any) => {
    return flight.totalFare < min ? flight.totalFare : min;
  }, Itenaryfilter?.zero[0]?.totalFare);

  const NonStopMinimumFare = Itenaryfilter.zero.reduce(
    (min: any, flight: any) => {
      return flight.totalFare < min ? flight.totalFare : min;
    },
    Itenaryfilter?.zero[0]?.totalFare
  );

  const OneStopMinimumFare = Itenaryfilter.one.reduce(
    (min: any, flight: any) => {
      return flight.totalFare < min ? flight.totalFare : min;
    },
    Itenaryfilter?.one[0]?.totalFare
  );

  const MultiStopMinimumFare = Itenaryfilter.two.reduce(
    (min: any, flight: any) => {
      return flight.totalFare < min ? flight.totalFare : min;
    },
    Itenaryfilter?.two[0]?.totalFare
  );
  const maximumTotalFare = [
    ...Itenaryfilter.zero,
    ...Itenaryfilter.one,
    ...Itenaryfilter.two,
  ].reduce((max: any, flight: any) => {
    return flight.totalFare > max ? flight.totalFare : max;
  }, [...Itenaryfilter?.zero, ...Itenaryfilter?.one, ...Itenaryfilter?.two][0]?.totalFare);

  const minimumTotalFare = [
    ...Itenaryfilter.zero,
    ...Itenaryfilter.one,
    ...Itenaryfilter.two,
  ].reduce((min: any, flight: any) => {
    return flight.totalFare < min ? flight.totalFare : min;
  }, [...Itenaryfilter?.zero, ...Itenaryfilter?.one, ...Itenaryfilter?.two][0]?.totalFare);

  const getFilterFlights = (allSearchData: any, fullItery: any) => {
    let itenaryFlights = [...fullItery];

    if (
      allSearchData?.stop.zeroStop ||
      allSearchData.stop.oneStop ||
      allSearchData.stop.twoStop
    ) {
      itenaryFlights = itenaryFlights.filter((item) =>
        item.flights.some((flight: any) => {
          const hasDesiredStops = flight.some((segment: any) => {
            const isZeroStop =
              allSearchData.stop.zeroStop && segment.stops === 0;
            const isOneStop = allSearchData.stop.oneStop && segment.stops === 1;
            const isTwoStop = allSearchData.stop.twoStop && segment.stops === 2;
            return isZeroStop || isOneStop || isTwoStop;
          });
          return hasDesiredStops;
        })
      );
    }

    if (allSearchData?.airlines?.length > 0) {
      itenaryFlights = itenaryFlights?.filter((item: any) => {
        return item.flights.some((flight: any) => {
          return flight.some((segment: any) => {
            return allSearchData.airlines.some((airline: any) => {
              return airline.airline === segment.airline;
            });
          });
        });
      });
    }

    if (
      allSearchData?.flightExperience?.overnight ||
      allSearchData?.flightExperience?.noLongStop
    ) {
      itenaryFlights = itenaryFlights?.filter((item: any) => {
        return item.flights.some((flight: any) => {
          return flight.some((segment: any) => {
            return (
              (allSearchData?.flightExperience?.overnight &&
                isOvernightFlight(segment)) ||
              (allSearchData?.flightExperience?.noLongStop &&
                hasLongStop(segment))
            );
          });
        });
      });
    }

    if (
      allSearchData?.farePolicy?.refundable ||
      allSearchData?.farePolicy?.nonrefundable
    ) {
      itenaryFlights = itenaryFlights?.filter((item: any) => {
        return (
          (allSearchData?.farePolicy?.refundable && !item.nonRefundable) ||
          (allSearchData?.farePolicy.nonrefundable && item.nonRefundable)
        );
      });
    }

    if (allSearchData?.flightNumber) {
      itenaryFlights = itenaryFlights?.filter((item: any) => {
        return item.flights.some((flight: any) => {
          return flight.some((segment: any) => {
            return (
              Number(segment.flightNumber) ===
              Number(allSearchData.flightNumber)
            );
          });
        });
      });
    }

    if (
      !isNaN(allSearchData?.priceRange[0]) ||
      !isNaN(allSearchData?.priceRange[1])
    ) {
      const [minPrice, maxPrice] = allSearchData.priceRange;
      itenaryFlights = itenaryFlights.filter((item: any) => {
        return item.totalFare >= minPrice && item.totalFare <= maxPrice;
      });
    }

    if (allSearchData?.layoverAirports?.length > 0) {
      itenaryFlights = itenaryFlights?.filter((item: any) => {
        return item.flights.some((flight: any) => {
          return flight.every((segment: any) => {
            return !allSearchData.layoverAirports.some((airport: any) => {
              return airport?.cityName === segment?.destination?.cityName;
            });
          });
        });
      });
    }

    return itenaryFlights;
  };

  // Utility function to parse time and determine the part of the day
  function getTimeOfDay(timeString: any) {
    const hour = new Date(timeString).getHours();
    if (hour >= 5 && hour < 12) return 'morning';
    if (hour >= 12 && hour < 17) return 'midnoon';
    if (hour >= 17 && hour < 21) return 'sunset';
    return 'night';
  }

  // Helper function to check if a flight is overnight
  const isOvernightFlight = (segment: any) => {
    const departureTime = new Date(segment.departureTime);
    const arrivalTime = new Date(segment.arrivalTime);
    return departureTime.getDate() !== arrivalTime.getDate();
  };

  // Helper function to check if a flight has long stop
  const hasLongStop = (segment: any) => {
    const groundTime = segment.groundTime
      ? segment.groundTime.split(':').map(Number)
      : [0, 0, 0];
    return groundTime[0] >= 6; // considering long stop as more than or equal to 6 hours
  };

  const onSendDateObject = async (type: number, dateTime: any) => {
    let updateSearchData: any = null;
    if (type == 1) {
      updateSearchData = {
        ...searchPayload,
        segments: searchPayload.segments.map((item: any, index: number) => {
          if (index === 0) {
            return {
              ...item,
              preferredArrivalTime: new Date(dateTime).toISOString(),

              preferredDepartureTime: new Date(dateTime).toISOString(),
            };
          } else {
            return item;
          }
        }),
      };
    }
    if (type == 2) {
      updateSearchData = {
        ...searchPayload,
        segments: searchPayload.segments.map((item: any, index: number) => {
          if (index === 1) {
            return {
              ...item,
              preferredArrivalTime: new Date(dateTime).toISOString(),
              preferredDepartureTime: new Date(dateTime).toISOString(),
            };
          } else {
            return item;
          }
        }),
      };
    }
    saveFlightSearchResults([]);
    saveSearchPayloadResults(updateSearchData);
    setLoader(true);
    const response: any = await searchFlights(updateSearchData);
    setLoader(false);
    try {
      if (response.status == 200 && response?.data) {
        refreshAirlineData();
        saveFlightSearchResults(response?.data);
        setAllSearchItenary(response?.data);
      } else {
        toast.error(response?.errorMessage);
        refreshAirlineData();
        saveFlightSearchResults([]);
        setAllSearchItenary([]);
      }
    } catch {
      refreshAirlineData();
      saveFlightSearchResults([]);
      setAllSearchItenary([]);
      toast.error('An error occurred. Please try again later.');
    }
  };
  const handleSelectChange = (e: any) => {
    let sortedAllSearchItenary = [...filteredSearchItenary]; // Create a new array

    if (e.target.value === 'Price') {
      sortedAllSearchItenary = sortedAllSearchItenary.sort(
        (a, b) => a.totalFare - b.totalFare
      );
    }
    if (e.target.value === 'Departure') {
      sortedAllSearchItenary = sortedAllSearchItenary.sort((a, b) => {
        const DateA: any = new Date(a.flights[0][0].departureTime);
        const DateB: any = new Date(b.flights[0][0].departureTime);
        return DateA - DateB;
      });
    }
    if (e.target.value === 'Arrival') {
      const getLastArrivalTime = (item: any): Date => {
        const journey = item.flights?.[0] || [];
        const lastFlight = journey[journey.length - 1];
        const arrivalTimeStr = lastFlight?.arrivalTime;
        return arrivalTimeStr ? new Date(arrivalTimeStr) : new Date(0);
      };
      sortedAllSearchItenary = sortedAllSearchItenary.sort((a, b) => {
        const dateA = getLastArrivalTime(a);
        const dateB = getLastArrivalTime(b);
        return dateA.getTime() - dateB.getTime();
      });
    }
    if (e.target.value === 'Duration') {
      const parseDurationToSeconds = (duration: string): number => {
        if (!duration) return 0;
        const [hours = '0', minutes = '0', seconds = '0'] = duration.split(':');
        return Number(hours) * 3600 + Number(minutes) * 60 + Number(seconds);
      };

      const getTotalDuration = (flights: any): number => {
        const duration1 = flights?.[0]?.[0]?.duration || '00:00:00';
        const duration2 = flights?.[0]?.[1]?.duration || '00:00:00';

        return (
          parseDurationToSeconds(duration1) + parseDurationToSeconds(duration2)
        );
      };

      const sortFlightsByDuration = (sortedAllSearchItenary: any[]): any[] => {
        return sortedAllSearchItenary.sort((a: any, b: any) => {
          const durationA = getTotalDuration(a?.flights);
          const durationB = getTotalDuration(b?.flights);
          return durationA - durationB;
        });
      };

      sortedAllSearchItenary = sortFlightsByDuration(sortedAllSearchItenary);
    }

    if (e.target.value === 'Airline') {
      sortedAllSearchItenary = sortedAllSearchItenary.sort((a, b) => {
        const airlineA = a.flights[0][0].airline;
        const airlineB = b.flights[0][0].airline;

        if (airlineA < airlineB) return -1;
        if (airlineA > airlineB) return 1;
        return 0;
      });
    }
    setAllSearchItenary(sortedAllSearchItenary); // Set the new sorted array
  };

  return (
    <>
      <MainLayout>
        <section>
          <div className="container">
            <FlightSearchBox isRes={true} />
            <div className="row">
              {loader ? (
                <div className="col-lg-4 mt-1">
                  <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                    <Skeleton height={100} />
                  </SkeletonTheme>
                </div>
              ) : (
                <BestPrice onSendDateObject={onSendDateObject} />
              )}

              <div
                className={`col-lg-8 col-lg-offset-2 mt-1 ${styles['airticketslide']} airticket-slider bg-border`}
              >
                {loader ? (
                  <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                    <Skeleton height={100} />
                  </SkeletonTheme>
                ) : (
                  <AirticketSlider filtersearchData={Itenaryfilter} onFilterSearchData ={onFilterSearchData} />
                )}
              </div>
            </div>

            <div className="row mt-3">
              {loader ? (
                <div className="col-lg-3">
                  <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                    <Skeleton height={900} />
                  </SkeletonTheme>
                </div>
              ) : (
                <SearchFilter
                  Itenaryfilter={Itenaryfilter}
                  NonStopMinimumFare={NonStopMinimumFare}
                  OneStopMinimumFare={OneStopMinimumFare}
                  MultiStopMinimumFare={MultiStopMinimumFare}
                  maximumTotalFare={maximumTotalFare}
                  minimumTotalFare={minimumTotalFare}
                  filteredSearchItenary={filteredSearchItenary}
                  allSearchDatafunc={allSearchDatafunc}
                  allSearchItenary={allSearchItenary}
                />
              )}

              <div className="col-lg-9">
                {loader ? (
                  <div className='mb-3'>
                    <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                      <Skeleton height={50} />
                    </SkeletonTheme>
                  </div>
                ) : (
                  <FindBestAboutAirlines
                    handleSelectChange={handleSelectChange}
                    cheapestFlights={cheapestFlights}
                    quckestFlight={quckestFlight}
                    bestFlight={bestFlight}
                  />
                )}
                {loader ? (
                  <div className='d-flex flex-column gap-2 mb-2'>
                    <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                      <Skeleton height={150} />
                    </SkeletonTheme>
                    <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                      <Skeleton height={150} />
                    </SkeletonTheme>
                    <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                      <Skeleton height={150} />
                    </SkeletonTheme>
                    <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                      <Skeleton height={150} />
                    </SkeletonTheme>
                    <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                      <Skeleton height={150} />
                    </SkeletonTheme>
                    <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                      <Skeleton height={150} />
                    </SkeletonTheme>
                  </div>
                ) : allSearchItenary && allSearchItenary?.length !== 0 ? (
                  allSearchItenary.map((itinerary: any, index: any) => (
                    <div key={index}>
                      <Itinerary
                      sliderScrolldata ={sliderScrolldata}
                        cheapestFlights={cheapestFlights}
                        itinerary={itinerary}
                        type={searchPayload.type}
                      />
                    </div>
                  ))
                ) : (
                  <>
                    {loader ? (
                      <span></span>
                    ) : (
                      <Link to="/home">
                        <span>No results found. Try to search again</span>
                      </Link>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        </section>
      </MainLayout>
      {/* {loader && <Loader />} */}
    </>
  );
};
export default SearchFlight;
