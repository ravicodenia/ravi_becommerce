import { useState, useEffect } from 'react';
import RecentSearch from './pages/recentSearch';
import Promotions from './pages/promotions';
import BookingsTables from './pages/bookingstables';
import { useStore, useHotelStore, RootState } from '@mfa-travel-app/store';
import {
  getRecentSearch,
  getAllTransaction,
  getBankDetails,
  getSupportDetails,
  getNotificationSearch,
  getSliderImages,
  getContactDetails
} from '../lib/service/homeApi';
import {
  getAllAirlinesList,
  getAllAirportsList,
} from '../lib/service/flightApi';
import { toast } from 'react-toastify';
import { Loader } from '@mfa-travel-app/ui';
import FlightSearchBox from './pages/flightSearchBox';
import { useSelector } from 'react-redux';


export const Home = () => {
  const {
    saveAirlineList,
    saveAirportList,
    saveRecentSearch,
    saveTansactionDetails,
    saveSearchPayloadResults,
    refreshAirlineData,
    saveFlightSearchResults,
    saveBankDetails,
    saveSupportResults,
    saveContactResults,
    saveSliderImagesData,
    saveNotificationDetails,
  } = useStore();
  const {
    refreshHotelData,
    saveHotelSearchPayloadResults,
    saveHotelSearchResults,
  } = useHotelStore();
  const { airlines, airports, recentSearchData, transactionData } = useSelector(
    (state: RootState) => state.flight
  );
  const { contactData, bankData, supportData, notificationData, sliderImages } = useSelector(
    (state: RootState) => state.config
  );

  const [loader, setLoader] = useState(false);

  const getAllInitialData = async () => {
    if (airlines?.length == 0) {
      try {
        setLoader(true);
        const airlineList: any = await getAllAirlinesList();
        setLoader(false);
        if (airlineList?.data && airlineList.status == 200) {
          saveAirlineList(airlineList?.data);
        } else {
          toast.error(airlineList?.data.error.message);
        }
      } catch (error) {
        toast.error('An error occurred. Please try again later.');
      }
    }

    if (airports?.length == 0) {
      try {
        setLoader(true);
        const airportList: any = await getAllAirportsList(1);
        setLoader(false);
        if (airportList?.data && airportList.status == 200) {
          saveAirportList(airportList?.data);
        } else {
          toast.error(airportList?.data.error.message);
        }
      } catch {
        toast.error('An error occurred. Please try again later.');
      }
    }

    if (recentSearchData?.length == 0) {
      try {
        setLoader(true);
        const recentSearch: any = await getRecentSearch(1);
        setLoader(false);
        if (recentSearch?.data && recentSearch.status == 200) {
          saveRecentSearch(recentSearch?.data);
        } else {
          toast.error(recentSearch?.data.error.message);
        }
      } catch {
        toast.error('An error occurred. Please try again later.');
      }
    }

    if (transactionData?.length == 0) {
      try {
        setLoader(true);
        const transaction: any = await getAllTransaction(1);
        setLoader(false);
        if (transaction?.data && transaction.status == 200) {
          saveTansactionDetails(transaction?.data);
        } else {
          toast.error(transaction?.data.error.message);
        }
      } catch {
        toast.error('An error occurred. Please try again later.');
      }
    }

    if (bankData == '') {
      try {
        setLoader(true);
        const bankDataRes: any = await getBankDetails(1);
        setLoader(false);
        if (bankDataRes?.data && bankDataRes.status == 200) {
          saveBankDetails(bankDataRes?.data?.data);
        } else {
          toast.error(bankDataRes?.data.error.message);
        }
      } catch {
        toast.error('An error occurred. Please try again later.');
      }
    }

    if (supportData == '') {
      try {
        setLoader(true);
        const supportDataRes: any = await getSupportDetails(1);
        setLoader(false);
        if (supportDataRes?.data && supportDataRes.status == 200) {
          saveSupportResults(supportDataRes?.data?.data);
        } else {
          toast.error(supportDataRes?.data.error.message);
        }
      } catch {
        toast.error('An error occurred. Please try again later.');
      }
    }
   
    if (contactData == '') {
      try {
        setLoader(true);
        const contactDataRes: any = await  getContactDetails(1);
        setLoader(false);
        if (contactDataRes?.data && contactDataRes.status == 200) {
          saveContactResults(contactDataRes?.data);
        } else {
          toast.error(contactDataRes?.data.error.message);
        }
      } catch {
        toast.error('An error occurred. Please try again later.');
      }
    }

    if (notificationData?.length == 0) {
      try {
        setLoader(true);
        const notificationDataRes: any = await getNotificationSearch(1);
        setLoader(false);
        if (notificationDataRes?.data && notificationDataRes.status == 200) {
          saveNotificationDetails(notificationDataRes?.data);
        } else {
          toast.error(notificationDataRes?.data.error.message);
        }
      } catch {
        toast.error('An error occurred. Please try again later.');
      }
    }

    if (sliderImages?.length == 0) {
      try {
        setLoader(true);
        const sliderImagesDataRes: any = await getSliderImages(1);
        setLoader(false);
        if (sliderImagesDataRes?.data && sliderImagesDataRes.status == 200) {
          saveSliderImagesData(sliderImagesDataRes?.data);
        } else {
          toast.error(sliderImagesDataRes?.data.error.message);
        }
      } catch {
        toast.error('An error occurred. Please try again later.');
      }
    }
  };

  useEffect(() => {
    getAllInitialData();
    saveSearchPayloadResults({});
    saveHotelSearchPayloadResults({});
    saveHotelSearchResults([]);
    saveFlightSearchResults([]);
    refreshAirlineData();
    refreshHotelData();
  }, []);

  return (
    <>
      <div>
        <FlightSearchBox isRes={false} />
      </div>
      <RecentSearch />
      <Promotions />
      <BookingsTables />
      {loader && <Loader />}
    </>
  );
};

export default Home;
