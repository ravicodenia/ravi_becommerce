import { MainLayout } from '@mfa-travel-app/layout';

const ErrorPage = () => {
    return (
        <>
            <MainLayout>
                <div style={{ height: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>This page is not found please search try Again or contact with Support Team</div>
            </MainLayout>
        </>
    )
}
export default ErrorPage;