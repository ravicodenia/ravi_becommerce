import React, { useEffect, useState } from 'react';
import Select from 'react-select';
import styles from '../oneway.module.scss';
import classNames from 'classnames';
import { useSelector } from 'react-redux';
import { RootState } from '@mfa-travel-app/store';

interface Supplier {
  value: string;
  label: string;
}

function AdditionalSerach({
  selectedAirlines,
  setSelectedAirlines,
  selectedFareTypes,
  setSelectedFareTypes,
  markup,
  setMarkup,
  selectedSupplier,
  setSelectedSupplier,
  directFlights,
  setDirectFlights,
  refundableFaresOnly,
  setRefundableFaresOnly,
}: any) {
  const { suppliers } = useSelector((state: RootState) => state.config);
  const { airlines } = useSelector((state: RootState) => state.flight);
  const [supplierOptions, setSupplierOptions] = useState<Supplier[]>(suppliers);
  const [showSuppliers, setShowSuppliers] = useState<boolean>(false);
  const [airlineOptions, setAirlineOptions] = useState<any[]>([]);

  useEffect(() => {
    if (suppliers && suppliers.length > 0) {
      const options = suppliers
        .filter((s: any) => s.productId === 1)
        .map((supplier: any) => ({
          value: supplier.code,
          label: supplier.text,
        }));
      setSupplierOptions(options);
      setSelectedSupplier(options); 
    }
  }, [suppliers]);

  useEffect(() => {
    if (airlines && airlines.length > 0) {
      setAirlineOptions(
        airlines.map((airline: any) => ({
          value: airline.code,
          label: airline.name,
        }))
      );
    }
  }, [airlines]);

  const fareTypeOptions = [{ value: 'published', label: 'Published' }];

  const handleSupplierClick = () => {
    setShowSuppliers(!showSuppliers);
  };

  const handleOutsideClick = (event: MouseEvent) => {
    const target = event.target as HTMLElement;
    if (!target.closest || !target.classList) {
      return;
    }

    if (
      !target.closest('#selectSuppliers') &&
      !target.classList.contains('supplier')
    ) {
      setShowSuppliers(false);
    }
  };

  useEffect(() => {
    document.body.addEventListener('click', handleOutsideClick);
    return () => {
      document.body.removeEventListener('click', handleOutsideClick);
    };
  }, []);

  return (
    <div id="div_additional_flight_search">
      <div className="row mt-2">
        <div className="col-lg-4 mb-2">

          <label htmlFor="preferred-airline" className={styles['form-label']}>
            Preferred Airline
          </label>
          <Select
            isMulti
            options={airlineOptions}
            value={selectedAirlines}
            onChange={(selectedOptions) =>
              setSelectedAirlines(
                selectedOptions as { value: string; label: string }[]
              )
            }
          />

        </div>

        <div className="col-lg-4 mb-2">
          <label htmlFor="faretypelist" className={styles['form-label']}>
            Select Fare Type
          </label>
          <Select
            isMulti
            options={fareTypeOptions}
            value={selectedFareTypes}
            onChange={(selectedOptions) =>
              setSelectedFareTypes(
                selectedOptions as { value: string; label: string }[]
              )
            }
          />
        </div>

        {/* <div className="col-lg-3 mb-2">

          <label htmlFor="markupin" className={styles['form-label']}>
            Markup in %
          </label>
          <input
            type="number"
            className={classNames(
              'form-control',
              styles['input-padd-markup']
            )}
            id="markupin"
            placeholder="Markup in %"
            value={markup}
            onChange={(e) => setMarkup(e.target.value)}
          />

        </div> */}

        <div className="col-lg-4 mb-2">

          <label htmlFor="supplierslist" className={styles['form-label']}>
            Select Suppliers
          </label>
          <Select
            isMulti
            options={supplierOptions}
            value={selectedSupplier}
            onChange={(selectedOptions) =>
              setSelectedSupplier(
                selectedOptions as { value: string; label: string }[]
              )
            }
          />

        </div>
      </div>

      <div className="col-lg-3 mb-2">
        <div className='form-check'>
          <input
            className="form-check-input"
            type="checkbox"
            checked={directFlights}
            id="direct-flights"
            onChange={() => setDirectFlights(!directFlights)}
          />
          <label className="form-check-label" htmlFor="direct-flights">Direct Flights</label>
        </div>
      </div>

      <div className="col-lg-3 mb-2">
        <div className='form-check'>
          <input
            className="form-check-input"
            type="checkbox"
            checked={refundableFaresOnly}
            id="refundable-fares-only"
            onChange={() => setRefundableFaresOnly(!refundableFaresOnly)}
          />
          <label className="form-check-label" htmlFor="refundable-fares-only"> Refundable fares only</label>
        </div>
      </div>

    </div>

  );
}

export default AdditionalSerach;
