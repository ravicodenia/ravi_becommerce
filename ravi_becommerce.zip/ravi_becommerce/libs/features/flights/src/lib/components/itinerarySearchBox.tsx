import React, { useEffect, useState, forwardRef, useImperativeHandle } from 'react';
import styles from '../oneway.module.scss';
import classNames from 'classnames';
import { AirportContainer } from '@mfa-travel-app/shared';
import SelectedDate from '../../Components/SelectedDate';
import { useSelector } from 'react-redux';
import { RootState } from '@mfa-travel-app/store';
import TravellersClass from '../../Components/TravellersClass';
import { toast } from 'react-toastify';

const ONEWAY = 1;
const RETURNWAY = 2;
const MULTIWAY = 3;
interface ITravellerDetails {
  adults: number;
  children: number;
  infants: number;
  selectedOption: { name: string; value: number };
}
const ItinerarySearchBox = forwardRef(({
  selectedAirlines,
  recentSearch,
  searchFlightsCommon,
}: any, ref) => {

  const { searchPayload } = useSelector((state: RootState) => state.flight);
  const { homeScreenShowHide }: any = useSelector((state: RootState) => state.config);
  const [flightType, setFlightType] = useState(RETURNWAY);
  const [trCash, setTRCash] = useState(false);
  const [selectedAirportFrom, setSelectedAirportFrom] = useState<any>();
  const [selectedAirportTo, setSelectedAirportTo] = useState<any>(null);
  const [showPopup, setShowPopup] = useState<any>(false);

  const [airportSelectdateDepartureDate, setAirportSelectdateDepartureDate] =
    useState<any>(null);
  const [airportSelectdateReturnDate, setAirportSelectdateReturnDate] =
    useState<any>(new Date());
  const [allTravellersData, setAllTravellersData] = useState<ITravellerDetails>(
    {
      adults:
        recentSearch && recentSearch.adultCount ? recentSearch.adultCount : 1,
      children:
        recentSearch && recentSearch.childCount ? recentSearch.childCount : 0,
      infants:
        recentSearch && recentSearch.infantCount ? recentSearch.infantCount : 0,
      selectedOption: { name: 'Economy', value: 1 },
    }
  );
  const showSelfClientHomeSreen = homeScreenShowHide?.some((item: any) => item.text === "SHOW SELF CLIENT" && item.show);
  const handleFlightTypeChange = (type: any) => {
    setFlightType(type);
  };

  const handleAirportSelectFrom = (airport: any) => {
    setSelectedAirportFrom(airport);
  };
  const handleAirportSelectTo = (airport: any) => {
    setSelectedAirportTo(airport);
  };

  const handleAirportSelectdateDeparture = (formattedDate: string, date: any) => {
    setAirportSelectdateDepartureDate(date);
    if (flightType !== ONEWAY) setShowPopup(true);
  };

  const handleAirportSelectdateReturn = (formattedDate: string, date: any) => {
    setAirportSelectdateReturnDate(date);
    setShowPopup(false);
  };

  const handleAllTravellers = ({
    adults,
    children,
    infants,
    selectedOption,
  }: any) => {
    setAllTravellersData({ adults, children, infants, selectedOption });
  };

  useEffect(() => {
    if (searchPayload?.type) {
      setFlightType(searchPayload.type);
    } else {
      setFlightType(RETURNWAY);
    }
    if (searchPayload && searchPayload.segments) {
      const depDate = new Date(searchPayload?.segments[0]?.preferredDepartureTime);
      setAirportSelectdateDepartureDate(depDate);
      if (flightType === RETURNWAY) {
        // console.log(searchPayload?.segments[1]?.preferredDepartureTime);
        let retDate: any = new Date(searchPayload?.segments[1]?.preferredDepartureTime);
        const today = new Date();
        const depDate = today.setDate(today.getDate() + 2);
        retDate = (retDate == 'Invalid Date') ? depDate : retDate
        setAirportSelectdateReturnDate(retDate);
      }
    } else {
      const today = new Date();
      const depDate = today.setDate(today.getDate() + 1);
      setAirportSelectdateDepartureDate(depDate);
      const arrDate = today.setDate(today.getDate() + 1);
      setAirportSelectdateReturnDate(arrDate);
    }
  }, [searchPayload]);

  const SearchReturnFlights = () => {
    const depDateString =
      typeof airportSelectdateDepartureDate == 'string'
        ? airportSelectdateDepartureDate
        : new Date(airportSelectdateDepartureDate)?.toISOString();

    const arrDateString =
      typeof airportSelectdateReturnDate == 'string'
        ? airportSelectdateReturnDate
        : new Date(airportSelectdateReturnDate)?.toISOString();

    if (selectedAirportFrom == null || selectedAirportTo == null) {
      toast.error('Please fill all required fields');
    } else if (selectedAirportFrom?.airportCode == selectedAirportTo?.airportCode) {
      toast.error('Origin and Destination airports are the same');
    } else if (flightType !== ONEWAY && depDateString == arrDateString) {
      toast.error('Departure and Arrival dates cannot be the same');
    } else {
      let segments: any = [
        {
          origin: selectedAirportFrom?.airportCode,
          destination: selectedAirportTo?.airportCode,
          preferredDepartureTime:
            typeof airportSelectdateDepartureDate == 'string'
              ? airportSelectdateDepartureDate
              : new Date(airportSelectdateDepartureDate)?.toISOString(),
          preferredArrivalTime:
            typeof airportSelectdateDepartureDate == 'string'
              ? airportSelectdateDepartureDate
              : new Date(airportSelectdateDepartureDate)?.toISOString(),
          flightCabinClass: allTravellersData?.selectedOption?.value
            ? allTravellersData?.selectedOption?.value
            : 0,
          preferredAirlines: selectedAirlines
            ? selectedAirlines.map((a: any) => a.code)
            : [],
          nearByOriginPort: false,
        },
      ];
      if (flightType !== ONEWAY) {
        segments.push({
          origin: selectedAirportTo?.airportCode,
          destination: selectedAirportFrom?.airportCode,
          preferredDepartureTime:
            typeof airportSelectdateReturnDate == 'string'
              ? airportSelectdateReturnDate
              : new Date(airportSelectdateReturnDate)?.toISOString(),
          preferredArrivalTime:
            typeof airportSelectdateReturnDate == 'string'
              ? airportSelectdateReturnDate
              : new Date(airportSelectdateReturnDate)?.toISOString(),
          flightCabinClass: allTravellersData?.selectedOption?.value
            ? allTravellersData?.selectedOption?.value
            : 0,
          preferredAirlines: selectedAirlines
            ? selectedAirlines.map((a: any) => a.code)
            : [],
          nearByOriginPort: false,
        });
      }

      searchFlightsCommon(flightType, segments, allTravellersData, true);
    }
  };

  const handleTrCash = () => {
    setTRCash(!trCash);
  };

  useImperativeHandle(ref, () => ({
    SearchReturnFlights,
  }));

  return (
    <>
      <div className="row">
        <div className="col-8 text-start">

          <button
            className={classNames('me-1',
              styles['onewayflight'],
              styles['flightstab'],
              `${flightType === 1 ? styles['active-radio'] : ''}`
            )}
            onClick={() => handleFlightTypeChange(ONEWAY)}
          >
            One Way
          </button>

          <button
            className={classNames('me-1',
              styles['returnflight'],
              styles['flightstab'],
              `${flightType === 2 ? styles['active-radio'] : ''}`
            )}
            onClick={() => handleFlightTypeChange(RETURNWAY)}
          >
            Return
          </button>

          {/* <button
            className={classNames(
              styles['multistopflight'],
              styles['flightstab'],
              `${flightType === 3 ? styles['active-radio'] : ''}`
            )}
            onClick={() => handleFlightTypeChange(MULTIWAY)}
          >
            Multi-stop
          </button> */}
        </div>
        {/* {showSelfClientHomeSreen && <div className="col-4 text-end">
          <div className="toogleRadioBtn">
            <div className="form-check form-switch">
              <input
                className="form-check-input"
                type="checkbox"
                name="self-client-toogle"
                id="home-client-toogle"
                onChange={handleTrCash}
              />
              <label className="form-check-label" htmlFor="home-client-toogle">
                Client
              </label>
            </div>
          </div>
        </div>
        } */}
      </div>
      <div className="mt-3" id="oneway">
        <div id="section_oneway_return" className="row align-items-center">
          <div className="col-lg-5" id="div_onway_return_des">
            <div className="row">
              <div
                className={classNames('col-lg-6', styles['flyingplaces'])}
                style={{ position: 'relative' }}
              >
                <AirportContainer
                  Source={'From'}
                  icon={
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="27"
                      viewBox="0 0 640 512"
                    >
                      <path d="M381 114.9L186.1 41.8c-16.7-6.2-35.2-5.3-51.1 2.7L89.1 67.4C78 73 77.2 88.5 87.6 95.2l146.9 94.5L136 240 77.8 214.1c-8.7-3.9-18.8-3.7-27.3 .6L18.3 230.8c-9.3 4.7-11.8 16.8-5 24.7l73.1 85.3c6.1 7.1 15 11.2 24.3 11.2H248.4c5 0 9.9-1.2 14.3-3.4L535.6 212.2c46.5-23.3 82.5-63.3 100.8-112C645.9 75 627.2 48 600.2 48H542.8c-20.2 0-40.2 4.8-58.2 14L381 114.9zM0 480c0 17.7 14.3 32 32 32H608c17.7 0 32-14.3 32-32s-14.3-32-32-32H32c-17.7 0-32 14.3-32 32z" />
                    </svg>
                  }
                  onAirportSelect={handleAirportSelectFrom}
                  airportPayload={
                    searchPayload?.segments && searchPayload?.segments[0].origin
                  }
                />
              </div>
              <div className={classNames('col-lg-6', styles['flyingplaces'])}>
                <AirportContainer
                  Source={'To'}
                  icon={
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="27"
                      viewBox="0 0 640 512"
                    >
                      <path d="M381 114.9L186.1 41.8c-16.7-6.2-35.2-5.3-51.1 2.7L89.1 67.4C78 73 77.2 88.5 87.6 95.2l146.9 94.5L136 240 77.8 214.1c-8.7-3.9-18.8-3.7-27.3 .6L18.3 230.8c-9.3 4.7-11.8 16.8-5 24.7l73.1 85.3c6.1 7.1 15 11.2 24.3 11.2H248.4c5 0 9.9-1.2 14.3-3.4L535.6 212.2c46.5-23.3 82.5-63.3 100.8-112C645.9 75 627.2 48 600.2 48H542.8c-20.2 0-40.2 4.8-58.2 14L381 114.9zM0 480c0 17.7 14.3 32 32 32H608c17.7 0 32-14.3 32-32s-14.3-32-32-32H32c-17.7 0-32 14.3-32 32z" />
                    </svg>
                  }
                  onAirportSelect={handleAirportSelectTo}
                  airportPayload={
                    searchPayload?.segments &&
                    searchPayload?.segments[0].destination
                  }
                />
              </div>
            </div>
          </div>

          <div style={{ position: 'relative' }} className="col-lg-3">
            <div className="row">
              <div className="col-6">
                <SelectedDate
                  datePayload={airportSelectdateDepartureDate}
                  onAirportSelectDate={handleAirportSelectdateDeparture}
                  initialDate={new Date()}
                  departureReturn={true}
                  flightType={flightType}
                  text={'Departure'}
                />
              </div>

              <div className="col-6">
                <SelectedDate
                  showPopup={showPopup}
                  setShowPopup={setShowPopup}
                  datePayload={airportSelectdateReturnDate}
                  onAirportSelectDate={handleAirportSelectdateReturn}
                  initialDate={airportSelectdateDepartureDate}
                  departureReturn={flightType == ONEWAY ? false : true}
                  updateFlightTypeToReturn={() => setFlightType(RETURNWAY)}
                  flightType={flightType}
                  text={'Return'}
                />
              </div>
            </div>
          </div>
          <div
            className={classNames(
              'col-lg-2',
              styles['travellersClassStyle'],
              styles['travellersClassStyles']
            )}
          >
            <TravellersClass
              onAllTravellers={handleAllTravellers}
              travellers={allTravellersData}
            />
          </div>
          <div className={classNames('col-lg-2', styles['btn-container'], styles['button-display-search-one'])}>
            <button
              type="button"
              className="btn btn-primary w-100 modifySearch mt-1"
              onClick={() => SearchReturnFlights()}
            >
              <span>
                {' '}
                <i className="fa-solid fa-magnifying-glass"></i> SEARCH
              </span>
            </button>
          </div>
        </div>
      </div>
    </>
  );
});

export default ItinerarySearchBox;
