
import  { useState } from "react";
import Dropdown from 'react-bootstrap/Dropdown';
import { Link   } from "react-router-dom";
import { FaRegFolderOpen } from "react-icons/fa";
import { ImCancelCircle } from "react-icons/im";

import { FaEye } from "react-icons/fa6";
import { LuFileInput } from "react-icons/lu";
import { Modal } from 'react-bootstrap';
import { ControlledSelect } from '@mfa-travel-app/ui';

export default function TQFilter() {

   const [cancelTicket, setCancelTicket] = useState(false); 
   const [changeRequest, setChangeRequest] = useState(false);

   const selectOptions = [
    { id: 1, text: 'Modification' },
    { id: 2, text: 'Refund' },
];

  return (

<>
<Dropdown>
      <Dropdown.Toggle id="dropdown-basic" className="more_icon rounded-circle">
      <i className="fa-solid fa-ellipsis-vertical"></i>       
      </Dropdown.Toggle>

      <Dropdown.Menu>

      <Link  className="dropdown-item" to="/flight-queue-open"> <FaRegFolderOpen/> Open</Link>
      <Link  className="dropdown-item" to=""  onClick={() => setCancelTicket(true)}> <ImCancelCircle/> Cancel</Link>
      <Link className="dropdown-item" to="/view-flight-invoice"> <FaEye/> View Invoice</Link>
      <Link className="dropdown-item" to=""  onClick={() => setChangeRequest(true)}> <LuFileInput/> Chanage Request</Link>

      </Dropdown.Menu>
    </Dropdown>
      
           
       
<Modal
        size="sm"
        centered
        show={cancelTicket}
        onHide={() => setCancelTicket(false)}
      >
    
        
<div className="text-center p-2"> 

    <div className="row">

<div className="col-12 mt-3">
  <svg className="animate__animated animate__shakeY bi bi-exclamation-circle" xmlns="http://www.w3.org/2000/svg" width="70" height="70" fill="#f2aa3b" fill-opacity="0.5" 
viewBox="0 0 16 16">
    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
    <path d="M7.002 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0M7.1 4.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0z"/>
  </svg>
</div>
<div className="col-12 mt-3">
         
<h3>Are you sure want to cancel?</h3>
{/* <p className="mt-2">You won't be able to revert this!</p> */}
</div>

<div className="col-12 mt-3 mb-2">
  <button type="button" className="btn btn-danger text-light me-2">Yes</button>
  <button  onClick={() => setCancelTicket(false)} type="button" className="btn btn-secondary rounded">No</button>
</div>
  </div>

  </div>
</Modal>



{/* //chanage request popup */}

<Modal
        size="sm"
        centered
        show={changeRequest}
        onHide={() => setChangeRequest(false)}
      >
    
        
<div className="p-2"> 

    <div className="row">

    <div className="col-12 mt-3">
<h5>Change Request </h5>

      </div>

<div className="col-12 mt-3">

  <label htmlFor="request_change">Request Change</label>
  <ControlledSelect
                   id={'request_change'}
                   value={''}
                   options={selectOptions}
                   required={true}
                   onChange={''}
               />
</div>


<div className="col-12 mt-3">
<label htmlFor="enter_remark">Remark</label>
<textarea className="form-control" id="enter_remark" rows={3}></textarea>
</div>

<div className="col-12 mt-3 mb-2">

  <button  onClick={() => setChangeRequest(false)} type="button" className="btn btn-primary rounded">Submit Request</button>
</div>
  </div>

  </div>
</Modal>

        

</>
  )
}
