import styles from './flights.module.scss';

/* eslint-disable-next-line */
export interface FlightsProps {}

export function Flights(props: FlightsProps) {
  return (
    <div className={styles['container']}>
      <h1>Welcome to Flights!</h1>
    </div>
  );
}

export default Flights;
