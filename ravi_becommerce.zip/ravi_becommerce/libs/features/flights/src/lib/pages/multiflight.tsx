import React, { useState } from 'react';
import styles from '../oneway.module.scss';
import classNames from 'classnames';
import { useStore, RootState } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { AirportContainer } from '@mfa-travel-app/shared';
import SelectedDate from '../../Components/SelectedDate';
import TravellersClass from '../../Components/TravellersClass';

const MultiFlights = () => {
  const { airlines } = useSelector((state: RootState) => state.flight);
  const { airports } = useSelector((state: RootState) => state.flight);
  const [adults, setAdults] = useState(1);
  const [children, setChildren] = useState(0);
  const [infants, setInfants] = useState(0);
const [ AirportDetailFromMultiFlight,setAirportDetailFromMultiFlight] = useState(null);
const [AirportDetailToMultiFlight,setAirportDetailToMultiFlight] = useState(null);
const[MultiflightDepartureDate,setMultiflightDepartureDate] = useState()
  const handleIncrement = (type: any) => {
    switch (type) {
      case 'adults':
        setAdults(adults + 1);
        break;
      case 'children':
        setChildren(children + 1);
        break;
      case 'infants':
        setInfants(infants + 1);
        break;
      default:
        break;
    }
  };

  const handleDecrement = (type: any) => {
    switch (type) {
      case 'adults':
        setAdults(adults > 0 ? adults - 1 : 0);
        break;
      case 'children':
        setChildren(children > 0 ? children - 1 : 0);
        break;
      case 'infants':
        setInfants(infants > 0 ? infants - 1 : 0);
        break;
      default:
        break;
    }
  };
  const handleAirportSelectFromMultiFlight = (airportDetail:any) =>{
    setAirportDetailFromMultiFlight(airportDetail)
      // console.log("suggetion",airportDetail)
    
  }
  const handleAirportSelectToMultiFlight = (airportDetail:any) =>{
    setAirportDetailToMultiFlight(airportDetail)
// console.log('airportDetail',airportDetail)
  }
  const handleSelectedDateMutiflight = (date:any) =>{
    setMultiflightDepartureDate(date);
// console.log("date",date);
  }
  const handleAllTravellersMultiflight = ({adults, children, infants}:any) =>{
    // console.log('adult children', adults, children, infants);
  }

  const handleAirportSelectToMultiFlightTwice = (airportDetail:any) =>{
    // console.log('airportDetail',airportDetail)
  }
  const handleAirportSelectFromMultiFlightTwice = (airportDetail:any) =>{
    // console.log('airportDetail',airportDetail);
  }
  const handleSelectedDateMutiflightTwice = (date:any) =>{
    // console.log('date',date)
  }
  const handleAllTravellersMultiflightTwice = ({adults, children, infants}:any) =>{
    // console.log('adult children', adults, children, infants);
  }
const handleAirportSelectFromMultiFlightRow = (airport:any) =>{
// console.log("airport",airport);
}
const handleAirportSelectToMultiFlightRow = (airport:any) =>{
  // console.log("airport",airport);
  }
  const handleSelectedDateMutiflightRow = (date:any)=>{
    // console.log("date",date);
  }
  const [istravellersClass, setIsTravellersClass] = useState(false);
  const openTravellersClass = () => {
    setIsTravellersClass(!istravellersClass);
  };
  const TravellersDone = () => {
    setIsTravellersClass(!istravellersClass);
  };

  const [selectedOption, setSelectedOption] = useState('economy'); // 'economy' is the default checked option
  const handleRadioChange = (event: any) => {
    setSelectedOption(event.target.value);
  };

  const [flightType, setFlightType] = useState(''); // '' | 'multistop' | 'oneway' | 'return'
  const [rows, setRows] = useState([1]); // Initial state with one row

  const handleFlightTypeChange = (type: any) => {
    setFlightType(type);
  };

  const addRow = () => {
    setRows([...rows, rows.length + 1]); // Add a new row to the rows state
  };

  const deleteRow = (index: any) => {
    const updatedRows = rows.filter((_, i) => i !== index); // Remove the row at the specified index
    setRows(updatedRows);
  };

  return (
    <div>
      <div className={`multistop-sec`}>
        {/* Multi-stop content */}
        <div className="row justify-content-between">
          <div className="col-lg-6" id="div_onway_return_des">
            <div className="row">
              <div className="col-lg-6" style={{ position: 'relative' }}>
                <a
                  className={styles['switch_destination']}
                  href="javascript:void(0);"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                    <path d="M32 96l320 0V32c0-12.9 7.8-24.6 19.8-29.6s25.7-2.2 34.9 6.9l96 96c6 6 9.4 14.1 9.4 22.6s-3.4 16.6-9.4 22.6l-96 96c-9.2 9.2-22.9 11.9-34.9 6.9s-19.8-16.6-19.8-29.6V160L32 160c-17.7 0-32-14.3-32-32s14.3-32 32-32zM480 352c17.7 0 32 14.3 32 32s-14.3 32-32 32H160v64c0 12.9-7.8 24.6-19.8 29.6s-25.7 2.2-34.9-6.9l-96-96c-6-6-9.4-14.1-9.4-22.6s3.4-16.6 9.4-22.6l96-96c9.2-9.2 22.9-11.9 34.9-6.9s19.8 16.6 19.8 29.6l0 64H480z" />
                  </svg>
                </a>
               
                  <AirportContainer Source={"To"}
                  icon={<svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="27"
                    viewBox="0 0 640 512"
                  >
                    <path d="M381 114.9L186.1 41.8c-16.7-6.2-35.2-5.3-51.1 2.7L89.1 67.4C78 73 77.2 88.5 87.6 95.2l146.9 94.5L136 240 77.8 214.1c-8.7-3.9-18.8-3.7-27.3 .6L18.3 230.8c-9.3 4.7-11.8 16.8-5 24.7l73.1 85.3c6.1 7.1 15 11.2 24.3 11.2H248.4c5 0 9.9-1.2 14.3-3.4L535.6 212.2c46.5-23.3 82.5-63.3 100.8-112C645.9 75 627.2 48 600.2 48H542.8c-20.2 0-40.2 4.8-58.2 14L381 114.9zM0 480c0 17.7 14.3 32 32 32H608c17.7 0 32-14.3 32-32s-14.3-32-32-32H32c-17.7 0-32 14.3-32 32z" />
                  </svg>}
                   onAirportSelect={handleAirportSelectFromMultiFlight} 
                />
              </div>
              <div className="col-lg-6">
              <AirportContainer Source={"To"}
                  icon={<svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="27"
                    viewBox="0 0 640 512"
                  >
                    <path d="M381 114.9L186.1 41.8c-16.7-6.2-35.2-5.3-51.1 2.7L89.1 67.4C78 73 77.2 88.5 87.6 95.2l146.9 94.5L136 240 77.8 214.1c-8.7-3.9-18.8-3.7-27.3 .6L18.3 230.8c-9.3 4.7-11.8 16.8-5 24.7l73.1 85.3c6.1 7.1 15 11.2 24.3 11.2H248.4c5 0 9.9-1.2 14.3-3.4L535.6 212.2c46.5-23.3 82.5-63.3 100.8-112C645.9 75 627.2 48 600.2 48H542.8c-20.2 0-40.2 4.8-58.2 14L381 114.9zM0 480c0 17.7 14.3 32 32 32H608c17.7 0 32-14.3 32-32s-14.3-32-32-32H32c-17.7 0-32 14.3-32 32z" />
                  </svg>}
                   onAirportSelect={handleAirportSelectToMultiFlight} 
                />
              </div>
            </div>
          </div>

          <div className="col-lg-2" id="div_calendar_oneway_return">
          <SelectedDate onAirportSelectDate ={handleSelectedDateMutiflight}/>
          </div>

          <div className="col-lg-2">
               <TravellersClass onAllTravellers = {handleAllTravellersMultiflight}/>
          </div>

          <div className="col-lg-2">
            <button
              type="button"
              className={classNames(
                styles['btn'],
                styles['btn-primary'],
                styles['modifySearch'],
                'mt-1 w-100'
              )}
            >
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                <path d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z" />
              </svg>
              <span>SEARCH</span>{' '}
            </button>
          </div>
        </div>

        <div className="row align-items-center">
          <div className="col-lg-6" id="div_onway_return_des">
            <div className="row">
              <div className="col-lg-6" style={{ position: 'relative' }}>
                <a
                  className={styles['switch_destination']}
                  href="javascript:void(0);"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                    <path d="M32 96l320 0V32c0-12.9 7.8-24.6 19.8-29.6s25.7-2.2 34.9 6.9l96 96c6 6 9.4 14.1 9.4 22.6s-3.4 16.6-9.4 22.6l-96 96c-9.2 9.2-22.9 11.9-34.9 6.9s-19.8-16.6-19.8-29.6V160L32 160c-17.7 0-32-14.3-32-32s14.3-32 32-32zM480 352c17.7 0 32 14.3 32 32s-14.3 32-32 32H160v64c0 12.9-7.8 24.6-19.8 29.6s-25.7 2.2-34.9-6.9l-96-96c-6-6-9.4-14.1-9.4-22.6s3.4-16.6 9.4-22.6l96-96c9.2-9.2 22.9-11.9 34.9-6.9s19.8 16.6 19.8 29.6l0 64H480z" />
                  </svg>
                </a>
               <AirportContainer Source={"To"}
                  icon={<svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="27"
                    viewBox="0 0 640 512"
                  >
                    <path d="M381 114.9L186.1 41.8c-16.7-6.2-35.2-5.3-51.1 2.7L89.1 67.4C78 73 77.2 88.5 87.6 95.2l146.9 94.5L136 240 77.8 214.1c-8.7-3.9-18.8-3.7-27.3 .6L18.3 230.8c-9.3 4.7-11.8 16.8-5 24.7l73.1 85.3c6.1 7.1 15 11.2 24.3 11.2H248.4c5 0 9.9-1.2 14.3-3.4L535.6 212.2c46.5-23.3 82.5-63.3 100.8-112C645.9 75 627.2 48 600.2 48H542.8c-20.2 0-40.2 4.8-58.2 14L381 114.9zM0 480c0 17.7 14.3 32 32 32H608c17.7 0 32-14.3 32-32s-14.3-32-32-32H32c-17.7 0-32 14.3-32 32z" />
                  </svg>}
                   onAirportSelect={handleAirportSelectFromMultiFlightTwice} 
                />
              </div>
              <div className='col-lg-6'>
              <AirportContainer Source={"To"}
                  icon={<svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="27"
                    viewBox="0 0 640 512"
                  >
                    <path d="M381 114.9L186.1 41.8c-16.7-6.2-35.2-5.3-51.1 2.7L89.1 67.4C78 73 77.2 88.5 87.6 95.2l146.9 94.5L136 240 77.8 214.1c-8.7-3.9-18.8-3.7-27.3 .6L18.3 230.8c-9.3 4.7-11.8 16.8-5 24.7l73.1 85.3c6.1 7.1 15 11.2 24.3 11.2H248.4c5 0 9.9-1.2 14.3-3.4L535.6 212.2c46.5-23.3 82.5-63.3 100.8-112C645.9 75 627.2 48 600.2 48H542.8c-20.2 0-40.2 4.8-58.2 14L381 114.9zM0 480c0 17.7 14.3 32 32 32H608c17.7 0 32-14.3 32-32s-14.3-32-32-32H32c-17.7 0-32 14.3-32 32z" />
                  </svg>}
                   onAirportSelect={handleAirportSelectToMultiFlightTwice} 
                />
                </div>
            </div>
          </div>
       <div className='col-lg-2'>
          <SelectedDate onAirportSelectDate ={handleSelectedDateMutiflightTwice}/>
          </div>
          <div className="col-lg-2">
               <TravellersClass onAllTravellers = {handleAllTravellersMultiflightTwice}/>
          </div>
        </div>
        {rows.map((row, index) => (
          <div key={index} className="row my-3 align-items-center">
            <div className="col-lg-6">
              <div className="row">
                <div className="col-lg-6 position-relative">
                  <a
                    className={styles['switch_destination']}
                    href="javascript:void(0);"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 512 512"
                    >
                      <path d="M32 96l320 0V32c0-12.9 7.8-24.6 19.8-29.6s25.7-2.2 34.9 6.9l96 96c6 6 9.4 14.1 9.4 22.6s-3.4 16.6-9.4 22.6l-96 96c-9.2 9.2-22.9 11.9-34.9 6.9s-19.8-16.6-19.8-29.6V160L32 160c-17.7 0-32-14.3-32-32s14.3-32 32-32zM480 352c17.7 0 32 14.3 32 32s-14.3 32-32 32H160v64c0 12.9-7.8 24.6-19.8 29.6s-25.7 2.2-34.9-6.9l-96-96c-6-6-9.4-14.1-9.4-22.6s3.4-16.6 9.4-22.6l96-96c9.2-9.2 22.9-11.9 34.9-6.9s19.8 16.6 19.8 29.6l0 64H480z" />
                    </svg>
                  </a>
                  <AirportContainer Source={"To"}
                  icon={<svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="27"
                    viewBox="0 0 640 512"
                  >
                    <path d="M381 114.9L186.1 41.8c-16.7-6.2-35.2-5.3-51.1 2.7L89.1 67.4C78 73 77.2 88.5 87.6 95.2l146.9 94.5L136 240 77.8 214.1c-8.7-3.9-18.8-3.7-27.3 .6L18.3 230.8c-9.3 4.7-11.8 16.8-5 24.7l73.1 85.3c6.1 7.1 15 11.2 24.3 11.2H248.4c5 0 9.9-1.2 14.3-3.4L535.6 212.2c46.5-23.3 82.5-63.3 100.8-112C645.9 75 627.2 48 600.2 48H542.8c-20.2 0-40.2 4.8-58.2 14L381 114.9zM0 480c0 17.7 14.3 32 32 32H608c17.7 0 32-14.3 32-32s-14.3-32-32-32H32c-17.7 0-32 14.3-32 32z" />
                  </svg>}
                   onAirportSelect={handleAirportSelectFromMultiFlightRow} 
                />
                </div>
                <div className="col-lg-6">
                <AirportContainer Source={"To"}
                  icon={<svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="27"
                    viewBox="0 0 640 512"
                  >
                    <path d="M381 114.9L186.1 41.8c-16.7-6.2-35.2-5.3-51.1 2.7L89.1 67.4C78 73 77.2 88.5 87.6 95.2l146.9 94.5L136 240 77.8 214.1c-8.7-3.9-18.8-3.7-27.3 .6L18.3 230.8c-9.3 4.7-11.8 16.8-5 24.7l73.1 85.3c6.1 7.1 15 11.2 24.3 11.2H248.4c5 0 9.9-1.2 14.3-3.4L535.6 212.2c46.5-23.3 82.5-63.3 100.8-112C645.9 75 627.2 48 600.2 48H542.8c-20.2 0-40.2 4.8-58.2 14L381 114.9zM0 480c0 17.7 14.3 32 32 32H608c17.7 0 32-14.3 32-32s-14.3-32-32-32H32c-17.7 0-32 14.3-32 32z" />
                  </svg>}
                   onAirportSelect={handleAirportSelectToMultiFlightRow} 
                />
                </div>
              </div>
            </div>
            <div className="col-lg-2">
            <SelectedDate onAirportSelectDate ={handleSelectedDateMutiflightRow}/>
            </div>
            <div className="col-lg-2">
              {index === rows.length - 1 && ( // Show "Add Another City" link only for the last row
                <a
                  href="javascript:void(0);"
                  className={styles['addMulticityRow']}
                  onClick={addRow}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="12"
                    viewBox="0 0 448 512"
                  >
                    <path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z" />
                  </svg>
                  Add Another City
                </a>
              )}
            </div>
            {index > 0 && ( // Show delete button for rows after the first one
              <div className="col-lg-2">
                <a
                  href="javascript:void(0);"
                  className={styles['deleteMulticityRow']}
                  onClick={() => deleteRow(index)}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="12"
                    viewBox="0 0 384 512"
                  >
                    <path d="M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z" />
                  </svg>
                </a>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default MultiFlights;
