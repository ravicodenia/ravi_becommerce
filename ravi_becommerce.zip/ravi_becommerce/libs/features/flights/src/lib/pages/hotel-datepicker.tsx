declare module 'hotel-datepicker' {
  interface HotelDatepickerOptions {
    autoClose?: boolean;
    format?: string;
    startOfWeek?: string;
    startDate?: Date;
    endDate?: Date;
    minNights?: number;
    maxNights?: number;
    selectForward?: boolean;
    disabledDates?: string[];
    noCheckInDates?: string[];
    noCheckOutDates?: string[];
    startDatePlaceholder?: string;
    endDatePlaceholder?: string;
    moveBothMonths?: boolean;
    showTopbar?: boolean;
    inline?: boolean;
    clearButton?: boolean;
    submitButton?: boolean;
    submitButtonName?: string;
    topbarPosition?: string;
  }

  class HotelDatepicker {
    constructor(element: HTMLElement, options?: HotelDatepickerOptions);
    open(): void;
    close(): void;
    getValue(): string;
    setValue(start: string, end: string): void;
    destroy(): void;
  }

  export default HotelDatepicker;
}



