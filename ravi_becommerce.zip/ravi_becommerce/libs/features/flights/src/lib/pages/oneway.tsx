import React, { useEffect, useState } from 'react';
import styles from '../oneway.module.scss';
import classNames from 'classnames';
import { AirportContainer } from '@mfa-travel-app/shared';
import SelectedDate from '../../Components/SelectedDate';
import TravellersClass from '../../Components/TravellersClass';
import { useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { RootState } from '@mfa-travel-app/store';

interface ITravellerDetails {
  adults: number;
  children: number;
  infants: number;
  selectedOption: string;
}
const OneWay = ({
  selectedAirlines,
  searchFlightsCommon,
  onSendDepatruture,
  recentSearch,
}: any) => {
  const [selectedAirportFrom, setSelectedAirportFrom] = useState<any>();
  const [selectedAirportTo, setSelectedAirportTo] = useState<any>(null);
  const [AirportSelectdateDeparture, setAirportSelectdateDeparture] = useState(
    Date.now().toString()
  );
  const [AirportSelectdateReturn, setAirportSelectdateReturn] = useState(
    Date.now().toString()
  );

  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const [AirportSelectdateDepartureDate, setAirportSelectdateDepartureDate] = useState<any>(tomorrow);
  const [allTravellersData, setAllTravellersData] = useState<ITravellerDetails>(
    { adults: 1, children: 0, infants: 0, selectedOption: 'Economy' }
  );
  const [selectedOption, setSelectedOption] = useState('economy'); // 'economy' is the default checked option
  const [isInput1Active, setIsInput1Active] = useState(true);
  const { searchPayload } = useSelector((state: RootState) => state.flight);
  const [isFormValid, setIsFormValid] = useState(false);

  useEffect(() => {
    if (onSendDepatruture) {
      onSendDepatruture(AirportSelectdateDepartureDate);
    }
  }, []);

  const handleRadioChange = (event: any) => {
    setSelectedOption(event.target.value);
  };

  const handleAirportSelectFrom = (airport: any) => {
    setSelectedAirportFrom(airport)
  };
  const handleAirportSelectTo = (airport: any) => {
    // console.log('AIRPORT TO - ', airport);
    setSelectedAirportTo(airport);
  };
  const handleAirportSelectdateDeparture = (
    formattedDate: string,
    date: any
  ) => {
    setAirportSelectdateDeparture(formattedDate);
    setAirportSelectdateDepartureDate(date);
  };
  const handleAirportSelectdateReturn = (date: any) => {
    setAirportSelectdateReturn(date);
  };
  const handleAllTravellers = ({
    adults,
    children,
    infants,
    selectedOption,
  }: any) => {
    setAllTravellersData({ adults, children, infants, selectedOption });
  };

  const handleSwitchInput = () => {
    setIsInput1Active((prevValue: any) => !prevValue);
  };
  const SearchOneWayFlights = () => {

    const segments: any = [
      {
        origin: selectedAirportFrom?.airportCode,
        destination: selectedAirportTo?.airportCode,
        preferredDepartureTime:
          typeof AirportSelectdateDepartureDate == 'string'
            ? AirportSelectdateDepartureDate
            : AirportSelectdateDepartureDate?.toISOString(),
        preferredArrivalTime:
          typeof AirportSelectdateDepartureDate == 'string'
            ? AirportSelectdateDepartureDate
            : AirportSelectdateDepartureDate?.toISOString(),
        flightCabinClass: 0,
        preferredAirlines: selectedAirlines.map((a: any) => a.code),
        nearByOriginPort: false,
      },
    ];
    searchFlightsCommon(1, segments, allTravellersData);
  };
  return (
    <>
      <div className="mt-3" id="section_oneway_return">
        <div className="row align-items-center">
          <div className="col-lg-5" id="div_onway_return_des">
            <div className="row">
              <div
                className={classNames('col-lg-6', styles['flyingplaces'])}
                style={{ position: 'relative' }}
              >
                <a
                  className={classNames(
                    styles['switch_destination'],
                    styles['switch_destinations']
                  )}
                  onClick={handleSwitchInput}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                    <path d="M32 96l320 0V32c0-12.9 7.8-24.6 19.8-29.6s25.7-2.2 34.9 6.9l96 96c6 6 9.4 14.1 9.4 22.6s-3.4 16.6-9.4 22.6l-96 96c-9.2 9.2-22.9 11.9-34.9 6.9s-19.8-16.6-19.8-29.6V160L32 160c-17.7 0-32-14.3-32-32s14.3-32 32-32zM480 352c17.7 0 32 14.3 32 32s-14.3 32-32 32H160v64c0 12.9-7.8 24.6-19.8 29.6s-25.7 2.2-34.9-6.9l-96-96c-6-6-9.4-14.1-9.4-22.6s3.4-16.6 9.4-22.6l96-96c9.2-9.2 22.9-11.9 34.9-6.9s19.8 16.6 19.8 29.6l0 64H480z" />
                  </svg>
                </a>
                <AirportContainer
                  Source={'From'}
                  icon={
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="27"
                      viewBox="0 0 640 512"
                    >
                      <path d="M381 114.9L186.1 41.8c-16.7-6.2-35.2-5.3-51.1 2.7L89.1 67.4C78 73 77.2 88.5 87.6 95.2l146.9 94.5L136 240 77.8 214.1c-8.7-3.9-18.8-3.7-27.3 .6L18.3 230.8c-9.3 4.7-11.8 16.8-5 24.7l73.1 85.3c6.1 7.1 15 11.2 24.3 11.2H248.4c5 0 9.9-1.2 14.3-3.4L535.6 212.2c46.5-23.3 82.5-63.3 100.8-112C645.9 75 627.2 48 600.2 48H542.8c-20.2 0-40.2 4.8-58.2 14L381 114.9zM0 480c0 17.7 14.3 32 32 32H608c17.7 0 32-14.3 32-32s-14.3-32-32-32H32c-17.7 0-32 14.3-32 32z" />
                    </svg>
                  }
                  onAirportSelect={handleAirportSelectFrom}
                  airportPayload={recentSearch?.segments[0].origin}
                />
              </div>
              <div className={classNames('col-lg-6', styles['flyingplaces'])}>
                <AirportContainer
                  Source={'To'}
                  icon={
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="27"
                      viewBox="0 0 640 512"
                    >
                      <path d="M381 114.9L186.1 41.8c-16.7-6.2-35.2-5.3-51.1 2.7L89.1 67.4C78 73 77.2 88.5 87.6 95.2l146.9 94.5L136 240 77.8 214.1c-8.7-3.9-18.8-3.7-27.3 .6L18.3 230.8c-9.3 4.7-11.8 16.8-5 24.7l73.1 85.3c6.1 7.1 15 11.2 24.3 11.2H248.4c5 0 9.9-1.2 14.3-3.4L535.6 212.2c46.5-23.3 82.5-63.3 100.8-112C645.9 75 627.2 48 600.2 48H542.8c-20.2 0-40.2 4.8-58.2 14L381 114.9zM0 480c0 17.7 14.3 32 32 32H608c17.7 0 32-14.3 32-32s-14.3-32-32-32H32c-17.7 0-32 14.3-32 32z" />
                    </svg>
                  }
                  onAirportSelect={handleAirportSelectTo}
                  airportPayload={recentSearch?.segments[0].destination}
                />
              </div>
            </div>
          </div>

          <div style={{ position: 'relative' }} className="col-lg-3">
            <div className="row">
              <div className="col-6">
              <SelectedDate
                  datePayload={
                    searchPayload?.segments ? searchPayload?.segments[0].preferredDepartureTime : new Date(new Date().setDate(new Date().getDate() + 1)).toISOString()
                  }
                  onAirportSelectDate={handleAirportSelectdateDeparture}
                  departureReturn={true}
                  text={'Departure'}
                />
              </div>
              <div className="col-6">
                <SelectedDate
                  datePayload={
                    searchPayload?.segments &&
                    searchPayload?.segments[0].preferredArrivalTime
                  }
                  onAirportSelectDate={handleAirportSelectdateReturn}
                  departureReturn={false}
                  text={'Return'}
                />
              </div>
            </div>
          </div>

          <div className="col-lg-2">
            <TravellersClass
              onAllTravellers={handleAllTravellers}
              travellers={allTravellersData}
            />
          </div>

          <div className="col-lg-2">    
            <button
              className="btn btn-primary w-100 modifySearch mt-1"
              type="button"
              onClick={() => SearchOneWayFlights()}
            >  
              <span>
                {' '}
                <i className="fa-solid fa-magnifying-glass"></i> SEARCH
              </span>
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default OneWay;
