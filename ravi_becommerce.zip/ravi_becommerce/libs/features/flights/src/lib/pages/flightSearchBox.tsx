import { useState,useRef } from 'react';
import ItinerarySearchBox from '../components/itinerarySearchBox';
import AdditionalSerach from '../components/additionalSearch';
import { toast } from 'react-toastify';
import { Loader } from '@mfa-travel-app/ui';
import { useStore } from '@mfa-travel-app/store';
import { searchFlights } from '../../lib/service/flightApi';
import { useNavigate } from 'react-router-dom';
import SearchMapBox from './searchMapBox';
import styles from '../oneway.module.scss';

interface Supplier {
  value: string;
  label: string;
}
const FlightSearchBox = ({ isRes }: any) => {
  const navigate = useNavigate();
  const {
    saveFlightSearchResults,
    saveSearchPayloadResults,
    refreshAirlineData,
  } = useStore();

  const [isResult, setIsResult] = useState<boolean>(isRes ? true : false);
  const [selectedAirlines, setSelectedAirlines] = useState<Supplier[]>([]);
  const [selectedSupplier, setSelectedSupplier] = useState<Supplier[]>([]);
  const [refundableFaresOnly, setRefundableFaresOnly] =
    useState<boolean>(false);
  const [directFlights, setDirectFlights] = useState<boolean>(false);
  const [selectedFareTypes, setSelectedFareTypes] = useState<
    { value: string; label: string }[]
  >([]);
  const [markup, setMarkup] = useState<string>('');
  const [loader, setLoader] = useState(false);
  const searchBoxRef:any = useRef();


  const searchFlightsCommon = async (
    type: number,
    segments: any[],
    travellerInfo: any,
    isRes: any
  ) => {
    const compareTimestamps = (timestamp1: any, timestamp2: any) => {
      const date1 = new Date(timestamp1);
      const date2 = new Date(timestamp2);

      return (
        date1.getFullYear() === date2.getFullYear() &&
        date1.getMonth() === date2.getMonth() &&
        date1.getDate() === date2.getDate() &&
        date1.getHours() === date2.getHours() &&
        date1.getMinutes() === date2.getMinutes() &&
        date1.getSeconds() === date2.getSeconds()
      );
    };
    if (
      !segments ||
      segments.length === 0 ||
      !segments[0].destination ||
      compareTimestamps(
        segments[0]?.preferredDepartureTime,
        segments[1]?.preferredDepartureTime
      ) ||
      !segments[0].origin ||
      (!travellerInfo.adults &&
        !travellerInfo.children &&
        !travellerInfo.infants)
    ) {
      toast.error('Please fill the  required and correct filled');
      return;
    }
    setIsResult(isRes);
    const searchData = {
      unrestrictedcarrier: null,
      type: type,
      restrictAirline: selectedAirlines.length > 0,
      segments: [...segments],
      adultCount: travellerInfo.adults,
      childCount: travellerInfo.children,
      seniorCount: 0,
      infantCount: travellerInfo.infants,
      sources: selectedSupplier.map((s) => s.value),
      refundableFares: refundableFaresOnly,
      maxStops: directFlights ? 0 : null,
      corporateTravelProfileId: 0,
      corporateTravelReasonId: 0,
      corporateTravelReason: null,
      appliedPolicy: false,
      searchBySegments: false,
      timeIntervalSpecified: false,
      gdsSpecialFareType: selectedFareTypes.map((f) => f.value)[0],
    };
    saveFlightSearchResults([]);
    saveSearchPayloadResults(searchData);
    navigate('/searchflight');
  };
  const onModifySearchResult = (res: any) => {
    setIsResult(res);
  };

  const handleSearchClick = () => {
    if (searchBoxRef.current) {
      searchBoxRef.current.SearchReturnFlights();
    }
  };
  return (
    <>
      {isResult ? (
        <SearchMapBox onModifySearchResult={onModifySearchResult} />
      ) : (
        <div className="searchForm mb-3">
          <ItinerarySearchBox
            searchFlightsCommon={searchFlightsCommon}
            selectedAirlines={selectedAirlines}
            ref={searchBoxRef}
          />
          <div className="row">
            <div className="col-sm-12">
              <details>
                <summary className="text-start">
                  <p className="mb-0 d-inline-block">
                    Additional Search Options
                  </p>
                </summary>
                <ul className="additional_searches mt-4">
                  <AdditionalSerach
                    selectedAirlines={selectedAirlines}
                    setSelectedAirlines={setSelectedAirlines}
                    selectedFareTypes={selectedFareTypes}
                    setSelectedFareTypes={setSelectedFareTypes}
                    markup={markup}
                    setMarkup={setMarkup}
                    selectedSupplier={selectedSupplier}
                    setSelectedSupplier={setSelectedSupplier}
                    directFlights={directFlights}
                    setDirectFlights={setDirectFlights}
                    refundableFaresOnly={refundableFaresOnly}
                    setRefundableFaresOnly={setRefundableFaresOnly}
                  />
                </ul>
              </details>
            </div>
          </div>
          <div className={styles['button-display-search-two']}>
          <button
              type="button"
              className="btn btn-primary w-100 modifySearch mt-1"
              onClick={handleSearchClick}
            >
              <span>
                {' '}
                <i className="fa-solid fa-magnifying-glass"></i> SEARCH
              </span>
            </button>
            </div>
        </div>
      )}
      {/* { loader && <Loader/> } */}
    </>
  );
};
export default FlightSearchBox;
