import { Logo } from '@mfa-travel-app/assets';
import  { useRef } from 'react';
import { useReactToPrint } from 'react-to-print';

export default function ViewFlightInvoice() {

  
  const contentToPrint = useRef(null);

  const handlePrint = useReactToPrint({
    documentTitle: "Print This Document",
    removeAfterPrint: true,
  });


  return (
    
<>

<div style={{padding:'0 10px'}}> 
<table  ref={contentToPrint} style={{fontSize:'13px', width:'96%', margin:'auto'}}>
  <tbody>



   <tr>
    <td style={{textAlign:'start'}}>
    <img style={{height:'16px'}} src={Logo} alt="logo" />
    </td>

    <td style={{textAlign:'center'}}> <h4 style={{margin:'0'}}>Invoice</h4> </td>

    <td style={{textAlign:'end'}}> 

      <table style={{display:'inline'}}>
        <tbody>

        <tr>
<td style={{textAlign:'end'}}> 
  <button onClick={() => {
        handlePrint(null, () => contentToPrint.current);
      }}>Print</button>
  
   </td>

        </tr>

           <tr> 
         
            <td>Agent Name: B-Commerce</td>
           </tr> 

           <tr> 
           
            <td>Agent eMail: Support@bcommerce.com </td>
           </tr> 

           <tr> 
           
            <td>Phone: +1 618 7785580 </td>
           </tr> 

          </tbody>
        </table>

  
    </td>
   </tr>






   <tr>

<td colSpan={3}> 

<table style={{fontSize:'13px', width:'100%', border:'solid 1px #ccc', marginBottom:'20px'}}>
<thead>

  <tr style={{background:'#f2aa3b', color:'white'}}>
<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>Invoice Details</th>
  </tr>
</thead>

<tbody> 


  <tr>
<td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>

<table style={{fontSize:'13px', width:'100%'}}>

<thead>

<tr>
<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc', width:'25%'}}>Invoice</th>
<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc', width:'25%'}}>Date</th>
<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc', width:'25%'}}>PNR No.</th>
<th style={{paddingLeft:'10px'}}>Akbar Travels of India Pvt Ltd</th>

</tr>
</thead>

<tbody>

  <tr>
  <td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>KW 46264</td>
  <td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>17/07/2024</td>
  <td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>7K7894</td>
  <td style={{paddingLeft:'10px', paddingRight:'10px'}}>

<div>Akbar Online Booking Co Pvt Ltd 17, 1st Floor, Pusa Rd · 011 6647 7000  </div>
<div>TRN No. : 6456981</div>
  </td>
  </tr>
</tbody>


  
</table>



</td>


  </tr>

</tbody>




</table>



</td>

</tr>



<tr>

<td colSpan={3}> 

<table style={{fontSize:'13px', width:'100%', border:'solid 1px #ccc'}}>
<thead>

  <tr style={{background:'#ddd'}}>

<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}> Pax Name</th>
<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc', textAlign:'center'}}>Ticket Number</th>
<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc', textAlign:'center'}}> Sector</th>
<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc', textAlign:'center'}}> Class</th>
<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc', textAlign:'center'}}> Flight No.</th>
<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc', textAlign:'center'}}> Date of Travel</th>
<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc', textAlign:'center'}}> Bacic Fare</th>
<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc', textAlign:'center'}}> K7 Tax</th>
<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc', textAlign:'center', width:'100px'}}> Airline Tax</th>
<th style={{paddingLeft:'10px', textAlign:'center', width:'100px'}}> Total</th>

  </tr>
</thead>

<tbody> 


  <tr>
<td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>MR.JAMES FLANAGAN</td>
<td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc', textAlign:'center'}}>1572627554458</td>

<td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc', textAlign:'center'}}> 
<div>MAN-DOH</div>
<div>DOH-BSR</div>
<div>BSR-DOH</div>
<div>DOH-MAN</div>
</td>


<td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc', textAlign:'center'}}>T</td>

<td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc', textAlign:'center'}}>
<div>QR-24</div>
<div>QR-448</div>
<div>QR-449</div>
<div>QR-23</div>
</td>

<td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc', textAlign:'center'}}>

<div>01/07/2024</div>
<div>02/07/2024</div>
<div>04/07/2024</div>
<div>04/07/2024</div>
</td>

<td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc', textAlign:'center'}}>2,460.00</td>
<td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc', textAlign:'center'}}>0.00</td>
<td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc', textAlign:'center'}}>0.00</td>
<td style={{paddingLeft:'10px', textAlign:'center'}}>2,460.00</td>

  </tr>


</tbody>




</table>



</td>

</tr>





<tr>

<td style={{textAlign:'end'}} colSpan={3}> 

<table style={{fontSize:'13px', width:'190px', display:'inline-block'}}>



<tbody> 
  <tr>
    <td style={{paddingLeft:'10px', textAlign:'right', width:'100px', borderBottom:'solid 1px #ccc'}}>Total Gross Fare:</td>
    <td style={{paddingLeft:'10px', textAlign:'left',  borderBottom:'solid 1px #ccc'}}>2,460.00</td>
</tr>

<tr>
    <td style={{paddingLeft:'10px', textAlign:'right',  borderBottom:'solid 1px #ccc'}}>Markup:</td>
    <td style={{paddingLeft:'10px', textAlign:'left',  borderBottom:'solid 1px #ccc'}}>1,170.00</td>
</tr>



<tr>
    <td style={{paddingLeft:'10px', textAlign:'right', borderBottom:'solid 1px #ccc'}}>Baggage:</td>
    <td style={{paddingLeft:'10px', textAlign:'left',  borderBottom:'solid 1px #ccc'}}>0.00</td>
</tr>
<tr>
    <td style={{paddingLeft:'10px', textAlign:'right',  borderBottom:'solid 1px #ccc'}}>Meal:</td>
    <td style={{paddingLeft:'10px', textAlign:'left',  borderBottom:'solid 1px #ccc'}}>0.00</td>
</tr>
<tr>
    <td style={{paddingLeft:'10px', textAlign:'right',  borderBottom:'solid 1px #ccc'}}>Seat:</td>
    <td style={{paddingLeft:'10px', textAlign:'left',  borderBottom:'solid 1px #ccc'}}>0.00</td>
</tr>
<tr>
    <td style={{paddingLeft:'10px', textAlign:'right', borderBottom:'solid 1px #ccc'}}>Input VAT:</td>
    <td style={{paddingLeft:'10px', textAlign:'left', borderBottom:'solid 1px #ccc'}}>0.00</td>
</tr>
<tr>
    <td style={{paddingLeft:'10px', textAlign:'right', borderBottom:'solid 1px #ccc'}}>Output VAT:</td>
    <td style={{paddingLeft:'10px', textAlign:'left',  borderBottom:'solid 1px #ccc'}}>0.00</td>
</tr>

<tr>
    <td style={{paddingLeft:'10px', textAlign:'right',  borderBottom:'solid 1px #ccc'}}>Total Amount:</td>
    <td style={{paddingLeft:'10px', textAlign:'left',  borderBottom:'solid 1px #ccc'}}><b>3,630.00</b></td>
</tr>

</tbody>



</table>



</td>

</tr>



<tr>

<td style={{textAlign:'end'}} colSpan={3}> 

<table style={{fontSize:'13px', width:'100%', marginTop:'6px'}}>



<tbody> 
  <tr>
    <td style={{paddingLeft:'10px', textAlign:'left', paddingBottom:'40px'}}>
      AED THREE THOUSAND SIX HUNDRED THIRTY ONLY</td>
    <td style={{paddingLeft:'10px', textAlign:'right', paddingBottom:'40px'}}>    
    Akbar Travels of India Pvt Ltd
    </td>
</tr>

<tr>
    <td style={{paddingLeft:'10px', textAlign:'left'}}>
    Booked by: Kamal Sharma</td>
    <td style={{paddingLeft:'10px', textAlign:'right'}}>  </td>
</tr>

<tr>
    <td style={{paddingLeft:'10px', textAlign:'left'}}>
    Place: Mumbai </td>
    <td style={{paddingLeft:'10px', textAlign:'right'}}>
    Authorised Signatory  </td>
</tr>


<tr>
<td colSpan={2} style={{borderTop:'solid 1px #ccc', paddingTop:'10px', paddingLeft:'10px', textAlign:'center'}}>
Dear Customer: Prior to Payment, Please Reconfirm Your Booking Details. Once Payment is made all Cozmo Travel Terms And condition will be Applicable

</td>

</tr>






</tbody>



</table>



</td>

</tr>


  </tbody>
</table>

</div>






</>


  )
}
