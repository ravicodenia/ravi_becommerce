import { useState } from 'react';

const Baggage = ({ itinerary }: any) => {
  return (
    <div className="table-responsive text-start">
      <table className="table border">
        <thead>
          <tr className="table-secondary">
            <th colSpan={3}>Baggage</th>
          </tr>
          <tr>
            <th>Sector / Flight</th>
            <th>Checkin Baggage</th>
            <th>Hand Baggage</th>
          </tr>
        </thead>
        <tbody>
          {itinerary?.flights?.map((journey: any) =>
            journey.map((flight: any, index: any) => (
              <tr key={index}>
                <td>
                  {flight?.origin?.cityName} to {flight?.destination?.cityName}
                </td>
                <td>
                  {flight?.defaultBaggage == null || flight?.defaultBaggage == ""
                    ? 'As per Airline Policy'
                    : flight?.defaultBaggage}
                </td>
                <td>
                  {flight?.carryOnBaggage == null || flight?.carryOnBaggage == ""
                    ? 'As per Airline Policy'
                    : flight?.carryOnBaggage}
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default Baggage;
