import React, { useState } from 'react';

const suggestions = ['Delhi Airport', 'Mumbai Airport', 'Calcutta Airport', 'Bangaluru Airport'];

const SearchInput = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [suggestionsList, setSuggestionsList] = useState([]);

  const handleInputChange = (event:any) => {
    const { value } = event.target;
    setSearchTerm(value);

    if (value.length >= 3) {
      // Filter suggestions based on the search term
      const filteredSuggestions:any = suggestions.filter((suggestion) =>
        suggestion.toLowerCase().includes(value.toLowerCase())
      );
      setSuggestionsList(filteredSuggestions);
    } else {
      setSuggestionsList([]);
    }
  };

  const handleSuggestionClick = (suggestion:any) => {
    setSearchTerm(suggestion);
    setSuggestionsList([]);
  };

  return (
    <div className='destination-dropdown' id='departure-dropdown'>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512">
        <path d="M381 114.9L186.1 41.8c-16.7-6.2-35.2-5.3-51.1 2.7L89.1 67.4C78 73 77.2 88.5 87.6 95.2l146.9 94.5L136 240 77.8 214.1c-8.7-3.9-18.8-3.7-27.3 .6L18.3 230.8c-9.3 4.7-11.8 16.8-5 24.7l73.1 85.3c6.1 7.1 15 11.2 24.3 11.2H248.4c5 0 9.9-1.2 14.3-3.4L535.6 212.2c46.5-23.3 82.5-63.3 100.8-112C645.9 75 627.2 48 600.2 48H542.8c-20.2 0-40.2 4.8-58.2 14L381 114.9zM0 480c0 17.7 14.3 32 32 32H608c17.7 0 32-14.3 32-32s-14.3-32-32-32H32c-17.7 0-32 14.3-32 32z"/></svg>
      <input
        type="text"
        value={searchTerm}
        onChange={handleInputChange}
        placeholder="Select"
        className='destination-input'
        id='departure-input'
      />
      {suggestionsList.length > 0 && (
        <ul>
          {suggestionsList.map((suggestion, index) => (
            <li key={index} onClick={() => handleSuggestionClick(suggestion)}>
              {suggestion}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default SearchInput;