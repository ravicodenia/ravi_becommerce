import React, { useState } from 'react';
import styles from '../oneway.module.scss';
import classNames from 'classnames';

const Flighttab = ({ flightType, setFlightType }: any) => {
    // const [flightType, setFlightType] = useState(''); // '' | 'multistop' | 'oneway' | 'return'

    const handleFlightTypeChange = (type: any) => {
        setFlightType(type);
    };

    return (
        <div className={styles["flight-options"]}>
            <button
                className={classNames(styles["onewayflight"], styles["flightstab"], `${flightType === 'oneway' ? styles['active-radio'] : ''}`)}
                onClick={() => handleFlightTypeChange('oneway')}
            >
                One Way
            </button>
            <button
                className={classNames(styles["returnflight"], styles["flightstab"], `${flightType === 'return' ? styles['active-radio'] : ''}`)}
                onClick={() => handleFlightTypeChange('return')}
            >
                Return
            </button>
            <button
                className={classNames(styles["multistopflight"], styles["flightstab"], `${flightType === 'multistop' ? styles['active-radio'] : ''}`)}
                onClick={() => handleFlightTypeChange('multistop')}
            >
                Multi-stop
            </button>
        </div>
    );
};

export default Flighttab;
