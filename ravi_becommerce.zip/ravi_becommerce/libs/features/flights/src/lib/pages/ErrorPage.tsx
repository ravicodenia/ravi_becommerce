import { MainLayout } from '@mfa-travel-app/layout';
import { scarecrow } from '@mfa-travel-app/assets';
import { FaArrowRightLong } from "react-icons/fa6";
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { RootState } from '@mfa-travel-app/store';
import { useHotelStore } from '@mfa-travel-app/store';

export default function ErrorPage2() {
  const { refreshHotelData } = useHotelStore();
  const { flightTicketError } = useSelector((state: RootState) => state.flight);
  const { hotelErrorMessage } = useSelector((state: RootState) => state.hotel);

  return (
    <>
      <MainLayout>
          <div className='container mt-3 mb-5'>
            <div className='row align-items-center'>
              <div className='col-12 text-center'>
                <img src={scarecrow} className='img-fluid' alt="" />
              </div>
              <div className='col-12 text-center'>

                {flightTicketError ?
                  <div>{flightTicketError?.message}</div> :  hotelErrorMessage  ? <div>{hotelErrorMessage?.message}</div> :
                  <>
                    <h4>Something went wrong!</h4>
                    <p className='mt-4 mb-4'>
                      You're in the right place to get your venture growing. Start with the tools below or head to our home page to get started.
                    </p>
                  </>}
                  <Link to='/home' className='btn btn-lg btn-primary rounded' onClick={()=>{ refreshHotelData() }}> Back to Home Page <FaArrowRightLong /></Link>
              </div>




            </div>


          </div>
      </MainLayout>

    </>

  )
}
