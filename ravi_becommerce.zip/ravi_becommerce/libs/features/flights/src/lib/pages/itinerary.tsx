import { useState, useEffect,useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import styles from '../flights.module.scss';
import classNames from 'classnames';
import { FaRegRectangleList, FaMinus } from 'react-icons/fa6';
import { FaPlane, FaSuitcase } from 'react-icons/fa';
import { IoMdClose } from 'react-icons/io';
import FlightDetails from './flightDetails';
import FareRules from './fareRules';
import Baggage from './baggage';
import { Modal } from 'react-bootstrap';
import { useStore, RootState } from '@mfa-travel-app/store';
import { getFareRuleDetails, getFlightRePrice } from '../service/flightApi';
import { Loader } from '@mfa-travel-app/ui';
import { findAirlineLogo } from '@mfa-travel-app/shared';
import { toast } from 'react-toastify';

const Itinerary = ({ sliderScrolldata,itinerary, cheapestFlights }: any) => {
  const navigate = useNavigate();
  const {
    saveFareRulesDetails,
    saveSelectedItineraryDetails,
    saveRePriceDetails,
  } = useStore();
  const [showDetails, setShowDetails] = useState(false);
  const [fareRules, setFareRules] = useState({});
  const [showFareRules, setShowFareRules] = useState(false);
  const [showBaggage, setShowBaggage] = useState(false);
  const [showSamePriceFlights, setShowSamePriceFlights] = useState(false);
  const [showItineraryHeader, setShowItineraryHeader] = useState(true);
  const [flyingTime, setFlyingTime] = useState('');
  const [journeyTime, setJourneyTime] = useState('');
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [showPriceChangeModal, setShowPriceChangeModal] = useState(false);
  const [priceChange, setPriceChange] = useState({
    originalFare: itinerary?.totalFare,
    changedFare: null,
  });
  const [showItineraryChangedModal, setShowItineraryChangeModal] =
    useState(false);
  const [loader, setLoader] = useState(false);
  const detailsRef : any = useRef(null);
  const fareRuleRef:any = useRef(null);
  const baggageRef :any = useRef(null);
  const scrollRef :any = useRef([])

  const { airlines } = useSelector((state: RootState) => state.flight);

  useEffect(() => {
    const totalFlyingTime = calculateFlyingTime();
    setFlyingTime(totalFlyingTime);
    const totalJourneyTime = calculateJourneyTime();
    setJourneyTime(totalJourneyTime);
  }, []);

  const calculateFlyingTime = () => {
    let durations = [];
    for (let i = 0; i < itinerary?.flights?.length; i++) {
      for (let j = 0; j < itinerary?.flights[i].length; j++) {
        durations.push(itinerary?.flights[i][j].duration);
      }
    }
    const time = calculateTotalDuration(durations);
    return `${time.hours}:${time.minutes}:${time.seconds}`;
  };

  const calculateJourneyTime = () => {
    let flightDurations = [];
    for (let i = 0; i < itinerary?.flights?.length; i++) {
      for (let j = 0; j < itinerary?.flights[i].length; j++) {
        flightDurations.push(itinerary?.flights[i][j].duration);
      }
    }

    let layoverDurations = [];
    for (let i = 0; i < itinerary?.flights?.length; i++) {
      for (let j = 0; j < itinerary?.flights[i].length; j++) {
        const flight = itinerary?.flights[i][j];
        if (flight.stopOver === true) {
          let arrival: any = new Date(flight.arrivalTime);
          let departure: any = new Date(
            itinerary?.flights[i][j + 1].departureTime
          );

          let duration = departure - arrival;

          let hours = Math.floor(duration / (1000 * 60 * 60));
          let minutes = Math.floor((duration % (1000 * 60 * 60)) / (1000 * 60));

          let formattedHours = hours.toString().padStart(2, '0');
          let formattedMinutes = minutes.toString().padStart(2, '0');

          layoverDurations.push(`${formattedHours}:${formattedMinutes}:00`);
        }
      }
    }
    const time = calculateTotalDuration([
      ...flightDurations,
      ...layoverDurations,
    ]);
    return `${time.hours}:${time.minutes}:${time.seconds}`;
  };

  const calculateTotalDuration = (durations: any) => {
    function convertToSeconds(duration: any) {
      let parts = duration?.split(':');
      let hours = parseInt(parts[0]);
      let minutes = parseInt(parts[1]);
      let seconds = parseInt(parts[2]);
      return hours * 3600 + minutes * 60 + seconds;
    }

    let totalSeconds = durations?.reduce((sum: number, duration: number) => {
      return sum + convertToSeconds(duration);
    }, 0);

    function convertToHHMMSS(totalSeconds: any) {
      let hours = Math.floor(totalSeconds / 3600);
      totalSeconds %= 3600;
      let minutes = Math.floor(totalSeconds / 60);
      let seconds = totalSeconds % 60;

      let paddedHours = String(hours).padStart(2, '0');
      let paddedMinutes = String(minutes).padStart(2, '0');
      let paddedSeconds = String(seconds).padStart(2, '0');

      return {
        hours: paddedHours,
        minutes: paddedMinutes,
        seconds: paddedSeconds,
      };
    }
    return convertToHHMMSS(totalSeconds);
  };

  const formatTime = (isoString: string) => {
    const date = new Date(isoString);
    return date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: 'numeric',
      hour12: true,
    });
  };

  const getDate = (dateTimeString: string) => {
    const date = new Date(dateTimeString);
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: '2-digit',
      year: 'numeric',
    });
  };

  const handleBookItinerary = async () => {
    setLoader(true);
    try {
      const rePriceResponse: any = await getFlightRePrice(
        itinerary?.sessionId,
        itinerary?.flightGuId
      );
      setLoader(false);
      if (rePriceResponse?.status == 200) {
        saveRePriceDetails(rePriceResponse?.data)
        if (rePriceResponse?.data?.isBookingClassChanged === true) {
          setPriceChange({ ...priceChange, changedFare: rePriceResponse?.price });
          setShowItineraryChangeModal(true);
        } else {
          saveSelectedItineraryDetails(itinerary);
          setLoader(true);
          const response: any = await getFareRuleDetails(
            itinerary?.sessionId,
            itinerary?.flightGuId
          );
          setLoader(false);
          if (response?.status === 200 && !response?.data?.errors) {
            if (response?.data[0]?.fareRuleDetail == null) {
              saveFareRulesDetails({
                errorMessage: 'No information from Airline',
              });

            } else {
              saveFareRulesDetails(response?.data);
            }
            navigate('/flight-pax-details');
          } else {
            navigate('/error-page');
            toast.error(response?.data?.errors);
          }
        }
      } else {
        toast.error(rePriceResponse?.message)
      }
    } catch (error: any) {
      toast.error(error);
    }
  };

  const openFareRules = async () => {
    setShowFareRules(!showFareRules);
    setShowDetails(false);
    setShowBaggage(false);
    setShowSamePriceFlights(false);

    if (showFareRules === false) {
      setLoader(true);
      const response: any = await getFareRuleDetails(
        itinerary?.sessionId,
        itinerary?.flightGuId
      );
      setLoader(false);
      if (response?.status === 200) {
        if (response?.data[0]?.fareRuleDetail == null) {
          setFareRules({ errorMessage: 'No information from Airline' });
          saveFareRulesDetails({ errorMessage: 'No information from Airline' });
        } else {
          setFareRules(response?.data);
          saveFareRulesDetails(response?.data);
        }
      }
    }
  };

  const getAirlineData = (airlineCode: string) => {
    const airline = airlines?.filter(
      (airline: any) => airline?.code === airlineCode
    );
    return airline[0];
  };


  const handleClickOutside = (event:any) => {
    if (detailsRef.current && !detailsRef.current.contains(event.target)) {
      setShowDetails(false);
    }
    if (fareRuleRef.current && !fareRuleRef.current.contains(event.target)) {
      setShowFareRules(false);
    }
  
    if ( baggageRef.current && ! baggageRef.current.contains(event.target)) {
      setShowBaggage(false);
    }
  };

  useEffect(() => {
    if (showDetails || fareRuleRef  || baggageRef) {
      document.addEventListener('mousedown', handleClickOutside);
    } else {
      document.removeEventListener('mousedown', handleClickOutside);
    }
    
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showDetails,fareRuleRef,baggageRef]);

  useEffect(() => {
    if (sliderScrolldata?.[0]?.totalFare) {
      const matchingElement = scrollRef.current.find(
        (el: any) =>
          el &&
          el.getAttribute('data-total-fare') ===
          sliderScrolldata[0]?.totalFare.toString()
      );
      if (matchingElement) {
        matchingElement.scrollIntoView({ behavior: 'smooth' });
      }
    }
  }, [sliderScrolldata]);

  return (
    <>
      <div className="my-2" >
        <div className="container-fluid border border-2">
          <div
            className={classNames(showItineraryHeader ? '' : 'd-none', 'row')}
          >
            <div className={classNames(styles['itinerary-header'])}>
              <div>
                <span key='1' className={styles['itinerary-header-title']}>
                  Agent Cost:{' '}
                </span>
                <span key='2' className={styles['itinerary-header-content']}>
                  {itinerary?.totalFare} |{' '}
                </span>
                <span key='3' className={styles['itinerary-header-title']}>
                  Total Profit:{' '}
                </span>
                <span key='4' className={styles['itinerary-header-content']}>
                  {itinerary?.price?.handlingFeeValue +
                    itinerary?.price?.markupValue -
                    itinerary?.price?.discountValue}
                </span>
              </div>
              <div className='hide_mobile'>
                <span key='1' className={styles['itinerary-header-title']}>
                  Journey Time:{' '}
                </span>
                <span key='2' className={styles['itinerary-header-content']}>
                  {journeyTime} |{' '}
                </span>
                <span key='3' className={styles['itinerary-header-title']}>
                  Flying Time:{' '}
                </span>
                <span key='4' className={styles['itinerary-header-content']}>
                  {flyingTime}
                </span>
                <button
                  className={classNames(styles['collapse-btn'], 'btn')}
                  onClick={() => setShowItineraryHeader(false)}
                >
                  <FaMinus />
                </button>
              </div>
            </div>
          </div>
       
          <div className="row py-2">
            <div className="col-lg-10 col-12">
              {cheapestFlights?.fare == itinerary.totalFare ? (
                <div className="d-flex justify-content-between">
                  <span className={classNames(styles['cheapest'], 'p-1')}>
                    Cheapest
                  </span>
                </div>
              ) : (
                ''
              )}
              {itinerary?.flights?.map((journey: any, i: any) => (
                <div className="row mt-2" key={i}  
                ref={(el) => {
                  if (el) {
                    scrollRef.current[i] = el;
                    el.setAttribute('data-total-fare', itinerary.totalFare);
                  }
                }}
                >
                  <div className="col-lg-4 col-5 d-flex">
                    <div className="d-flex">
                      <div
                        className={classNames(
                          'form-check form-check-inline d-flex'
                        )}
                        style={{ marginRight: 0 }}
                      >
                        <input
                          className="form-check-input"
                          type="checkbox"
                          id="chkfl1"
 
                        />
                        <label
                          htmlFor="chkfl1"
                          className={classNames(styles['flightComp-label'])}
                        >
                          <img
                            src={ journey && journey[0]?.airline && findAirlineLogo(
                              journey && journey[0]?.airline
                            )}
                            className="rounded"
                          />
                          <div className="trimtextfull hide_mobile">
                            {getAirlineData(journey && journey[0]?.airline)?.name}
                          </div>
                          <div>{`${journey[0].airline}-${journey[0].flightNumber}`}</div>
                        </label>
                      </div>
                      <div className="d-flex flex-column justify-content-start align-items-start">
                        <div>
                          <span className={classNames(styles['airport'])}>
                            {journey[0]?.origin?.cityName}
                          </span>
                          <span
                            className={classNames(
                              styles['airport-code'],
                              'ms-md-1'
                            )}
                          >
                            {journey[0]?.origin?.cityCode}
                          </span>
                        </div>
                        <div style={{lineHeight:'normal'}}>
                          
                          <span className={classNames(styles['flight-time'])}>
                            {getDate(journey[0]?.departureTime)}
                          </span>
                          <span className="text-muted">- </span>
                          <span className={classNames(styles['flight-time'])}>
                            {formatTime(journey[0]?.departureTime)}
                          </span>
                       
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {journey[0].stops > 0 ? (
                    <div className="col-lg-2 col-3">

                      <div
                        className={classNames(
                          'text-danger',
                          'text-center',
                          styles['stops-label']
                        )}
                      >
                        STOPS AT
                      </div>
                      <div className={classNames(styles['stops-container'])}>
                        <div
                          className={classNames(
                            styles['line'],
                            styles['left-line'],
                            'bg-danger'
                          )}
                        ></div>
                        <div
                          className={classNames(
                            styles['text'],
                            'd-flex flex-column'
                          )}
                        >
                          {journey?.map((flight: any, j: any) =>
                            flight?.stopOver ? (
                              <span key={j}>
                                {flight.destination?.airportCode}&nbsp;
                              </span>
                            ) : j + 1 !== journey?.length ? (
                              <span key={j}>
                                {flight.destination?.airportCode}&nbsp;
                              </span>
                            ) : (
                              <span></span>
                            )
                          )}
                        </div>
                        <div
                          className={classNames(
                            styles['line'],
                            styles['right-line'],
                            'bg-danger'
                          )}
                        ></div>
                      </div>
                    </div>
                  ) : (
                    <div
                      className={classNames(
                        'col-lg-2',
                        'col-3',
                        styles['stops-container']
                      )}
                    >
                      <div
                        className={classNames(
                          styles['line'],
                          styles['left-line']
                        )}
                      ></div>
                      <div className={classNames(styles['text'])}>NONSTOP</div>
                      <div
                        className={classNames(
                          styles['line'],
                          styles['right-line']
                        )}
                      ></div>
                    </div>
                  )}

                  <div className="col-lg-5 col-4">
                    
                    <div className='row'>
                      <div className="col-lg-7 col-12"> 
                    <div className="d-flex flex-column">
                     
                      <div>
                        
                        <span className={classNames(styles['airport'])}>
                          {journey[journey?.length - 1].destination?.cityName}
                        </span>
                        <span
                          className={classNames(styles['airport-code'], 'ms-md-1')}
                        >
                          {journey[journey?.length - 1].destination?.cityCode}
                        </span>
                      </div>
                     
                      <div>
                        
                        <span className={classNames(styles['flight-time'])}>
                          {getDate(journey[journey?.length - 1].arrivalTime)}
                        </span>
                        <span className="text-muted">- </span>
                        <span className={classNames(styles['flight-time'])}>
                          {formatTime(journey[journey?.length - 1].arrivalTime)}
                        </span>
                      </div>

                    </div>
                    </div>

                    <div className="col-lg-5 col-12"> 

                    <div>
                      
                      <span className={classNames(styles['duration'])}>
                        {
                          calculateTotalDuration(
                            journey?.map((flight: any) => flight.duration)
                          ).hours
                        }
                      </span>
                      <span className={classNames(styles['time-unit'])}>
                        hr{' '}
                      </span>
                      <span className={classNames(styles['duration'])}>
                        {
                          calculateTotalDuration(
                            journey?.map((flight: any) => flight.duration)
                          ).minutes
                        }
                      </span>
                      <span className={classNames(styles['time-unit'])}>
                        min
                      </span>
                      <br />
                      <span
                        className={classNames(
                          styles['time-unit'],
                          'd-none',
                          'd-lg-block'
                        )}
                      >
                        Duration
                      </span>
                    </div>
                    
                    </div>


                    </div>

                  </div>

                  <div className="col-lg-1 col-12 text-md-start">
                    <div className={classNames(styles['flightLrLast'])}>
                      <div className="row g-0 align-items-center">
                       
                        <div className="col-4 col-lg-12">
                          <div className="ref_eco_non_basic">
                            {itinerary?.nonRefundable ? (
                              <span className="text-danger">
                                Non Refundable
                              </span>
                            ) : (
                              <span className="text-success">Refundable</span>
                            )}
                          </div>
                        </div>

                        {itinerary?.fareType !== '' ? (
                          <div
                            style={{ lineHeight: 'normal' }}
                            className="col-4 col-lg-12 text-md-start text-center"
                          >
                            <span>{journey[0]?.segmentFareType}</span>
                          </div>
                        ) : (
                          <span></span>
                        )}

                        <div
                          style={{ lineHeight: 'normal' }}
                          className="col-4 col-lg-12 text-md-start text-center"
                        >
                          <span>{`${journey[0].cabinClass} - ${journey[0].bookingClass}`}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}



            </div>
           
            <div className="col-lg-2 col-12">
           
              <div className='row align-items-center mt-2 mb-2'> 

           
                    <div className='col-lg-12 col-4 order-last'>
                        <div className="d-flex align-items-center justify-content-end">
                        <div>
                          <button
                            className="btn btn-primary w-100"
                            onClick={() => handleBookItinerary()}
                          >
                            Book{' '}
                          </button>
                        </div>
                        <div>
                          <button
                            className="btn text-secondary p-0 ms-2"
                            onClick={() => setShowDetailsModal(true)}
                          >
                            <i className="fa-solid fa-circle-info"></i>
                          </button>{' '}
                        </div>
                      </div>
                    </div>


            
                <div className='col-lg-12 col-4 text-center'>
                  <span className={classNames(styles['currency'])}></span>
                  <span className={classNames(styles['price'])}>
                    {itinerary?.totalFare.toFixed(2)}
                  </span>
                </div>

                <div className="col-lg-12 col-4 order-lg-last order-first text-lg-end">
                    {' '}
                    <span style={{ fontSize: '11px' }}>
                      {itinerary?.sourceName}
                    </span>
                   </div>
            
        
              </div>
            </div>


            <div className="col-lg-12 col-12">
                <button
                  className={classNames(
                    'btn',
                    styles['tab'],
                    showDetails ? styles['active-tab'] : ''
                  )}
                  onClick={() => {
                    setShowDetails(!showDetails);
                    setShowFareRules(false);
                    setShowBaggage(false);
                    setShowSamePriceFlights(false);
                  }}
                >
                  <FaPlane className="me-2" />
                  Flight Details
                </button>
                <button
                  className={classNames(
                    'btn',
                    styles['tab'],
                    showFareRules ? styles['active-tab'] : ''
                  )}
                  onClick={() => openFareRules()}
                >
                  <FaRegRectangleList className="me-2" />
                  Fare Rules
                </button>
                <button
                  className={classNames(
                    'btn',
                    styles['tab'],
                    showBaggage ? styles['active-tab'] : ''
                  )}
                  onClick={() => {
                    setShowBaggage(!showBaggage);
                    setShowDetails(false);
                    setShowFareRules(false);
                    setShowSamePriceFlights(false);
                  }}
                >
                  <FaSuitcase className="me-2" />
                  Baggage
                </button>
              </div>



          </div>
        </div>
        <div ref={detailsRef} className={showDetails ? 'd-block' : 'd-none'}>
          <FlightDetails itinerary={itinerary} />
        </div>
        <div ref ={fareRuleRef } className={showFareRules ? 'd-block' : 'd-none'}>
          <FareRules fareRules={fareRules} />
        </div>
        <div ref = {baggageRef} className={showBaggage ? 'd-block' : 'd-none'}>
          <Baggage itinerary={itinerary} />
        </div>
        <Modal
          size="lg"
          centered
          show={showDetailsModal}
          onHide={() => setShowDetailsModal(false)}
        >
          <header className={classNames(styles['fare-modal-header'], 'ps-2')}>
            <span>Fare Summary</span>
            <button className="btn" onClick={() => setShowDetailsModal(false)}>
              <IoMdClose color="#fff" />
            </button>
          </header>
          <div className='table-responsive'>
          <table
            className={classNames(
              styles['fare-modal'],
              'table',
              'table-bordered',
              'text-center'
            )}
          >
            <thead>
              <tr>
                <th>Passengers</th>
                <th>Base Fare</th>
                <th>Taxes & Fees</th>
                <th>Per Passenger</th>
                <th>Total Fare</th>
              </tr>
            </thead>
            <tbody>
              {itinerary?.fareBreakdown?.map((passengers: any, index: any) => (
                <tr key={index}>
                  <td>
                    {passengers?.passengerType == 1
                      ? 'Adults'
                      : passengers?.passengerType == 2
                        ? 'Children'
                        : 'Infants'}
                  </td>
                  <td>
                    {(
                      passengers?.baseFare / passengers?.passengerCount
                    ).toFixed(2)}
                  </td>
                  <td>
                    {(passengers?.tax / passengers?.passengerCount).toFixed(2)}
                  </td>
                  <td>
                    {(
                      passengers?.baseFare / passengers?.passengerCount +
                      passengers?.tax / passengers?.passengerCount
                    ).toFixed(2)}{' '}
                    x {passengers?.passengerCount}
                  </td>
                  <td>{(passengers?.totalFare).toFixed(2)}</td>
                </tr>
              ))}
              <tr>
                <td colSpan={4} className="fw-semibold  text-end">
                  Total Price
                </td>
                <td className="fw-semibold">
                  {itinerary?.price?.supplierCurrency}{' '}
                  {itinerary?.totalFare.toLocaleString()}
                </td>
              </tr>
              <tr>
                <td
                  colSpan={5}
                  className="text-start"
                  style={{ fontSize: '0.8rem' }}
                >
                  <span className="text-danger">* </span>
                  There might be a slight difference in the total price in fare
                  summary due to rounding off.
                </td>
              </tr>
            </tbody>
          </table>
          </div>
        </Modal>
        <Modal
          show={showPriceChangeModal}
          onHide={() => setShowPriceChangeModal(false)}
        >
          <Modal.Body>
            <Modal.Header closeButton></Modal.Header>
            <h5>Price has changed for the selected itinerary</h5>
            <table className="table table-responsive table-borderless text-center">
              <tbody>
                <tr>
                  <td className="fw-semibold">Original Fare:</td>
                  <td className="fw-semibold">Changed Fare</td>
                </tr>
                <tr>
                  <td>{priceChange.originalFare}</td>
                  <td className="text-danger">{priceChange.changedFare}</td>
                </tr>
                <tr>
                  <td>
                    <button
                      onClick={() => {
                        saveSelectedItineraryDetails(itinerary);
                        navigate('/flight-pax-details');
                      }}
                      className="btn btn-outline-primary"
                    >
                      Continue
                    </button>
                  </td>
                  <td>
                    <button
                      onClick={() => setShowPriceChangeModal(false)}
                      className="btn btn-outline-primary"
                    >
                      Select another itinerary
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </Modal.Body>
        </Modal>
        <Modal
          show={showItineraryChangedModal}
          onHide={() => setShowItineraryChangeModal(false)}
        >
          <Modal.Header closeButton></Modal.Header>
          <Modal.Body className="text-center">
            <h5>Selected Itinerary has changed</h5>
            <div>
              <button
                className="btn btn-outline-primary"
                onClick={() => setShowItineraryChangeModal(false)}
              >
                Select another itinerary
              </button>
            </div>
          </Modal.Body>
        </Modal>
      </div>
      {loader && <Loader />}
    </>
  );
};

export default Itinerary;
