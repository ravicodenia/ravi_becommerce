import { MainLayout } from '@mfa-travel-app/layout';
import { Link, useLocation } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import FareSummary from '../../Components/FlightPax/FareSummary';
import FlightItinerary from '../../Components/FlightPax/FlightItinerary';
import FlightDetailsPopup from '../../Components/FlightPax/FlightDetailsPopup';
import BaggagePolicyPopup from '../../Components/FlightPax/BaggagePolicyPopup';
import PaxNames from '../../Components/FlightPax/PaxNames';
import { RootState } from '@mfa-travel-app/store';
import { useStore } from '@mfa-travel-app/store';
import {
  getFlightBookInfo,
  getUapiFlightBookInfo,
} from '../../lib/service/flightApi';
import { Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { Loader } from '@mfa-travel-app/ui';

import { FiChevronDown } from 'react-icons/fi';
import { FiChevronUp } from 'react-icons/fi';

export default function FlightPayment() {
  const location = useLocation();
  const [trCash, setTRCash] = useState(false);
  const [trBank, setTRBank] = useState(false);
  const [trCredit, setTRCredit] = useState(false);
  const [trPos, setTRPos] = useState(false);
  const [trRemark, setTrRemark] = useState(false);
  const [trBalance, setTrBalance] = useState(false);
  const [trOnAccount, setTrOnAccount] = useState(true);
  const [loader, setLoader] = useState(false);
  const [checkboxValues, setCheckboxValues] = useState({
    termconditions3: false,
    termconditions4: false,
  });

  const { selectedItinerary, passengerList, rePriceData } = useSelector(
    (state: RootState) => state.flight
  );
  const { agentProfile, balanceInfo, countries, nationalities }: any =
    useSelector((state: RootState) => state.config);
  const { saveFlightTicketErrorResult } = useStore();
  const { saveBookingDataResult } = useStore();
  const navigate = useNavigate();

  // const { pax, contact, markup } = location.state || [];
  // console.log(passengerList);
  // console.log(selectedItinerary);
  // console.log('flightID', selectedItinerary?.flights[0][0]?.flightId);
  // console.log('rePrice', rePriceData);

  const [baggageFee, setBaggageFee] = useState(0);
  const [mealFee, setMealFee] = useState(0);
  const [seatFee, setSeatFee] = useState(0);
  const [serviceFee, setServiceFee] = useState(0);

  useEffect(() => {
    let baggageFee = 0;
    passengerList?.forEach((passenger: any) => {
      if (passenger?.baggageInfo?.onwardBaggage) {
        baggageFee =
          baggageFee +
          Number(passenger?.baggageInfo?.onwardBaggage?.baggageCharge ? passenger?.baggageInfo?.onwardBaggage?.baggageCharge : 0);
      }
      if (passenger?.baggageInfo?.returnBaggage) {
        baggageFee =
          baggageFee +
          Number(passenger?.baggageInfo?.returnBaggage?.baggageCharge ? passenger?.baggageInfo?.returnBaggage?.baggageCharge : 0);
      }
    });
    setBaggageFee(baggageFee);

    let mealFee = 0;
    passengerList?.forEach((passenger: any) => {
      if (passenger?.mealInfo?.onwardMeal) {
        mealFee = mealFee + Number(passenger?.mealInfo?.onwardMeal?.mealCharge ? passenger?.mealInfo?.onwardMeal?.mealCharge : 0);
      }
      if (passenger?.mealInfo?.returnMeal) {
        mealFee = mealFee + Number(passenger?.mealInfo?.returnMeal?.mealCharge ? passenger?.mealInfo?.returnMeal?.mealCharge : 0);
      }
    });
    setMealFee(mealFee);

    let passenSeatFee = 0;
    passengerList?.forEach((passenger: any) => {
      if (passenger?.seatInfo?.onwardFlights) {
        passenger?.seatInfo?.onwardFlights.forEach((p: any) => {
          passenSeatFee = passenSeatFee + Number(p?.price);
        });
      }
      if (passenger?.seatInfo?.returnFlights) {
        passenger?.seatInfo?.returnFlights.forEach((p: any) => {
          passenSeatFee = passenSeatFee + Number(p?.price);
        });
      }
    });
    setSeatFee(passenSeatFee);

    if (passengerList[0]?.markup) {
      let serviceFee =
        selectedItinerary?.price?.handlingFeeValue +
        Number(passengerList[0]?.markup?.markupValue) -
        selectedItinerary?.price?.discount;
      // console.log(
      //   selectedItinerary?.price?.handlingFeeValue,
      //   Number(passengerList[0]?.markup),
      //   selectedItinerary?.price?.discount
      // );
      setServiceFee(serviceFee);
    }
  }, [passengerList]);

  const bookRequestPaxData = passengerList?.map(
    (passenger: any, paxIndex: any) => {
      const {
        baggageInfo,
        contactInfo,
        mealInfo,
        passportInfo,
        paxInfo,
        markup,
        seatInfo,
      } = passenger;

      let baggageCharge = 0;
      let mealCharge = 0;

      // if (selectedItinerary?.isRequiredAncillary) {
        baggageCharge =
          baggageInfo?.onwardBaggage?.baggageCharge ? baggageInfo?.onwardBaggage?.baggageCharge : 0 +
          baggageInfo?.returnBaggage?.baggageCharge ? baggageInfo?.returnBaggage?.baggageCharge : 0;

        mealCharge =
          mealInfo?.onwardMeal?.mealCharge ? mealInfo?.onwardMeal?.mealCharge : 0 + 
          mealInfo?.returnMeal?.mealCharge ? mealInfo?.returnMeal?.mealCharge : 0;
      // }

      let seatPrice = 0;
      seatInfo?.onwardFlights?.forEach((seat: any) => {
        seatPrice = seatPrice + seat?.price ? seat?.price : 0;
      });

      seatInfo?.returnFlights?.forEach((seat: any) => {
        seatPrice = seatPrice + seat?.price ? seat?.price : 0;
      });

      const country = countries?.filter(
        (country: any) => country?.value == passportInfo?.country
      )[0];
      const nationality = nationalities?.filter(
        (nationality: any) => nationality?.value == passportInfo?.nationality
      )[0];

      let mealCodeString: any = '';
      let mealDescString: any = '';

      if (mealInfo?.onwardMeal != null || mealInfo?.returnMeal != null) {
        let mealCodes: any = [];
        const mealArr = Object.values(mealInfo);
        mealArr?.forEach((meal: any) => {
          let mealCode = '';
          mealCode = meal == null ? '' : meal?.mealCode;
          mealCodes.push(mealCode);
        });

        mealCodes?.forEach((mealCode: any, index: number) => {
          if (index + 1 !== mealCodes?.length) {
            mealCodeString = mealCodeString + `${mealCode}, `;
          } else {
            mealCodeString = mealCodeString + `${mealCode}`;
          }
        });

        let mealDes: any = [];
        mealArr?.forEach((meal: any) => {
          let mealDesc = '';
          mealDesc = meal == null ? '' : meal?.mealDescription;
          mealDes.push(mealDesc);
        });

        mealDes?.forEach((mealdescription: any, index: number) => {
          if (index + 1 !== mealDes?.length) {
            mealDescString = mealDescString + `${mealdescription}, `;
          } else {
            mealDescString = mealDescString + `${mealdescription}`;
          }
        });
      }

      let baggageCodeString: any = '';

      if (
        baggageInfo?.onwardBaggage != null ||
        baggageInfo?.returnBaggage != null
      ) {
        let baggageCodes: any = [];
        const baggageArr = Object.values(baggageInfo);
        baggageArr?.forEach((baggage: any) => {
          let baggageCode = '';
          baggageCode = baggage == null ? '0 kg' : baggage?.baggageCode;
          baggageCodes.push(baggageCode);
        });
        baggageCodes?.forEach((baggageCode: any, index: number) => {
          if (index + 1 !== baggageCodes?.length) {
            baggageCodeString = baggageCodeString + `${baggageCode}, `;
          } else {
            baggageCodeString = baggageCodeString + `${baggageCode}`;
          }
        });
      }
      let cabinBaggage: any = [];
      selectedItinerary?.flights?.forEach((journey: any) => {
        journey?.forEach((flight: any) => {
          let baggage = '';
          if (flight?.carryOnBaggage != null) baggage = flight?.carryOnBaggage;
          cabinBaggage.push(baggage);
        });
      });

      let cabinBaggageString = '';
      cabinBaggage?.forEach((baggage: any, index: number) => {
        if (index + 1 !== cabinBaggage?.length) {
          cabinBaggageString = cabinBaggageString + `${baggage}, `;
        } else {
          cabinBaggageString = cabinBaggageString + `${baggage}`;
        }
      });

      let seats: any = [];
      let seatInfoArr: any = [];

      seatInfo?.onwardFlights?.forEach((flightSeat: any) => {
        const segmentFlight = selectedItinerary?.flights[0]?.filter(
          (flight: any) => flight?.flightNumber == flightSeat?.flightNo
        )[0];
        // const seatString = `${flightSeat?.seatNo}(${segmentFlight?.segmentId})`;
        const seatString = `${flightSeat?.seatNo}(${segmentFlight?.origin?.airportCode}-${segmentFlight?.destination?.airportCode})`;
        seatInfoArr?.push(seatString);
        const segmentString = `${segmentFlight?.origin?.airportCode}-${segmentFlight?.destination?.airportCode}`;
        const seat = {
          paxNo: paxIndex,
          segment: segmentString,
          seatNo: flightSeat?.seatNo,
          price: flightSeat?.price,
          seatStatus: 'A',
          code: flightSeat?.seatNo,
          priceRefKey: '',
          supplierPrice: flightSeat?.price,
        };
        seats?.push(seat);
      });

      seatInfo?.returnFlights?.forEach((flightSeat: any) => {
        const segmentFlight = selectedItinerary?.flights[1]?.filter(
          (flight: any) => flight?.flightNumber == flightSeat?.flightNo
        )[0];
        // const seatString = `${flightSeat?.seatNo}(${segmentFlight?.segmentId})`;
        const seatString = `${flightSeat?.seatNo}(${segmentFlight?.origin?.airportCode}-${segmentFlight?.destination?.airportCode})`;
        seatInfoArr?.push(seatString);
        const segmentString = `${segmentFlight?.origin?.airportCode}-${segmentFlight?.destination?.airportCode}`;
        const seat = {
          paxNo: paxIndex,
          segment: segmentString,
          seatNo: flightSeat?.seatNo,
          price: flightSeat?.price,
          seatStatus: 'A',
          code: flightSeat?.seatNo,
          priceRefKey: '',
          supplierPrice: flightSeat?.price,
        };
        seats?.push(seat);
      });

      let seatInfoString = '';
      seatInfoArr?.forEach((seatString: any, index: number) => {
        if (index + 1 != seatInfoArr?.length) {
          seatInfoString = seatInfoString + `${seatString}|`;
        } else {
          seatInfoString = seatInfoString + seatString;
        }
      });

      return {
        paxId: paxIndex,
        supplierPaxId: 0,
        flightId: 0,
        firstName: paxInfo?.firstName,
        lastName: paxInfo?.lastName,
        title: paxInfo?.title === '01' ? 'Mr. ' : 'Mrs. ',
        cellPhone: contactInfo?.mobileNo,
        isLeadPax: paxIndex === 0 ? true : false,
        dateOfBirth: new Date(
          parseInt(paxInfo?.dobyear),
          parseInt(paxInfo?.dobmonth) - 1,
          parseInt(paxInfo?.dobdate)
        ),
        type: passenger?.type,
        passportNo: passportInfo?.passportNo,
        nationality: {
          countryName: nationality?.value,
          regioncode: nationality?.value,
          nationality: nationality?.value,
          countryCode: nationality?.value,
        },
        country: {
          countryName: country?.text,
          regioncode: country?.value,
          nationality: country?.text,
          countryCode: country?.value,
        },
        city: passportInfo?.address1,
        addressLine1: passportInfo?.address1,
        addressLine2: passportInfo?.address2,
        gender: Number(paxInfo?.gender),
        email: contactInfo?.email,
        meal: {
          code: mealCodeString,
          description: mealDescString,
        },
        seat: {
          code: '',
          description: '',
        },
        price: {
          ...selectedItinerary?.price,
          ...rePriceData?.price,
          baggageCharge: baggageCharge,
          mealCharge: mealCharge,
          seatPrice: seatPrice,
          airlineCommission: {
            commissionId: 0,
            discount: 0,
            commissionValue: 0,
            commissionType: '',
            commissionAppliedOn: '',
            priceId: 0,
            discountValue: 0,
            discountType: '',
          },
          markupValue: Number(markup?.markupValue),
          markupType: markup?.markupType,
          asvAmount: Number(markup?.markupValue),
          asvType: markup?.markupUnit,
          asvElement: markup?.markupType,
        },
        ffAirline: paxInfo?.maxinp1,
        ffNumber: paxInfo?.maxinp2,
        createdBy: 0,
        createdOn: new Date().toISOString(),
        lastModifiedBy: 0,
        lastModifiedOn: new Date().toISOString(),
        passportExpiry: new Date(
          parseInt(passportInfo?.passportYear),
          parseInt(passportInfo?.passportMonth) - 1,
          parseInt(passportInfo?.passportDate)
        ).toISOString(),
        baggageCode: baggageCodeString,
        cabinBaggage: cabinBaggageString,
        baggageType: baggageCodeString,
        categoryId: '',
        flyDubaiBaggageCharge: [0],
        flexDetailsList: [
          {
            detailsId: 0,
            flexId: 0,
            paxId: 0,
            flexLabel: '',
            flexData: '',
            createdBy: 0,
            productID: 0,
            flexGDSprefix: '',
            sIsOffline: '',
          },
        ],
        destinationPhone: '',
        gstStateCode: '',
        gstTaxRegNo: '',
        stateCode: '',
        taxBreakup: [
          {
            key: '',
            value: 0,
          },
        ],
        mealType: mealCodeString,
        mealDesc: mealDescString,
        seatInfo: seatInfoString,
        corpProfileId: '',
        liPaxSeatInfo: seats,
        agentId: 0,
        salamAirMealCharge: [0],
        passengerKey: '',
        priceInfoKey: '',
        bookingTravellerRefKey: '',
        ssrInfos: [
          {
            code: '',
            description: '',
            group: 0,
            price: 0,
            discount: 0,
            currencyCode: '',
            baseCurrencyPrice: 0,
            baseCurrencyDiscount: 0,
            baseCurrencyCode: '',
            ssrType: '',
            suppInfo: [
              {
                keys: [''],
                baseCurrencyPrice: 0,
                baseCurrencyCode: '',
              },
            ],
          },
        ],
        isTicketed: true,
      };
    }
  );

  const bookRequestData = {
    sessionId: selectedItinerary?.sessionId,
    flightGuId: selectedItinerary?.flightGuId,
    passenger: bookRequestPaxData,
  };

  const handleTrCash = () => {
    setTRCash(!trCash);
    setTrRemark(!trRemark);
    setTrBalance(!trBalance);
    setTrOnAccount(!trOnAccount);
  };

  const handleTrBank = () => {
    setTRBank(!trBank);
    setTrRemark(!trRemark);
    setTrBalance(!trBalance);
    setTrOnAccount(!trOnAccount);
  };

  const handleTrCredit = () => {
    setTRCredit(!trCredit);
    setTrRemark(!trRemark);
    setTrBalance(!trBalance);
    setTrOnAccount(!trOnAccount);
  };

  const handleTrPos = () => {
    setTRPos(!trPos);
    setTrRemark(!trRemark);
    setTrBalance(!trBalance);
    setTrOnAccount(!trOnAccount);
  };

  const onProceedBook = async (data: any) => {
    try {
      setLoader(true);
      const getFlightBookData: any = await getFlightBookInfo(bookRequestData);
      const data1 = data == 'hold' ? getFlightBookData : null;
      const data2 = data == 'proceed' ? getFlightBookData : null;

      setLoader(false);
      if (
        getFlightBookData &&
        getFlightBookData.status === 200 &&
        getFlightBookData.data.status === 1
      ) {
        saveBookingDataResult({ data1, data2 });
        navigate('/flight-e-ticket');
      } else if (
        getFlightBookData &&
        getFlightBookData.status === 200 &&
        getFlightBookData.data.message
      ) {
        saveFlightTicketErrorResult({
          message: `Session ID: ${selectedItinerary?.sessionId} Error: ${getFlightBookData.data.message}`,
        });
      } else if (
        getFlightBookData &&
        getFlightBookData.status === 200 &&
        getFlightBookData.data.error
      ) {
        saveFlightTicketErrorResult({
          message: `Session ID: ${selectedItinerary?.sessionId} Error: ${getFlightBookData.data.error}`,
        });
      } else if (
        getFlightBookData &&
        getFlightBookData.status === 200 &&
        getFlightBookData.data.ssrMessage
      ) {
        saveFlightTicketErrorResult({
          message: `Session ID: ${selectedItinerary?.sessionId} Error: ${getFlightBookData.data.ssrMessage}`,
        });
      } else {
        if (
          getFlightBookData &&
          getFlightBookData.status === 200 &&
          getFlightBookData?.data?.pnr
        ) {
          saveFlightTicketErrorResult({
            message: `Session ID: ${selectedItinerary?.sessionId} Error: Booking is created. PNR is ${getFlightBookData.data.pnr}  Ticket is not created and contact support team.`,
          });
        } else {
          saveFlightTicketErrorResult({
            message: `Session ID: ${selectedItinerary?.sessionId} Error: Something went wrong. Please contact support`,
          });
        }
        navigate('/error-page');
      }
      // if (getFlightBookData && getFlightBookData.status == 200 && getFlightBookData.data.error !== null ) {
      //    navigate('/error-page');
      //   throw new Error(getFlightBookData.data.error);
      // } else {
      //   saveBookingDataResult({data1,data2});
      //   navigate('/flight-e-ticket');
      // }
    } catch (errorMessage: any) {
      navigate('/error-page');
      toast.error(` ${errorMessage}`);
    }
  };

  const onBookUapiFlight = async (data: any) => {
    try {
      setLoader(true);
      const getFlightBookData: any = await getUapiFlightBookInfo(
        bookRequestData
      );
      const data1 = null;
      const data2 = data == 'proceed' ? getFlightBookData : null;
      setLoader(false);
      saveBookingDataResult({ data1, data2 });
      if (
        getFlightBookData &&
        getFlightBookData.status === 200 &&
        getFlightBookData.data.status === 1
      ) {
        navigate('/flight-e-ticket');
      } else if (
        getFlightBookData &&
        getFlightBookData.status === 200 &&
        getFlightBookData.data.message
      ) {
        saveFlightTicketErrorResult({
          message: `Session ID: ${selectedItinerary?.sessionId} Error: ${getFlightBookData.data.message}`,
        });
      } else if (
        getFlightBookData &&
        getFlightBookData.status === 200 &&
        getFlightBookData.data.error
      ) {
        saveFlightTicketErrorResult({
          message: `Session ID: ${selectedItinerary?.sessionId} Error: ${getFlightBookData.data.error}`,
        });
      } else if (
        getFlightBookData &&
        getFlightBookData.status === 200 &&
        getFlightBookData.data.ssrMessage
      ) {
        saveFlightTicketErrorResult({
          message: `Session ID: ${selectedItinerary?.sessionId} Error: ${getFlightBookData.data.ssrMessage}`,
        });
      } else {
        if (
          getFlightBookData &&
          getFlightBookData.status === 200 &&
          getFlightBookData?.data?.pnr
        ) {
          saveFlightTicketErrorResult({
            message: `Session ID: ${selectedItinerary?.sessionId} Error: Booking is created. PNR is ${getFlightBookData.data.pnr}  Ticket is not created and contact support team.`,
          });
        } else {
          saveFlightTicketErrorResult({
            message: `Session ID: ${selectedItinerary?.sessionId} Error: Something went wrong. Please contact support`,
          });
        }
        navigate('/error-page');
      }

      // if ((getFlightBookData && getFlightBookData.status !== 200 && getFlightBookData.data.status !== 2 && getFlightBookData.data.error)) {
      //   navigate('/error-page');
      //   throw new Error(getFlightBookData.data.error);
      // }else if ( getFlightBookData?.data?.status == 0 &&  getFlightBookData?.data?.pnr)
      //   {
      //     saveFlightTicketErrorResult({ message: `${selectedItinerary?.sessionId }Booking is created. PNR is ${getFlightBookData.data.pnr}  Ticket is not created and contact support team.` });
      // }else if(getFlightBookData?.data?.status == 0 &&  !getFlightBookData?.data?.pnr){
      //   saveFlightTicketErrorResult({ message: ` ${selectedItinerary?.sessionId } Something went wrong. Please contact support` } )
      // }
      // else {
      //   navigate('/flight-e-ticket');
      // }
    } catch (errorMessage: any) {
      navigate('/error-page');
      toast.error(` ${errorMessage}`);
    }
  };

  const handleCheckboxChange = (e: any) => {
    const { name, checked } = e.target;
    setCheckboxValues((prevValues) => ({
      ...prevValues,
      [name]: checked,
    }));
  };
  console.log('checkboxValues', checkboxValues);
  //show hide Itinerary mobile toogle
  const [showItinerary, setShowItinerary] = useState(false);
  const showFilterBlock = () => {
    setShowItinerary(!showItinerary);
  };

  return (
    <>
      <MainLayout>
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="innerContainer border-top-0">
                <div className="row">
                  <div className="col-lg-8 order-lg-0 order-2">
                    <div className="wrapper p_t_0_mb">
                      <div className="row">
                        <div className="col-12">
                          <div className="form_heading">
                            <span className="title">Passanger Details</span>
                          </div>
                        </div>
                      </div>

                      <div className="row">
                        <div className="col-12 mb-4">
                          <PaxNames pax={passengerList} />
                        </div>
                      </div>

                      <div className="row text-muted">
                        <div className="col-12 mb-1">
                          <h6>Terms & Conditions</h6>

                          <p className="font_size_90">
                            Ticket changes may incur peralties andfor increased
                            fares. Tickets are nontransferable and name charges
                            are not allowed. Read The complate enality rules for
                            changes adn cancellations applicable to this farm.
                          </p>
                        </div>

                        {/* <div className="col-12 mb-1">
                          <div className="form-check">
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="termconditions"
                              name="termconditions"
                            />

                            <label
                              className="font_size_90"
                              htmlFor="termconditions"
                            >
                              I confirm the required authorization has been
                              agreed by my line manager to travel.
                            </label>
                          </div>
                        </div> */}

                        {/* <div className="col-12 mb-1">
                          <div className="form-check">
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="termconditions2"
                              name="termconditions2"
                            />

                            <label
                              className="font_size_90"
                              htmlFor="termconditions2"
                            >
                              I confirm the required authorization has been
                              agreed by my line manager to travel. Please note:
                              Failure to obtain the required approval may result
                              in discplinary action and/or dismissal.
                            </label>
                          </div>
                        </div> */}

                        <div className="col-12 mb-1">
                          <div className="form-check">
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="termconditions3"
                              name="termconditions3"
                              checked={checkboxValues.termconditions3}
                              onChange={handleCheckboxChange}
                            />
                            <label
                              className="font_size_90"
                              htmlFor="termconditions3"
                            >
                              I have read and accept the rules & restrictions.
                            </label>
                          </div>

                          <div className="col-12 mb-1">
                            <div className="form-check">
                              <input
                                className="form-check-input"
                                type="checkbox"
                                id="termconditions4"
                                name="termconditions4"
                                checked={checkboxValues.termconditions4}
                                onChange={handleCheckboxChange}
                              />
                              <label
                                className="font_size_90"
                                htmlFor="termconditions4"
                              >
                                Kindly acknowledge the traveler has read the
                                travel declaration.
                              </label>
                            </div>
                          </div>
                        </div>
                        {/* <div className="col-12 mb-1">
                          <div className="form-check">
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="termconditions3"
                              name="termconditions3"
                            />

                            <label
                              className="font_size_90"
                              htmlFor="termconditions3"
                            >
                              I have read and aceept the rales & restrictions.
                            </label>
                          </div>
                        </div>

                        <div className="col-12 mb-1">
                          <div className="form-check">
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="termconditions4"
                              name="termconditions4"
                            />

                            <label
                              className="font_size_90"
                              htmlFor="termconditions4"
                            >
                              Kindly acknowledge the traveler have read the
                              travel declaration.
                            </label>
                          </div>
                        </div>
                      </div> */}

                        {!selectedItinerary?.isRequiredAncillary && (
                          <div className="row">
                            <div className="col-12 mt-2 mb-2 text-end">
                              <button
                                className="btn btn-primary text-uppercase"
                                onClick={() => onProceedBook('hold')}
                              >
                                Hold{' '}
                              </button>
                            </div>
                          </div>
                        )}

                        <div className="row">
                          <div className="col-12 mt-4 mb-4">
                            <div className="chkFlightPayCon mb-4">
                              <label
                                className="chkpleft me-3"
                                htmlFor="onAccount"
                              >
                                <div className="input-group">
                                  <div className="input-group-prepend">
                                    <span className="iconholder mt-2">
                                      <i className="fa-regular fa-user"></i>
                                    </span>
                                  </div>
                                  <span className="title">On Account </span>
                                </div>
                                <input
                                  type="checkbox"
                                  id="onAccount"
                                  name="onAccount"
                                  checked
                                  disabled
                                />
                                <span className="checkmark"></span>
                              </label>

                              {/* <label
                              className="chkpleft me-3"
                              htmlFor="paybycash"
                            >
                              <div className="input-group">
                                <div className="input-group-prepend">
                                  <span className="iconholder mt-2">
                                    <i className="fa-solid fa-dollar-sign"></i>
                                  </span>
                                </div>
                                <span className="title">Pay By Cash</span>
                              </div>
                              <input
                                type="checkbox"
                                id="paybycash"
                                name="paybycash"
                                onChange={handleTrCash}
                              />
                              <span className="checkmark"></span>
                            </label> */}

                              {/* <label
                              className="chkpleft me-3"
                              htmlFor="banktransfer"
                            >
                              <div className="input-group">
                                <div className="input-group-prepend">
                                  <span className="iconholder mt-2">
                                    <i className="fa-solid fa-dollar-sign"></i>
                                  </span>
                                </div>
                                <span className="title">Bank Transfer</span>
                              </div>
                              <input
                                type="checkbox"
                                id="banktransfer"
                                name="banktransfer"
                                onChange={handleTrBank}
                              />
                              <span className="checkmark"></span>
                            </label> */}

                              {/* <label
                              className="chkpleft me-3"
                              htmlFor="paybycredit"
                            >
                              <div className="input-group">
                                <div className="input-group-prepend">
                                  <span className="iconholder mt-2">
                                    <i className="fa-solid fa-dollar-sign"></i>
                                  </span>
                                </div>
                                <span className="title">Credit</span>
                              </div>
                              <input
                                type="checkbox"
                                id="paybycredit"
                                name="paybycredit"
                                onChange={handleTrCredit}
                              />
                              <span className="checkmark"></span>
                            </label> */}

                              {/* <label className="chkpleft me-3" htmlFor="ccpos">
                              <div className="input-group">
                                <div className="input-group-prepend">
                                  <span className="iconholder mt-2">
                                    <i className="fa-solid fa-dollar-sign"></i>
                                  </span>
                                </div>
                                <span className="title">CC POS</span>
                              </div>
                              <input
                                type="checkbox"
                                id="ccpos"
                                name="ccpos"
                                onChange={handleTrPos}
                              />
                              <span className="checkmark"></span>
                            </label> */}

                              {/* <label className="chkpleft" htmlFor="paybycard">
                              <div className="input-group">
                                <div className="input-group-prepend">
                                  <span className="iconholder mt-2">
                                    <i className="fa-solid fa-credit-card"></i>
                                  </span>
                                </div>
                                <span className="title">Pay By Card</span>
                              </div>
                              <input type="checkbox" id="paybycard" />
                              <span className="checkmark"></span>
                            </label> */}
                            </div>

                            <div className="col-12">
                              <div className="flightPayTbl">
                                <table className="table table-bordered mb-0">
                                  <tbody>
                                    {trCash && (
                                      <tr id="tr_Cash">
                                        <td className="align-middle">Cash</td>
                                        <td>
                                          <div className="row">
                                            <div className="col-lg-3">
                                              <div className="input-group">
                                                <div className="input-group-append me-2">
                                                  <small className="color-muted">
                                                    {
                                                      selectedItinerary?.price
                                                        ?.supplierCurrency
                                                    }{' '}
                                                  </small>
                                                </div>

                                                <input
                                                  type="text"
                                                  className="form-control"
                                                  value="320"
                                                />
                                              </div>
                                            </div>
                                          </div>
                                        </td>
                                      </tr>
                                    )}

                                    {trBank && (
                                      <tr id="tr_bankTransfer">
                                        <td className="align-middle">
                                          Bank Transfer
                                        </td>
                                        <td>
                                          <div className="row">
                                            <div className="col-lg-3">
                                              <div className="input-group">
                                                <div className="input-group-append me-2">
                                                  <small className="color-muted">
                                                    {
                                                      selectedItinerary?.price
                                                        ?.supplierCurrency
                                                    }{' '}
                                                  </small>
                                                </div>

                                                <input
                                                  type="text"
                                                  className="form-control"
                                                  value="320"
                                                />
                                              </div>
                                            </div>

                                            <div className="col-lg-4">
                                              <div className="group_input_flight_pc">
                                                <div className="input-group">
                                                  <div className="input-group-prepend p-0">
                                                    <span className="input-group-text">
                                                      Ref. No.
                                                    </span>
                                                  </div>
                                                  <input
                                                    type="text"
                                                    className="form-control"
                                                  />
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </td>
                                      </tr>
                                    )}

                                    {trPos && (
                                      <tr id="tr_CCPOS">
                                        <td className="align-middle">CC POS</td>
                                        <td>
                                          <div className="row">
                                            <div className="col-lg-3">
                                              <div className="input-group">
                                                <div className="input-group-append me-2">
                                                  <small className="color-muted">
                                                    {
                                                      selectedItinerary?.price
                                                        ?.supplierCurrency
                                                    }{' '}
                                                  </small>
                                                </div>

                                                <input
                                                  type="text"
                                                  className="form-control"
                                                  value="320"
                                                />
                                              </div>
                                            </div>

                                            <div className="col-lg-3">
                                              <div className="group_input_flight_pc">
                                                <div className="input-group">
                                                  <select className="form-select">
                                                    <option value="">
                                                      Card Type
                                                    </option>
                                                    <option value="">
                                                      ---
                                                    </option>
                                                    <option value="">
                                                      ---
                                                    </option>
                                                  </select>
                                                </div>
                                              </div>
                                            </div>

                                            <div className="col-lg-6">
                                              <div className="group_input_flight_pc">
                                                <div className="input-group">
                                                  <div className="input-group-prepend p-0">
                                                    <span className="input-group-text">
                                                      Card No.
                                                    </span>
                                                  </div>
                                                  <input
                                                    type="text"
                                                    className="form-control"
                                                  />
                                                </div>
                                              </div>
                                            </div>

                                            <div className="col-lg-6">
                                              <div className="group_input_flight_pc">
                                                <div className="input-group mt-2">
                                                  <div className="input-group-prepend p-0">
                                                    <span className="input-group-text">
                                                      Auth Code
                                                    </span>
                                                  </div>
                                                  <input
                                                    type="text"
                                                    className="form-control"
                                                  />
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </td>
                                      </tr>
                                    )}

                                    {trCredit && (
                                      <tr id="tr_Credit">
                                        <td className="align-middle">Credit</td>
                                        <td>
                                          <div className="row">
                                            <div className="col-lg-3">
                                              <div className="input-group">
                                                <div className="input-group-append me-2">
                                                  <small className="color-muted">
                                                    {
                                                      selectedItinerary?.price
                                                        ?.supplierCurrency
                                                    }{' '}
                                                  </small>
                                                </div>

                                                <input
                                                  type="text"
                                                  className="form-control"
                                                  value="320"
                                                />
                                              </div>
                                            </div>

                                            <div className="col-lg-3">
                                              <div className="input-group">
                                                <select className="form-select">
                                                  <option value="">
                                                    Customer
                                                  </option>
                                                  <option value="">---</option>
                                                  <option value="">---</option>
                                                </select>
                                              </div>
                                            </div>
                                          </div>
                                        </td>
                                      </tr>
                                    )}

                                    {trRemark && (
                                      <tr id="remarks_TRN">
                                        <td className="align-middle"></td>
                                        <td>
                                          <div className="row">
                                            <div className="col-lg-6">
                                              <div className="group_input_flight_pc">
                                                <div className="input-group">
                                                  <div className="input-group-prepend p-0">
                                                    <span className="input-group-text">
                                                      TRN No.
                                                    </span>
                                                  </div>
                                                  <input
                                                    type="text"
                                                    className="form-control"
                                                  />
                                                </div>
                                              </div>
                                            </div>

                                            <div className="col-lg-6">
                                              <div className="group_input_flight_pc">
                                                <div className="input-group">
                                                  <div className="input-group-prepend p-0">
                                                    <span className="input-group-text">
                                                      Remarks
                                                    </span>
                                                  </div>
                                                  <input
                                                    type="text"
                                                    className="form-control"
                                                  />
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </td>
                                      </tr>
                                    )}

                                    {trBalance && (
                                      <tr id="TrBalance2">
                                        <td className="align-middle">
                                          Balance
                                        </td>
                                        <td>
                                          <small className="color-muted">
                                            {
                                              selectedItinerary?.price
                                                ?.supplierCurrency
                                            }{' '}
                                          </small>{' '}
                                          <strong>0.00</strong>
                                        </td>
                                      </tr>
                                    )}
                                  </tbody>
                                </table>

                                {trOnAccount && (
                                  <table className="table table-bordered mb-0">
                                    <tbody>
                                      <tr>
                                        <td className="align-middle">
                                          Available Balance
                                        </td>
                                        <td>
                                          <small className="color-muted">
                                            {
                                              selectedItinerary?.price
                                                ?.supplierCurrency
                                            }{' '}
                                          </small>{' '}
                                          <strong>
                                            {balanceInfo?.currentBalance?.toFixed(
                                              2
                                            )}
                                          </strong>
                                        </td>
                                      </tr>

                                      <tr>
                                        <td className="align-middle">
                                          Order Amount
                                        </td>
                                        <td>
                                          <small className="color-muted">
                                            {
                                              selectedItinerary?.price
                                                ?.supplierCurrency
                                            }{' '}
                                          </small>{' '}
                                          <strong>
                                            {selectedItinerary?.totalFare +
                                              Number(baggageFee) +
                                              Number(mealFee) +
                                              Number(seatFee) +
                                              Number(
                                                selectedItinerary?.price
                                                  ?.discount
                                              ) +
                                              Number(serviceFee)}
                                          </strong>
                                        </td>
                                      </tr>

                                      <tr>
                                        <td className="align-middle">
                                          Remaining Balance
                                        </td>
                                        <td>
                                          <small className="color-muted">
                                            {
                                              selectedItinerary?.price
                                                ?.supplierCurrency
                                            }{' '}
                                          </small>{' '}
                                          <strong>
                                            {!isNaN(
                                              balanceInfo?.currentBalance
                                            ) &&
                                              !isNaN(
                                                selectedItinerary?.totalFare
                                              ) &&
                                              (
                                                balanceInfo?.currentBalance -
                                                selectedItinerary?.totalFare
                                              )?.toFixed(2)}
                                          </strong>
                                        </td>
                                      </tr>
                                    </tbody>
                                  </table>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="row">
                          <div className="col-12 mt-4 mb-4 text-end">
                            {selectedItinerary?.isRequiredAncillary ? (
                              <Button
                                // to="/flight-e-ticket"
                                className="btn btn-primary text-uppercase ps-4 pe-4"
                                onClick={() => onProceedBook('proceed')}
                                disabled={
                                  !checkboxValues.termconditions3 ||
                                  !checkboxValues.termconditions4 ||
                                  isNaN(balanceInfo?.currentBalance) ||
                                  isNaN(selectedItinerary?.totalFare) ||
                                  balanceInfo?.currentBalance < 0 ||
                                  balanceInfo?.currentBalance -
                                    selectedItinerary?.totalFare <=
                                    0
                                }
                              >
                                Proceed to Book
                              </Button>
                            ) : (
                              <Button
                                // to="/flight-e-ticket"
                                className="btn btn-primary text-uppercase ps-4 pe-4"
                                onClick={() => onBookUapiFlight('proceed')}
                                disabled={
                                  !checkboxValues.termconditions3 ||
                                  !checkboxValues.termconditions4 ||
                                  isNaN(balanceInfo?.currentBalance) ||
                                  isNaN(selectedItinerary?.totalFare) ||
                                  balanceInfo?.currentBalance < 0 ||
                                  balanceInfo?.currentBalance -
                                    selectedItinerary?.totalFare <=
                                    0
                                }
                              >
                                Proceed to Book
                              </Button>
                            )}
                            {/* {agentProfile?.currentBalance -
                            selectedItinerary?.totalFare <=
                          0 ? (
                            <button
                              className="btn btn-primary text-uppercase ps-4 pe-4"
                              disabled
                            >
                              Proceed to Book
                            </button>
                          ) : (
                            <Button
                              // to="/flight-e-ticket"
                              className="btn btn-primary text-uppercase ps-4 pe-4"
                              onClick={onProceedBook}
                              disabled={
                                !selectedItinerary?.isRequiredAncillary == true
                              }
                            >
                              Proceed to Book
                            </Button>
                          )} */}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-lg-4">
                    <div className="col-12 text-end mt-2 show_mobile">
                      <button
                        onClick={showFilterBlock}
                        type="button"
                        className="btn btn-sm"
                      >
                        {showItinerary ? (
                          <span>
                            Hide Itinerary <FiChevronUp />
                          </span>
                        ) : (
                          <span>
                            Review Itinerary <FiChevronDown />
                          </span>
                        )}
                      </button>
                    </div>
                    <div className={showItinerary ? '' : 'hide_mobile'}>
                      <div className="innerContainerRight">
                        <div className="row">
                          <div className="col-12 mt-md-2">
                            <div className="itenaryDetails">
                              <div className="row">
                                <div className="col-12">
                                  <div className="form_heading">
                                    <span className="title">
                                      Itinerary Details
                                    </span>
                                  </div>
                                </div>
                                <div className="col-12">
                                  {' '}
                                  <FlightItinerary />{' '}
                                </div>
                              </div>

                              <div className="row">
                                <div className="col-6">
                                  <FlightDetailsPopup
                                    itinerary={selectedItinerary}
                                  />
                                </div>
                                <div className="col-6">
                                  <BaggagePolicyPopup
                                    itinerary={selectedItinerary}
                                  />
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className="col-12 mt-2 mb-4">
                            <div className="row">
                              <div className="col-12">
                                <div className="form_heading">
                                  <span className="title">Fare Summary</span>
                                </div>
                              </div>
                              <div className="col-12">
                                <FareSummary passengerDetails={passengerList} />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                   
                    </div>

                  </div>
                </div>
              </div>
            </div>
          {/* </div> */}
          {loader && <Loader />}
        </div>
      </MainLayout>
    </>
  );
}
