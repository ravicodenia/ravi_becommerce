import { MainLayout } from '@mfa-travel-app/layout';
import { RootState } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { findAirlineLogo } from '@mfa-travel-app/shared';
import styles from '../flights.module.scss';
import classNames from 'classnames';
import { useState, useEffect } from 'react';

const DISCOUNT = 0;
const VAT = 0;

export default function FlightETicket() {
  const { passengerList, selectedItinerary, bookingData } = useSelector(
    (state: RootState) => state.flight
  );
  const { agentProfile } = useSelector(
    (state: RootState) => state.config
  );
  const [isPrinting, setIsPrinting] = useState(false);
  const flightBookingStatus: any = {
    0: 'NoStatus',
    1: 'Successful',
    2: 'Failed',
    3: 'OtherFare',
    4: 'OtherClass',
    5: 'BookedOther',
    6: 'ScheduleChanged',
    7: 'ReturnFailed',
    8: 'UpdatePaxFailed',
    9: 'Bookbaggagefailed',
    10: 'SSRforInfantFailed',
    11: 'Assignseatfailed',
    12: 'PriceChanged',
    13: 'DuplicateBooking',
    14: 'PartiallyConfirmed'

  }

  const onPrint = () => {
    window.print();
  };

  // useEffect(() => {
  //   const mediaQueryList = window.matchMedia('print');
  //   const handlePrintChange = (mql:any) => {
  //     setIsPrinting(mql.matches);
  //   };

  //   mediaQueryList.addListener(handlePrintChange);
  //   return () => {
  //     mediaQueryList.removeListener(handlePrintChange);
  //   };
  // }, []);


const transformPassengerData = () => {
  return passengerList?.flatMap((passenger: any, passengerIndex: number) => {
    const ticketNumber =
      bookingData?.data2?.data?.tickets?.[passengerIndex]?.ticketNumber ||
      bookingData?.data2?.data?.pnr ||
      bookingData?.data1?.data?.pnr;
    const getAirportCodes = (flights: any) => {
      return flights.map((journey: any) => {
        return journey.map((flight: any, index: number) => {
          return {
            origin: flight.origin.airportCode,
            destination:
              index < journey.length - 1
                ? journey[index + 1].origin.airportCode
                : flight.destination.airportCode
          };
        });
      });
    };

    const airportCodes = getAirportCodes(selectedItinerary.flights);

    const createPassengerEntry = (
      flight: any,
      isOnward: boolean,
      journeyIndex: number,
      flightIndex: number,
      sector: any,
      ticketNumber: string
    ) => {
      const flightType = isOnward ? 'onwardFlights' : 'returnFlights';
      const seatInfo = passenger?.seatInfo?.[flightType]?.find((f: any) => {
        return (
          f.passengerNo === passenger?.passengerNo &&
          f.flightNo === flight.flightNumber
        );
      });

      const baggageInfo = isOnward
        ? passenger?.baggageInfo?.onwardBaggage
        : passenger?.baggageInfo?.returnBaggage;

      const mealInfo = isOnward
        ? passenger?.mealInfo?.onwardMeal
        : passenger?.mealInfo?.returnMeal;

      return {
        paxInfo: {
          firstName: passenger.paxInfo.firstName,
          lastName: passenger.paxInfo.lastName,
        },
        ticketNumber,
        flightNumber: flight.flightNumber,
        sector: `${sector.origin} - ${sector.destination}`,
        checkinBaggage: `${flight.defaultBaggage} ${
          baggageInfo?.baggageCode || ""
        }`,
        handBaggage: flight.carryOnBaggage || "Airline Policy",
        meal: mealInfo?.mealCode
          ? `${mealInfo.mealCode} ${mealInfo.mealDescription}`
          : "Airline Policy",
        seats: seatInfo ? seatInfo.seatNo : "Airline Policy",
        airlinePNR:
          bookingData?.data2?.data?.pnr || bookingData?.data1?.data?.pnr,
        journeyType: isOnward ? "Onward" : "Return",
        journeyIndex: journeyIndex + 1,
        flightIndex: flightIndex + 1,
      };
    };
    const createEntriesForFlights = (
      flights: any[],
      sectors: any[],
      isOnward: boolean,
      ticketNumber: string
    ) => {
      return flights.flatMap((journey: any[], journeyIndex: number) => {
        return journey.map((flight: any, flightIndex: number) => {
          const sector = sectors[journeyIndex]?.[flightIndex];
          return createPassengerEntry(
            flight,
            isOnward,
            journeyIndex,
            flightIndex,
            sector,
            ticketNumber
          );
        });
      });
    };

    const onwardFlights =
      selectedItinerary.flights.length === 1
        ? selectedItinerary.flights
        : selectedItinerary.flights.slice(
            0,
            Math.ceil(selectedItinerary.flights.length / 2)
          );

    const returnFlights =
      selectedItinerary.flights.length > 1
        ? selectedItinerary.flights.slice(
            Math.ceil(selectedItinerary.flights.length / 2)
          )
        : [];

    return [
      ...createEntriesForFlights(
        onwardFlights,
        airportCodes.slice(0, Math.ceil(airportCodes.length / 2)),
        true,
        ticketNumber
      ),
      ...createEntriesForFlights(
        returnFlights,
        airportCodes.slice(Math.ceil(airportCodes.length / 2)),
        false,
        ticketNumber
      ),
    ];
  });
};

  const modifyPassengerData = transformPassengerData();

  const processData = () => {
    const fareDetail = passengerList.map((passenger: any) => {
      const baseFare = selectedItinerary.fareBreakdown.find((fb: any) => fb.passengerType === passenger.type)?.baseFare || 0;
      const tax = selectedItinerary.fareBreakdown.find((fb: any) => fb.passengerType === passenger.type)?.tax || 0;
      let totalFare = selectedItinerary.fareBreakdown.find((fb: any) => fb.passengerType === passenger.type)?.totalFare || 0;
      const flight = selectedItinerary.flights[0][0];
      const onwardSeatPrice = passenger?.seatInfo?.onwardFlights?.reduce((acc: number, flight: any) => acc + (flight.price || 0), 0) || 0;
      const returnSeatPrice = passenger?.seatInfo?.returnFlights?.reduce((acc: number, flight: any) => acc + (flight.price || 0), 0) || 0;
      const totalSeatPrice = onwardSeatPrice + returnSeatPrice;
      const totalBaggagePrice = Number(passenger?.baggageInfo?.onwardBaggage?.baggageCharge) + Number(passenger?.baggageInfo?.returnBaggage?.baggageCharge || 0) || "AirPolicy";
      const totalMealPrice = Number(passenger?.mealInfo?.onwardMeal?.mealCharge) + Number(passenger?.mealInfo?.returnMeal?.mealCharge || 0) || "AirPolicy";
  
      // if (totalBaggagePrice != 'AirPolicy') {
      //   totalFare = totalFare + totalBaggagePrice
      // }
      // if (totalMealPrice != 'Airline Policy') {
      //   totalFare = totalFare + totalMealPrice
      // }
      totalFare = (totalFare + totalSeatPrice + VAT) - DISCOUNT

      return {
        passengerType: passenger.type === 1 ? 'Adult' : 'Child',
        airFare: baseFare.toFixed(2),
        taxesFees: tax.toFixed(2),
        discount: DISCOUNT.toFixed(2),
        baggage: totalBaggagePrice,
        meal: totalMealPrice,
        seats: (totalSeatPrice).toFixed(2),
        // seats: passenger?.seatInfo?.onwardJourney[flight.flightNumber] || passenger?.seatInfo?.returnJourney[flight.flightNumber] || 'Airline Policy',
        vat: VAT.toFixed(2),
        total: totalFare?.toFixed(2)
      };
    });

    const grandTotal = selectedItinerary.totalFare;

    return { fareDetail, grandTotal };
  };

  const { fareDetail, grandTotal } = processData();

  const totalSumFaareDetail = fareDetail?.reduce((accumulator: any, current: any) => {
    return accumulator + parseFloat(current.total);
  }, 0);

  const convertDate = (dateString: any) => {
    let date;
    if (dateString.includes('T')) {
      const [datePart, timePart] = dateString.split('T');
      const [year, month, day] = datePart.split('-');
      const [hour, minute, second] = timePart.split(':');
      date = new Date(year, month - 1, day, hour, minute, second);
    } else {
      date = new Date(dateString);
    }

    return date.toLocaleString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  }

  const convertTimeString = (timeString: any) => {
    const [hours, minutes, seconds] = timeString.split(':').map(Number);
    const totalMinutes = (hours * 60) + minutes;
    const newHours = Math.floor(totalMinutes / 60);
    const newMinutes = totalMinutes % 60;
    return `${newHours}hr ${newMinutes}min`;
  }


  let currentName = '';
  let currentTicket = '';
  let nameRowSpan = 0;
  let ticketRowSpan = 0;

  return (
    <>
      <div className={styles['print-wrapper']}>

        <MainLayout>
          <div className={classNames(`container `)}>
            <div className={classNames(`row `)}>
              <div className={styles['main-container']}>
                <div className="col-12">
                  <table className="table table-borderless">
                    <tbody>
                      <tr>
                        <td className="text-center" colSpan={2}> <h4>e-Ticket</h4></td>
                        <td className="text-end">
                          <button className={classNames(`btn p-0 m-0,${styles['print-button']}`)} onClick={onPrint}>
                            <i className="fa fa-print" aria-hidden="true"></i>
                          </button>
                          {/* <button className="btn p-0 m-0">
                        <i className="fa fa-print" aria-hidden="true" onClick={onPrint}></i>
                      </button> */}
                        </td>
                      </tr>
                      <tr>
                        <td colSpan={2}><strong>Reservation Details:</strong></td>
                      </tr>
                      <tr>
                        <td>
                          <div><small className="text-muted">Trip Ref.:</small> | <b>{bookingData?.data2?.data?.pnr || bookingData?.data1?.data?.pnr}</b></div>
                          <div><small className="text-muted">Status</small>  | <b>{flightBookingStatus[bookingData?.data1?.data?.status || bookingData?.data2?.data?.status || 0]}</b> </div>
                        </td>
                        <td className="fw-bold float-end">
                          <table className="d-inline">
                            <tbody>
                              <tr>
                                <td><span className="me-3">Agent Name:</span> </td>
                                <td>{agentProfile.name}</td>
                              </tr>
                              <tr>
                                <td><span className="me-3">Agent eMail:</span></td>
                                <td>Support@bcommerce.com </td>
                              </tr>
                              <tr>
                                <td><span className="me-3">Phone:</span>  </td>
                                <td>{agentProfile.mobile}</td>
                              </tr>
                            </tbody>
                          </table>
                        </td>
                      </tr>
                    </tbody>
                  </table>

                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-12">
                <div className="tblFlightEticket">
                  <div className="heading">Passenger Details</div>
                  <div className="table-responsive paxDetails">
                    <table className="table table-bordered border-primary">
                      <thead>
                        <tr>
                          <th>Passenger Name</th>
                          <th className="text-center">Ticket Number</th>
                          <th className="text-center">Flight Number</th>
                          <th className="text-center">Sector</th>
                          <th className="text-center">
                            <div>Checkin Baggage</div>
                            <div>
                              <span className="border-top">Included</span> |{" "}
                              <span className="border-top">Extra</span>
                            </div>
                          </th>
                          <th className="text-center">Hand Baggage</th>
                          <th className="text-center">Meal</th>
                          <th className="text-center">Seats</th>
                          <th className="text-center">Airline PNR</th>
                        </tr>
                      </thead>
                      <tbody>
                        {modifyPassengerData?.map((passenger: any, index: any) => {
                          const fullName = `${passenger?.paxInfo?.firstName} ${passenger?.paxInfo?.lastName}`;

                          if (fullName !== currentName) {
                            currentName = fullName;
                            nameRowSpan = 1;
                            while (
                              index + nameRowSpan < modifyPassengerData.length &&
                              `${modifyPassengerData[index + nameRowSpan].paxInfo.firstName} ${modifyPassengerData[index + nameRowSpan].paxInfo.lastName}` === fullName
                            ) {
                              nameRowSpan++;
                            }
                          }

                          if (passenger?.ticketNumber !== currentTicket) {
                            currentTicket = passenger?.ticketNumber;
                            ticketRowSpan = 1;
                            while (
                              index + ticketRowSpan < modifyPassengerData.length &&
                              modifyPassengerData[index + ticketRowSpan].ticketNumber === currentTicket
                            ) {
                              ticketRowSpan++;
                            }
                          }

                          return (
                            <tr key={index}>
                              {fullName !== `${modifyPassengerData[index - 1]?.paxInfo.firstName} ${modifyPassengerData[index - 1]?.paxInfo.lastName}` && (
                                <td rowSpan={nameRowSpan}>{fullName}</td>
                              )}
                              {/* {passenger.ticketNumber !== modifyPassengerData[index - 1]?.ticketNumber && ( */}
                              {/* rowSpan={ticketRowSpan} */}
                              <td className="text-center" >{passenger?.ticketNumber}</td>
                              {/* )} */}
                              <td className="text-center">{passenger?.flightNumber}</td>
                              <td className="text-center">{passenger?.sector}</td>
                              <td className="text-center">{passenger?.checkinBaggage}</td>
                              <td className="text-center">{passenger?.handBaggage}</td>
                              <td className="text-center">{passenger?.meal}</td>
                              <td className="text-center">{passenger?.seats}</td>
                              <td className="text-center">{passenger?.airlinePNR}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>

            </div>

            <div className="row">
              <div className="col-12">

                <div className="tblFlightEticket">

                  <div className="heading">Flight Details</div>

                  <div className="paxEticketwrap">
                    <table className="table">
                      <thead>
                        <tr>
                          <th>Airline</th>
                          <th>Departure</th>
                          <th className="text-center">Duration</th>
                          <th className="text-center">Arrival</th>
                        </tr>
                      </thead>

                      <tbody>
                        {selectedItinerary?.flights?.flatMap((group: any, groupIndex: any) =>
                          group?.map((flight: any, index: any) => (
                            <tr key={`${groupIndex}-${index}`}>
                              <td className="align-middle">
                                <div className="text-center pd_label">
                                  <div>
                                    <img src={flight?.airline && findAirlineLogo(flight?.airline)} alt="" className="img-fluid rounded me-2" style={{ width: '40px' }} />
                                  </div>
                                  <div className="extrasml">{flight?.airline}</div>
                                  <div className="extrasml">{flight?.flightNumber}</div>
                                </div>
                              </td>
                              <td>
                                <div className="text-uppercase destination">{flight?.origin?.cityName}{`(${flight?.origin?.airportCode})`}</div>
                                <div><small>{convertDate(flight?.departureTime)}</small></div>
                                <div><small>{flight?.origin?.airportName}</small></div>
                              </td>
                              <td className="text-center align-middle">
                                <span><small className="fw-bold">{convertTimeString(flight?.duration)}</small></span>
                              </td>
                              <td>
                                <div className="row align-items-center">
                                  <div className="col-6 text-end">
                                    <div className="text-uppercase destination">{flight?.destination?.cityName}{`(${flight?.destination?.airportCode})`}</div>
                                    <div><small>{convertDate(flight?.arrivalTime)}</small></div>
                                    <div>{flight?.destination?.airportName}</div>
                                  </div>
                                  <div className="col-6">
                                    <div className="nonstop">{flight?.stopOver ? 'STOP' : 'NON STOP'}</div>
                                    <div><span><small>className-</small></span> <span className="fw-bold">{flight?.bookingClass}</span></div>
                                    <div><span><small>CabinClass-</small></span> <span className="fw-bold">{flight?.cabinClass}</span></div>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>

                    </table>

                  </div>

                </div>

              </div>

            </div>


            <div className="row">
              <div className="col-12">

                <div className="tblFlightEticket">

                  <div className="heading">Fare Details ({agentProfile?.currency})</div>
                  <div className="table-responsive">

                    <table className="table table-bordered border-primary fareDetails">
                      <thead className="align-middle">
                        <tr>
                          <th>Passenger Type</th>
                          <th>Air Fare</th>
                          <th>Taxes & Fees</th>
                          <th>Discount</th>
                          <th>Baggage</th>
                          <th>Meal</th>
                          <th>Seats</th>
                          <th>VAT</th>
                          <th>Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {fareDetail.map((row: any, index: any) => (
                          <tr key={index}>
                            <td>{row.passengerType}</td>
                            <td>{row.airFare}</td>
                            <td>{row.taxesFees}</td>
                            <td>{row.discount}</td>
                            <td>{row.baggage}</td>
                            <td>{row.meal}</td>
                            <td>{row.seats}</td>
                            <td>{row.vat}</td>
                            <td>
  {(Number(row.airFare) + 
    Number(row.taxesFees) + 
    Number(row.baggage) + 
    Number(row.meal) + 
    Number(row.seats)).toFixed(2)}
</td>
                          </tr>
                        ))}
                        <tr>
                          <td className="text-end" colSpan={8}><strong>Grand Total</strong></td>
                          <td><strong>
                            {fareDetail
                              .reduce((acc: number, row: any) =>
                                acc + Number(row.airFare) +Number(row.taxesFees) +Number(row.baggage)  + Number(row.discount)+ Number(row.meal) + Number(row.seats), 0)
                              .toFixed(2)}
                          </strong>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>


            </div>


            {/* <div className="row">


            <div className="col-12 text-muted mb-5 mt-2">

              <h6> Flightinventory </h6>

              <p>   For international flights, you are suggested to arrive at the airport at least 3-4 hours prior to your departure time to check in and go through security. For connecting flights, please confirm at the counter whether not you can check your luggage through to the final destination when you check in.

              </p>

              <p> Don't forget to purchase travel insurance for your visit Please contact us to purchase travel insurance.</p>
            </div>

          </div> */}



          </div>
        </MainLayout>
      </div>


    </>
  )

}