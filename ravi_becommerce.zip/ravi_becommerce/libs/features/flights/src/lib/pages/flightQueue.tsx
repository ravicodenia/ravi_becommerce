
import { MainLayout } from '@mfa-travel-app/layout';
import FlightQueeModal from '../components/tQFilter';
import Paging from 'libs/masters/role-master/src/lib/components/paging';
import ViewPerPage from 'libs/masters/role-master/src/lib/components/viewPerPage';
import { ControlledSelect, ControlledInput, ControlledDatePicker } from '@mfa-travel-app/ui';
// import FilterCom from 'libs/masters/role-master/src/lib/components/filterCom';




export default function FlightQueue() {
    const selectOptions = [
        { id: 1, text: 'First Option' },
        { id: 2, text: 'Second Option' },
    ];


    return (

        <>
            <MainLayout>

                <div className="container">
                    <section className="country_section mt-2 mb-3 font_size_90">


                        <div className="row mt-3">

                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="fromDate" className="col-lg-5">From Date :</label>
                                    <div className="col-lg-7">
                                        <ControlledDatePicker
                                            id={'fromDate'}
                                            value={''}
                                            format={'dd/MMM/yyyy'}
                                            required={true}
                                            onChange={''}
                                        />
                                    </div>
                                </div>

                            </div>


                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="tomDate" className="col-lg-5">To Date :</label>
                                    <div className="col-lg-7">
                                        <ControlledDatePicker
                                            id={'tomDate'}
                                            value={''}
                                            format={'dd/MMM/yyyy'}
                                            required={true}
                                            onChange={''}
                                        />
                                    </div>
                                </div>

                            </div>


                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="agent" className="col-lg-5">Agent :</label>
                                    <div className="col-lg-7">
                                        <ControlledSelect
                                            id={'firm'}
                                            value={''}
                                            options={selectOptions}
                                            required={true}
                                            onChange={''}
                                        />
                                    </div>
                                </div>

                            </div>

                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="b2b" className="col-lg-5">B2B  </label>
                                    <div className="col-lg-7">
                                        <ControlledSelect
                                            id={'firm'}
                                            value={''}
                                            options={selectOptions}
                                            required={true}
                                            onChange={''}
                                        />
                                    </div>
                                </div>

                            </div>

                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="b2b2b" className="col-lg-5">B2B2B :</label>
                                    <div className="col-lg-7">
                                        <ControlledSelect
                                            id={'b2b2b'}
                                            value={''}
                                            options={selectOptions}
                                            required={true}
                                            onChange={''}
                                        />
                                    </div>
                                </div>

                            </div>

                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="location" className="col-lg-5">Location :</label>
                                    <div className="col-lg-7">
                                        <ControlledSelect
                                            id={'location'}
                                            value={''}
                                            options={selectOptions}
                                            required={true}
                                            onChange={''}
                                        />
                                    </div>
                                </div>

                            </div>

                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="bookingstatus" className="col-lg-5">Booking Status :</label>
                                    <div className="col-lg-7">
                                        <ControlledSelect
                                            id={'bookingstatus'}
                                            value={''}
                                            options={selectOptions}
                                            required={true}
                                            onChange={''}
                                        />
                                    </div>
                                </div>

                            </div>

                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="pnrno" className="col-lg-5">PNR No.               :</label>
                                    <div className="col-lg-7">

                                        <ControlledInput
                                            id={'pnrno'}
                                            value={''}
                                            type={'text'}
                                            required={true}
                                            onChange={''}
                                        />
                                    </div>
                                </div>

                            </div>

                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="paxname" className="col-lg-5">Pax Name  :</label>
                                    <div className="col-lg-7">
                                        <ControlledInput
                                            id={'paxname'}
                                            value={''}
                                            type={'text'}
                                            required={true}
                                            onChange={''}
                                        />
                                    </div>
                                </div>

                            </div>

                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="transtype" className="col-lg-5">TransType:</label>
                                    <div className="col-lg-7">
                                        <ControlledSelect
                                            id={'transtype'}
                                            value={''}
                                            options={selectOptions}
                                            required={true}
                                            onChange={''}
                                        />
                                    </div>
                                </div>

                            </div>


                            <div className="col-lg-6 text-end">

                                <button className='btn btn-sm btn-primary rounded mt-2'>Search </button>

                            </div>

                        </div>


                        <div className="row mt-2">

                            <div className="col-12">
                                <div className="table-responsive">
                                    <table className="table text-secondary">
                                        <thead>

                                            <tr className='align-middle'>
                                                <th scope="col">SN</th>
                                                <th scope="col">Booking Date</th>
                                                <th scope="col">Agent</th>
                                                <th scope="col">PNR</th>
                                                <th scope="col">Status</th>
                                                <th scope="col">Route</th>
                                                <th scope="col">Provider</th>
                                                <th scope="col">Location</th>
                                                <th scope="col">Created By</th>
                                                <th scope="col">Pax Name     </th>
                                                <th scope="col">Total Price</th>
                                                <th scope="col">Airline</th>
                                                <th scope="col">Pax Count</th>
                                                <th scope="col">Travel Date</th>
                                                <th scope="col">Ticketed Date</th>
                                                <th scope="col">Ticketing Date Expiry </th>
                                                <th scope="col">Actions</th>




                                                <th> </th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <tr>
                                                <td> 1 </td>
                                                <td> 29 July 2024 </td>
                                                <td> Akbar Travel LLC	 </td>
                                                <td> <span className='text-success'><b>8CQ30P</b></span> </td>

                                                <td>    <span className='text-primary'>Hold</span>	 </td>
                                                <td> DXB-BOM-DXB </td>
                                                <td> UAPI	 </td>
                                                <td> Sharjah </td>
                                                <td> Admin	 </td>
                                                <td>Pawan Sharma </td>
                                                <td> AED 1,200,67 </td>
                                                <td> EK-176 </td>
                                                <td className='text-center'> 3 </td>
                                                <td> 12 August 2024 </td>
                                                <td> 29 July 2024 </td>
                                                <td> 29 July 2024  </td>
                                                <td className='btnDropMenu'>
                                                    <FlightQueeModal />
                                                </td>
                                            </tr>

                                            <tr>
                                                <td> 2 </td>
                                                <td> 29 July 2024 </td>
                                                <td> Akbar Travel LLC	 </td>
                                                <td> <span className='text-success'><b>8CQ30P</b></span> </td>

                                                <td>    <span className='text-primary'>Hold</span>	 </td>
                                                <td> DXB-BOM-DXB </td>
                                                <td> UAPI	 </td>
                                                <td> Sharjah </td>
                                                <td> Admin	 </td>
                                                <td>Pawan Sharma </td>
                                                <td> AED 1,200,67 </td>
                                                <td> EK-176 </td>
                                                <td className='text-center'> 3 </td>
                                                <td> 12 August 2024 </td>
                                                <td> 29 July 2024 </td>
                                                <td> 29 July 2024  </td>
                                                <td className='btnDropMenu'>
                                                    <FlightQueeModal />
                                                </td>
                                            </tr>


                                            <tr>
                                                <td> 3 </td>
                                                <td> 29 July 2024 </td>
                                                <td> Akbar Travel LLC	 </td>
                                                <td> <span className='text-success'><b>8CQ30P</b></span> </td>

                                                <td>    <span className='text-primary'>Hold</span>	 </td>
                                                <td> DXB-BOM-DXB </td>
                                                <td> UAPI	 </td>
                                                <td> Sharjah </td>
                                                <td> Admin	 </td>
                                                <td>Pawan Sharma </td>
                                                <td> AED 1,200,67 </td>
                                                <td> EK-176 </td>
                                                <td className='text-center'> 3 </td>
                                                <td> 12 August 2024 </td>
                                                <td> 29 July 2024 </td>
                                                <td> 29 July 2024  </td>
                                                <td className='btnDropMenu'>
                                                    <FlightQueeModal />
                                                </td>
                                            </tr>



                                            <tr>
                                                <td> 4 </td>
                                                <td> 29 July 2024 </td>
                                                <td> Akbar Travel LLC	 </td>
                                                <td> <span className='text-success'><b>8CQ30P</b></span> </td>

                                                <td>    <span className='text-primary'>Hold</span>	 </td>
                                                <td> DXB-BOM-DXB </td>
                                                <td> UAPI	 </td>
                                                <td> Sharjah </td>
                                                <td> Admin	 </td>
                                                <td>Pawan Sharma </td>
                                                <td> AED 1,200,67 </td>
                                                <td> EK-176 </td>
                                                <td className='text-center'> 3 </td>
                                                <td> 12 August 2024 </td>
                                                <td> 29 July 2024 </td>
                                                <td> 29 July 2024  </td>
                                                <td className='btnDropMenu'>
                                                    <FlightQueeModal />
                                                </td>
                                            </tr>



                                            <tr>
                                                <td> 5 </td>
                                                <td> 29 July 2024 </td>
                                                <td> Akbar Travel LLC	 </td>
                                                <td> <span className='text-success'><b>8CQ30P</b></span> </td>

                                                <td>    <span className='text-primary'>Hold</span>	 </td>
                                                <td> DXB-BOM-DXB </td>
                                                <td> UAPI	 </td>
                                                <td> Sharjah </td>
                                                <td> Admin	 </td>
                                                <td>Pawan Sharma </td>
                                                <td> AED 1,200,67 </td>
                                                <td> EK-176 </td>
                                                <td className='text-center'> 3 </td>
                                                <td> 12 August 2024 </td>
                                                <td> 29 July 2024 </td>
                                                <td> 29 July 2024  </td>
                                                <td className='btnDropMenu'>
                                                    <FlightQueeModal />
                                                </td>
                                            </tr>



                                            <tr>
                                                <td> 6 </td>
                                                <td> 29 July 2024 </td>
                                                <td> Akbar Travel LLC	 </td>
                                                <td> <span className='text-success'><b>8CQ30P</b></span> </td>

                                                <td>    <span className='text-primary'>Hold</span>	 </td>
                                                <td> DXB-BOM-DXB </td>
                                                <td> UAPI	 </td>
                                                <td> Sharjah </td>
                                                <td> Admin	 </td>
                                                <td>Pawan Sharma </td>
                                                <td> AED 1,200,67 </td>
                                                <td> EK-176 </td>
                                                <td className='text-center'> 3 </td>
                                                <td> 12 August 2024 </td>
                                                <td> 29 July 2024 </td>
                                                <td> 29 July 2024  </td>
                                                <td className='btnDropMenu'>
                                                    <FlightQueeModal />
                                                </td>
                                            </tr>


                                            <tr>
                                                <td> 7 </td>
                                                <td> 29 July 2024 </td>
                                                <td> Akbar Travel LLC	 </td>
                                                <td> <span className='text-success'><b>8CQ30P</b></span> </td>

                                                <td>    <span className='text-primary'>Hold</span>	 </td>
                                                <td> DXB-BOM-DXB </td>
                                                <td> UAPI	 </td>
                                                <td> Sharjah </td>
                                                <td> Admin	 </td>
                                                <td>Pawan Sharma </td>
                                                <td> AED 1,200,67 </td>
                                                <td> EK-176 </td>
                                                <td className='text-center'> 3 </td>
                                                <td> 12 August 2024 </td>
                                                <td> 29 July 2024 </td>
                                                <td> 29 July 2024  </td>
                                                <td className='btnDropMenu'>
                                                    <FlightQueeModal />
                                                </td>
                                            </tr>


                                            <tr>
                                                <td> 8 </td>
                                                <td> 29 July 2024 </td>
                                                <td> Akbar Travel LLC	 </td>
                                                <td> <span className='text-success'><b>8CQ30P</b></span> </td>

                                                <td>    <span className='text-primary'>Hold</span>	 </td>
                                                <td> DXB-BOM-DXB </td>
                                                <td> UAPI	 </td>
                                                <td> Sharjah </td>
                                                <td> Admin	 </td>
                                                <td>Pawan Sharma </td>
                                                <td> AED 1,200,67 </td>
                                                <td> EK-176 </td>
                                                <td className='text-center'> 3 </td>
                                                <td> 12 August 2024 </td>
                                                <td> 29 July 2024 </td>
                                                <td> 29 July 2024  </td>
                                                <td className='btnDropMenu'>
                                                    <FlightQueeModal />
                                                </td>
                                            </tr>



                                            <tr>
                                                <td> 9 </td>
                                                <td> 29 July 2024 </td>
                                                <td> Akbar Travel LLC	 </td>
                                                <td> <span className='text-success'><b>8CQ30P</b></span> </td>

                                                <td>    <span className='text-primary'>Hold</span>	 </td>
                                                <td> DXB-BOM-DXB </td>
                                                <td> UAPI	 </td>
                                                <td> Sharjah </td>
                                                <td> Admin	 </td>
                                                <td>Pawan Sharma </td>
                                                <td> AED 1,200,67 </td>
                                                <td> EK-176 </td>
                                                <td className='text-center'> 3 </td>
                                                <td> 12 August 2024 </td>
                                                <td> 29 July 2024 </td>
                                                <td> 29 July 2024  </td>
                                                <td className='btnDropMenu'>
                                                    <FlightQueeModal />
                                                </td>
                                            </tr>


                                            <tr>
                                                <td> 10 </td>
                                                <td> 29 July 2024 </td>
                                                <td> Akbar Travel LLC	 </td>
                                                <td> <span className='text-success'><b>8CQ30P</b></span> </td>

                                                <td>    <span className='text-primary'>Hold</span>	 </td>
                                                <td> DXB-BOM-DXB </td>
                                                <td> UAPI	 </td>
                                                <td> Sharjah </td>
                                                <td> Admin	 </td>
                                                <td>Pawan Sharma </td>
                                                <td> AED 1,200,67 </td>
                                                <td> EK-176 </td>
                                                <td className='text-center'> 3 </td>
                                                <td> 12 August 2024 </td>
                                                <td> 29 July 2024 </td>
                                                <td> 29 July 2024  </td>
                                                <td className='btnDropMenu'>
                                                    <FlightQueeModal />
                                                </td>
                                            </tr>


                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </div>

                        <div className="row align-items-center">

                            <div className="col-lg-8">
                                <Paging />
                            </div>

                            <div className="col-lg-4">

                                <ViewPerPage />

                            </div>






                        </div>

                    </section>

                </div>
            </MainLayout>
        </>


    )
}
