import React, { useEffect, useState } from 'react';
import styles from '../oneway.module.scss';
import { RootState } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';

const AirportContainer = ({ Source, icon, onAirportSelect, airportPayload }: any) => {
  const { airports } = useSelector((state: RootState) => state.flight);

  const [searchTerm, setSearchTerm] = useState('');
  const [sourcesuggestionsList, setsourceSuggestionsList] = useState([]);
  const [selectedairport, setSelectedairport] = useState<any>();
  const [nearbyAirports, setNearbyAirports] = useState(false);

  useEffect(() => {
    if (airportPayload) {
      const airport = airports.filter((airport: any) => airport.airportCode === airportPayload)
      setSelectedairport(airport[0])
      setSearchTerm(airport[0]?.cityName);
      onAirportSelect(airport[0]);
    }
  }, [airportPayload])

  const handleInputChange = (event: any) => {
    const { value } = event.target;
    setSearchTerm(value);

    if (value.length >= 2) {
      setsourceSuggestionsList(
        airports?.filter((suggestion: any) =>
          suggestion.cityName.slice(0, 2).toLowerCase() === value.slice(0, 2).toLowerCase() ||
          suggestion.airportCode.slice(0, 2).toLowerCase() === value.slice(0, 2).toLowerCase() ||
          suggestion.cityName.toLowerCase() === value.toLowerCase()
        )
      );
    } else {
      setsourceSuggestionsList([]);
    }
  };

  const handleSuggestionClick = (option: any) => {
    // console.log('suggetion', option);
    setSearchTerm(option.cityName);
    setSelectedairport(option);
    setsourceSuggestionsList([]);
    onAirportSelect(option);
  };
  const handleCheckboxChange = (event: any) => {
    const { checked } = event.target;
    setNearbyAirports(checked);
    onAirportSelect({ ...selectedairport, nearbyAirports: checked });
  };
  return (
    <>
      <div className='row'>
        <div className='col-12'>

          <table className='flightheadertbl'>
            <thead>
              <tr>
                <td>
                  <input
                    type="checkbox"
                    value=""
                    id="flyingfrom"
                    checked={nearbyAirports}
                    onChange={handleCheckboxChange}
                  />
                  <label htmlFor="flyingfrom"> Nearby Airports</label>
                </td>
              </tr>
            </thead>
            <tbody></tbody>
          </table>

          <div className="srchCon">
            <div className="srchRow">
              <div className="srchCol">
                <div className="mb-1 text-start"><span className="srchsml">{Source}</span></div>
                <div className={styles['destination-dropdown']}
                  id="departure-dropdown"
                >
                  <span className='me-1'> {icon} </span>
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={handleInputChange}
                    placeholder="Select"
                    className="srchTitle enterAirport inputTxt"
                    id="departure-input"
                    autoComplete='off'
                  />

                </div>


                <div><span className="srchsml textTrim"> {selectedairport?.airportCode} {selectedairport?.airportName}</span> </div>
              </div>
            </div>
            {sourcesuggestionsList?.length > 0 && (
              <ul className={styles['suggestion-list-modal']}>
                {sourcesuggestionsList.map(
                  (suggestion: any, index: number) => (
                    <li
                      key={index}
                      onClick={() => handleSuggestionClick(suggestion)}
                    >
                      {`${suggestion.airportCode}, ${suggestion.airportName}`}
                    </li>
                  )
                )}
              </ul>
            )}
          </div>
        </div>

      </div>

    </>
  );
};

export default AirportContainer;
