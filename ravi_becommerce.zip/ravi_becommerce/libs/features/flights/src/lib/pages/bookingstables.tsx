import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import SearchIcon from '@mui/icons-material/Search';
import { useSelector } from "react-redux";
import { RootState } from '@mfa-travel-app/store';

interface ITransactions {
  bookingRef: string,
  leadPax: string,
  travelDate: string,
  bookingStage: string,
  module: string,
  bookingType: string
}

const BookingsTables: React.FC = () => {
  const { transactionData } = useSelector((state: RootState) => state.flight);

  const [latestBookings, setLatestBookings] = useState<ITransactions[]>([]);
  const [onHoldBookings, setOnHoldBookings] = useState<ITransactions[]>([]);

  useEffect(() => {
    setOnHoldBookings(transactionData.filter(
      (transaction: any) => transaction.bookingType === 'Hold'
    ));
    setLatestBookings(transactionData.filter(
      (transaction: any) =>
        transaction.bookingType !== 'Hold'
    ));

  }, [transactionData]);

  return (
    <React.Fragment>
      <section className="latestBooking mt-3 mb-4">
        <div className="row justify-content-center">
          <div className="col-lg-6">
            <div className="boxB">
              <div className="card h-100">
                <div className="card-header d-none d-lg-block d-md-block">
                  <div className="row">
                    <div className="col-md-5 d-flex align-items-center mb-2 mb-sm-0">
                      <h6 className="fw-bold mb-0">MY LATEST BOOKINGS</h6>
                    </div>
                    <div className="col-md-7 d-flex">
                      <div className="input-group">
                        <input
                          type="text"
                          className="form-control shadow-none"
                          placeholder="Bookings Reference"
                          aria-label="Input group example"
                          aria-describedby="basic-addon1"
                        />
                        <span className="input-group-text" id="basic-addon1">
                          <SearchIcon />
                        </span>
                      </div>
                      <div className="d-flex justify-content-end align-items-center" style={{ width: '120px' }}
                      >
                        <Link to="" className='view_all'>
                          View All
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="card-body">
                  <div className='table-responsive'>
                    <table className='table'>
                      <thead>
                        <tr>
                          <th scope="col">
                            Booking Ref
                          </th>
                          <th scope="col">
                            Lead Pax
                          </th>
                          <th scope="col">
                            Travel Date
                          </th>
                          <th scope="col">
                            Booking Stage
                          </th>
                          <th scope="col">
                            Module
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {latestBookings.map((latestBooking, index) => {
                          let styleClass = '';
                          const status = latestBooking.bookingStage;
                          switch (status) {
                            case 'Completed':
                              styleClass = 'completed';
                              break;
                            case 'Cancelled':
                              styleClass = 'cancelled';
                              break;
                            case 'Pending':
                              styleClass = 'pending';
                              break;
                            default:
                              break;
                          }
                          return (
                            <tr key={index}>
                              <td className="text-primary">
                                <a href="#">{latestBooking.bookingRef}</a>
                              </td>
                              <td>{latestBooking.leadPax}</td>
                              <td>{latestBooking.travelDate}</td>
                              <td>
                                <div
                                  className={`${styleClass}`}
                                  role="alert"
                                >
                                  {' '}
                                  {latestBooking.bookingStage}{' '}
                                </div>
                              </td>
                              <td>{latestBooking.module}</td>
                            </tr>
                          );
                        })}

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>


          {/* Second card */}
          <div className="col-lg-6">

            <div className="boxB">

              <div className="card h-100">
                <div className="card-header d-none d-lg-block d-md-block">
                  <div className="row">
                    <div className="col-md-5 d-flex align-items-center mb-2 mb-sm-0">
                      <h6 className="fw-bold mb-0">ON HOLD BOOKINGS</h6>
                    </div>
                    <div className="col-md-7 d-flex">
                      <div className="input-group">

                        <input
                          type="text"
                          className="form-control shadow-none"
                          placeholder="Bookings Reference"
                          aria-label="Input group example"
                          aria-describedby="basic-addon2"
                        />
                        <span className="input-group-text" id="basic-addon1">
                          <SearchIcon />
                        </span>
                      </div>
                      <div className="d-flex justify-content-end align-items-center" style={{ width: '120px' }}>

                        <Link to="" className='view_all'>
                          View All
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="card-body">
                  <div className='table-responsive'>
                    <table className='table'>
                      <thead>
                        <tr>
                          <th scope="col">
                            Booking Ref
                          </th>
                          <th scope="col">
                            Lead Pax
                          </th>
                          <th scope="col">
                            Travel Date
                          </th>
                          <th scope="col">
                            Booking Stage
                          </th>
                          <th scope="col">
                            Module
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {onHoldBookings.map((onHoldBooking, index) => {
                          let styleClass = '';
                          const status = onHoldBooking.bookingStage;
                          switch (status) {
                            case 'Completed':
                              styleClass = 'completed';
                              break;
                            case 'Cancelled':
                              styleClass = 'pending';
                              break;
                            case 'Pending':
                              styleClass = 'cancelled';
                              break;
                            default:
                              break;
                          }
                          return (
                            <tr key={index}>
                              <td className="text-primary">
                                <a href="#">{onHoldBooking.bookingRef}</a>
                              </td>
                              <td>{onHoldBooking.leadPax}</td>
                              <td>{onHoldBooking.travelDate}</td>
                              <td>
                                <div
                                  className={`${styleClass}`}
                                  role="alert"
                                >
                                  {' '}
                                  {onHoldBooking.bookingStage}{' '}
                                </div>
                              </td>
                              <td>{onHoldBooking.module}</td>
                            </tr>
                          );
                        })}

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </React.Fragment>
  );
};

export default BookingsTables;
