import { useState } from 'react';

const SamePriceFlights = () => {
  return (
    <div className='text-start border p-1'>
      <span>rwrwrwr</span>
    </div>
  );
};

export default SamePriceFlights