import { useState } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import '../custom-datepicker.scss';

const TwoMonthSingleDatePicker = ({ selectedDate, setSelectedDate, isOpen, setIsOpen, minDate }:any) => {
  const [startDate, setStartDate] = useState(selectedDate);

  const handleDateChange = (date:any) => {
    setStartDate(date);
    setSelectedDate(date);
    setIsOpen(false); // Close the date picker after selecting a date
  };

  const handleClickOutside = () => {
    setIsOpen(false); // Close the date picker when clicking outside
  };

  const handleDoneClick = () => {
    setIsOpen(false); 
  };

  return (
    <div>
      {isOpen && (
        <div className="datepicker-container">
          <DatePicker
            selected={startDate}
            onChange={handleDateChange}
            minDate={minDate}
            monthsShown={2}
            inline
          />
         
          <div className="outside-click-handler" onClick={handleClickOutside}></div>
          <button className='btn done_Btn_Calendar' onClick={handleDoneClick}>Done</button>
        </div>
      )}
    </div>
  );
};

export default TwoMonthSingleDatePicker;
