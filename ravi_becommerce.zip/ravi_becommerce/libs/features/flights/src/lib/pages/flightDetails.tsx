import { useState } from 'react';
import styles from '../flights.module.scss';
import classNames from 'classnames';
import { useSelector } from 'react-redux';
import {  RootState } from '@mfa-travel-app/store';

const FlightDetails = ({ itinerary }: any) => {
  const { airlines } = useSelector((state: RootState) => state.flight);
  const getTime = (dateTimeString: string) => {
    const date = new Date(dateTimeString);
    return date.toLocaleTimeString('en', {
      timeStyle: 'short',
    });
  };

  const getDate = (dateTimeString: string) => {
    const date = new Date(dateTimeString);
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: '2-digit',
      year: 'numeric',
    });
  };

  const calculateDurationHours = (departureTime: any, arrivalTime: any) => {
    let departure: any = new Date(departureTime);
    let arrival: any = new Date(arrivalTime);

    let duration = arrival - departure;

    let hours = Math.floor(duration / (1000 * 60 * 60));

    let formattedHours = hours.toString().padStart(2, '0');

    return formattedHours;
  };

  const calculateDurationMinutes = (departureTime: any, arrivalTime: any) => {
    let departure: any = new Date(departureTime);
    let arrival: any = new Date(arrivalTime);

    let duration = arrival - departure;

    let minutes = Math.floor((duration % (1000 * 60 * 60)) / (1000 * 60));

    let formattedMinutes = minutes.toString().padStart(2, '0');

    return formattedMinutes;
  };

  const getAirlineData = (airlineCode: string) => {
    const airline = airlines?.filter(
      (airline: any) => airline?.code === airlineCode
    );
    return airline[0];
  };

  return (
    <div className="table-responsive pb-4">
      {itinerary?.flights?.map((journey: any, i: any) => {
        return (
          <table className="table table-borderless text-start border mb-0" key={i}>
            <thead>
              <tr className="table-secondary">
                <th className="text-center">
                  {`${journey[0]?.origin?.cityName} to
              ${journey[journey?.length - 1].destination?.cityName}`}
                </th>
                <th>{`${getDate(journey[0]?.departureTime)}`}</th>
                <th>{i === 0 ? 'Departure' : 'Return'}</th>
                <th></th>
                <th>Summary</th>
              </tr>
            </thead>
            {journey?.map((flight: any, index: any) => (
              <tbody key={index}>
                <tr>
                  <td>
                    <div className="d-flex flex-column text-center">
                      <span className="fw-semibold">{getAirlineData(flight && flight?.airline)?.name}</span>
                      <span>{`${flight?.airline}-${flight?.flightNumber}`}</span>
                      <span>Operated by:{getAirlineData(flight && flight?.airline)?.name}</span>
                    </div>
                  </td>
                  <td>
                    <div className="d-flex flex-column">
                      <span className="fw-semibold">
                        {getTime(flight?.departureTime)}
                        <br />
                        {getDate(flight?.departureTime)}
                      </span>
                      <span>
                        {`${flight?.origin?.cityName} - ${flight?.origin?.airportName}(${flight?.origin?.airportCode})`}
                        <br />
                        {`${
                          flight?.depTerminal !== null
                            ? `TERMINAL ${flight?.depTerminal}`
                            : ''
                        }`}
                      </span>
                    </div>
                  </td>
                  <td valign="middle">
                    <span className="fw-semibold">{`${
                      flight?.duration?.split(':')[0]
                    }:${flight?.duration?.split(':')[1]} Hrs`}</span>
                  </td>
                  <td>
                    <div className="d-flex flex-column align-items-end">
                      <span className="fw-semibold text-end">
                        {getTime(flight?.arrivalTime)}
                        <br />
                        {getDate(flight?.arrivalTime)}
                      </span>
                      <span className="text-end">
                        {`${flight?.destination?.cityName} - ${flight?.destination?.airportName}(${flight?.destination?.airportCode})`}
                        <br />
                        {`${
                          flight?.arrTerminal !== null
                            ? `TERMINAL ${flight?.arrTerminal}`
                            : ''
                        }`}
                      </span>
                    </div>
                  </td>
                  <td>
                    <div className="d-flex flex-column">
                      <span>
                        <span className="fw-semibold">Total time: </span>
                        {journey?.length > 1
                          ? `${calculateDurationHours(
                              journey[0]?.departureTime,
                              journey[journey?.length - 1].arrivalTime
                            )}:${calculateDurationMinutes(
                              journey[0]?.departureTime,
                              journey[journey?.length - 1].arrivalTime
                            )} Hrs`
                          : `${flight?.duration?.split(':')[0]}:${
                              flight?.duration?.split(':')[1]
                            } Hrs`}
                      </span>
                      <span>
                        <span className="fw-semibold">Class: </span>
                        {flight?.cabinClass}
                        <br />
                        {flight?.stops > 0 ? '' : 'NONSTOP'}
                      </span>
                    </div>
                  </td>
                </tr>
                {flight?.stopOver ? (
                  <tr>
                    <td colSpan={5}>
                      <div className={classNames(styles['layover-time-div'])}>
                        <hr />
                        <span className="fw-semibold">{`Layover Time: ${calculateDurationHours(
                          flight?.arrivalTime,
                          journey[index + 1]?.departureTime
                        )}h ${calculateDurationMinutes(
                          flight?.arrivalTime,
                          journey[index + 1]?.departureTime
                        )}m`}</span>
                      </div>
                    </td>
                  </tr>
                ) : (
                  ''
                )}
              </tbody>
            ))}
            {/* <tbody key={index}>
              <tr>
                <td>
                  <div className="d-flex flex-column text-center">
                    <span className="fw-semibold">Air India Express</span>
                    <span>{`${journey?.airline}-${journey?.flightNumber}`}</span>
                    <span>Operated by: Air India</span>
                    <span>Express Airlines</span>
                  </div>
                </td>
                <td>
                  <div className="d-flex flex-column">
                    <span className="fw-semibold">
                      {getTime(flight?.departureTime)}
                      <br />
                      {getDate(flight?.departureTime)}
                    </span>
                    <span>
                      {`${flight?.origin?.cityName} - ${flight?.origin?.airportName}(${flight?.origin?.airportCode})`}
                      <br />
                      {`${
                        flight?.depTerminal !== null
                          ? `TERMINAL ${flight?.depTerminal}`
                          : ''
                      }`}
                    </span>
                  </div>
                </td>
                <td valign="middle">
                  <span className="fw-semibold">{`${
                    flight?.duration?.split(':')[0]
                  }:${flight?.duration?.split(':')[1]} Hrs`}</span>
                </td>
                <td>
                  <div className="d-flex flex-column align-items-end">
                    <span className="fw-semibold text-end">
                      {getTime(flight?.arrivalTime)}
                      <br />
                      {getDate(flight?.arrivalTime)}
                    </span>
                    <span className="text-end">
                      {`${flight?.destination?.cityName} - ${flight?.destination?.airportName}(${flight?.destination?.airportCode})`}
                      <br />
                      {`${
                        flight?.arrTerminal !== null
                          ? `TERMINAL ${flight?.arrTerminal}`
                          : ''
                      }`}
                    </span>
                  </div>
                </td>
                <td>
                  <div className="d-flex flex-column">
                    <span>
                      <span className="fw-semibold">Total time: </span>
                      {itinerary?.flights?.length > 1
                        ? `${calculateDurationHours(
                            itinerary?.flights[0].departureTime,
                            itinerary?.flights[itinerary?.flights.length - 1]
                              .arrivalTime
                          )}:${calculateDurationMinutes(
                            itinerary?.flights[0].departureTime,
                            itinerary?.flights[itinerary?.flights.length - 1]
                              .arrivalTime
                          )} Hrs`
                        : `${flight?.duration?.split(':')[0]}:${
                            flight?.duration?.split(':')[1]
                          } Hrs`}
                    </span>
                    <span>
                      <span className="fw-semibold">Class: </span>
                      {flight?.cabinClass}
                      <br />
                      {flight?.stops > 0 ? '' : 'NONSTOP'}
                    </span>
                  </div>
                </td>
              </tr>
              {flight?.stopOver ? (
                <tr>
                  <td colSpan={5}>
                    <div className={classNames(styles['layover-time-div'])}>
                      <hr />
                      <span className="fw-semibold">{`Layover Time: ${calculateDurationHours(
                        flight?.arrivalTime,
                        itinerary?.flights[index + 1].departureTime
                      )}h ${calculateDurationMinutes(
                        flight?.arrivalTime,
                        itinerary?.flights[index + 1].departureTime
                      )}m`}</span>
                    </div>
                  </td>
                </tr>
              ) : (
                ''
              )}
            </tbody> */}
          </table>
        );
      })}
      {/* <table className="table table-borderless text-start border">
        <thead>
          <tr className="table-secondary">
            <th className="text-center">
              {`${itinerary?.flights[0].origin?.cityName} to
              ${
                itinerary?.flights[itinerary?.flights?.length - 1].destination
                  ?.cityName
              }`}
            </th>
            <th>{`${getDate(itinerary?.flights[0].departureTime)}`}</th>
            <th>Departure</th>
            <th></th>
            <th>Summary</th>
          </tr>
        </thead>
        {itinerary?.flights?.map((flight: any, index: any) => (
          <tbody key={index}>
            <tr>
              <td>
                <div className="d-flex flex-column text-center">
                  <span className="fw-semibold">Air India Express</span>
                  <span>{`${flight?.airline}-${flight?.flightNumber}`}</span>
                  <span>Operated by: Air India</span>
                  <span>Express Airlines</span>
                </div>
              </td>
              <td>
                <div className="d-flex flex-column">
                  <span className="fw-semibold">
                    {getTime(flight?.departureTime)}
                    <br />
                    {getDate(flight?.departureTime)}
                  </span>
                  <span>
                    {`${flight?.origin?.cityName} - ${flight?.origin?.airportName}(${flight?.origin?.airportCode})`}
                    <br />
                    {`${
                      flight?.depTerminal !== null
                        ? `TERMINAL ${flight?.depTerminal}`
                        : ''
                    }`}
                  </span>
                </div>
              </td>
              <td valign="middle">
                <span className="fw-semibold">{`${
                  flight?.duration?.split(':')[0]
                }:${flight?.duration?.split(':')[1]} Hrs`}</span>
              </td>
              <td>
                <div className="d-flex flex-column align-items-end">
                  <span className="fw-semibold text-end">
                    {getTime(flight?.arrivalTime)}
                    <br />
                    {getDate(flight?.arrivalTime)}
                  </span>
                  <span className="text-end">
                    {`${flight?.destination?.cityName} - ${flight?.destination?.airportName}(${flight?.destination?.airportCode})`}
                    <br />
                    {`${
                      flight?.arrTerminal !== null
                        ? `TERMINAL ${flight?.arrTerminal}`
                        : ''
                    }`}
                  </span>
                </div>
              </td>
              <td>
                <div className="d-flex flex-column">
                  <span>
                    <span className="fw-semibold">Total time: </span>
                    {itinerary?.flights?.length > 1
                      ? `${calculateDurationHours(
                          itinerary?.flights[0].departureTime,
                          itinerary?.flights[itinerary?.flights.length - 1]
                            .arrivalTime
                        )}:${calculateDurationMinutes(
                          itinerary?.flights[0].departureTime,
                          itinerary?.flights[itinerary?.flights.length - 1]
                            .arrivalTime
                        )} Hrs`
                      : `${flight?.duration?.split(':')[0]}:${
                          flight?.duration?.split(':')[1]
                        } Hrs`}
                  </span>
                  <span>
                    <span className="fw-semibold">Class: </span>
                    {flight?.cabinClass}
                    <br />
                    {flight?.stops > 0 ? '' : 'NONSTOP'}
                  </span>
                </div>
              </td>
            </tr>
            {flight?.stopOver ? (
              <tr>
                <td colSpan={5}>
                  <div className={classNames(styles['layover-time-div'])}>
                    <hr />
                    <span className='fw-semibold'>{`Layover Time: ${calculateDurationHours(
                      flight?.arrivalTime,
                      itinerary?.flights[index + 1].departureTime
                    )}h ${calculateDurationMinutes(
                      flight?.arrivalTime,
                      itinerary?.flights[index + 1].departureTime
                    )}m`}</span>
                  </div>
                </td>
              </tr>
            ) : (
              ''
            )}
          </tbody>
        ))}
      </table> */}
    </div>
  );
};

export default FlightDetails;
