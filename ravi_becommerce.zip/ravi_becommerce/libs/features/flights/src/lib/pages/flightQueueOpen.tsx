
import { MainLayout } from '@mfa-travel-app/layout';
import { ailogo } from '../../../../../assets/src';
import FlightDetailsPopup from '../../Components/FlightPax/FlightDetailsPopup';
import BaggagePolicyPopup from '../../Components/FlightPax/BaggagePolicyPopup';
import { Link } from 'react-router-dom';


export default function FlightQueueOpen() {
  return (
    <>
      <MainLayout>
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="innerContainer border-top-0">
                <div className="row">
                  <div className="col-lg-8 order-lg-0 order-2">
                    <div className="wrapper">



                      <div className='row font_size_90'>

                <div className='col-lg-4'>
                Booked By: Admin
                </div>

                {/* <div className='col-lg-4'>
              Ticket No. 80384034803
                </div> */}

                <div className='col-lg-4'>
                PNR No. Qwe234
                </div>

         


                      </div>
                     
                      <div className="row">

                        <div className="col-12">
                          <div className="form_heading">
                            <span className=" title">Passenger Details</span>
                          </div>
                        </div>
            

                        <div className="col-12">


                        <table className="table table-bordered">
                      <thead>
                    
                      <tr>
                    <td> </td>
                    <th>Name</th>
                      <th>Type</th>
                      <th>DOB</th>
                      <th></th>
                    
                      </tr>
                      </thead>
                      <tbody>

                      <tr>
                      <td>1</td>
                      <td>MR JAMES FLANGAN</td>
                      <td>Adult</td>
                      <td>03/09/1970</td>
                      <td> <Link className='text-primary' to='/'>View Ticket</Link> </td>

                      </tr>

                      
                      <tr>
                      <td>2</td>
                      <td>MR LINDA FLANGAN</td>
                      <td>Adult</td>
                      <td>03/09/1970</td>
                      <td> <Link className='text-primary' to='/'>View Ticket</Link> </td>

                      </tr>




                      </tbody>
                      </table>

                        </div>


                        <div className='col-12 text-end'>
                          <button className='btn btn-sm btn-secondary'>
                          View All Tickets
                          </button>
                        </div>
                 

                      </div>
      

                        <div className="row">

                        <div className="col-12">
                        <div className="form_heading">
                        <span className=" title">Booking History</span>
                        </div>
                        </div>


                        <div className="col-12">



                        <table className="table table-bordered align-middle">

                        <tbody>


                        <tr>
                        <td>17 July 2024</td>
                        <td>12:30 PM</td>
                        <td>Booking</td>
                        <td>Imported from QMS</td>
                        <td> Kamal Sharma</td>

                        </tr>

                        <tr>
                        <td>17 July 2024</td>
                        <td>12:30 PM</td>
                        <td>Booking</td>
                        <td>



                        <div className='leTxtFit'>

                        Invoice generated error while getting transaction log check in adult log. 
                        date time 7/17/2024 5:23:48 PM
                        </div>



                        </td>
                        <td> Kamal Sharma</td>

                        </tr>

                        </tbody>

                        </table>

                        </div>


                        <div className="col-12 text-end mt-1 mb-2">

                        <button className='btn btn-sm btn-primary'>
                        Create Ticket Now
                        </button>


                        </div>

                        </div>
                        

                        <div className="col-12">
                          <div className="form_heading">
                            <span className=" title">Comments</span>
                          </div>
                        </div>

                        <div className="col-12 mb-3">

                        <Link className='text-primary' to='/'>Show Comments</Link>
                          </div>


                

                          <div className='col-12'> 

                          <div className="form-floating">
  <textarea className="form-control" placeholder="Leave a comment here" id="floatingTextarea2" 
  style={{height:'100px'}}></textarea>
  <label htmlFor="floatingTextarea2">Enter Comments</label>
</div>

<div className="col-12 text-end mt-3 mb-2">

<button className='btn btn-sm btn-primary'>
Submit
</button>


</div>

                          </div>

                 
                    </div>
                  </div>

                  <div className="col-lg-4">
                    <div className="innerContainerRight">
                      <div className="row">
                        <div className="col-12 mt-2">
                          <div className="itenaryDetails">


                            <div className='row'>
                            <div className='col-lg-6'>Status: Hold</div>
                              <div className='col-lg-6'>  Booking Date: 01/03/2024 </div>

                            </div>


                            <div className="row">

                              
                              <div className="col-12">
                                <div className="form_heading">
                                  <span className="title">
                                    Itinerary Details
                                  </span>
                                </div>
                              </div>
                              <div className="col-12">

                            <div className="row">
                    <div className="col-12">
                    <div className="itrbg">
                        <div className="row">
                        <div className="col-6">
                            <strong>
                            <i className="fa-solid fa-plane-departure"></i> DXB to Delhi
                            </strong>
                        </div>

                        <div className="col-6 text-end">
                            <strong>
                            <i className="fa-solid fa-calendar-days"></i> Wed Nov 15 2023
                            </strong>
                        </div>
                        </div>
                    </div>
                    </div>

                    <div className="col-12 mb-3 mt-3">
                    <img
                        src={ailogo}
                        alt=""
                        className="img-fluid rounded me-2"
                        style={{ width: '40px' }}
                    />
                    <strong>Air India Express</strong> <small>AE-908 Airbus 321</small>
                    </div>

                    <div className="col-12 mb-4">
                    <div className="row align-items-center">
                        <div className="col-5 text-end">
                        <div>
                            <strong>4:20 AM</strong>
                        </div>
                        <div>Wed Nov 15 2023</div>
                        <div>
                            <small className="text-muted">Dubai (DXB)</small>
                        </div>
                        </div>
                        <div className="col-2 text-center">
                        <span className="text-muted">
                            <i className="fa-solid fa-plane-departure"></i>
                        </span>{' '}
                        </div>
                        <div className="col-5">
                        <div>
                            <strong>4:20 AM</strong>
                        </div>
                        <div>Wed Nov 15 2023</div>
                        <div>
                            <small className="text-muted">Dubai (DXB)</small>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>

                
      <div className="row">
        <div className="col-12">
          <div className="itrbg">
            <div className="row">
              <div className="col-6">
                <strong>
                  <i className="fa-solid fa-calendar-days"></i> Delhi to DXB
                </strong>
              </div>

              <div className="col-6 text-end">
                <strong>
                  <i className="fa-solid fa-plane-departure"></i> Wed Nov 15
                  2023
                </strong>
              </div>
            </div>
          </div>
        </div>

        <div className="col-12 mb-3 mt-3">
          <img
            src={ailogo}
            alt=""
            className="img-fluid rounded me-2"
            style={{ width: '40px' }}
          />
          <strong>Air India Express</strong> <small>AE-908 Airbus 321</small>
        </div>

        <div className="col-12 mb-4">
          <div className="row align-items-center">
            <div className="col-5 text-end">
              <div>
                <strong>4:20 AM</strong>
              </div>
              <div>Wed Nov 15 2023</div>
              <div>
                <small className="text-muted">Dubai (DXB)</small>
              </div>
            </div>
            <div className="col-2 text-center">
              <span className="text-muted">
                <i className="fa-solid fa-plane-departure"></i>
              </span>{' '}
            </div>
            <div className="col-5">
              <div>
                <strong>4:20 AM</strong>
              </div>
              <div>Wed Nov 15 2023</div>
              <div>
                <small className="text-muted">Dubai (DXB)</small>
              </div>
            </div>
          </div>
        </div>
      </div>


      <div className="col-12">
        <table className="table tbl_itenerary">
          <tbody>
            <tr>
              <td>
                <strong>Check In:</strong> 
                As per Airline Policy	
              </td>
              <td className="text-end">
                <strong>Cabin:</strong>
                10
              </td>
            </tr>
            <tr>
              <td><Link className='text-primary' to='/'>
              Fare Rules</Link></td>
              <td className='text-end'>
              <span className="text-uppercase text-success">
              
              <small>
              NON-REFUNDABLE

              </small>
            </span>
           
           
              </td>
            </tr>
          </tbody>
        </table>
      </div>



                              </div>
                            </div>

                            <div className="row">
                              <div className="col-6">
                              <FlightDetailsPopup />
                              
                              </div>
                              <div className="col-6">
                              <BaggagePolicyPopup />
                              </div>

                        
                            </div>
                          </div>
                        </div>

                        <div className="col-12 mt-2 mb-2">
                          <div className="row">
                            <div className="col-12">
                              <div className="form_heading">
                                <span className="title">Fare Summary</span>
                              </div>
                            </div>
                            <div className="col-12">
                         
                            <div className="fare_details">
        <div className="tbl_fare_summary">
          <table className="table">
            <tbody>
           
                <tr>
                  <td>
                  Adult x 1	
                  </td>
                  <td className="text-end">1287.46
                  </td>
                </tr>
             
              <tr>
                <td>Baggage Free</td>
                <td className="text-end">0</td>
              </tr>
              <tr>
                <td>Meal Fee</td>
                <td className="text-end">0</td>
              </tr>
              <tr>
                <td>Seat Fee</td>
                <td className="text-end">0</td>
              </tr>
              <tr>
                <td>Promo Discount</td>
                <td className="text-end">
                 0
                </td>
              </tr>
              <tr>
                <td>Service Fee</td>
                <td className="text-end">0</td>
              </tr>

              <tr>
                <td>VAT</td>
                <td className="text-end">0</td>
              </tr>
              <tr className="grandTotal">
                <td className="border-bottom-0">
                  <strong>Grand Total</strong>
                </td>
                <td className="border-bottom-0 font-weight-bold text-end">
                  <strong>
                  1287.46

                  </strong>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

                            </div>
                      
                          </div>
                        </div>

                      </div>
                    </div>
                  </div>
                  
                </div>
              </div>
            </div>
          </div>
        </div>
      </MainLayout>

    </>
  )
}
