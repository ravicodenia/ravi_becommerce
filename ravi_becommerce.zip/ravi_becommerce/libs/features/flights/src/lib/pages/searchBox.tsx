import { useState, useEffect } from 'react';
import { useStore, RootState } from '@mfa-travel-app/store';
import { useNavigate } from 'react-router-dom';
import { searchFlights } from '../../lib/service/flightApi';
import Flighttab from './flighttab';
import OneWay from './oneway';
import Returnflight from './returnflight';
import MultiFlights from './multiflight';
import AdditionalSerach from '../components/additionalSearch';
import { useSelector } from "react-redux";
interface Supplier {
  value: string;
  label: string;
}
import { toast } from 'react-toastify';
import { Loader } from '@mfa-travel-app/ui';

const SearchBox = ({ payload }: any) => {

  const { saveFlightSearchResults, saveSearchPayloadResults } = useStore();
  const navigate = useNavigate();

  const [flightType, setFlightType] = useState(
    payload?.type === 1 ? 'oneway' : payload?.type === 2 ? 'return' : 'multistop'
  );
  const [selectedAirlines, setSelectedAirlines] = useState<Supplier[]>([]);
  const [selectedSupplier, setSelectedSupplier] = useState<Supplier[]>([]);
  const [refundableFaresOnly, setRefundableFaresOnly] = useState<boolean>(false);
  const [directFlights, setDirectFlights] = useState<boolean>(false);
  const [selectedFareTypes, setSelectedFareTypes] = useState<{ value: string; label: string }[]>([]);
  const [markup, setMarkup] = useState<string>('');
  const { searchPayload } = useSelector((state: RootState) => state.flight);
  const [loader, setLoader] = useState(false);
  const searchFlightsCommon = async (
    type: number,
    segments: any[],
    travellerInfo: any
  ) => {
    // console.log('searchFlightsCommon',segments,payload?.segments);
    const searchData = {
      unrestrictedcarrier: null,
      type: type,
      restrictAirline: selectedAirlines.length > 0,
      segments: payload?.segments ? payload?.segments : [...segments],
      adultCount: travellerInfo.adults,
      childCount: travellerInfo.children,
      seniorCount: 0,
      infantCount: travellerInfo.infants,
      sources: selectedSupplier.map((s) => s.value),
      refundableFares: refundableFaresOnly,
      maxStops: directFlights ? 0 : null,
      corporateTravelProfileId: 0,
      corporateTravelReasonId: 0,
      corporateTravelReason: null,
      appliedPolicy: false,
      searchBySegments: false,
      timeIntervalSpecified: false,
      gdsSpecialFareType: selectedFareTypes.map((f) => f.value)[0],
    };
    // console.log('saveSearchPayloadResults',searchData);
    saveSearchPayloadResults(searchData)
    setLoader(true);
    const response: any = await searchFlights(searchData);
    setLoader(false);
    try {
      if (response.status == 200 && response?.data) {
        saveFlightSearchResults(response?.data);
        navigate('/searchflight', { state: { searchData: searchData } });
      }
      else {
        toast.error(response?.data.error.message);
      }
    }
    catch {
      toast.error("An error occurred. Please try again later.");
    }
  };

  return (
    <>
    <div className="trip_section">
      <div className="col-sm-12">
        <div className="row">
          <div
            className="col-sm-8 text-start d-flex align-items-center mb-3 mb-sm-0"
            style={{ paddingLeft: '10px' }}
          >
            <Flighttab flightType={flightType} setFlightType={setFlightType} />
          </div>
          {flightType == 'multistop' && <MultiFlights />}
          {flightType == 'return' &&
            <Returnflight
              recentSearch={payload}
              selectedAirlines={selectedAirlines}
              searchFlightsCommon={searchFlightsCommon}
            />
          }
          {flightType == 'oneway' && (
            <OneWay
              recentSearch={payload}
              selectedAirlines={selectedAirlines}
              searchFlightsCommon={searchFlightsCommon}
            />
          )}
          <div className="row">
            <div className="col-sm-12">
              <details>
                <summary className="text-start">
                  <p className="mb-0 d-inline-block">
                    Additional Search Options
                  </p>
                </summary>
                <ul className="additional_searches mt-4">
                  <AdditionalSerach
                    selectedAirlines={selectedAirlines}
                    setSelectedAirlines={setSelectedAirlines}
                    selectedFareTypes={selectedFareTypes}
                    setSelectedFareTypes={setSelectedFareTypes}
                    markup={markup}
                    setMarkup={setMarkup}
                    selectedSupplier={selectedSupplier}
                    setSelectedSupplier={setSelectedSupplier}
                    directFlights={directFlights}
                    setDirectFlights={setDirectFlights}
                    refundableFaresOnly={refundableFaresOnly}
                    setRefundableFaresOnly={setRefundableFaresOnly}
                  />
                </ul>
              </details>
            </div>
          </div>
        </div>
      </div>
    </div>
    {loader && <Loader/>}
    </>
  );
};

export default SearchBox;
