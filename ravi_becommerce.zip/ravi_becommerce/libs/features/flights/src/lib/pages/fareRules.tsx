import styles from '../oneway.module.scss';

const FareRules = ({ fareRules }: any) => {
  // const { fareRules } = useSelector((state: RootState) => state.flight);

  return (
    <div className="text-start border">
      <div className="fw-semibold bg-secondary-subtle px-3">Fare Rules</div>
      <div className="py-2 px-3" style={{ fontSize: '0.8rem' }}>
        {fareRules?.errorMessage ? (
          <div>{fareRules?.errorMessage}</div>
        ) : (
          Object.values(fareRules)?.map((flight: any, index: number) => (
            <div key={index}>
              <div className="fw-semibold">
                {flight?.origin} - {flight?.destination}
              </div>
              <div
                className={styles['fareRulesOverflow']}
                dangerouslySetInnerHTML={{ __html: flight?.fareRuleDetail }}
              ></div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default FareRules;
