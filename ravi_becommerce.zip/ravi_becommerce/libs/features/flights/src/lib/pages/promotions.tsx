import React, { useEffect, useState } from 'react';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import SliderComponent from '../../Components/SliderComponent';
import { useSelector } from 'react-redux';
import { RootState } from '@mfa-travel-app/store';
import { flightsPromoImg, promoImg, dubaiImg, carioImg } from '@mfa-travel-app/assets';


interface ImageBanner {
  id: number;
  agentId: number;
  imageFilePath: string;
  fileType: string;
  imageLabel: string;
  imageReturnUrl: string;
  bannerType: string;
  order: number;
}

// https://app.pierofcloudtech.com/flights-promo-img.png
// https://app.pierofcloudtech.com/promo-img.png

const IMAGE_ARR: ImageBanner[] = [

  {
    id: 1,
    agentId: 1,
    imageFilePath: promoImg,
    fileType: "png",
    imageLabel: "Travelrestriction",
    imageReturnUrl: "https://www.airindia.com/in/en/book/special-offers.html",
    bannerType: "MainSlider",
    order: 1
  },
  {
    id: 2,
    agentId: 1,
    imageFilePath: flightsPromoImg,
    fileType: "png",
    imageLabel: "Flightpromo",
    imageReturnUrl: "https://www.airindia.com/in/en/book/special-offers.html",
    bannerType: "SideBig1",
    order: 1
  },
  {
    id: 3,
    agentId: 1,
    imageFilePath: dubaiImg,
    fileType: "png",
    imageLabel: "DubaiHoliday",
    imageReturnUrl: "https://www.airindia.com/in/en/manage/web-checkin.html",
    bannerType: "Sidesmall1",
    order: 1
  },
  {
    id: 4,
    agentId: 1,
    imageFilePath: carioImg,
    fileType: "png",
    imageLabel: "Cairoholidays",
    imageReturnUrl: "https://www.thomascook.in/holidays/international-tour-packages/egypt-tour-packages/egyptian-dhamaka?pkgId=PKG012160&packageClassId=0&destination=PKG012160_egypt_COUNTRY_1&destTag=Egypt&https://www.thomascook.in/holidays/international-tour-packages/egypt-tour-packages",
    bannerType: "Sidesmall2",
    order: 1
  },
  {
    id: 5,
    agentId: 1,
    imageFilePath: promoImg,
    fileType: "png",
    imageLabel: "Travelrestriction",
    imageReturnUrl: "https://www.airindia.com/in/en/book/special-offers.html",
    bannerType: "MainSlider",
    order: 2
  },
  {
    id: 6,
    agentId: 1,
    imageFilePath: flightsPromoImg,
    fileType: "png",
    imageLabel: "Flightpromo",
    imageReturnUrl: "https://www.airindia.com/in/en/book/special-offers.html",
    bannerType: "SideBig1",
    order: 2
  },
  {
    id: 7,
    agentId: 1,
    imageFilePath: dubaiImg,
    fileType: "png",
    imageLabel: "DubaiHoliday",
    imageReturnUrl: "https://www.airindia.com/in/en/manage/web-checkin.html",
    bannerType: "Sidesmall1",
    order: 2
  },
  {
    id: 8,
    agentId: 1,
    imageFilePath: carioImg,
    fileType: "png",
    imageLabel: "Cairoholidays",
    imageReturnUrl: "https://www.thomascook.in/holidays/international-tour-packages/egypt-tour-packages/egyptian-dhamaka?pkgId=PKG012160&packageClassId=0&destination=PKG012160_egypt_COUNTRY_1&destTag=Egypt&https://www.thomascook.in/holidays/international-tour-packages/egypt-tour-packages",
    bannerType: "Sidesmall2",
    order: 2
  },
  {
    id: 9,
    agentId: 1,
    imageFilePath: promoImg,
    fileType: "png",
    imageLabel: "Travelrestriction",
    imageReturnUrl: "https://www.airindia.com/in/en/book/special-offers.html",
    bannerType: "MainSlider",
    order: 3
  },
  {
    id: 10,
    agentId: 1,
    imageFilePath: flightsPromoImg,
    fileType: "png",
    imageLabel: "Flightpromo",
    imageReturnUrl: "https://www.airindia.com/in/en/book/special-offers.html",
    bannerType: "SideBig1",
    order: 3
  },
  {
    id: 11,
    agentId: 1,
    imageFilePath: dubaiImg,
    fileType: "png",
    imageLabel: "DubaiHoliday",
    imageReturnUrl: "https://www.airindia.com/in/en/manage/web-checkin.html",
    bannerType: "Sidesmall1",
    order: 3
  },
  {
    id: 12,
    agentId: 1,
    imageFilePath: carioImg,
    fileType: "png",
    imageLabel: "Cairoholidays",
    imageReturnUrl: "https://www.thomascook.in/holidays/international-tour-packages/egypt-tour-packages/egyptian-dhamaka?pkgId=PKG012160&packageClassId=0&destination=PKG012160_egypt_COUNTRY_1&destTag=Egypt&https://www.thomascook.in/holidays/international-tour-packages/egypt-tour-packages",
    bannerType: "Sidesmall2",
    order: 3
  }
];

const Promotions: React.FC = () => {
  const { sliderImages } = useSelector((state: RootState) => state.config);

  const [mainSlider, setMainSlider] = useState<ImageBanner[]>([]);
  const [sideBig1, setSideBig1] = useState<ImageBanner[]>([]);
  const [sidesmall2, setSidesmall2] = useState<ImageBanner[]>([]);
  const [sidesmall1, setSidesmall1] = useState<ImageBanner[]>([]);
  const { homeScreenShowHide }: any = useSelector(
    (state: RootState) => state.config
  );

  useEffect(() => {
    if (IMAGE_ARR && IMAGE_ARR.length > 0) {
      setMainSlider(IMAGE_ARR.filter((item: any) => item.bannerType == 'MainSlider'));
      setSideBig1(IMAGE_ARR.filter((item: any) => item.bannerType == 'SideBig1'));
      setSidesmall2(IMAGE_ARR.filter((item: any) => item.bannerType == 'Sidesmall2'));
      setSidesmall1(IMAGE_ARR.filter((item: any) => item.bannerType == 'Sidesmall1'));
    }
  }, []);

  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };
  const showBannerHomeSreen = homeScreenShowHide?.some((item: any) => item.text === "SHOW_BANNERS" && item.show);
  return (
    <React.Fragment>
      {showBannerHomeSreen &&
        <section className="promotionsHome">
          <div className='row'>
            <div className='col-lg-6'>
              <div className="card h-100">
                <div className="card-body">
                  <SliderComponent ImageData={mainSlider} />
                </div>
              </div>
            </div>

            <div className='col-lg-6'>
              <div className="card h-100">
                <div className="card-body">
                  <div className='row'>
                    <div style={{ marginBottom: '12px' }} className='col-12'><SliderComponent ImageData={sideBig1} /></div>
                    <div className='col-6'> <SliderComponent ImageData={sidesmall2} /></div>
                    <div className='col-6'> <SliderComponent ImageData={sidesmall1} /></div>
                  </div>


                </div>
              </div>
            </div>
          </div>
        </section>
      }



    </React.Fragment>
  );
};

export default Promotions;
