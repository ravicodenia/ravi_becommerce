import React, { useState, useEffect } from 'react';
import { MainLayout } from '@mfa-travel-app/layout';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { useStore, RootState } from '@mfa-travel-app/store';
import { Link } from 'react-router-dom';
import AdultPax from '../../Components/FlightPax/AdultPax';
import ContactInfo from '../../Components/FlightPax/ContactInfo';
import PassportInfo from '../../Components/FlightPax/PassportInfo';
import BaggageInfo from '../../Components/FlightPax/BaggageInfo';
import MealInfo from '../../Components/FlightPax/MealInfo';
import PromoCode from '../../Components/FlightPax/PromoCode';
import FareSummary from '../../Components/FlightPax/FareSummary';
import AddMarkup from '../../Components/FlightPax/AddMarkup';
import FlightItinerary from '../../Components/FlightPax/FlightItinerary';
import FlightDetailsPopup from '../../Components/FlightPax/FlightDetailsPopup';
import BaggagePolicyPopup from '../../Components/FlightPax/BaggagePolicyPopup';
import SearchPax from '../../Components/FlightPax/SearchPax';
import { getSeatAvailable } from '../service/flightApi';
import { Loader } from '@mfa-travel-app/ui';
import { toast } from 'react-toastify';
import { getBalance } from '@mfa-travel-app/shared';
import { getBookSSR } from '../service/flightApi';

import { FiChevronDown } from "react-icons/fi";
import { FiChevronUp } from "react-icons/fi";



export default function flightPaxDetails() {
  const navigate = useNavigate();
  const { savePassengerDetails, saveSeatLayoutDetails } = useStore();
  const [chkTermsBtn, setChkTermsBtn] = useState(true);
  const [loader, setLoader] = useState(false);

  // const [contactInfo, setContactInfo] = useState({
  //   email: '',
  //   mobileNo: '',
  // });
  // const [markup, setMarkup] = useState({
  //   markupType: '',
  //   markupValue: '',
  //   markupUnit: '',
  // });
  const [passengerDetails, setPassengerDetails] = useState<any[]>([]);
  const {
    selectedItinerary,
    passengerList,
    mealsList,
    baggageInfo,
    rePriceData,
  } = useSelector((state: RootState) => state.flight);
  const { countries, nationalities, agentProfile }: any = useSelector(
    (state: RootState) => state.config
  );
  const { saveBalanceDetails } = useStore();

  useEffect(() => {
    let seatInfo: any = {
      onwardJourney: {},
      returnJourney: {},
    };
    selectedItinerary?.flights?.forEach((journey: any, journeyIndex: any) => {
      journey?.forEach((flight: any) => {
        if (journeyIndex == 0) {
          seatInfo.onwardJourney[`${flight.flightNumber}`] = '';
        } else if (journeyIndex == 1) {
          seatInfo.returnJourney[`${flight.flightNumber}`] = '';
        }
      });
    });
    if (selectedItinerary?.fareBreakdown) {
      const passengers = selectedItinerary.fareBreakdown.map(
        (passengerType: any) =>
          Array(passengerType.passengerCount).fill({
            type: passengerType.passengerType,
            baggageInfo: {
              onwardBaggage: null,
              returnBaggage: null,
            },
            mealInfo: {
              onwardMeal: null,
              returnMeal: null,
            },
            passportInfo: {
              passportNo: '',
              passportDate: '01',
              passportMonth: '01',
              passportYear: '',
              address1: '',
              address2: '',
              nationality: '',
              country: '',
            },
            paxInfo: {
              title: '',
              firstName: '',
              lastName: '',
              gender: '',
              dobdate: '01',
              dobmonth: '01',
              dobyear: '',
              maxinp1: selectedItinerary?.flights[0][0]?.flightNumber,
              maxinp2: '',
              addrewardinp: '',
            },
            seatInfo: seatInfo,
            markup: {
              markupType: '',
              markupValue: 0,
              markupUnit: '',
            },
            contactInfo: {
              email: '',
              mobileNo: '',
            },
          })
      );
      let passengersArray: any[] = [];
      let count = 1;
      passengers?.forEach((passengerTypeArr: any) => {
        passengerTypeArr.forEach((singlePassenger: any) => {
          passengersArray.push({ ...singlePassenger, passengerNo: count++ });
        });
      });

      setPassengerDetails(passengersArray);
    }
  }, [selectedItinerary]);

  useEffect(() => {
    if (passengerList && passengerList.length > 0) {
      setPassengerDetails(passengerList);
    }
  }, [passengerList]);

  const handleMarkupChange = (data: any) => {
    // setMarkup(data);
    const updatedPassengers = passengerDetails?.map((passenger: any) => ({
      ...passenger,
      markup: data,
    }));
    setPassengerDetails(updatedPassengers);
  };

  const handleNavigation = async () => {
    try {
      if (validatePaxInput()) {
        if (validateDob() === true) {
          savePassengerDetails(passengerDetails);
          const response: any = await getBalance(agentProfile?.id);
          if (response?.data) {
            saveBalanceDetails(response?.data);
          }
          const bookRequestPaxData = passengerDetails?.map(
            (passenger: any, paxIndex: any) => {
              const {
                baggageInfo,
                contactInfo,
                mealInfo,
                passportInfo,
                paxInfo,
                markup,
                seatInfo,
              } = passenger;

              const country = countries?.filter(
                (country: any) => country?.value == passportInfo?.country
              )[0];
              const nationality = nationalities?.filter(
                (nationality: any) =>
                  nationality?.value == passportInfo?.nationality
              )[0];
              let mealCodeString: any = '';
              let mealDescString: any = '';

              // if (mealInfo?.onwardMeal != null && mealInfo?.returnMeal != null) {
              let mealCodes: any = [];
              const mealArr = Object.values(mealInfo);
              mealArr?.forEach((meal: any) => {
                let mealCode = '';
                mealCode = meal == null ? '' : meal?.mealCode;
                mealCodes.push(mealCode);
              });

              mealCodes?.forEach((mealCode: any, index: number) => {
                if (index + 1 !== mealCodes?.length) {
                  mealCodeString = mealCodeString + `${mealCode}, `;
                } else {
                  mealCodeString = mealCodeString + `${mealCode}`;
                }
              });

              let mealDes: any = [];
              mealArr?.forEach((meal: any) => {
                let mealDesc = '';
                mealDesc = meal == null || '' ? '' : meal?.mealDescription;
                mealDes.push(mealDesc);
              });

              mealDes?.forEach((mealdescription: any, index: number) => {
                if (index + 1 !== mealDes?.length) {
                  mealDescString = mealDescString + `${mealdescription}, `;
                } else {
                  mealDescString = mealDescString + `${mealdescription}`;
                }
              });
              // }

              let baggageCodeString: any = '';

              // if (
              //   baggageInfo?.onwardBaggage != null &&
              //   baggageInfo?.returnBaggage != null
              // ) {
              let baggageCodes: any = [];
              const baggageArr = Object.values(baggageInfo);
              baggageArr?.forEach((baggage: any) => {
                let baggageCode = '';
                baggageCode =
                  baggage == null || '' ? '0 kg' : baggage?.baggageCode;
                baggageCodes.push(baggageCode);
              });

              baggageCodes?.forEach((baggageCode: any, index: number) => {
                if (index + 1 !== baggageCodes?.length) {
                  baggageCodeString = baggageCodeString + `${baggageCode}, `;
                } else {
                  baggageCodeString = baggageCodeString + `${baggageCode}`;
                }
              });
              // }

              let cabinBaggage: any = [];
              selectedItinerary?.flights?.forEach((journey: any) => {
                journey?.forEach((flight: any) => {
                  let baggage = '';
                  if (flight?.carryOnBaggage != null)
                    baggage = flight?.carryOnBaggage;
                  cabinBaggage.push(baggage);
                });
              });

              let cabinBaggageString = '';
              cabinBaggage?.forEach((baggage: any, index: number) => {
                if (index + 1 !== cabinBaggage?.length) {
                  cabinBaggageString = cabinBaggageString + `${baggage}, `;
                } else {
                  cabinBaggageString = cabinBaggageString + `${baggage}`;
                }
              });

              let seats: any = [];
              let seatInfoArr: any = [];

              seatInfo?.onwardFlights?.forEach((flightSeat: any) => {
                const segmentFlight = selectedItinerary?.flights[0]?.filter(
                  (flight: any) => flight?.flightNumber == flightSeat?.flightNo
                )[0];
                // const seatString = `${flightSeat?.seatNo}(${segmentFlight?.segmentId})`;
                const seatString = `${flightSeat?.seatNo}(${segmentFlight?.origin?.airportCode}-${segmentFlight?.destination?.airportCode})`;
                seatInfoArr?.push(seatString);
                const segmentString = `${segmentFlight?.origin?.airportCode}-${segmentFlight?.destination?.airportCode}`;
                const seat = {
                  paxNo: paxIndex,
                  segment: segmentString,
                  seatNo: flightSeat?.seatNo,
                  price: flightSeat?.price,
                  seatStatus: 'A',
                  code: flightSeat?.seatNo,
                  priceRefKey: '',
                  supplierPrice: flightSeat?.price,
                };
                seats?.push(seat);
              });

              seatInfo?.returnFlights?.forEach((flightSeat: any) => {
                const segmentFlight = selectedItinerary?.flights[1]?.filter(
                  (flight: any) => flight?.flightNumber == flightSeat?.flightNo
                )[0];
                // const seatString = `${flightSeat?.seatNo}(${segmentFlight?.segmentId})`;
                const seatString = `${flightSeat?.seatNo}(${segmentFlight?.origin?.airportCode}-${segmentFlight?.destination?.airportCode})`;
                seatInfoArr?.push(seatString);
                const segmentString = `${segmentFlight?.origin?.airportCode}-${segmentFlight?.destination?.airportCode}`;
                const seat = {
                  paxNo: paxIndex,
                  segment: segmentString,
                  seatNo: flightSeat?.seatNo,
                  price: flightSeat?.price,
                  seatStatus: 'A',
                  code: flightSeat?.seatNo,
                  priceRefKey: '',
                  supplierPrice: flightSeat?.price,
                };
                seats?.push(seat);
              });

              let seatInfoString = '';
              seatInfoArr?.forEach((seatString: any, index: number) => {
                if (index + 1 != seatInfoArr?.length) {
                  seatInfoString = seatInfoString + `${seatString}|`;
                } else {
                  seatInfoString = seatInfoString + seatString;
                }
              });

              let baggageCharge = 0;
              baggageCharge =
                baggageInfo?.onwardBaggage?.baggageCharge ? baggageInfo?.onwardBaggage?.baggageCharge : 0 +
                baggageInfo?.returnBaggage?.baggageCharge ? baggageInfo?.returnBaggage?.baggageCharge : 0;

              let mealCharge = 0;
              mealCharge =
                mealInfo?.onwardMeal?.mealCharge ? mealInfo?.onwardMeal?.mealCharge : 0 +
                mealInfo?.returnMeal?.mealCharge ? mealInfo?.returnMeal?.mealCharge : 0;

              let seatPrice = 0;
              seatInfo?.onwardFlights?.forEach((seat: any) => {
                seatPrice = seatPrice + seat?.price ? seat?.price : 0;
              });

              seatInfo?.returnFlights?.forEach((seat: any) => {
                seatPrice = seatPrice + seat?.price ? seat?.price : 0;
              });

const hasBaggageInfo = baggageInfo && (
  baggageInfo?.onwardBaggage?.baggageCode ||
  baggageInfo?.onwardBaggage?.baggageDescription ||
  baggageInfo?.onwardBaggage?.baggageCharge ||
  baggageInfo?.onwardBaggage?.currencyCode ||
  baggageInfo?.onwardBaggage?.segmentId
);

const hasMealInfo = mealInfo?.onwardMeal !== null || mealInfo?.returnMeal !== null;
const hasSeatInfo = seatInfo?.onwardFlights?.length > 0 || seatInfo?.returnFlights?.length > 0;

if (!hasBaggageInfo && !hasMealInfo && !hasSeatInfo) {
  return null;
}


              return {
                paxId: paxIndex,
                supplierPaxId: 0,
                flightId: 0,
                firstName: paxInfo?.firstName,
                lastName: paxInfo?.lastName,
                title: paxInfo?.title === '01' ? 'Mr. ' : 'Mrs. ',
                cellPhone: contactInfo?.mobileNo,
                isLeadPax: paxIndex === 0 ? true : false,
                dateOfBirth: new Date(
                  parseInt(paxInfo?.dobyear),
                  parseInt(paxInfo?.dobmonth) - 1,
                  parseInt(paxInfo?.dobdate)
                ),
                type: passenger?.type,
                passportNo: passportInfo?.passportNo,
                nationality: {
                  countryName: nationality?.value,
                  regioncode: nationality?.value,
                  nationality: nationality?.value,
                  countryCode: nationality?.value,
                },
                country: {
                  countryName: country?.text,
                  regioncode: country?.value,
                  nationality: country?.text,
                  countryCode: country?.value,
                },
                city: passportInfo?.address1,
                addressLine1: passportInfo?.address1,
                addressLine2: passportInfo?.address2,
                gender: Number(paxInfo?.gender),
                email: contactInfo?.email,
                meal: {
                  code: mealCodeString,
                  description: mealDescString,
                },
                seat: {
                  code: '',
                  description: '',
                },
                price: {
                  ...selectedItinerary?.price,
                  ...rePriceData?.price,
                  airlineCommission: {
                    commissionId: 0,
                    discount: 0,
                    commissionValue: 0,
                    commissionType: '',
                    commissionAppliedOn: '',
                    priceId: 0,
                    discountValue: 0,
                    discountType: '',
                  },
                  markupValue: Number(markup?.markupValue),
                  markupType: markup?.markupType,
                  asvAmount: Number(markup?.markupValue),
                  asvType: markup?.markupUnit,
                  asvElement: markup?.markupType,
                  baggageCharge: baggageCharge,
                  mealCharge: mealCharge,
                  seatPrice: seatPrice
                },
                ffAirline: paxInfo?.maxinp1,
                ffNumber: paxInfo?.maxinp2,
                createdBy: 0,
                createdOn: new Date().toISOString(),
                lastModifiedBy: 0,
                lastModifiedOn: new Date().toISOString(),
                passportExpiry: new Date(
                  parseInt(passportInfo?.passportYear),
                  parseInt(passportInfo?.passportMonth) - 1,
                  parseInt(passportInfo?.passportDate)
                ).toISOString(),
                baggageCode: baggageCodeString,
                cabinBaggage: cabinBaggageString,
                baggageType: baggageCodeString,
                categoryId: '',
                flyDubaiBaggageCharge: [0],
                flexDetailsList: [
                  {
                    detailsId: 0,
                    flexId: 0,
                    paxId: 0,
                    flexLabel: '',
                    flexData: '',
                    createdBy: 0,
                    productID: 0,
                    flexGDSprefix: '',
                    sIsOffline: '',
                  },
                ],
                destinationPhone: '',
                gstStateCode: '',
                gstTaxRegNo: '',
                stateCode: '',
                taxBreakup: [
                  {
                    key: '',
                    value: 0,
                  },
                ],
                mealType: mealCodeString,
                mealDesc: mealDescString,
                seatInfo: seatInfoString,
                corpProfileId: '',
                liPaxSeatInfo: seats,
                agentId: 0,
                salamAirMealCharge: [0],
                passengerKey: '',
                priceInfoKey: '',
                bookingTravellerRefKey: '',
                ssrInfos: [
                  {
                    code: '',
                    description: '',
                    group: 0,
                    price: 0,
                    discount: 0,
                    currencyCode: '',
                    baseCurrencyPrice: 0,
                    baseCurrencyDiscount: 0,
                    baseCurrencyCode: '',
                    ssrType: '',
                    suppInfo: [
                      {
                        keys: [''],
                        baseCurrencyPrice: 0,
                        baseCurrencyCode: '',
                      },
                    ],
                  },
                ],
                isTicketed: true,
              };
            }
          );
  

    const validPaxData = bookRequestPaxData?.filter(pax => pax !== null);

    const bookRequestData = {
      sessionId: selectedItinerary?.sessionId,
      flightGuId: selectedItinerary?.flightGuId,
      passenger: validPaxData,
    };

    if (validPaxData.length > 0) {
      if (selectedItinerary?.isRequiredAncillary) {
        const res: any = await getBookSSR(bookRequestData);
        if (res.status === 200 && res.data) {
          navigate('/flight-payment');
        } else {
          toast.error('Error while booking');
        }
      } else {
        navigate('/flight-payment');
      }
    } else {
      navigate('/flight-payment');
    }
  } else {
    navigate('/flight-payment');
  }
} else {
  toast.error('Please fill all required fields');
}
} catch (error) {
toast.error('An error occurred. Please try again later.');
}
    

  };
  const validatePaxInput = () => {
    let ret = true;
    passengerDetails?.forEach((passenger: any) => {
      const { contactInfo, passportInfo, paxInfo } = passenger;
      if (
        !contactInfo?.email ||
        !contactInfo?.mobileNo ||
        !paxInfo?.firstName ||
        !paxInfo?.lastName ||
        !paxInfo?.dobyear ||
        !passportInfo?.passportNo ||
        !passportInfo?.address1 ||
        !passportInfo?.passportYear ||
        !passportInfo?.nationality ||
        !passportInfo?.country
      ) {
        ret = false;
      }
      // var regex = /[^\s@]+@[^\s@]+\.[^\s@]+/;
      // if (!regex.test(contactInfo?.email)) {
      //   ret = false;
      // }
    });
    return ret;
  };

  const validateDob = () => {
    let ret = true;
    passengerDetails?.forEach((passenger: any) => {
      const { paxInfo } = passenger;
      if (passenger?.type === 2) {
        const now = new Date();
        const dob = new Date(
          parseInt(paxInfo.dobyear),
          parseInt(paxInfo.dobmonth) - 1,
          parseInt(paxInfo.dobdate)
        );
        const twelveYearsInMillis = 12 * 365.25 * 24 * 60 * 60 * 1000;
        const timeDiff = now.getTime() - dob.getTime();
        if (timeDiff > twelveYearsInMillis) {
          alert('Child cannot be more than 12 years old');
          ret = false;
        }
      }
    });
    return ret;
  };

  const handleInfoChange = (index: any, key: any, value: any) => {
    const updatedPassengers = passengerDetails.map((passenger, i) =>
      i === index ? { ...passenger, [key]: value } : passenger
    );
    setPassengerDetails(updatedPassengers);
  };

  const onContactChange = (value: any) => {
    // setContactInfo(value);
    const updatedPassengers = passengerDetails?.map((passenger: any) => ({
      ...passenger,
      contactInfo: value,
    }));
    setPassengerDetails(updatedPassengers);
  };

  const toggleChkDisableButton = () => {
    setChkTermsBtn(!chkTermsBtn);
  };

  const navigateToSelectSeats = () => {
    if (validatePaxInput()) {
      savePassengerDetails(passengerDetails);
      let passengerString = '';
      passengerDetails?.forEach((passenger: any, index: number) => {
        if (index + 1 !== passengerDetails?.length) {
          const paxName = `${
            passenger?.paxInfo?.title === '01' ? 'Mr-' : 'Mrs-'
          }${passenger?.paxInfo?.firstName} ${passenger?.paxInfo?.lastName}-${
            passenger?.type == 1 ? 'A' : passenger?.type == 2 ? 'C' : 'I'
          }, `;
          passengerString = passengerString + paxName;
        } else {
          const paxName = `${
            passenger?.paxInfo?.title === '01' ? 'Mr-' : 'Mrs-'
          }${passenger?.paxInfo?.firstName} ${passenger?.paxInfo?.lastName}-${
            passenger?.type == 1 ? 'A' : passenger?.type == 2 ? 'C' : 'I'
          }`;
          passengerString = passengerString + paxName;
        }
      });

      let onwardJourney: any = {};
      let returnJourney: any = {};

      selectedItinerary?.flights?.forEach((journey: any, index: any) => {
        journey?.forEach(async (flight: any) => {
          try {
            setLoader(true);
            const response: any = await getSeatAvailable(
              selectedItinerary?.sessionId,
              selectedItinerary?.flightGuId,
              flight?.origin?.airportCode,
              flight?.destination?.airportCode,
              passengerString
            );
            setLoader(false);
            if (
              response?.data &&
              response?.data?.segmentSeat &&
              response?.data?.segmentSeat.length > 0
            ) {
              if (
                response?.data?.segmentSeat?.every(
                  (segment: any) => segment?.seatInfoDetails == null
                )
              ) {
                const key = `${flight?.flightNumber}`;
                if (index == 0) {
                  onwardJourney[key] = 'All seats occupied';
                  saveSeatLayoutDetails({
                    onwardJourney: {
                      ...onwardJourney,
                      [key]: 'All seats occupied',
                    },
                  });
                } else if (index == 1) {
                  returnJourney[key] = 'All seats occupied';
                  saveSeatLayoutDetails({
                    returnJourney: {
                      ...returnJourney,
                      [key]: 'All seats occupied',
                    },
                  });
                }
              } else {
                const segmentFlight = response?.data?.segmentSeat?.find(
                  (segment: any) =>
                    segment?.origin == flight?.origin?.airportCode &&
                    segment?.destination == flight?.destination?.airportCode &&
                    // segment?.flightNo == flight?.flightNumber &&
                    segment?.seatInfoDetails !== null
                );
                if (segmentFlight) {
                  const key = `${segmentFlight.flightNo}`;
                  if (index == 0) {
                    onwardJourney[key] = segmentFlight?.seatInfoDetails;
                    saveSeatLayoutDetails({
                      onwardJourney: {
                        ...onwardJourney,
                        [key]: segmentFlight?.seatInfoDetails,
                      },
                    });
                  } else if (index == 1) {
                    returnJourney[key] = segmentFlight?.seatInfoDetails;
                    saveSeatLayoutDetails({
                      returnJourney: {
                        ...returnJourney,
                        [key]: segmentFlight?.seatInfoDetails,
                      },
                    });
                  }
                } else {
                  const key = `${flight?.flightNumber}`;
                  if (index == 0) {
                    onwardJourney[key] = 'Seats not available';
                    saveSeatLayoutDetails({
                      onwardJourney: {
                        ...onwardJourney,
                        [key]: 'Seats not available',
                      },
                    });
                  } else if (index == 1) {
                    returnJourney[key] = 'Seats not available';
                    saveSeatLayoutDetails({
                      returnJourney: {
                        ...returnJourney,
                        [key]: 'Seats not available',
                      },
                    });
                  }
                }
                // response?.data?.segmentSeat?.forEach((segment: any) => {
                //   if (
                //     segment?.origin == flight?.origin?.airportCode &&
                //     segment?.destination == flight?.destination?.airportCode &&
                //     segment?.seatInfoDetails !== null
                //     // ||
                //     // segment?.seatInfoDetails?.length != 0
                //   ) {
                //     const key = `${segment.flightNo}`;
                //     if (index == 0) {
                //       onwardJourney[key] = segment?.seatInfoDetails;
                //       saveSeatLayoutDetails({
                //         onwardJourney: {
                //           ...onwardJourney,
                //           [key]: segment?.seatInfoDetails,
                //         },
                //       });
                //     } else if (index == 1) {
                //       returnJourney[key] = segment?.seatInfoDetails;
                //       saveSeatLayoutDetails({
                //         returnJourney: {
                //           ...returnJourney,
                //           [key]: segment?.seatInfoDetails,
                //         },
                //       });
                //     }
                //   } else {
                //     const key = `${flight?.flightNumber}`;
                //     if (index == 0) {
                //       onwardJourney[key] = 'Seats not available';
                //       saveSeatLayoutDetails({
                //         onwardJourney: {
                //           ...onwardJourney,
                //           [key]: 'Seats not available',
                //         },
                //       });
                //     } else if (index == 1) {
                //       returnJourney[key] = 'Seats not available';
                //       saveSeatLayoutDetails({
                //         returnJourney: {
                //           ...returnJourney,
                //           [key]: 'Seats not available',
                //         },
                //       });
                //     }
                //   }
                // });
              }
            } else {
              const key = `${flight?.flightNumber}`;
              if (index == 0) {
                onwardJourney[key] = 'Seats not available';
                saveSeatLayoutDetails({
                  onwardJourney: {
                    ...onwardJourney,
                    [key]: 'Seats not available',
                  },
                });
              } else if (index == 1) {
                returnJourney[key] = 'Seats not available';
                saveSeatLayoutDetails({
                  returnJourney: {
                    ...returnJourney,
                    [key]: 'Seats not available',
                  },
                });
              }
            }
          } catch (error) {
            toast.error('An error occurred. Please try again later.');
          }
        });
      });
      navigate('/select-seats');
    } else {
      toast.error('Please fill all required fields');
    }
  };

  //show hide Itinerary mobile toogle
  const [showItinerary, setShowItinerary] = useState(false)
  const showFilterBlock = () => {
    setShowItinerary(!showItinerary)
  }





  return (
    <>
      <MainLayout>
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="innerContainer border-top-0">
                <div className="row">
                  <div className="col-lg-8 order-lg-0 order-2">
                    <div className="wrapper p_t_0_mb">
                      <div className="row">
                        <div className="col-12">
                          <div className="form_heading">
                            <span className=" title">Contact Info</span>
                          </div>
                        </div>
                        <div className="col-12">
                          {passengerDetails?.length > 0 && (
                            <ContactInfo
                              data={passengerDetails[0]?.contactInfo}
                              onChange={(value: any) => onContactChange(value)}
                            />
                          )}{' '}
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-12">
                          <div className="form_heading">
                            <span className="title">Passenger Details</span>
                          </div>
                        </div>

                        <div className="col-12">
                          {passengerDetails?.map(
                            (passenger: any, index: any) => (
                              <div className="row" key={index}>
                                <div className="col-12">
                                  <div className="row align-items-center">
                                    <div className="col-6 mb-3">
                                      <span className="paxrow">
                                        {' '}
                                        <i className="fa-solid fa-caret-down"></i>{' '}
                                        Passenger
                                      </span>{' '}
                                      {index + 1}:{' '}
                                      <span className="paxtype">
                                        {' '}
                                        <strong>
                                          {passenger?.type == 1
                                            ? 'Adult'
                                            : passenger?.type == 2
                                            ? 'Child'
                                            : 'Infant'}
                                        </strong>{' '}
                                      </span>
                                    </div>

                                    {/* <div className="col-6 mb-3 text-end">
                                      <SearchPax />
                                    </div> */}
                                  </div>
                                </div>

                                <div className="col-12 mb-3">
                                  <AdultPax
                                    data={passengerDetails[index].paxInfo}
                                    onChange={(value: any) =>
                                      handleInfoChange(index, 'paxInfo', value)
                                    }
                                  />{' '}
                                </div>
                                <div className="col-12 mb-3">
                                  <PassportInfo
                                    data={passengerDetails[index].passportInfo}
                                    onChange={(value: any) =>
                                      handleInfoChange(
                                        index,
                                        'passportInfo',
                                        value
                                      )
                                    }
                                  />{' '}
                                </div>
                                {selectedItinerary?.isRequiredAncillary && (
                                  <>
                                    <div className="col-12 mb-3">
                                      <BaggageInfo
                                        data={
                                          passengerDetails[index].baggageInfo
                                        }
                                        onChange={(value: any) =>
                                          handleInfoChange(
                                            index,
                                            'baggageInfo',
                                            value
                                          )
                                        }
                                      />{' '}
                                    </div>
                                    <div className="col-12 mb-3">
                                      <MealInfo
                                        data={passengerDetails[index].mealInfo}
                                        onChange={(value: any) =>
                                          handleInfoChange(
                                            index,
                                            'mealInfo',
                                            value
                                          )
                                        }
                                      />{' '}
                                    </div>
                                  </>
                                )}

                                <div className="col-12">
                                  {' '}
                                  <hr></hr>
                                </div>
                              </div>
                            )
                          )}
                        </div>
                      </div>

                      <div className="row">
                        <div className="col-12 mt-2">
                          <button
                            type="button"
                            className="btn btn-secondary"
                            onClick={() => navigateToSelectSeats()}
                          >
                            SELECT SEATS
                          </button>
                        </div>
                      </div>

                      <div className="row">
                        <div className="col-12 mt-4 mb-4">
                          <input
                            className="form-check-input"
                            type="checkbox"
                            id="termconditions"
                            name="termconditions"
                            onChange={toggleChkDisableButton}
                          />

                          <label
                            className="ms-2 font_size_90"
                            htmlFor="termconditions"
                          >
                            I understand and agree to the rules,
                            <Link to="/" className="text-primary">
                              {' '}
                              Privacy Policy
                            </Link>
                            ,
                            <Link to="/" className="text-primary">
                              User Agreement{' '}
                            </Link>{' '}
                            and
                            <Link to="/" className="text-primary">
                              {' '}
                              Terms & Conditions
                            </Link>
                            .
                          </label>
                        </div>

                        <div className="col-12 mt-4 mb-4 text-end">
                          <button
                            disabled={chkTermsBtn}
                            className="btn btn-primary text-uppercase ps-4 pe-4"
                            onClick={() => handleNavigation()}
                          >
                            Proceed to Book{' '}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="col-lg-4">

            <div className="col-12 text-end mt-2 show_mobile">
            <button 
            onClick={showFilterBlock} 
            type="button" 
            className="btn btn-sm"
            >
           
            {showItinerary ? (<span>Hide Itinerary <FiChevronUp/></span>) : (<span>Review Itinerary <FiChevronDown/></span>)} 
            
            </button>
            </div>

            <div className={showItinerary ? '' : 'hide_mobile'}>
                    <div className="innerContainerRight">
                      <div className="row">
                        <div className="col-12 mt-md-2">
                          <div className="itenaryDetails">
                            <div className="row">
                              <div className="col-12">
                                <div className="form_heading">
                                  <span className="title">
                                    Itinerary Details
                                  </span>
                                </div>
                              </div>
                              <div className="col-12">
                                {' '}
                                <FlightItinerary />{' '}
                              </div>
                            </div>

                            <div className="row">
                              <div className="col-6">
                                <FlightDetailsPopup
                                  itinerary={selectedItinerary}
                                />
                              </div>
                              <div className="col-6">
                                <BaggagePolicyPopup
                                  itinerary={selectedItinerary}
                                />
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="col-12 mt-2 mb-2">
                          <div className="row">
                            <div className="col-12">
                              <div className="form_heading">
                                <span className="title">Fare Summary</span>
                              </div>
                            </div>
                            <div className="col-12">
                              <FareSummary
                                passengerDetails={passengerDetails}
                              />
                            </div>
                            <div className="col-12 mt-4">
                              <PromoCode />
                            </div>
                          </div>
                        </div>

                        <div className="col-12 mb-2">
                          <div className="row">
                            <div className="col-12">
                              <div className="form_heading">
                                <span className="title">Markup</span>
                              </div>
                            </div>
                            <div className="col-12">
                              <AddMarkup
                                totalFare={selectedItinerary?.totalFare?.toFixed(
                                  2
                                )}
                                onChange={handleMarkupChange}
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                   </div>                 

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </MainLayout>
      {loader && <Loader />}
    </>
  );
}
