import React from 'react';
import { useSelector } from 'react-redux';
import { RootState } from '@mfa-travel-app/store';
import { TbArrowsLeftRight } from "react-icons/tb";


const SearchMapBox = ({ onModifySearchResult }: any) => {
  const { searchPayload } = useSelector((state: RootState) => state.flight);

  const handleModifyParams = () => {
    onModifySearchResult(false);
  };
  const formatDate = (dateString: any) => {
    const date = new Date(dateString);
    const monthNames = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    const dayNames = [
      'Sunday',
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
    ];

    const day = date.getDate();
    const month = monthNames[date.getMonth()];
    const year = date.getFullYear().toString().slice(-2);
    const weekday = dayNames[date.getDay()];

    return `${day} ${month}'${year} ${weekday}`;
  };

  const travelClassOptions = [
    { name: 'Any', value: 0 },
    { name: 'Economy', value: 1 },
    { name: 'FirstClass', value: 2 },
    { name: 'PremiumEconomy', value: 3 },
    { name: 'Business', value: 4 },
  ];

  const getTravelClassName = (value: any) => {
    const option = travelClassOptions.find((option) => option.value === value);
    return option ? option.name : 'Economy';
  };

  return (
    <>
      <div className="col-12 mb-md-3">


        <div className="modify_search_params hide_mobile">
          <div className="row align-items-center">
            <div className="col-md-9 align-items-center">
              <div className="d-flex align-items-center">


                <div className="border-end-0 ps-0">

                  <h6>
                    {searchPayload?.segments &&
                      searchPayload?.segments[0]?.origin}


                  </h6>
                </div>

                <div className="border-end-0 p-0"> <TbArrowsLeftRight />
                </div>

                <div>

                  <h6>           {searchPayload?.segments &&
                    searchPayload?.segments[0]?.destination}</h6>

                </div>




                {/* <div className="p-0"> <h6 className="me-4"><i className="fa-solid fa-hotel"></i>{searchPayload?.segments && searchPayload?.segments[0]?.origin}</h6> </div>
                                <div className="p-0"> <h6 className="me-4"><i className="fa-solid fa-hotel"></i>{searchPayload?.segments && searchPayload?.segments[0]?.destination}</h6> </div> */}
                <div>
                  <span className="con_title">Departure</span>
                  <span className="con_details">
                    {' '}
                    {Array.isArray(searchPayload?.segments) && searchPayload?.segments.length > 0
                      ? formatDate(searchPayload.segments[0].preferredArrivalTime)
                      : 'Preferred arrival time not available'}
                  </span>
                </div>
                {searchPayload.type == 2 && (
                  <div>
                    <span className="con_title">Return</span>
                    <span className="con_details">
                      {formatDate(
                        searchPayload?.segments[1]?.preferredDepartureTime
                      )}
                    </span>
                  </div>
                )}
                <div>
                  <span className="con_title">Travellers</span>
                  <span className="con_details">
                    <strong>
                      {searchPayload?.adultCount +
                        searchPayload?.childCount +
                        searchPayload?.infantCount}
                    </strong>
                  </span>
                </div>
                <div>
                  <span className="con_title">Travel Class</span>
                  <span className="con_details">
                    <strong>
                      {Array.isArray(searchPayload?.segments) && searchPayload?.segments.length > 0
                        ? getTravelClassName(searchPayload.segments[0]?.flightCabinClass)
                        : 'Class not available'}
                    </strong>

                  </span>
                </div>
              </div>
            </div>
            <div className="col-md-3 text-end">
              <button
                onClick={() => handleModifyParams()}
                id="show_hotel_search_jq"
                type="button"
                className="btn btn-outline-primary"
              >
                <span>MODIFY</span>{' '}
              </button>
            </div>
          </div>
        </div>




        <div id="editFlightDescription" className="editFlights col-12 mt-3 show_mobile">

          <div className="row align-items-center">
            <div className="col-9">

              <div>

                <span> <strong> {searchPayload?.segments &&
                  searchPayload?.segments[0]?.origin}  </strong></span>

                <span className='ms-1 me-1'> {' '} <TbArrowsLeftRight />   {' '}</span>


                <span>     <strong>   {searchPayload?.segments &&
                  searchPayload?.segments[0]?.destination}  </strong></span>


              </div>
              <div className="details"> <small>
                {' '}
                {Array.isArray(searchPayload?.segments) && searchPayload.segments.length > 0
                  ? formatDate(searchPayload.segments[0]?.preferredArrivalTime || 'Default Date')
                  : 'Preferred arrival time not available'}

                {' '}
                -
                {' '}
                {Array.isArray(searchPayload?.segments) && searchPayload.segments.length > 1
                  ? formatDate(searchPayload.segments[1]?.preferredDepartureTime || 'Default Date')
                  : 'Preferred departure time not available'}

                {' '}
              </small>
                <span className="text-muted">|
                </span> <small> {Array.isArray(searchPayload?.segments) && searchPayload.segments.length > 0
  ? getTravelClassName(searchPayload.segments[0]?.flightCabinClass )
  : 'Class not available'}
 {' '}</small>
                <span className="text-muted">|</span>
                <small> {searchPayload?.adultCount +
                  searchPayload?.childCount +
                  searchPayload?.infantCount}   {' '}</small>
              </div>

            </div>


            <div className="col-3 text-end">
              <button
                onClick={() => handleModifyParams()}

                id="show_flight_search_jq_mb"
                className="btn btn-primary rounded"
                type="button"> <small>Modify</small> </button>
            </div>

          </div>


        </div>






      </div>







    </>
  );
};
export default SearchMapBox;
