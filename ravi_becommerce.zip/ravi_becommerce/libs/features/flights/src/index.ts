export * from './lib/flights';
export { default as Home } from './lib/home';
export * from './lib/service/homeApi';
export { default as SearchFlight } from './lib/searchflight';
export { default as FlightPax } from './lib/pages/flightPaxDetails';
export { default as FlightPayment } from './lib/pages/FlightPayment';
export { default as FlightETicket } from './lib/pages/FlightETicket';
export { default as SelectSeats } from './lib/pages/selectSeats';
export { default as ErrorPage } from '../src/lib/components/errorPage';
export { default as FlightQueue } from './lib/pages/flightQueue';
export { default as FlightReport } from './lib/pages/flightReport';
export { default as FlightQueueOpen } from './lib/pages/flightQueueOpen';
export { default as ViewFlightInvoice } from './lib/pages/view-flight-invoice';

export { default as ErrorPage2 } from './lib/pages/ErrorPage';
