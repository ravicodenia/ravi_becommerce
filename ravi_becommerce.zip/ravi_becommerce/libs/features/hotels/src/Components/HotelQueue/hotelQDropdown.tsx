import  { useState } from "react";
import Dropdown from 'react-bootstrap/Dropdown';
import { Link   } from "react-router-dom";
import { FaRegFolderOpen } from "react-icons/fa";
import { ImCancelCircle } from "react-icons/im";
import { BsTicketPerforated } from "react-icons/bs";




import { FaEye } from "react-icons/fa6";
import { LuFileInput } from "react-icons/lu";
import { Modal } from 'react-bootstrap';
import { ControlledSelect } from '@mfa-travel-app/ui';

export default function HotelQDropdown() {

    const [cancelPolicy, setCancelPolicy] = useState(false); 
    const [changeRequest, setChangeRequest] = useState(false);
 
    const selectOptions = [
     { id: 1, text: 'Modification' },
     { id: 2, text: 'Refund' },
 ];



    return (

<>
<Dropdown>
      <Dropdown.Toggle id="dropdown-basic" className="more_icon rounded-circle">
      <i className="fa-solid fa-ellipsis-vertical"></i>       
      </Dropdown.Toggle>

      <Dropdown.Menu>

      <Link  className="dropdown-item" to="/hotel-queue-open"> <FaRegFolderOpen/> Open</Link>
      <Link className="dropdown-item" to="/view-hotel-voucher"> <BsTicketPerforated />  View Voucher</Link>
      <Link className="dropdown-item" to="/view-hotel-invoice"> <FaEye/> View Invoice</Link>

      <Link  className="dropdown-item" to=""  onClick={() => setCancelPolicy(true)}> <ImCancelCircle/> Cancellation Policy</Link>   
      <Link className="dropdown-item" to=""  onClick={() => setChangeRequest(true)}> <LuFileInput/> Chanage Request</Link>

      </Dropdown.Menu>
    </Dropdown>
      
           
       
<Modal
        size="lg"
        centered
        show={cancelPolicy}
        onHide={() => setCancelPolicy(false)}
      >
    
   <div className="p-3">
   <h5>Cancellation Policy</h5>
   
<div style={{maxHeight:'400px', overflowY:'scroll', overflowX:'hidden', paddingBottom:'20px'}} > 

    <div className="row">


<div className="col-12">

         


<table className="table table-bordered border-primary mb-0"><thead className="align-middle text-center bg-light"><tr><th>Cancelled on or After</th><th>Cancelled on or Before</th><th>Cancelled Charges</th></tr></thead><tbody><tr><td>4-Aug-2024</td><td>8-Aug-2024</td><td>100%</td></tr></tbody></table>

<p>Early check out will attract full cancellation charge unless otherwise specified.</p>
<h5>Inclusions</h5>
<h6>Hotel Norms</h6>
<ul className="mb-0"><li>CheckIn Time-Begin: 1:00 PM </li><li> CheckIn Time-End: 1:30 PM</li><li>CheckOut Time: 12:00 PM</li><li>CheckIn Instructions: <ul>  <li>Extra-person charges may apply and vary depending on property policy</li><li>Government-issued photo identification and a credit card, debit card, or cash deposit may be required at check-in for incidental charges</li><li>Special requests are subject to availability upon check-in and may incur additional charges; special requests cannot be guaranteed</li><li>This property accepts credit cards and cash</li><li>Safety features at this property include a fire extinguisher and a security system</li><li>Please note that cultural norms and guest policies may differ by country and by property; the policies listed are provided by the property</li>  </ul> </li><li> Special Instructions : This property doesn't offer after-hours check-in. Front desk staff will greet guests on arrival. For more details, please contact the property using the information on the booking confirmation.  Couples who are from different nationalities are required to present proof of marriage at check-in when sharing a room.</li><li>Minimum CheckIn Age : 18</li><li>Mandatory Fees: <p>You'll be asked to pay the following charges at the property:</p> <ul><li>A tax is imposed by the city: AED 7.00 per accommodation, per night</li></ul> <p>We have included all charges provided to us by the property. </p></li><li>Cards Accepted: Visa,Debit cards not accepted,Cash,Mastercard</li><li><ul>  <li>Local laws may restrict unmarried guests from sharing rooms. Guests are responsible for providing proof of marriage, if requested by the property. </li> <li>Only registered guests are allowed in the guestrooms. </li> <li>No pets and no service animals are allowed at this property. </li> </ul>,Service animals not allowed,Pets not allowed,Professional property host/manager,Property confirms they are implementing guest safety measures,No cribs (infant beds) available,Temperature checks are available to guests,No rollaway/extra beds available,Social distancing measures are in place,Staff temperature checks are conducted regularly,Property confirms they are implementing enhanced cleaning measures,Guests are provided with free hand sanitizer,Property is cleaned with disinfectant,Staff wears personal protective equipment,Commonly-touched surfaces are cleaned with disinfectant</li><li>Please note that this a special rate which should be sold only with an airline ticket as part of a package.</li></ul>

</div>





{/* <div className="col-12 mt-3 mb-2">
  <button type="button" className="btn btn-danger text-light me-2">Yes</button>
  <button  onClick={() => setCancelPolicy(false)} type="button" className="btn btn-secondary rounded">No</button>
</div> */}

  </div>

  </div>
  </div>     
</Modal>



{/* //chanage request popup */}

<Modal
        size="sm"
        centered
        show={changeRequest}
        onHide={() => setChangeRequest(false)}
      >
    
        
<div className="p-2"> 

    <div className="row">

    <div className="col-12 mt-3">
<h5>Change Request </h5>

      </div>

<div className="col-12 mt-3">

  <label htmlFor="request_change">Request Change</label>
  <ControlledSelect
                   id={'request_change'}
                   value={''}
                   options={selectOptions}
                   required={true}
                   onChange={''}
               />
</div>


<div className="col-12 mt-3">
<label htmlFor="enter_remark">Remark</label>
<textarea className="form-control" id="enter_remark" rows={3}></textarea>
</div>

<div className="col-12 mt-3 mb-2">

  <button  onClick={() => setChangeRequest(false)} type="button" className="btn btn-primary rounded">Submit Request</button>
</div>
  </div>

  </div>
</Modal>

        

</>


  )
}
