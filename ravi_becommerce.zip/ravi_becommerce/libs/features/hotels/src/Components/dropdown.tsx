import { RootState, useStore } from "@mfa-travel-app/store";
import { getCountries} from "../../../flights/src/lib/service/homeApi/index"
import { useEffect, useState } from "react";
import { useSelector } from 'react-redux';

const Dropdown = ({ selectedValue, setSelectedValue ,onNationality}: any) => {
  const [nationalities, setNationalities] = useState([])
  const { saveNationalitiesDetails } = useStore()
  const { searchPayload } = useSelector((state: RootState) => state.hotel);

  useEffect(() => {
    getNationalitiesList()
  },[])

  const getNationalitiesList = async () => {
    const response: any = await getCountries();
    if (response?.status == 200) {
      setNationalities(response?.data)
      saveNationalitiesDetails(response?.data)
    } else {
      console.error(response)
    }
  }

  const handleChange = (event: any) => {
    onNationality(event.target.value);
    setSelectedValue(event.target.value);

  };

  return (
    <div>
       <label htmlFor="nationality-select" className="form-label">
        Nationality
      </label>
      <select
        className="form-select"
        aria-label="Default select example"
        onChange={handleChange}
        value={selectedValue}
        style={{ background: 'inherit', border: 'none' }}
        // defaultValue= searchPayload,
      >
        <option value="" >
          Select Nationality
        </option>
        {nationalities && nationalities?.map((nationality:any) => (
          <option value={nationality?.value}>{nationality?.text}</option>
        ))}
      </select>
    </div>
  );
};

export default Dropdown;
