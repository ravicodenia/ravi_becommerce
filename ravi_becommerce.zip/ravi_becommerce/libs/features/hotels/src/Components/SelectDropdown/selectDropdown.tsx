import React from 'react';
import Select from 'react-select';

const options = [
  { value: 'select', label: 'Select' },
  { value: 'india', label: 'India' },
  { value: 'uae', label: 'UAE' },
  { value: 'us', label: 'United States' }
];

function App() {
  const [selectedOption, setSelectedOption] = React.useState(null);

  const handleChange = (selectedOption:any) => {
    setSelectedOption(selectedOption);
  };

  return (
    <div className="App">
      <form>
        <label htmlFor="country">Country of Residence</label>
        <Select
          id="country"
          value={selectedOption}
          onChange={handleChange}
          options={options}
          isSearchable
        />
      </form>
    </div>
  );
}

export default App;
