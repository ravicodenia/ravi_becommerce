import { useState } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import './hotalDatePickers.scss';
// import '../../../../../../libs/features/flights/src/lib/custom-datepicker.scss';

const TwoMonthSingleDatePicker = ({ selectedDate, setSelectedDate, isOpen, setIsOpen, minDate }:any) => {
  const [startDate, setStartDate] = useState(selectedDate);

  const handleDateChange = (date:any) => {
    setStartDate(date);
    setSelectedDate(date);
    setIsOpen(false); // Close the date picker after selecting a date
  };

  const handleClickOutside = () => {
    setIsOpen(false); // Close the date picker when clicking outside
  };

  const handleDoneClick = () => {
    setIsOpen(false); 
  };

  return (
    <div>
      {isOpen && (
        <div className="datepicker-container" style={{backgroundColor:'white'}}>
          <DatePicker
            selected={startDate}
            onChange={handleDateChange}
            minDate={minDate}
            monthsShown={2}
            inline
          />
          <button style={{position: 'absolute',  right: '-235px', bottom: '-304px',zIndex:'100'}} onClick={handleDoneClick}>Done</button>
          <div className="outside-click-handler" onClick={handleClickOutside}></div>
        </div>
      )}
    </div>
  );
};

export default TwoMonthSingleDatePicker;