import { FaCalendarAlt } from 'react-icons/fa';
import { useState, useRef, useEffect } from 'react';
import TwoMonthSingleDatePicker from '../HotalDatePickers/hotalDatePickers';
import styles from '../../../../flights/src/lib/oneway.module.scss';

const SelectedDate = ({ onSelectHotelDate, text, datePayload, initialDate, showPopup=false, setShowPopup=null }: any) => {
  const formatDate = (dateString: string) => {
    // Create a Date object from the input date string
    const date = new Date(dateString);
    // Define arrays for month and weekday names
    const monthNames = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    const dayNames = [
      'Sunday',
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
    ];

    // Extract the day, month, year, and weekday
    const day = date.getDate();
    const month = monthNames[date.getMonth()];
    const year = date.getFullYear().toString().slice(-2); // Get last two digits of the year
    const weekday = dayNames[date.getDay()];

    // Format the date string
    const formattedDate = `${day} ${month}'${year} ${weekday}`;
    return formattedDate;
  }

  const [selectedDate, setSelectedDate] = useState<any>(datePayload ? formatDate(datePayload) : initialDate)
  const [selectedDateText, setSelectedDateText] = useState<any>(datePayload ? formatDate(datePayload) : formatDate(initialDate));
  const [showCalendar, setShowCalendar] = useState(false);
  const datePickerRef = useRef<any>(null);

  useEffect(() => {
    if (showPopup) {
      setShowCalendar(!showCalendar);
      if (setShowPopup) setShowPopup(false);
    }
  },[showPopup]);

  const updateDate = (e: any) => {
    const newDate = new Date(e);
    setSelectedDate(e);
    const inputDate = formatDate(typeof (e) === 'string' ? e : e.toString());
    if (inputDate) {
      onSelectHotelDate(newDate);
    }
    setSelectedDateText(inputDate);
  }
  const handleClickOutside = (event: any) => {
    if (datePickerRef.current && !datePickerRef?.current?.contains(event.target)) {
      setShowCalendar(false);
    }
  };

  useEffect(() => {
    document.addEventListener('click', handleClickOutside, true);
    return () => {
      document.removeEventListener('click', handleClickOutside, true);
    };
  }, []);
  useEffect(() => {
    // setSelectedDate(datePayload);
    // onSelectHotelDate(datePayload);
  }, [datePayload]);

  return (
    <div className='srchCon notranslate' style={{ position: 'relative' }}>
     
     
     <div className="srchRow"  style={{cursor:'pointer'}} onClick={() => setShowCalendar(!showCalendar)}>
  <div className="srchCol"> 
    <div className="mb-1"><span className="srchsml">{text} <i className="fa-solid fa-angle-down"></i></span></div>

    <div>
    <span className="srchLabel"><FaCalendarAlt /> {selectedDateText} </span>   
    </div>
    {/* <div><span className="srchsml textTrim">Friday</span> </div> */}
  </div>
              </div>


              <div ref={datePickerRef} >
            {showCalendar &&
              <TwoMonthSingleDatePicker
                onChange={(date: any) => setSelectedDate(date)}
                minDate={initialDate}
                selectedDate={selectedDate}
                setSelectedDate={(e: any) => updateDate(e)}
                isOpen={showCalendar}
                setIsOpen={setShowCalendar}
              />
            }
          </div>

    </div>
  );
};
export default SelectedDate;
