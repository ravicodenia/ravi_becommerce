import { useState, useEffect } from 'react';
import { RootState } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';

export default function SearchByRating({ rating, handleFilterChange }: any) {
  const [cheapestByRating, setCheapestByRating] = useState<any[]>([]);
  const [currency, setCurrency] = useState<any>('')
  const { searchResults } = useSelector((state: RootState) => state.hotel);

  useEffect(() => {
    getCheapestByRating();
  }, [searchResults]);

  useEffect(() => {
    if (searchResults?.length > 0) {
      const { currency } = searchResults[0]
      setCurrency(currency)
    }
  }, [])

  const getCheapestByRating = () => {
    const cheapest = [];
    for (let i = 0; i < 5; i++) {
      const filteredByRating = searchResults?.filter(
        (hotel: any) => hotel.hotelRating === i + 1
      );
      if (filteredByRating.length > 0) {
        const cheapestByRating = Math.min(...filteredByRating.map((hotel: any) => hotel.totalPrice));
        cheapest[i] = cheapestByRating;
      } else {
        cheapest[i] = '';
      }
    }
    setCheapestByRating(cheapest);
  };

  return (
    <>
      <div className="chk_filter_tbl">
        <table className="table table-borderless">
          <tbody>
            <tr>
              <td>
                {' '}
                <div className="form-check">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    value=""
                    id="AI"
                    name="5"
                    checked={rating[5]}
                    onChange={(e) => handleFilterChange(e)}
                  />
                  <label className="form-check-label" htmlFor="AI">
                    5 Star
                  </label>
                </div>
              </td>
              <td className="text-end">{cheapestByRating[4] ? `${currency} ${cheapestByRating[4]}` : ''}</td>
            </tr>

            <tr>
              <td>
                {' '}
                <div className="form-check">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    value=""
                    id="EI"
                    name="4"
                    checked={rating[4]}
                    onChange={(e) => handleFilterChange(e)}
                  />
                  <label className="form-check-label" htmlFor="EI">
                    4 Star
                  </label>
                </div>
              </td>
              <td className="text-end">
                {' '}
                <span className="fltfare">{cheapestByRating[3] ? `${currency} ${cheapestByRating[3]}` : ''}</span>
              </td>
            </tr>

            <tr>
              <td>
                {' '}
                <div className="form-check">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    value=""
                    id="indigo"
                    name="3"
                    checked={rating[3]}
                    onChange={(e) => handleFilterChange(e)}
                  />
                  <label className="form-check-label" htmlFor="indigo">
                    3 Star
                  </label>
                </div>
              </td>
              <td className="text-end">{cheapestByRating[2] ? `${currency} ${cheapestByRating[2]}` : ''}</td>
            </tr>

            <tr>
              <td>
                {' '}
                <div className="form-check">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    value=""
                    id="omanair"
                    name="2"
                    checked={rating[2]}
                    onChange={(e) => handleFilterChange(e)}
                  />
                  <label className="form-check-label" htmlFor="omanair">
                    2 Star
                  </label>
                </div>
              </td>
              <td className="text-end">{cheapestByRating[1] ? `${currency} ${cheapestByRating[1]}` : ''}</td>
            </tr>

            <tr>
              <td>
                {' '}
                <div className="form-check">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    value=""
                    id="muliairlines"
                    name="1"
                    checked={rating[1]}
                    onChange={(e) => handleFilterChange(e)}
                  />
                  <label className="form-check-label" htmlFor="muliairlines">
                    1 Star
                  </label>
                </div>
              </td>
              <td className="text-end">{cheapestByRating[0] ? `${currency} ${cheapestByRating[0]}` : ''}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </>
  );
}
