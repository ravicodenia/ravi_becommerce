export default function RdTotalPrice({ priceInfo }: any) {

  return (
    <>
      <div className="roomdetailsCon">
        <div className="room_details_chk_in_out">
          <div className="row mb-1 mt-2 align-items-center">
            <div className="col-6 mb-2">
              <strong> Total Price</strong>
            </div>
            <div className="col-6 text-end mb-2 text-danger">
              <strong>{priceInfo?.currency} {priceInfo?.totalPrice?.toFixed(2)}</strong>
            </div>
            <div className="col-6 mb-2">
              <strong>Service Charge (+)</strong>
            </div>
            <div className="col-6 text-end mb-2 text-danger">
              <strong>{priceInfo?.currency} 0.00</strong>
            </div>
            <div className="col-6 mb-2">
              <strong>Discount</strong>
            </div>
            <div className="col-6 text-end mb-2 text-danger">
              <strong>{priceInfo?.currency} {priceInfo?.discountprice?.toFixed(2)}</strong>
            </div>

            <div className="col-12">
              <div className="d-flex">
                <div className="col-6 mb-2 mt-2 border-top  border-bottom">
                  <div className="total_cal">Grand Total</div>
                </div>

                <div className="col-6 text-end mb-2 mt-2 border-top  border-bottom">
                  <div className="total_cal">{priceInfo?.currency} {(priceInfo?.totalPrice - priceInfo?.discountprice)?.toFixed(2)}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
