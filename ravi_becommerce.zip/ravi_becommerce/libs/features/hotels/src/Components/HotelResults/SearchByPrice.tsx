import RangeSlider from './RangeSlider';

export default function SearchByPrice({range,setRange}:any) {

  return (
    <>
      <RangeSlider range={range} setRange={setRange} />
    </>
  );
}
