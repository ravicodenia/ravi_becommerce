import { RootState } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';

const months = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
];

export default function CancellationCharges() {
  const { hotelCancellationPolicies } = useSelector(
    (state: RootState) => state.hotel
  );

  const getDate = (dateString: string) => {
    const dateObj = new Date(dateString);
    return dateObj;
  };
  return (
    <>
      {hotelCancellationPolicies?.cancelPolicies?.map((room: any) => {
        return (
          <>
            <div className="table-responsive">
              <table className="table table-bordered border-primary mb-0">
                <thead className="align-middle text-center bg-light">
                  <tr>
                    <th>Cancelled on or After</th>
                    <th>Cancelled on or Before</th>
                    <th>Cancelled Charges</th>
                  </tr>
                </thead>
                <tbody>
                  {room?.nodePolicy?.map((policy: any) => {
                    return (
                      <tr>
                        <td>
                          {getDate(policy?.fromDate).getDate()}
                          {'-'}
                          {months[getDate(policy?.fromDate).getMonth()]}
                          {'-'}
                          {getDate(policy?.fromDate).getFullYear()}
                        </td>
                        <td>
                          {getDate(policy?.toDate).getDate()}
                          {'-'}
                          {months[getDate(policy?.toDate).getMonth()]}
                          {'-'}
                          {getDate(policy?.toDate).getFullYear()}
                        </td>
                        <td>
                          {policy?.chargeType === 'Percentage'
                            ? policy?.cancellationCharge + '%'
                            : policy?.currency +
                              ' ' +
                              policy?.cancellationCharge}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <div className='my-2'>{room?.defaultPolicy}</div>
            <div>{room?.autoCancellationText}</div>
          </>
        );
      })}
    </>
  );
}
