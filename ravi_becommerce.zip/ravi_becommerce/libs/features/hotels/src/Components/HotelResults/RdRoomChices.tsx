export default function RdRoomChices({mealFilters, handleChangeFilters}:any) {

  return (
    <>
      <div className="row">
        <div className="col-12">
          <div className="border p-2 font_size_90">
            <div className="d-flex">
              <div>
                <div className="form-check-inline">
                  <span className="ms-2">
                    <strong>Room Choices</strong>
                  </span>
                </div>
                <div className="form-check-inline">
                  <span className="text-danger"> Meal Type</span>
                </div>

                {mealFilters?.map((filter: any) => {
                  return (
                    <div className="form-check form-check-inline">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        id="inlineCheckbox1"
                        checked={filter.checked}
                        onChange={() => handleChangeFilters(filter?.filterName)}
                      />
                      <label
                        className="form-check-label"
                        htmlFor="inlineCheckbox1"
                      >
                        {filter.filterName}
                      </label>
                    </div>
                  );
                })}

                {/* <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id="inlineCheckbox1"
                  />
                  <label className="form-check-label" htmlFor="inlineCheckbox1">
                    Room Only
                  </label>
                </div>

                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id="inlineCheckbox2"
                  />
                  <label className="form-check-label" htmlFor="inlineCheckbox2">
                    Bed & Breakfast
                  </label>
                </div>

                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id="inlineCheckbox3"
                  />
                  <label className="form-check-label" htmlFor="inlineCheckbox3">
                    Full Board
                  </label>
                </div> */}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
