import { searchOnMap } from "../../../../../assets/src";

export default function SearchOnMap() {

  return (
    <>
      <div className="hide_mobile">
        <a href="#">
          <img className="img-fluid" src={searchOnMap} alt="" />
        </a>
      </div>
    </>


  )
}
