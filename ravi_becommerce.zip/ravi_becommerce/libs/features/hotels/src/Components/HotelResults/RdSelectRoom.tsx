import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import classNames from 'classnames';
import styles from '../../lib/hotels.module.scss';
import { Modal } from 'react-bootstrap';
import { useHotelStore, RootState } from '@mfa-travel-app/store';
import { getHotelCancellationPolicy } from '../../lib/service/hotelApi';
import CancellationCharges from './CancellationCharges';
import HotelNorms from './HotelNorms';
import { Loader } from '@mfa-travel-app/ui';
import 'react-tooltip/dist/react-tooltip.css';
import { Tooltip } from 'react-tooltip';

export default function RdSelectRoom({ mealFilters }: any) {
  const { saveRoomsDetails, saveHotelCancellationPoliciesDetails } =
    useHotelStore();
  const { selectedHotelRoom, searchPayload, hotelCancellationPolicies, rooms } =
    useSelector((state: RootState) => state.hotel);
  const [selectedRoomIndex, setselectedRoomIndex] = useState(0);
  const [roomKey, setRoomKey] = useState(
    selectedHotelRoom?.roomDetails &&
      selectedHotelRoom?.roomDetails[0]?.roomBookingKey
  );
  const [showCancellationPolicies, setShowCancellationPolicies] =
    useState(false);
  const [loader, setLoader] = useState(false);

  const filterByMeal = (rooms: any) => {
    let filteredRooms: any = [];
    const allFiltersFalse = mealFilters?.every((mealFilter:any) => mealFilter?.checked === false);
    // console.log(allFiltersFalse)
    if (allFiltersFalse) {
      filteredRooms = rooms;
    } else {
      rooms?.forEach((room: any) => {
        mealFilters?.map((mealFilter: any) => {
          if (
            mealFilter?.filterName === room?.mealType &&
            mealFilter?.checked
          ) {
            filteredRooms.push(room);
          }
        });
      });
    }
    return filteredRooms;
  };

  const handleSelectRoom = (index: number, selectedRoomKey: string) => {
    setselectedRoomIndex(index);
    setRoomKey(selectedRoomKey);
    const filteredRooms = selectedHotelRoom?.roomDetails?.filter(
      (room: any) => room?.roomBookingKey === selectedRoomKey
    );
    const selectedRooms: any = filteredRooms?.map((room: any, index: any) => {
      const roomPax = searchPayload?.roomPaxInfo[index];
      return { ...room, roomPax };
    });
    saveRoomsDetails(selectedRooms);
  };

  const openCancellationPolicies = async () => {
    const roomReferences = [];
    for (let i = 0; i < searchPayload?.noOfRooms; i++) {
      roomReferences.push(roomKey);
    }
    setLoader(true);
    const response: any = await getHotelCancellationPolicy(
      selectedHotelRoom?.sessionId,
      selectedHotelRoom?.hotelId,
      selectedHotelRoom?.hotelCode,
      selectedHotelRoom?.hotelReferenceCode,
      searchPayload?.noOfRooms,
      roomReferences
    );
    setLoader(false);
    saveHotelCancellationPoliciesDetails(response?.data?.result);
    setShowCancellationPolicies(true);
  };

  return (
    <>
      <div>
        <div className="row">
          <div className="col-12 mb-2">
            {searchPayload?.roomPaxInfo?.map((roomNo: any, index: any) => (
              <div className="table-responsive" key={index}>
                <table className="table  table-bordered">
                  <thead className="bg-light">
                    <tr className="align-middle">
                      <th colSpan={2} scope="col">
                        <div className="row">
                          <div className="col-md-6">
                            <span className="room_no">Room - {index + 1}</span>
                          </div>
                          <div className="col-md-6">
                            <span>Room Type</span>
                          </div>
                        </div>
                      </th>
                      <th className="text-center" colSpan={2} scope="col">
                        Options
                      </th>
                      <th className="text-center" scope="col">
                        Room Price
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {filterByMeal(
                      selectedHotelRoom?.roomDetails?.filter(
                        (roomType: any) => roomType?.index === index + 1
                      )
                    ).map((room: any, j: number) => {
                      const tooltipContent = `<div>Total Price - ${room?.currency} ${room?.roomTotalPrice?.toFixed(2)}</div><div>Total Tax - ${room?.currency} ${room?.roomTotalTax?.toFixed(2)}</div>`;
                      return (
                        <tr className="align-middle" key={j}>
                          <td colSpan={2}>
                            <div className="row">
                              <div className="col-12">
                                <span className="text-secondary room_type">
                                  {room?.name}
                                </span>
                              </div>

                              <div className="col-6">
                                <span className="room_provider">
                                  Provider: {room?.supplierName}
                                </span>
                              </div>
                              <div className="col-6 text-end">
                                {' '}
                                <strong>
                                  {room?.isRefundable ? 'R' : 'NR'}
                                </strong>
                              </div>
                            </div>
                          </td>

                          <td>
                            <div>
                              <span className="text-secondary">
                                Package Rate
                              </span>
                            </div>
                            <div>
                              {' '}
                              <span className="text-success">
                                <i className="fa-solid fa-circle-check"></i>
                                {room?.mealType}
                              </span>{' '}
                            </div>
                          </td>

                          <td>
                            {' '}
                            <button
                              className="btn text-primary"
                              onClick={() => openCancellationPolicies()}
                            >
                              Cancellation Policy
                            </button>{' '}
                          </td>

                          <td>
                            <div className="room_priceR text-md-center">
                              <div>
                                <span className="currency text-secondary">
                                  {room?.currency}
                                </span>{' '}
                                <span className="price">
                                  {(room?.roomTotalPrice + room?.roomTotalTax)?.toFixed(2)}
                                </span>
                              </div>
                              <div className="mt-1">
                                <button
                                  type="button"
                                  className={classNames(
                                    'btn btn-sm rounded',
                                    j === selectedRoomIndex
                                      ? styles['selected_room']
                                      : styles['btn_select_room']
                                  )}
                                  onClick={() =>
                                    handleSelectRoom(j, room?.roomBookingKey)
                                  }
                                >
                                  {j === selectedRoomIndex
                                    ? 'SELECTED'
                                    : 'SELECT'}
                                </button>
                                <a
                                  data-tooltip-id="price-tooltip"
                                  data-tooltip-html={tooltipContent}
                                >
                                  <i className="fa-solid fa-circle-info"></i>
                                </a>
                                <Tooltip id="price-tooltip" />
                              </div>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ))}
          </div>
        </div>
        <Modal
          size="xl"
          centered
          show={showCancellationPolicies}
          onHide={() => setShowCancellationPolicies(false)}
        >
          <Modal.Header closeButton>
            <Modal.Title>Cancellation Policies & Charges</Modal.Title>
          </Modal.Header>
          <Modal.Body style={{ overflowY: 'scroll', height: '80vh' }}>
            <strong>Cancellation Charges</strong>
            <CancellationCharges />
            <strong>Hotel Norms</strong>
            <HotelNorms />
          </Modal.Body>
        </Modal>
      </div>
      {loader && <Loader />}
    </>
  );
}
