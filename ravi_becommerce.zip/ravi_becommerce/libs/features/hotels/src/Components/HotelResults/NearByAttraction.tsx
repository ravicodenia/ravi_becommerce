import { useSelector } from 'react-redux';
import { RootState } from '@mfa-travel-app/store';

export default function NearByAttraction() {
  const { selectedHotel } = useSelector((state: RootState) => state.hotel);
  const markup = { __html: selectedHotel?.hotelInfo?.attractions['1) '] };
  return (
    <>
     <div className='roomdetailsCon'> 
      <div className="near_by_attraction">
        <h5 className="mb-3">Nearby Attractions</h5>
        <div dangerouslySetInnerHTML={markup}></div>
      </div>
      </div>
    </>
  );
}
