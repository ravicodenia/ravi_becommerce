import { useSelector } from 'react-redux';
import { RootState } from '@mfa-travel-app/store';

export default function RdBedChkInOut() {
  const { searchPayload } = useSelector((state: RootState) => state.hotel);
  const monthNames = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  const days = [
    'Sunday',
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
  ];

  const calculateNights = () => {
    const start = new Date(searchPayload?.checkIn).getTime()
    const end = new Date(searchPayload?.checkOut).getTime()
    const diff = end - start
    const hours = (diff / (1000 * 60 * 60));
    return hours / 24;
  }
  calculateNights()

  return (
    <>
      <div className="roomdetailsCon">
        <div className="room_details_chk_in_out">
          <div className="row d-flex align-items-center">
            <div className="col-4">
              <div>
                <i className="fa-solid fa-calendar-days"></i> CHECK IN{' '}
                <i className="fa-solid fa-angle-down"></i>
              </div>
              <div>
                <span className="chkTime">
                  {new Date(searchPayload?.checkIn).getDate()}
                </span>{' '}
                <span>
                  {monthNames[new Date(searchPayload?.checkIn).getMonth()]}’
                  {new Date(searchPayload?.checkIn)
                    .getFullYear()
                    .toString()
                    .slice(2)}
                </span>{' '}
              </div>
              <div>
                <span className="text-secondary">
                  <small>
                    {days[new Date(searchPayload?.checkIn).getDay()]}
                  </small>
                </span>
              </div>
            </div>

            <div className="col-4 text-center">
              <b>{calculateNights()} {calculateNights() === 1 ? 'Night' : 'Nights'}</b>
            </div>

            <div className="col-4">
              <div>
                <i className="fa-solid fa-calendar-days"></i> CHECK OUT{' '}
                <i className="fa-solid fa-angle-down"></i>
              </div>
              <div>
                <span className="chkTime">
                  {new Date(searchPayload?.checkOut).getDate()}
                </span>{' '}
                <span>
                  {monthNames[new Date(searchPayload?.checkOut).getMonth()]}’
                  {new Date(searchPayload?.checkOut)
                    .getFullYear()
                    .toString()
                    .slice(2)}
                </span>{' '}
              </div>
              <div>
                <span className="text-secondary">
                  <small>{days[new Date(searchPayload?.checkOut).getDay()]}</small>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
