import { useState } from 'react';
import Slider from 'rc-slider';
import 'rc-slider/assets/index.css';
import styles from "../../../../flights/src/Components/RangeSlider/rangeSlider.module.scss";

const RangeSlider = ({ range, setRange }: any) => {
  const [lowerActive, setLowerActive] = useState(false);
  const [upperActive, setUpperActive] = useState(false);

  const handleChange = (newRange: any) => {
    setRange(newRange);
  }

  return (
    <div className={styles.rangeSliderContainer}>
      <div id="range-slider" className={styles.rangeSlider}>
        <Slider
          range
          step={1}
          value={range}
          onChange={handleChange}
          trackStyle={[{ backgroundColor: '#ccc', }]}
          handleStyle={[
            {
              backgroundColor:'#173540',
              width: 26,
              height: 26,
              top:-3
            },
            {
              backgroundColor:'#173540',
              width: 26,
              height: 26,
              top:-3
            }
          ]}
          onBeforeChange={() => {
            setLowerActive(true);
            setUpperActive(true);
          }}
          onAfterChange={() => {
            setLowerActive(false);
            setUpperActive(false);
          }}
        />
      </div>
    </div>
  );
};

export default RangeSlider;