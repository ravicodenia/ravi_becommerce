import { RootState } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';

export default function HotelNorms() {
  const { hotelCancellationPolicies } = useSelector(
    (state: RootState) => state.hotel
  );
  return (
    <ul className="mb-0">
      {hotelCancellationPolicies?.hotelNorms?.map((policy: any, index: any) => (
        <li key={index} dangerouslySetInnerHTML={{ __html: policy }}></li>
      ))}
    </ul>
  );
}
