import { useState, useEffect } from 'react';
import SearchHotelBox from '../searchHotelBox';
import { CiSearch } from 'react-icons/ci';
import { searchHotelList } from '../../lib/service/hotelApi';
import { useHotelStore, RootState } from '@mfa-travel-app/store';
import AdditionalSerach from '../../lib/pages/additionalSearch';
import { toast } from 'react-toastify';
import { Loader } from '@mfa-travel-app/ui';
import { useSelector } from 'react-redux';

export default function ModifySearchCon() {
  const [modifySearchParams, setModifySearchParams] = useState(false);
  const { searchPayload } = useSelector((state: RootState) => state.hotel);
  const [modifysearchPayload, setModifySearchPayload] = useState({
    cityName: searchPayload?.cityName,
    checkIn: searchPayload?.checkIn,
    checkOut: searchPayload?.checkOut,
    countryName: searchPayload?.countryName,
    noOfRooms: searchPayload.noOfRooms,
    starRating: searchPayload?.starRating,
    nationalityCode: searchPayload?.nationalityCode,
    roomPaxInfo: searchPayload?.roomPaxInfo,
    sources: searchPayload.sources,
    // markup:'',
    propertyName:''
  });
  const [loader, setLoader] = useState(false);
  const handleModifyParams = () => {
    setModifySearchParams(true);
  };
  const { saveHotelSearchResults, saveHotelSearchPayloadResults } =
    useHotelStore();

  const searchHotels = async () => {
    const { cityName, checkIn, checkOut, countryName, roomPaxInfo } =
      modifysearchPayload;

    if (!cityName || !checkIn || !checkOut || !countryName || !roomPaxInfo) {
      toast.error('Please fill in all the search parameters.');
      return;
    }
    let adultGuests = 0;
    roomPaxInfo?.forEach((room: any) => {
      adultGuests = adultGuests + room?.adults;
    });
    if (roomPaxInfo?.length > adultGuests) {
      toast.error('Please fill in all the search parameters.');
      return;
    }
    setModifySearchParams(false);
    setLoader(true);
    const response: any = await searchHotelList({...modifysearchPayload, IsOnBehalf: false});
    setLoader(false);
    try {
      if (response.status == 200 && response?.data?.result) {
        saveHotelSearchResults(response?.data?.result);
        saveHotelSearchPayloadResults(modifysearchPayload);
      } else {
        toast.error(response?.data.error.message);
      }
    } catch {
      toast.error('An error occurred. Please try again later.');
    }
  };

  const formatDate = (timestamp: any) => {
    const date = new Date(timestamp);
    // Define an array of weekday names
    const weekdays = [
      'Sunday',
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
    ];
    // Define an array of month names
    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
    const day = date.getDate();
    const month = months[date.getMonth()];
    const year = date.getFullYear().toString().slice(-2);
    const weekday = weekdays[date.getDay()];
    return `${day} ${month}'${year}, ${weekday}`;
  };

  const calculateDaysBetweenDates = (date1Str: any, date2Str: any) => {
    let date1 = new Date(date1Str);
    let date2 = new Date(date2Str);
    let timeDifference = date2.getTime() - date1.getTime();
    // Convert the time difference to days
    let dayDifference = timeDifference / (1000 * 3600 * 24);
    // Round the day difference to handle daylight saving time changes
    dayDifference = Math.round(dayDifference);

    return dayDifference;
  };

  const countPeople = (peopleArray: any) => {
    let total = 0;
    peopleArray?.forEach((person: any) => {
      total += (person.adults || 0) + (person.children || 0);
    });
    return total;
  };
  const onSendsearchHotelData = (
    city: any,
    from: any,
    to: any,
    traveller: any,
    country:any,
    nation: any,
  ) => {
    setModifySearchPayload({
      ...modifysearchPayload,
      cityName: city,
      checkIn: from,
      checkOut: to,
      countryName: country,
      nationalityCode: nation,
      roomPaxInfo: traveller,
    });
  };
  const onAdditionalSearch = (
    residence: any,
    propertyName: any,
    starRating: any,
    markup: any,
    suppliers: any
  ) => {
    setModifySearchPayload({
      ...modifysearchPayload,
      sources: suppliers?.map((i: any) => i.value),
      starRating: starRating.value,
      propertyName: propertyName,
      // markup: markup,
    });
  };

  return (
    <>
      <div className="mt-1 mb-3">
        {modifySearchParams ? (
          <>
            <div className="searchForm mt-2 mb-2">
              <div className="flightSearch mt-1">
                <div className="row align-items-center">
                  <div className="col-12 mb-3">
                    <SearchHotelBox
                      onSendsearchHotelData={onSendsearchHotelData}
                    />
                  </div>

                  <div className="col-lg-9">
                    <details>
                      <summary className="text-start">
                        <p className="mb-0 d-inline-block">
                          Additional Search Options
                        </p>
                      </summary>
                      <ul className="additional_searches mt-4">
                        <AdditionalSerach
                          onAdditionalSearch={onAdditionalSearch}
                        />
                      </ul>
                    </details>
                  </div>

                  <div className="col-lg-3  text-end">
                    <button
                      onClick={searchHotels}
                      id="show_hotel_search_jq"
                      type="button"
                      className="btn btn-primary"
                    >
                      <span>
                        <CiSearch />
                        SEARCH
                      </span>{' '}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="col-12">
           
            <div className="modify_search_params hide_mobile">
              <div className="row align-items-center">
                <div className="col-md-10 align-items-center">
                  <div className="d-flex align-items-center">
                    <div className="p-0">
                      {' '}
                      <h6 className="me-4">
                        <i className="fa-solid fa-hotel"></i> {' '}
                        {searchPayload.cityName} {' '}
                      </h6>
                    </div>
                    <div>
                      <span className="con_title">Check-In</span>
                      <span className="con_details">
                        {' '}
                        {formatDate(searchPayload.checkIn)}
                      </span>
                    </div>

                    <div>
                      <span>
                        {' '}
                        <strong>
                          {calculateDaysBetweenDates(
                            searchPayload.checkIn,
                            searchPayload.checkOut
                          )}
                        </strong>{' '}
                        Nights
                      </span>
                    </div>

                    <div>
                      <span className="con_title">Check-Out</span>
                      <span className="con_details">
                        {formatDate(searchPayload.checkOut)}
                      </span>
                    </div>
                    <div>
                      <span className="con_title">Rooms & Guests</span>
                      <span className="con_details">
                        <strong>{searchPayload.noOfRooms}</strong> Rooms,{' '}
                        <strong>
                          {countPeople(searchPayload?.roomPaxInfo)}
                        </strong>{' '}
                        Guests
                      </span>
                    </div>
                  </div>
                </div>
                <div className="col-md-2 text-end">
                  <button
                    onClick={handleModifyParams}
                    id="show_hotel_search_jq"
                    type="button"
                    className="btn btn-outline-primary"
                  >
                    <span>MODIFY</span>{' '}
                  </button>
                </div>
              </div>
            </div>


            <div id="editHotelDescription" className="editFlights col-12 mt-2 show_mobile">

<div className="row align-items-center">
  <div className="col-9">

      <div>  <small><i className="fa-solid fa-hotel"></i></small> {' '}<strong>  {searchPayload.cityName}</strong></div>
      <div className="details"> <small> {formatDate(searchPayload.checkIn)} -  {formatDate(searchPayload.checkOut)} </small>  
       </div>
       <div className="details">
        <small>{calculateDaysBetweenDates(
                            searchPayload.checkIn,
                            searchPayload.checkOut
                          )} Nights</small>     
        <span className="text-muted">|</span> <small>{searchPayload.noOfRooms} Rooms,{' '}</small>             
        <span className="text-muted">|</span> <small>  {countPeople(searchPayload?.roomPaxInfo)}Guests</small> 
       </div>

  </div>


  <div className="col-3 text-end">
    <button 
     onClick={handleModifyParams}

    id="show_hotel_search_jq_mb" 
    className="btn btn-primary rounded" 
    type="button"> <small>Modify</small> </button>
  </div>

</div>


            </div>




          </div>
        )}
      </div>

      {loader && <Loader />}
    </>
  );
}
