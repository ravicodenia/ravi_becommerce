import { useSelector } from 'react-redux';
import { RootState } from '@mfa-travel-app/store';
import CancellationCharges from './CancellationCharges';
import HotelNorms from './HotelNorms';

export default function EssentialInfo() {
  const { hotelCancellationPolicies } = useSelector(
    (state: RootState) => state.hotel
  );

  return (
    <>
      <div className="hotel_pax_details_con">
        <div className="essential_informations">
          <div className="row">
            <div className="col-12">
              <div className="form_heading">
                <span className=" title">Essential Information</span>
              </div>
            </div>
            <strong>Cancellation Charges</strong>
            <CancellationCharges />
            <div className="col-12">
              <div>
                <span className="heading">Inclusions</span>{' '}
              </div>
              <strong>Hotel Norms</strong>
              <HotelNorms />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
