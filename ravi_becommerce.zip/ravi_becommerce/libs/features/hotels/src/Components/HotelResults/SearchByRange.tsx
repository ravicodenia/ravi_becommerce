import Slider from 'rc-slider';
import 'rc-slider/assets/index.css';

function SearchByRange() {

  return (
    <>
      <div className="row">
        <div className="col-12 mb-4">
          <Slider />
        </div>
      </div>
    </>
  );
}

export default SearchByRange;
