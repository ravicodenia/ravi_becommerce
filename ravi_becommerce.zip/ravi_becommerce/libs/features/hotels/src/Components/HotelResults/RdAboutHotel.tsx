import { useState } from "react"

export default function RdAboutHotel() {

  const aboutHotel = ['Atlantis, The Palm is Dubai’s iconic 5 star beach resort. With luxurious guest rooms and suites boasting breathtaking views of the Arabian Gulf or the world renowned Palm Island from every room. The exclusive Bridge Suite spans the soaring Royal Towers as well as two stunning underwater Suites featuring captivating and direct views into the Ambassador Lagoon, home to over 65,000 marine.']
  const [showAll, setShowAll] = useState(false);
  const showMore = () => setShowAll(true);
  const showLess = () => setShowAll(false);

  return (
    <div className="row">
      <div className="col-md-12">
        <hr />
      </div>
      <div className="col-md-12 mb-2"> <h6>ABOUT THE HOTEL </h6> </div>
      <div className="col-md-12">
        {showAll ?
          <div> {aboutHotel}</div>
          :

          <div> {aboutHotel.toString().slice(0, 240)}...</div>

        }
      </div>
      <div className="col-md-12">
        {showAll ?
          <button onClick={showLess}
            type="button" className="btn show_more_about_hotel mb-2 ps-0 pe-0 text-primary">
            <small>Show Less</small>
          </button>
          :

          <button onClick={showMore}
            type="button" className="btn show_more_about_hotel mb-2 ps-0 pe-0 text-primary">
            <small>Show More</small>
          </button>
        }
      </div>
    </div>
  )
}
