import { Link, useNavigate } from 'react-router-dom';
// import { hotelimgnotavail } from '@mfa-travel-app/assets';
import { useSelector } from 'react-redux';
import { useState } from 'react';
import { Modal } from 'react-bootstrap';
import { Tab, Tabs } from 'react-bootstrap';
import styles from '../../lib/hotels.module.scss';
import 'react-responsive-carousel/lib/styles/carousel.min.css'; // requires a loader
import { Carousel } from 'react-responsive-carousel';
import {
  searchHotelInformation,
  searchHotelRoomInformation,
} from '../../lib/service/hotelApi';
import { useHotelStore, RootState } from '@mfa-travel-app/store';
import { toast } from 'react-toastify';
import { Loader } from '@mfa-travel-app/ui';

export default function HotelListing({ hotel }: any) {
  const {
    saveSelectedHotelDetails,
    saveSelectedHotelRoomDetails,
    saveSelectedHotelRecordDetails,
  } = useHotelStore();

  const [compareHotel, setCompareHotel] = useState(false);
  const [flHeader, setFlHeader] = useState(true);
  const [hotelTabs, setHotelTabs] = useState(false);
  const [showMore, setShowMore] = useState(false);
  const navigate = useNavigate();
  const { searchPayload, selectedHotel } = useSelector(
    (state: RootState) => state.hotel
  );
  const [loader, setLoader] = useState(false);
  const hideAgentCostProfit = () => {
    setFlHeader(false);
  };

  const showMoreInfo = async (hotel: any) => {
    setHotelTabs(!hotelTabs);
    if (!hotelTabs) {
      setLoader(true);
      const hotelInfoResponse: any = await searchHotelInformation(
        hotel?.sessionId,
        hotel?.hotelId,
        hotel?.hotelCode
      );
      setLoader(false);
      try {
        if (hotelInfoResponse?.data?.statusCode === 200) {
          saveSelectedHotelDetails(hotelInfoResponse?.data?.result);
          saveSelectedHotelRecordDetails(hotel);
        } else {
          alert('An error occured');
        }
      } catch {
        toast.error('An error occurred. Please try again later.');
      }
    } else return
  };

  const navigateToRoomDetails = async (hotel: any) => {
    setLoader(true);
    const hotelInfoResponse: any = await searchHotelInformation(
      hotel?.sessionId,
      hotel?.hotelId,
      hotel?.hotelCode
    );
    setLoader(false);
    setLoader(true);
    const roomInfoResponse: any = await searchHotelRoomInformation(
      hotel?.sessionId,
      hotel?.hotelId,
      hotel?.hotelCode,
      hotel?.hotelRefNumber,
      searchPayload?.roomPaxInfo
    );
    setLoader(false);

    try {
      if (
        hotelInfoResponse?.data?.statusCode === 200 &&
        roomInfoResponse?.data?.statusCode === 200
      ) {
        saveSelectedHotelDetails(hotelInfoResponse?.data?.result);
        saveSelectedHotelRoomDetails(roomInfoResponse?.data?.result);
        saveSelectedHotelRecordDetails(hotel);
        navigate('/room-details');
      } else {
        alert('An error occured');
      }
    } catch {
      toast.error('An error occurred. Please try again later.');
    }
  };

  return (
    <>
      <div className="row">
        <div className="col-12 listht">
          <div className="flightListingRp">
            {flHeader ? (
              <div className="flheader">
                <div className="row">

                  <div className="col-lg-6 col-11">
                    <span className="text-secondary"> Agent Cost:</span>{' '}
                    {hotel?.currency} {hotel?.totalPrice}
                  </div>

                  <div className="col-lg-6 col-1 text-end fl_lastcol">
                  <Link
                          to=""
                          onClick={hideAgentCostProfit}
                          className="hideAgentCost"
                        >
                          {' '}
                          <i className="fa-solid fa-minus"></i>{' '}
                        </Link>
                  </div>
                </div>
              </div>
            ) : null}

            <div className="row">
              <div className="col-lg-10">
                <div className="flightLtcol hotel_listing">
                  <div className="row mb-2">
                    <div className="col-lg-3">
                      <div className='thumbnail_pic'> 
                      <img
                        className="img-fluid rounded" alt="" 
                        src={
                          hotel?.images[0]
                            ? hotel?.images[0]
                            : 'https://assets.kerzner.com/api/public/content/18027857b7fe4810bf3b799d63022b56?v=88190ae7&t=w2880'
                        }
                      />
                    </div>

                    </div>

                    <div className="col-lg-6 hotel_title">
                      <div className="hotelName mt-2">{hotel?.hotelName}</div>
                      <div className="hotelAdress text-secondary mt-2">
                        <i className="fa-solid fa-location-dot"></i>
                        {hotel?.address}
                        {hotel?.cityName}, {hotel?.countryName} {hotel?.pincode}
                      </div>

                      <div className="moreInfo mt-2">
                        <div className="d-flex align-items-center">
                          <div className="col-6">
                            <button
                              onClick={() => showMoreInfo(hotel)}
                              type="button"
                              className="btn btn-sm"
                            >
                              More Info {''}
                              <i
                                className={`fa-solid ${
                                  hotelTabs ? 'fa-angle-up' : 'fa-angle-down'
                                }`}
                              ></i>
                            </button>
                          </div>

                          <div className="col-6 text-end">
                            <button
                              onClick={() => setCompareHotel(true)}
                              type="button"
                              className="btn compare text-secondary"
                            >
                              <span>
                                <i className="fa-solid fa-scale-balanced"></i>
                              </span>{' '}
                            </button>{' '}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="col-lg-3">
                      <div className=" mt-2">
                        {Array.from({ length: hotel?.hotelRating || 0 }).map(
                          (_, index) => (
                            <span key={index}>
                              <i className="fa-solid fa-star"></i>
                            </span>
                          )
                        )}
                        {Array.from({
                          length: 5 - hotel?.hotelRating || 0,
                        }).map((_, index) => (
                          <span key={index}>
                            <i className="fa-regular fa-star"></i>
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div style={{ position: 'relative' }} className="col-lg-2 col-12">
                <span className="circle-top"></span>

                <div className="flightRtcol">
                  <div className="row align-items-center mb-3">
                   
                    <div className="col-lg-12 col-6  text-start text-lg-center mt-md-3">
                   
                        <div className='pricecol'>
                        {' '}
                        <span className="currency">{hotel?.currency}</span>{' '}
                        <span className="price">{hotel?.totalPrice}</span>
                    
                      </div>
                    </div>

                    <div className="col-lg-12 col-6 text-end text-lg-center">
                      <button
                        className="btn btn-primary"
                        onClick={() => navigateToRoomDetails(hotel)}
                      >
                        Book
                      </button>
                    </div>
                  </div>
                </div>
                <span className="circle-bottom"></span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {hotelTabs && (
        <div className="hotel_listing_details">
          <div className="hotel_listing_tabs">
            <Tabs
              defaultActiveKey="Gallery"
              id="uncontrolled-tab-example"
              className="mb-2"
            >
              <Tab eventKey="Gallery" title="Gallery">
                <Carousel autoPlay infiniteLoop showIndicators={false}>
                  {selectedHotel?.hotelInfo?.images?.map((imageUrl: any) => (
                    <div>
                      <img src={imageUrl} />
                    </div>
                  ))}
                </Carousel>
              </Tab>

              <Tab eventKey="Location" title="Location">
                {selectedHotel?.hotelInfo?.address}
              </Tab>

              <Tab eventKey="Overview" title="Overview">
                <div className="con_overview">
                  <div className="row">
                    <div className="col-md-8">
                      <div className="row">
                        <div className="col-12">
                          <h6>Details</h6>
                          <p
                            className={
                              showMore
                                ? styles['expanded']
                                : styles['collapsed']
                            }
                            dangerouslySetInnerHTML={{
                              __html: selectedHotel?.hotelInfo?.description,
                            }}
                          ></p>
                          <button
                            type="button"
                            className="btn btn-sm text-primary p-0"
                            onClick={() => setShowMore(!showMore)}
                          >
                            {showMore ? 'Show less' : 'Show more'}
                          </button>
                        </div>

                        <div className="col-12 mt-3">
                          <table className="table table-borderless">
                            <tbody>
                              <tr>
                                <th>
                                  <i className="fa-solid fa-map-location-dot text-secondary"></i>{' '}
                                  Address{' '}
                                </th>
                                <td style={{ textWrap: 'wrap' }}>
                                  {selectedHotel?.hotelInfo?.address}
                                </td>
                              </tr>
                              <tr>
                                <th>
                                  <i className="fa-solid fa-phone  text-secondary"></i>{' '}
                                  Contact{' '}
                                </th>
                                <td>{selectedHotel?.hotelInfo?.phoneNumber}</td>
                              </tr>

                              <tr>
                                <th>
                                  <i className="fa-solid fa-calendar-days text-secondary"></i>{' '}
                                  Check-in time{' '}
                                </th>
                                <td>{selectedHotel?.hotelInfo?.checkInTime}</td>
                              </tr>

                              <tr>
                                <th>
                                  <i className="fa-solid fa-calendar-days text-secondary"></i>{' '}
                                  Check-out time{' '}
                                </th>
                                <td>{selectedHotel?.hotelInfo?.checkOutTime}</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>

                    <div className="col-md-4">
                      <div className="col-12 mt-3">
                        <h6>Amenities</h6>

                        <div className="amenities_hotel_listing">
                          {selectedHotel?.hotelInfo?.hotelFacilities?.map(
                            (facility: any) => (
                              <span className="bg-light">{facility}</span>
                            )
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </Tab>
            </Tabs>
          </div>
        </div>
      )}

      <Modal centered show={compareHotel} onHide={() => setCompareHotel(false)}>
        <Modal.Body>
          <h5>rtretert</h5>
        </Modal.Body>
      </Modal>
      {loader && <Loader />}
    </>
  );
}
