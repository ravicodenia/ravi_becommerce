
import Tooltip from 'react-bootstrap/Tooltip';
import OverlayTrigger from 'react-bootstrap/OverlayTrigger'

export default function RdToolTip() {

  return (
    <>
      <OverlayTrigger
        delay={{ hide: 450, show: 300 }}
        overlay={(props) => (
          <Tooltip {...props}>
            Hi, I am a simple tooltip information!
          </Tooltip>
        )}
        placement="bottom"
      >

        <button className="btn text-secondary p-0">
          <i className="fa-solid fa-circle-info"></i>
        </button>
      </OverlayTrigger>
    </>


  )
}
