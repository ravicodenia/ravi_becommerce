
export default function SpecialRequest() {

  return (
    
    <>
      <div className="hotel_pax_details_con">
        <div className="row">
          <div className="col-12">
            <div className="form_heading">
              <span className=" title">Special Requests</span>
            </div>
          </div>
          <div className="col-12">
            <div className="special_requests">
              <div className="row">
                <div className="col-md-4 mb-2"> <span className="sp_li">Connecting rooms</span>   </div>
                <div className="col-md-4 mb-2"> <span className="sp_li">King Size Bed</span>  </div>
                <div className="col-md-4 mb-2"> <span className="sp_li"> Smoking Rooms</span>   </div>
                <div className="col-md-4 mb-2"> <span className="sp_li">Honeymoobers</span>   </div>
                <div className="col-md-4 mb-2"> <span className="sp_li">Late check in</span>   </div>
                <div className="col-md-4 mb-2"> <span className="sp_li"> Launch supplement</span>   </div>
                <div className="col-md-4 mb-2"> <span className="sp_li"> Misc</span>   </div>
                <div className="col-md-4 mb-2"> <span className="sp_li"> Twin Beds</span>   </div>
                <div className="col-md-4 mb-2"> <span className="sp_li"> Non Smoking Room</span>   </div>
                <div className="col-md-4 mb-2"> <span className="sp_li"> Room Upgrade</span>   </div>
                <div className="col-md-4 mb-2"> <span className="sp_li"> Early check in</span>   </div>
                <div className="col-md-4 mb-2"> <span className="sp_li"> Breakfast</span>   </div>
                <div className="col-md-4 mb-2"> <span className="sp_li"> Dinner</span>   </div>
                <div className="col-md-4 mb-2"> <span className="sp_li"> Hotel Membership Details</span>   </div>
              </div>
            </div>
          </div>
          <div className="col-12 text-danger">
            <div className="mt-3">
              <h6>  **General Notification</h6>
              <small> Please note that these requests are not covered under this booking cost. Additional may not incur depending upon the Hotel. Selecting these request does not guarantee their availibilty. status of your request shall be updated after confirming the hotel.
              </small>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
