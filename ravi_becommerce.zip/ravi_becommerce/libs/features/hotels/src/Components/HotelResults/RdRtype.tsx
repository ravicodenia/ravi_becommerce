export default function RdRtype({ details }: any) {

  return (
    <>
      {' '}
      <div className="roomdetailsCon">
        <div className="room_details_chk_in_out">
          <div className="row mb-1">
            <div className="col-12 mt-3 mb-2">
              <span className="room_type_htl">{details?.name}</span>
            </div>
            <div className="col-12 mb-2">
              {' '}
              <span className="text-success">
                <i className="fa-solid fa-circle-check"></i>
              </span>{' '}
              {details?.mealType}
            </div>
            <div className="col-6 mb-2">
              <span className="text-secondary">
                <i className="fa-solid fa-users"></i> Room Guests
              </span>
            </div>
            <div className="col-6 mb-2">
              <span>
                {details?.roomPax?.adults} Adult(s) &{' '}
                {details?.roomPax?.children} Child(s)
              </span>
            </div>

            {details?.roomPax?.children > 0 && (
              <>
                <div className="col-6 mb-2">
                  <span className="text-secondary">
                    <i className="fa-solid fa-users"></i> Child Age
                  </span>
                </div>
                <div className="col-6 mb-2">
                  <span>
                    {details?.roomPax?.childrenAges?.map(
                      (age: any, index: any) =>
                        `${age}${details?.roomPax?.childrenAges?.length !== index + 1
                          ? ', '
                          : ''
                        }`
                    )}{' '}
                    Year(s)
                  </span>
                </div>
              </>
            )}
            {details?.supplements?.map((supplement: any, index:any) => (
              <div key={index} className="d-flex">
                <div className="col-4 mb-2">
                  <span className="text-secondary">
                    <i className="fa-solid fa-file-lines"></i> {supplement?.description === 'mandatory_tax' ? 'Mandatory Tax' : supplement?.description}
                  </span>
                </div>
                <div className="col-4 mb-2">
                  <span>{supplement?.type === 'AtProperty' ? 'At Property' : supplement?.type}</span>
                </div>
                <div className="col-4 mb-2">
                  <span>{supplement?.currency} {supplement?.price}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
