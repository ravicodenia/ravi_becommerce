import { CustomInput1, ListBox } from '@mfa-travel-app/ui';
import { useState } from 'react';

export default function HotelAdultPax({ data, onChange }: any) {

  const [guest, setGuest] = useState(data)

  const handleSelectChange = (e: any) => {
    const { name, value } = e.target;
    const updatedPaxData = { ...guest, [name]: value }
    setGuest(updatedPaxData);
    onChange(updatedPaxData)
  };

  const handleInputChange = (e: any) => {
    const { name, value } = e.target;
    const updatedPaxData = { ...guest, [name]: value }
    setGuest(updatedPaxData);
    onChange(updatedPaxData)
  };

  return (
    <>
      <div className="row">
        <div className="col-lg-2">
          <div className="mb-2 row">
            <label className="col-sm-4 col-form-label">
              Title:<i className="text-danger">*</i>
            </label>
            <div className="col-sm-8">
              <ListBox
                name="title"
                id="Title"
                defaultValue="01"
                options={[
                  { label: 'Mr.', value: '01' },
                  { label: 'Mrs.', value: '02' },
                ]}
                handleChange={(e) => handleSelectChange(e)}
              />
            </div>
          </div>
        </div>

        <div className="col-lg-5">
          <div className="mb-2 row">
            <label className="col-sm-4 col-form-label">
              {' '}
              First Name:<i className="text-danger">*</i>
            </label>
            <div className="col-sm-8">
              <CustomInput1
                id="firstname"
                placeholder="First Name"
                name="firstName"
                handleChange={(e) => handleInputChange(e)}
              />
            </div>
          </div>
        </div>

        <div className="col-lg-5">
          <div className="mb-2 row">
            <label className="col-sm-4 col-form-label">
              Last Name:<i className="text-danger">*</i>
            </label>
            <div className="col-sm-8">
              <CustomInput1
                id="lastname"
                placeholder="Last Name"
                name="lastName"
                handleChange={(e) => handleInputChange(e)}
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
