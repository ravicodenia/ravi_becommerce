import { useState } from "react"

export default function SelectToogleBtn() {
  const [roomSelect, setRoomSelect] = useState(true);
  const selectRoom = () => setRoomSelect(roomSelect => !roomSelect)

  return (
    <>
      <button onClick={selectRoom}
        type="button"
        className={`toggle-button ${roomSelect ? 'btn btn-sm btn-primary rounded' : 'btn btn-sm btn-success rounded'}`}>
        {roomSelect ? 'SELECT' : 'SELECTED'}
      </button>

    </>


  )
}
