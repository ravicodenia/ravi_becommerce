import { CustomInput1 } from '@mfa-travel-app/ui';
import { useState } from 'react';

export default function HotelPaxAddress({ roomNo, onAddressChange }: any) {

  const [address, setAddress] = useState({
    address1: '',
    address2: ''
  })

  const handleInputChange = (e: any) => {
    const { name, value } = e.target;
    const updatedPaxData = { ...address, [name]: value }
    setAddress(updatedPaxData);
    onAddressChange(roomNo, updatedPaxData)
  };

  return (
    <>
      <div className="row">
        <div className="col-lg-6">
          <div className="mb-2 row">
            <label className="col-sm-3 col-form-label">Address:</label>
            <div className="col-sm-9">
              <CustomInput1 id="Address" placeholder="" name="address1" handleChange={(e) => handleInputChange(e)} />
            </div>
          </div>

          <div className="input-group mb-3">
            <div className="input-group-prepend"></div>
          </div>
        </div>
        <div className="col-lg-6">
          <div className="mb-2 row">
            <div className="col-sm-12">
              <CustomInput1 id="Address2" placeholder="" name="address2" handleChange={(e) => handleInputChange(e)} />
            </div>
          </div>
          <div className="input-group mb-3">
            <div className="input-group-prepend"></div>
          </div>
        </div>
      </div>
    </>
  );
}
