import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { RootState, useHotelStore } from '@mfa-travel-app/store';
import { getHotelCancellationPolicy } from '../../lib/service/hotelApi';
import { Loader } from '@mfa-travel-app/ui';
import { getBalance } from '@mfa-travel-app/shared';
import { useStore } from '@mfa-travel-app/store';

export default function RdTophdr() {
  const navigate = useNavigate()
  const { selectedHotel, rooms, searchPayload, selectedHotelRoom } = useSelector((state: RootState) => state.hotel)
  const { agentProfile }: any = useSelector(
    (state: RootState) => state.config
  );
  const { saveHotelCancellationPoliciesDetails } = useHotelStore();
  const { saveBalanceDetails } = useStore();
  const [totalPrice, setTotalPrice] = useState<any>()
  const [totalTax, setTotalTax] = useState<any>()
  const [loader, setLoader] = useState(false)

  useEffect(() => {
    let price = 0
    let tax = 0
    rooms?.map((room: any) => {
      price += room?.roomTotalPrice
      tax += room?.roomTotalTax
    })
    setTotalPrice(price)
    setTotalTax(tax)
  }, [rooms])

  const handleNavigate =  async () => {
    setLoader(true)
    const roomReferences = []
    for (let i = 0; i < searchPayload?.noOfRooms; i++) {
      roomReferences.push(rooms[0]?.roomBookingKey)
    }
    const response:any = await getHotelCancellationPolicy(
      selectedHotelRoom?.sessionId,
      selectedHotelRoom?.hotelId,
      selectedHotelRoom?.hotelCode,
      selectedHotelRoom?.hotelReferenceCode,
      searchPayload?.noOfRooms,
      roomReferences
    );
    setLoader(false)
    saveHotelCancellationPoliciesDetails(response?.data?.result)
    navigate('/hotel-pax-details')
    const responseBalance: any = await getBalance(agentProfile?.id);
          if(response?.data){
          saveBalanceDetails(responseBalance?.data);
          }
  }

  return (
    <>
      <div className="roomdetailsCon " style={{position:'sticky', top:'0',left :'0',background:'white',zIndex:'100'}}>
        <div className="StickynavbarWrapper">
          <div className="container">
            <div className="row align-items-center mt-3 mb-3">
              <div className="col-md-6">
                <div className="d-flex">
                  <div className="me-3">
                    {' '}
                    <h5>{selectedHotel?.hotelInfo?.hotelName}</h5>{' '}
                  </div>
                  <div>
                    {Array.from({
                      length: selectedHotel?.hotelInfo?.hotelRating || 0,
                    }).map((_, index) => (
                      <span key={index}>
                        <i className="fa-solid fa-star"></i>
                      </span>
                    ))}
                    {Array.from({
                      length: 5 - selectedHotel?.hotelInfo?.hotelRating || 0,
                    }).map((_, index) => (
                      <span key={index}>
                        <i className="fa-regular fa-star"></i>
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  {' '}
                  <small>
                    <i className="fa-solid fa-location-dot text-primary"></i>{' '}
                    {selectedHotel?.hotelInfo?.address}
                  </small>
                </div>
              </div>

              <div className="col-md-6 text-end">
                <div>
                  <h5 className="m-0">
                    {rooms[0]?.currency} {(totalPrice + totalTax)?.toFixed(2)}
                  </h5>
                </div>
                <div className="text-muted">
                  <small>{rooms[0]?.currency} {totalTax?.toFixed(2)} Tax and Fees</small>
                </div>

                <div className="mt-1">
                  <button
                    id="show_hotel_search_jq"
                    type="button"
                    className="btn btn-sm border me-1"
                    onClick={() => navigate('/hotel-results')}
                  >
                    BACK
                  </button>
                  {/* <button type="button" className="btn btn-sm border me-3">
                    <i className="fa-solid fa-share-nodes"></i>
                  </button> */}

                  <button type="button" className="btn btn-primary rounded" onClick={() => handleNavigate()}>
                    BOOK
                  </button>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-12">
                <div className="border Stickynavbar">
                  <ul>
                    <li>
                      <a className="menuitem" href="/room-details#PHOTOS">
                        PHOTOS
                      </a>
                    </li>
                    <li>
                      <a className="menuitem" href="/room-details#ROOM-RATES">
                        ROOM & RATES
                      </a>
                    </li>
                    <li>
                      <a className="menuitem" href="/room-details#HOTEL-AMENITIES">
                        HOTEL AMENITIES
                      </a>
                    </li>
                    <li>
                      <a className="menuitem" href="/room-details#ATTRACTIONS">
                        NEARBY ATTRACTIONS
                      </a>
                    </li>
                    <li>
                      <a className="menuitem" href="/room-details#MAP">
                        MAP
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {loader && <Loader/>}
    </>
  );
}
