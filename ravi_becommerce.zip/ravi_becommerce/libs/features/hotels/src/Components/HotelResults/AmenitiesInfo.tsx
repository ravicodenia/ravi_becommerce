import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { RootState } from '@mfa-travel-app/store';
import styles from '../../lib/hotels.module.scss';

export default function AmenitiesInfo() {
  const [showMore, setShowMore] = useState(false);

  const { selectedHotel } = useSelector((state: RootState) => state.hotel);

  return (
    <>
    <div className='roomdetailsCon'> 
      <div className="amenties_info">
        <h5>Amenities & Info</h5>
        <div className="row">
          {selectedHotel?.hotelInfo?.hotelFacilities?.map((facility: any, index:any) => (
            <div className="col-md-4 mb-2" key={index}><i className="fa-solid fa-check"></i> {facility}</div>
          ))}
        </div>

        <div className="row">
          <div className="col-md-12">
            <hr />
          </div>
          <div className="col-md-12 mb-2">
            {' '}
            <h6>ABOUT THE HOTEL </h6>{' '}
          </div>
          <p
            className={showMore ? styles['expanded'] : styles['collapsed']}
            dangerouslySetInnerHTML={{
              __html: selectedHotel?.hotelInfo?.description,
            }}
          ></p>
          <div className="col-md-12">
            <button
              type="button"
              className="btn show_more_about_hotel mb-2 ps-0 pe-0 text-primary"
              onClick={() => setShowMore(!showMore)}
            >
              <small>{showMore ? 'Show less' : 'Show more'}</small>
            </button>
          </div>
        </div>
      </div>
      </div>
    </>
  );
}
