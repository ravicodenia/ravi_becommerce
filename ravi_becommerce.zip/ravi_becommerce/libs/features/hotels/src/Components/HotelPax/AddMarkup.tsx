import { RootState } from '@mfa-travel-app/store';
import { RadioInput, CustomInput1 } from '@mfa-travel-app/ui';
import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';

export default function AddMarkup({ totalFare, onChange }: any) {
  const [markupType, setMarkupType] = useState('');
  const [markupValue, setMarkupValue] = useState<any>(0);
  const { selectedItinerary } = useSelector((state: RootState) => state.flight);

  useEffect(() => {
    if (markupValue == '' && markupType != '') {
      calculateMarkup();
      return;
    } else if (markupType === '' || markupValue === '') {
      return;
    } else {
      calculateMarkup();
    }
  }, [markupType, markupValue]);

  const checkedUnit = (e: any) => {
    const selectedUnit = e.target.name;
    if (selectedUnit !== markupType) {
      setMarkupType(selectedUnit);
    }
  };

  const markupInput = (e: any) => {
    setMarkupValue(e.target.value);
  };
  // handlingFeeValue + markup - discount

  const calculateMarkup = () => {
    if (markupType == '') {
      onChange({
        markupType: 'F',
        markupValue: '0',
        markupAmount: 0,
      });
      return;
    } else if (markupType === 'F') {
      onChange({
        markupType: markupType,
        markupValue: markupValue,
        markupAmount: Number(markupValue),
      });
      return;
    } else {
      // console.log('percentMarkUp',totalFare,markupValue)
      const value = ((Number(totalFare) / 100) * Number(markupValue)).toFixed(2);
      onChange({
        markupType: markupType,
        markupValue: markupValue,
        markupAmount: value,
      });
    }
  };

  return (
    <>
      <div className="markup">
        <div className="row">
          {/* <div className="col-12">
            <div className="input-group">
              <div className="input-group-prepend me-2">Add Markup on</div>
              <div className="form-check-inline me-3">
                <RadioInput
                  onClick={(e) => checkedLabel(e)}
                  id="fare"
                  name="F"
                  checked={markupType === 'F'}
                />
                <label htmlFor="fare">Fare</label>
              </div>
              <div className="form-check-inline">
                <RadioInput
                  onClick={(e) => checkedLabel(e)}
                  id="tax"
                  name="TF"
                  checked={markupType === 'TF'}
                />
                <label htmlFor="tax">Tax</label>
              </div>
            </div>
          </div> */}
          <div className="col-12">
            <div className="input-group mt-3 align-items-center">
              <div className="form-check-inline">
                <div className="d-flex align-items-center">
                  <div className="me-2">
                    <label htmlFor="valueinnum">Value</label>
                  </div>
                  <div style={{ width: '100px' }}>
                    <CustomInput1
                      id="valueinnum"
                      placeholder=""
                      value={markupValue}
                      handleChange={(e) => markupInput(e)}
                    />
                  </div>
                </div>
              </div>
              <div className="form-check-inline">
                <RadioInput
                  onClick={(e) => checkedUnit(e)}
                  id="valueper"
                  name="P"
                  checked={markupType === 'P'}
                />
                <label htmlFor="valueper">%</label>
              </div>
              <div className="form-check-inline">
                <RadioInput
                  onClick={(e) => checkedUnit(e)}
                  id="valueamo"
                  name="F"
                  checked={markupType === 'F'}
                />
                <label htmlFor="valueamo">Amount</label>
              </div>
            </div>
          </div>
          <div className="col-12 mt-2 text-end">
            <button
              type="button"
              className="btn btn-primary"
              onClick={() => calculateMarkup()}
            >
              APPLY
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
