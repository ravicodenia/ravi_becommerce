import { useState, useEffect } from 'react';
import styles from '../../../../features/flights/src/lib/oneway.module.scss';
import classNames from 'classnames';
import SelectSearch from '../Components/SelectSearch/SelectSearch';
import SelectedDate from '../Components/SelectDate/selectDate';
import HotelGuest from '../Components/TravellersClass/HotelGuest';
import Dropdown from '../Components/dropdown';
import { useSelector } from 'react-redux';
import { RootState } from '@mfa-travel-app/store';
import { Loader } from '@mfa-travel-app/ui';
import { getHotelNames } from '../lib/service/hotelApi';
import { useHotelStore } from '@mfa-travel-app/store';

const SearchHotelBox = ({ onSendsearchHotelData }: any) => {
  const { searchPayload } = useSelector((state: RootState) => state.hotel);
  const [loader, setLoader] = useState<any>(false);
  const [selectedSeachCity, setSelectedSeachCity] = useState<any>(searchPayload?.cityName);
  const [selectedSearchCountry,setSelectedSearchCountry] = useState<any>(searchPayload?.countryName);
  const [checkIn, setCheckIn] = useState<any>(
    new Date(new Date().setDate(new Date().getDate() + 1))
  );
  const [checkOut, setCheckOut] = useState(
    new Date(new Date().setDate(new Date().getDate() + 2))
  );
  const [showPopup, setShowPopup] = useState<any>(false);
  const [selectNationality, setSelectNationality] = useState(searchPayload?.nationalityCode);
  const [travellers, setTravellers] = useState<any>([
    { adults: 2, children: 0, childrenAges: [] },
  ]);
  const [selectedValue, setSelectedValue] = useState(searchPayload?.nationalityCode);
  const { saveHotelNamesDetails } =
  useHotelStore();

  const onSelectSearch = async (searchData: any) => {
    setSelectedSeachCity(searchData.cityName);
    setSelectedSearchCountry(searchData.countryName)

    setLoader(true)
    const response:any = await getHotelNames(searchData.cityName.toLowerCase())
    setLoader(false)
    saveHotelNamesDetails(response?.data)
    setSelectNationality(selectedValue)
    // setSelectNationality(searchData.countryCode);
    onSendsearchHotelData(
      searchData?.cityName,
      checkIn,
      checkOut,
      travellers,
      searchData.countryName,
      selectNationality
    );
  };
  const onSelectHotelCheckInDate = (date: any) => {
    setCheckIn(date);
    setShowPopup(true);
    onSendsearchHotelData(
      selectedSeachCity,
      date,
      checkOut,
      travellers,
      selectedSearchCountry,
      selectNationality
    );
  };
  const onSelectHotelCheckOutDate = (checkOutdate: any) => {
    setCheckOut(checkOutdate);
    setShowPopup(false);
    onSendsearchHotelData(
      selectedSeachCity,
      checkIn,
      checkOutdate,
      travellers,
      selectedSearchCountry,
      selectNationality
    );
  };
  const OnRoomDetailData = (roomDetail: any) => {
    setTravellers(roomDetail);
    onSendsearchHotelData(
      selectedSeachCity,
      checkIn,
      checkOut,
      roomDetail,
      selectedSearchCountry,
      selectNationality
    );
  };

  const onNationality = (e:any) =>{
    setSelectNationality(e)
    onSendsearchHotelData(
      selectedSeachCity,
      checkIn,
      checkOut,
      travellers,
      selectedSearchCountry,
     e
    );
  }

  return (
    <>
     <div className='row g-2'>
        <div style={{ position: 'relative' }} className="col-lg-3">
          <SelectSearch
            searchPayloadProp={searchPayload}
            onSelectSearch={onSelectSearch}
          />
        </div>

        <div className="col-lg-3">
        <div className='row g-2'>
            <div className="col-6">
              <SelectedDate
                onSelectHotelDate={onSelectHotelCheckInDate}
                text={'Check In'}
                datePayload={searchPayload?.checkIn}
                initialDate={new Date().setDate(new Date().getDate() + 1)}
              />
            </div>

            <div className="col-6">
              <SelectedDate
                showPopup={showPopup}
                setShowPopup={setShowPopup}
                onSelectHotelDate={onSelectHotelCheckOutDate}
                text={'Check Out'}
                datePayload={searchPayload?.checkOut}
                initialDate={searchPayload?.checkOut ? searchPayload?.checkOut : new Date().setDate(new Date().getDate() + 2)}
              />
            </div>
          </div>
        </div>

        <div className="col-lg-3">
          <HotelGuest
            OnRoomDetailData={OnRoomDetailData}
            roomPaxInfoPayload={searchPayload?.roomPaxInfo}
            noOfRoom={searchPayload?.noOfRooms}
          />
        </div>

        <div className="col-lg-3">
          <div className="srchCon">
            <div className="srchRow">
              <div className="srchCol">
                <div className="mb-1">
                  {/* <span className="srchsml">
                    Select Nationality{' '}
                    <i className="fa-solid fa-angle-down"></i>
                  </span> */}
                </div>
                <div>
                  <span className="srchTitle enterAirport">
                    {' '}
                    <Dropdown
                      selectedValue={selectedValue}
                      setSelectedValue={setSelectedValue}
                      onNationality = {onNationality}
                    />
                  </span>{' '}
                </div>
                {/* <div>
                  <span className="srchsml textTrim">Indian</span>{' '}
                </div> */}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default SearchHotelBox;
