import { useEffect, useState } from 'react';
import styles from '../../../../flights/src/lib/oneway.module.scss';
import classNames from 'classnames';
import { RootState } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { FaLocationDot } from "react-icons/fa6";


const SelectSearch = ({ Source, icon, onSelectSearch, searchPayloadProp }: any) => {
  const { cities } = useSelector((state: RootState) => state.hotel);
  const [searchTerm, setSearchTerm] = useState(searchPayloadProp?.cityName);
  const [selectedHotel, setSelectedhotel] = useState<any>({
    "countryName": searchPayloadProp.countryName,
    "countryCode": searchPayloadProp?.nationalityCode,
    "cityName": searchPayloadProp?.cityName,
  })

  const [searchSuggetionCityHotel, setSearchSuggetionHotelCity] = useState<any>();
  const handleInputChange = async (event: any) => {
    const { value } = event.target;
    setSearchTerm(value);

    if (value.length >= 2) {
      setSearchSuggetionHotelCity(cities?.filter((suggestion: any) => {
        return suggestion?.cityName?.slice(0, 2).toLowerCase() === value.slice(0, 2).toLowerCase() ||
          suggestion?.cityCode?.slice(0, 2).toLowerCase() === value.slice(0, 2).toLowerCase() ||
          suggestion?.cityName?.toLowerCase() === value.toLowerCase();
      }));
    } else {
      setSearchSuggetionHotelCity([]);
    }
  };
  const handleSuggestionClick = (option: any) => {
    setSearchTerm(option?.cityName);
    setSelectedhotel(option);
    setSearchSuggetionHotelCity([]);
    onSelectSearch(option)
  }

  return (
    <>


<div className="srchCon notranslate">
            <div className="srchRow">
              <div className="srchCol">
              <div className="mb-1"><span className="srchsml">Where do you want to go?</span></div>
              <div className="mb-1 text-start"><span className="srchsml">{Source}</span></div>

              <div className={styles['destination-dropdown']}
                  id="departure-dropdown"
                >
                  <span className='me-1'> <FaLocationDot/> </span>


                  <input
                    type="text"
                    value={searchTerm}
                    onChange={handleInputChange}
                    placeholder="Select"
                    className="srchTitle enterAirport inputTxt"
                    id="departure-input"
                    autoComplete='off'
                  />

                </div>
                <div><span className="srchsml textTrim"> {searchTerm == selectedHotel.cityName ? selectedHotel?.countryName : ""}</span> </div>


                </div>
                </div>

                {searchSuggetionCityHotel?.length > 0 && (
          <ul className={styles['suggestion-list-modal']}>
            {searchSuggetionCityHotel.map(
              (suggestion: any, index: number) => (
                <li
                  key={index}
                  onClick={() => handleSuggestionClick(suggestion)}
                >
                  {`${suggestion.cityName},${suggestion.countryName}`}
                </li>
              )
            )}
          </ul>
        )}

                </div>


  

  

    </>
  );
};

export default SelectSearch;
