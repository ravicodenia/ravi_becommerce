import { useState, useRef, useEffect } from 'react';
import { LuPlus, LuMinus } from 'react-icons/lu';

export default function HotelGuest({ OnRoomDetailData, roomPaxInfoPayload, noOfRoom }: any) {
  const [hotelGuests, setHotelGuests] = useState(false);
  const [noOfRooms, setNoOfRooms] = useState(noOfRoom ? noOfRoom:1 );
  const [totalAdult, setTotalAdult] = useState(2);
  const [roomDetails, setRoomDetails] = useState([
    { adults: 2, children: 0, childrenAges: [] },
  ]);

  const buttonRefs = useRef<any>([]);
  const maxRooms = 5;

  const incrementRooms = () => {
    if (noOfRooms < maxRooms) {
      setNoOfRooms(noOfRooms + 1);
      setTotalAdult(totalAdult + 1);
      const updated = [
        ...roomDetails,
        { adults: 1, children: 0, childrenAges: [] },
      ]
      setRoomDetails(updated);
      OnRoomDetailData(updated);
    }
  };

  const decrementRooms = () => {
    if (noOfRooms > 1) {
      setNoOfRooms(noOfRooms - 1);
      setTotalAdult(totalAdult - roomDetails[noOfRooms - 1].adults - roomDetails[noOfRooms - 1].children);
      const updated = roomDetails.slice(0, -1);
      setRoomDetails(updated);
      OnRoomDetailData(updated);
    }
  };

  const updateRoomDetails = (roomIndex: any, type: any, operation: any) => {
    let roomDetailsMap = [...roomDetails];
    let roomObj: any = { ...roomDetailsMap[roomIndex] };
    let newValue = operation === 'increment' ? roomObj[type] + 1 : roomObj[type] - 1;
    if (newValue < 0) newValue = 0;

    let newChildrenAges = [...roomObj?.childrenAges];
    if (type === 'children' && newValue >= 0) {
      newChildrenAges = operation === 'increment'
        ? [...newChildrenAges, 0]
        : newChildrenAges.slice(0, -1);
    }
    roomObj = { ...roomObj, [type]: newValue, childrenAges: newChildrenAges };
    roomDetailsMap[roomIndex] = roomObj;
    setRoomDetails(roomDetailsMap);
    OnRoomDetailData(roomDetailsMap);
  };

  const updateChildAge = (roomIndex: any, childIndex: any, age: any) => {
    const roomDetailMap = roomDetails.map((room: any, index: any) => {
      if (index === roomIndex) {
        const newChildrenAges = room.childrenAges.map((childAge: any, i: any) => {
          if (i === childIndex) {
            return age;
          }
          return childAge;
        });
        return { ...room, childrenAges: newChildrenAges };
      }
      return room;
    })
    setRoomDetails(roomDetailMap);
    OnRoomDetailData(roomDetailMap);
  };

  useEffect(() => {
    buttonRefs.current[0].disabled = noOfRooms <= 1;
    buttonRefs.current[1].disabled = noOfRooms >= maxRooms;
  }, [noOfRooms]);
  useEffect(() => {
    noOfRoom && setNoOfRooms(noOfRoom);
    roomPaxInfoPayload && setTotalAdult(roomPaxInfoPayload);
    roomPaxInfoPayload &&  setRoomDetails(roomPaxInfoPayload);

  }, [roomPaxInfoPayload, noOfRoom])

  return (
    <>
      <div className="frwrapper">
        <div onClick={() => setHotelGuests(!hotelGuests)} className="srchCon">
          <div className="srchRow">
            <div className="srchCol">
              <div className="mb-1">
                <span className="srchsml">
                  Room & Guests <i className="fa-solid fa-angle-down"></i>
                </span>
              </div>
              <div>
                <span className="srchTitle">{noOfRooms}</span>
                <span className="srchLabel">Rooms</span>
                <span className="srchTitle">
                  {roomDetails?.reduce((acc, room) => acc + room.adults, 0)}
                </span>
                <span className="srchLabel"> Adults</span>
                <span className="srchTitle">
                  {roomDetails?.reduce((acc, room) => acc + room.children, 0)}
                </span>
                <span className="srchLabel"> Children</span>
              </div>
            </div>
          </div>
        </div>

        <div className={`${hotelGuests ? 'travelersHotel' : 'd-none'}`}>
          <div id="room" className="row align-items-center">
            <div className="col-6">Rooms:</div>
            <div className="col-6">
              <div className="input-group">
                <button
                  className="input-group-text"
                  onClick={decrementRooms}
                  ref={(el) => (buttonRefs.current[0] = el)}
                >
                  <LuMinus />
                </button>
                <span className="inptval">{noOfRooms}</span>
                <button
                  className="input-group-text"
                  onClick={incrementRooms}
                  ref={(el) => (buttonRefs.current[1] = el)}
                >
                  <LuPlus />
                </button>
              </div>
            </div>
          </div>

          {roomDetails?.map((room, index) => (
            <section key={index}>
              <hr />
              <div className="row">
                <div className="col-6">
                  <div>Adults(12+)</div>
                  <div className="input-group">
                    <button
                      className="input-group-text"
                      onClick={() => updateRoomDetails(index, 'adults', 'decrement')}
                    >
                      <LuMinus />
                    </button>
                    <span className="inptval">{room.adults}</span>
                    <button
                      className="input-group-text"
                      onClick={() => updateRoomDetails(index, 'adults', 'increment')}
                    >
                      <LuPlus />
                    </button>
                  </div>
                </div>

                <div className="col-6">
                  <div>Children</div>
                  <div className="input-group">
                    <button
                      className="input-group-text"
                      onClick={() => updateRoomDetails(index, 'children', 'decrement')}
                    >
                      <LuMinus />
                    </button>
                    <span className="inptval">{room.children}</span>
                    <button
                      className="input-group-text"
                      onClick={() => updateRoomDetails(index, 'children', 'increment')}
                    >
                      <LuPlus />
                    </button>
                  </div>
                </div>

                {room?.childrenAges.map((age, childIndex) => (
                  <div key={childIndex} className="col-6">
                    <select
                      className="form-select mt-2"
                      value={age}
                      onChange={(e) => updateChildAge(index, childIndex, parseInt(e.target.value))}
                    >
                      {Array.from({ length: 18 }).map((_, age) => (
                        <option key={age} value={age}>{age} yr</option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>
            </section>
          ))}

          <div className="row">
            <div className="col-12 text-end">
              <hr />
              <button
                onClick={() => setHotelGuests(!hotelGuests)}
                className="btn btn-primary"
              >
                DONE
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
