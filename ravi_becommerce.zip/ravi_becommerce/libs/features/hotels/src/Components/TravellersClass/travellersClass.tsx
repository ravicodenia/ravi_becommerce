import classNames from 'classnames';
import { useState } from "react";
import styles from "../../../../flights/src/lib/oneway.module.scss";

const TravellersClass = ({ onAllTravellers, travellers }: any) => {
  const [istravellersClass, setIsTravellersClass] = useState(false);
  const [rooms, setrooms] = useState(
    travellers?.rooms ? travellers?.rooms : 0
  );
  const [children, setChildren] = useState(
    travellers?.children ? travellers?.children : 0
  );
  const [adults, setadults] = useState(
    travellers?.adults ? travellers?.adults : 0
  );
  const [selectedOption] = useState('economy');

  const openTravellersClass = () => {
    setIsTravellersClass(!istravellersClass);
    onAllTravellers({
      rooms: rooms,
      children: children,
      adults: adults,
      selectedOption: selectedOption,
    });
  };

  const handleIncrement = (type: any) => {
    switch (type) {
      case 'rooms':
        setrooms(rooms + 1);
        break;
      case 'children':
        setChildren(children + 1);
        break;
      case 'adults':
        setadults(adults + 1);
        break;
      default:
        break;
    }
  };

  const handleDecrement = (type: any) => {
    switch (type) {
      case 'rooms':
        setrooms(rooms > 0 ? rooms - 1 : 0);
        break;
      case 'children':
        setChildren(children > 0 ? children - 1 : 0);
        break;
      case 'adults':
        setadults(adults > 0 ? adults - 1 : 0);
        break;
      default:
        break;
    }
  };
  const TravellersDone = () => {
    setIsTravellersClass(!istravellersClass);
    onAllTravellers({
      rooms: rooms,
      children: children,
      adults: adults,
      selectedOption: selectedOption,
    });
  };

  return (
    <div className="frwrapper position-relative">
      <div
        className={classNames(styles['srchCon'], styles['srchConTravellers'])}
      >
        <div
          className={classNames(
            'py-2',
            styles['srchRow'],
            styles['selectflightpax']
          )}
          onClick={openTravellersClass}
        >
          <div className={styles['srchCon']}>
            <div>
              <span className={styles['srchsml']}>
                Room &amp; Guest{' '}
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                  <path d="M201.4 374.6c12.5 12.5 32.8 12.5 45.3 0l160-160c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L224 306.7 86.6 169.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l160 160z" />
                </svg>
              </span>
            </div>
            <div
              className="d-flex justify-content-start align-items-center gap-2"
              style={{ height: '27px' }}
            >
              {rooms}
              <span className={styles['srchLabel']}>Room</span>

              {children}
              <span className={styles['srchLabel']}>Adults</span>
            </div>
            <div>
            </div>
          </div>
        </div>
        <div
          id="div_flightPax"
          className={classNames(
            styles['travelersFlight'],
            `${istravellersClass ? 'd-block' : 'd-none'}`
          )}
        >
          <div className="row align-items-center mb-1">
            <div className="col-6">Rooms</div>
            <div className="col-6">
              <div className={classNames(styles['input-group'], 'input-group')}>
                <button
                  className={classNames(
                    styles['input-group-text'],
                    styles['dec-btn']
                  )}
                  onClick={() => handleDecrement('rooms')}
                  disabled={rooms === 0}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                    <path d="M432 256c0 17.7-14.3 32-32 32L48 288c-17.7 0-32-14.3-32-32s14.3-32 32-32l352 0c17.7 0 32 14.3 32 32z" />
                  </svg>
                </button>
                <input
                  type="text"
                  className={classNames(styles['form-control'], 'text-center')}
                  value={rooms}
                  disabled
                />
                <button
                  className={classNames(
                    styles['input-group-text'],
                    styles['inc-btn']
                  )}
                  onClick={() => handleIncrement('rooms')}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                    <path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z" />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          <div className="row align-items-center mb-1">
            <div className="col-6">Adults (12+) </div>
            <div className="col-6">
              <div className={classNames(styles['input-group'], 'input-group')}>
                <button
                  className={classNames(
                    styles['input-group-text'],
                    styles['dec-btn']
                  )}
                  onClick={() => handleDecrement('children')}
                  disabled={children === 0}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                    <path d="M432 256c0 17.7-14.3 32-32 32L48 288c-17.7 0-32-14.3-32-32s14.3-32 32-32l352 0c17.7 0 32 14.3 32 32z" />
                  </svg>
                </button>
                <input
                  type="text"
                  className={classNames(styles['form-control'], 'text-center')}
                  value={children}
                  disabled
                />
                <button
                  className={classNames(
                    styles['input-group-text'],
                    styles['inc-btn']
                  )}
                  onClick={() => handleIncrement('children')}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                    <path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z" />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          <div className="row align-items-center mb-1">
            <div className="col-6">Children
              (0 - 17 Years Old) </div>
            <div className="col-6">
              <div className={classNames(styles['input-group'], 'input-group')}>
                <button
                  className={classNames(
                    styles['input-group-text'],
                    styles['dec-btn']
                  )}
                  onClick={() => handleDecrement('adults')}
                  disabled={adults === 0}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                    <path d="M432 256c0 17.7-14.3 32-32 32L48 288c-17.7 0-32-14.3-32-32s14.3-32 32-32l352 0c17.7 0 32 14.3 32 32z" />
                  </svg>
                </button>
                <input
                  type="text"
                  className={classNames(styles['form-control'], 'text-center')}
                  value={adults}
                  disabled
                />
                <button
                  className={classNames(
                    styles['input-group-text'],
                    styles['inc-btn']
                  )}
                  onClick={() => handleIncrement('adults')}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                    <path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z" />
                  </svg>
                </button>
              </div>
            </div>
          </div>
          <div className="row mt-3 mb-2">
            <div className={classNames('col-lg-2')}>
              <button
                className={classNames(
                  styles['btn'],
                  styles['btn-primary'],
                  styles['btn-primarys'],
                  styles['close_div_flightPax']
                )}
                onClick={TravellersDone}
              >
                Done
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default TravellersClass;
