export * from './lib/hotels';
export { default as Hotel } from './lib/home';

export { default as HotelResults } from './lib/pages/hotelResults';
export { default as RoomDetails } from './lib/pages/roomDetails';
export { default as HotelPaxDetails } from './lib/pages/hotelPaxDetails';
export { default as HotelVoucher } from './lib/pages/hotelVoucher';

export { default as HotelQueue } from './lib/pages/hotelQueue';
export { default as ViewHotelInvoice } from './lib/pages/viewHotelInvoice';
export { default as ViewHotelVoucher } from './lib/pages/viewHotelVoucher';
export { default as HotelQueueOpen } from './lib/pages/hotelQueueOpen';



