import styles from './hotels.module.scss';

/* eslint-disable-next-line */
export interface HotelsProps {}

export function Hotel(props: HotelsProps) {
  return (
    <div className={styles['container']}>
      <h1>Welcome to Hotels!</h1>
    </div>
  );
}

export default Hotel;
