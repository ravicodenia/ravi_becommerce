import { useEffect, useState } from 'react';
import { MainLayout } from '@mfa-travel-app/layout';
import RdTophdr from '../../Components/HotelResults/RdTophdr';
import RdBedChkInOut from '../../Components/HotelResults/RdBedChkInOut';
import RdRtype from '../../Components/HotelResults/RdRtype';
import RdTotalPrice from '../../Components/HotelResults/RdTotalPrice';
import RdRoomChices from '../../Components/HotelResults/RdRoomChices';
import RdSelectRoom from '../../Components/HotelResults/RdSelectRoom';
import AmenitiesInfo from '../../Components/HotelResults/AmenitiesInfo';
import NearByAttraction from '../../Components/HotelResults/NearByAttraction';
import RdLocationMap from '../../Components/HotelResults/RdLocationMap';
import { useSelector } from 'react-redux';
import 'react-responsive-carousel/lib/styles/carousel.min.css'; // requires a loader
import { Carousel } from 'react-responsive-carousel';
import { useHotelStore, RootState } from '@mfa-travel-app/store';

export default function roomDetails() {
  const { saveRoomsDetails } = useHotelStore();
  const { selectedHotel, selectedHotelRoom, searchPayload, rooms } = useSelector(
    (state: RootState) => state.hotel
  );
  const [hotelInfo, setHotelInfo] = useState<any>({});
  const [mealFilters, setMealFilters] = useState<any>([])

  useEffect(() => {
    let filterNames: any = [];
    selectedHotelRoom?.roomDetails?.forEach((roomDetail: any) => {
      if (!filterNames.includes(roomDetail?.mealType)) {
        filterNames.push(roomDetail?.mealType);
      }
    });
    const filters = filterNames?.map((filterName: any) => ({
      filterName: filterName,
      checked: false,
    }));
    setMealFilters(filters);
  }, []);

  useEffect(() => {
    const selectedRooms: any = searchPayload?.roomPaxInfo?.map(
      (roomPax: any, index: any) => {
        const selectedRoom = selectedHotelRoom?.roomDetails?.find(
          (room: any) => room?.index === index + 1
        );
        const returnedRoom = { ...selectedRoom, roomPax };
        return returnedRoom;
      }
    );
    saveRoomsDetails(selectedRooms);
  }, [selectedHotelRoom]);

  useEffect(() => {
    let price = {
      totalPrice: 0,
      currency: '',
      discountprice: 0
    }
    rooms?.forEach((room: any) => {
      price.totalPrice += room.roomTotalPrice;
      price.totalPrice += room.roomTotalTax;
      price.currency = room.currency;
    })
    setHotelInfo(price);
  }, [rooms]);

  const handleChangeFilters = (filterName:string) => {
    let newFilters = mealFilters?.map((filter:any) => {
      if(filter?.filterName === filterName) {
        return {
          ...filter,
          checked: !filter?.checked
        }
      } else {
        return filter
      }
    })
    setMealFilters(newFilters)
  }

  return (
    <>
      <MainLayout>
        <RdTophdr />
       
       <div className='roomdetailsCon'> 
        <div className="container">
          <div className="row mt-4 mb-4">
            <div className="col-lg-8 align-items-center" id="PHOTOS">
              <Carousel autoPlay infiniteLoop showIndicators={false}>
                {selectedHotel?.hotelInfo?.images?.map(
                  (imageUrl: any, index: any) => (
                    <div key={index}>
                      <img src={imageUrl}/>
                    </div>
                  )
                )}
              </Carousel>
            </div>

            <div className="col-lg-4">
            
          
            <div className="rdchkoutvh">
             
              <RdBedChkInOut />
              {rooms?.map((room: any, index:any) => (
                <RdRtype details={room} key={index}/>
              ))}
              <RdTotalPrice priceInfo={hotelInfo} />
           </div>

            </div>
          </div>

          <div className="row">
            <div className="col-12" id="ROOM-RATES">
              {' '}
              <RdRoomChices mealFilters={mealFilters} handleChangeFilters={handleChangeFilters}/>{' '}
            </div>

            <div className="col-12">
              <RdSelectRoom mealFilters={mealFilters}/>
            </div>

            <div className="col-12 mt-4" id="HOTEL-AMENITIES">
              {' '}
              <AmenitiesInfo />{' '}
            </div>
            <div className="col-12 mt-4" id="ATTRACTIONS">
              {' '}
              <NearByAttraction />
            </div>

            <div className="col-12 mb-5 mt-5" id="MAP">
              <RdLocationMap />
            </div>
          </div>
        </div>
        </div>
      </MainLayout>
    </>
  );
}
