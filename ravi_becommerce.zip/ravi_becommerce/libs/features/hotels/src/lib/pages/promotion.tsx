import React, { useEffect, useState } from 'react';
import Grid from '@mui/material/Grid';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import SliderComponent from '../../Components/SliderComponent/slider';
import styles from '../../../../flights/src/lib/oneway.module.scss';
import {
  promoImg,
  flightsPromoImg,
  dubaiImg,
  carioImg,
} from '@mfa-travel-app/assets';

interface ImageBanner {
  id: number;
  agentId: number;
  imageFilePath: string;
  fileType: string;
  imageLabel: string;
  imageReturnUrl: string;
  bannerType: string;
  order: number;
}

const Promotions: React.FC = () => {
  const [mainSlider, setMainSlider] = useState<ImageBanner[]>([]);
  const [sideBig1, setSideBig1] = useState<ImageBanner[]>([]);
  const [sidesmall2, setSidesmall2] = useState<ImageBanner[]>([]);
  const [sidesmall1, setSidesmall1] = useState<ImageBanner[]>([]);
  // const imageBanner: ImageBanner[] = [
  //   {
  //     id: 1,
  //     agentId: 1,
  //     imageFilePath:
  //       'http://bcom.b2b.pierofcloudtech.com/assets/png/promo-img.png',
  //     fileType: 'png',
  //     imageLabel: 'Travelrestriction',
  //     imageReturnUrl: 'https://www.airindia.com/in/en/book/special-offers.html',
  //     bannerType: 'MainSlider',
  //     order: 1,
  //   },
  //   {
  //     id: 2,
  //     agentId: 1,
  //     imageFilePath:
  //       'http://bcom.b2b.pierofcloudtech.com/assets/png/flights-promo-img.png',
  //     fileType: 'png',
  //     imageLabel: 'Flightpromo',
  //     imageReturnUrl: 'https://www.airindia.com/in/en/book/special-offers.html',
  //     bannerType: 'SideBig1',
  //     order: 1,
  //   },
  //   {
  //     id: 3,
  //     agentId: 1,
  //     imageFilePath: 'http://bcom.b2b.pierofcloudtech.com/assets/png/dubai.png',
  //     fileType: 'png',
  //     imageLabel: 'DubaiHoliday',
  //     imageReturnUrl: 'https://www.airindia.com/in/en/manage/web-checkin.html',
  //     bannerType: 'Sidesmall1',
  //     order: 1,
  //   },
  //   {
  //     id: 4,
  //     agentId: 1,
  //     imageFilePath: 'http://bcom.b2b.pierofcloudtech.com/assets/png/cairo.png',
  //     fileType: 'png',
  //     imageLabel: 'Cairoholidays',
  //     imageReturnUrl:
  //       'https://www.thomascook.in/holidays/international-tour-packages/egypt-tour-packages/egyptian-dhamaka?pkgId=PKG012160&packageClassId=0&destination=PKG012160_egypt_COUNTRY_1&destTag=Egypt&https://www.thomascook.in/holidays/international-tour-packages/egypt-tour-packages',
  //     bannerType: 'Sidesmall2',
  //     order: 1,
  //   },
  //   {
  //     id: 5,
  //     agentId: 1,
  //     imageFilePath:
  //       'http://bcom.b2b.pierofcloudtech.com/assets/png/promo-img.png',
  //     fileType: 'png',
  //     imageLabel: 'Travelrestriction',
  //     imageReturnUrl: 'https://www.airindia.com/in/en/book/special-offers.html',
  //     bannerType: 'MainSlider',
  //     order: 2,
  //   },
  //   {
  //     id: 6,
  //     agentId: 1,
  //     imageFilePath:
  //       'http://bcom.b2b.pierofcloudtech.com/assets/png/flights-promo-img.png',
  //     fileType: 'png',
  //     imageLabel: 'Flightpromo',
  //     imageReturnUrl: 'https://www.airindia.com/in/en/book/special-offers.html',
  //     bannerType: 'SideBig1',
  //     order: 2,
  //   },
  //   {
  //     id: 7,
  //     agentId: 1,
  //     imageFilePath: 'http://bcom.b2b.pierofcloudtech.com/assets/png/dubai.png',
  //     fileType: 'png',
  //     imageLabel: 'DubaiHoliday',
  //     imageReturnUrl: 'https://www.airindia.com/in/en/manage/web-checkin.html',
  //     bannerType: 'Sidesmall1',
  //     order: 2,
  //   },
  //   {
  //     id: 8,
  //     agentId: 1,
  //     imageFilePath: 'http://bcom.b2b.pierofcloudtech.com/assets/png/cairo.png',
  //     fileType: 'png',
  //     imageLabel: 'Cairoholidays',
  //     imageReturnUrl:
  //       'https://www.thomascook.in/holidays/international-tour-packages/egypt-tour-packages/egyptian-dhamaka?pkgId=PKG012160&packageClassId=0&destination=PKG012160_egypt_COUNTRY_1&destTag=Egypt&https://www.thomascook.in/holidays/international-tour-packages/egypt-tour-packages',
  //     bannerType: 'Sidesmall2',
  //     order: 2,
  //   },
  //   {
  //     id: 9,
  //     agentId: 1,
  //     imageFilePath:
  //       'http://bcom.b2b.pierofcloudtech.com/assets/png/promo-img.png',
  //     fileType: 'png',
  //     imageLabel: 'Travelrestriction',
  //     imageReturnUrl: 'https://www.airindia.com/in/en/book/special-offers.html',
  //     bannerType: 'MainSlider',
  //     order: 3,
  //   },
  //   {
  //     id: 10,
  //     agentId: 1,
  //     imageFilePath:
  //       'http://bcom.b2b.pierofcloudtech.com/assets/png/flights-promo-img.png',
  //     fileType: 'png',
  //     imageLabel: 'Flightpromo',
  //     imageReturnUrl: 'https://www.airindia.com/in/en/book/special-offers.html',
  //     bannerType: 'SideBig1',
  //     order: 3,
  //   },
  //   {
  //     id: 11,
  //     agentId: 1,
  //     imageFilePath: 'http://bcom.b2b.pierofcloudtech.com/assets/png/dubai.png',
  //     fileType: 'png',
  //     imageLabel: 'DubaiHoliday',
  //     imageReturnUrl: 'https://www.airindia.com/in/en/manage/web-checkin.html',
  //     bannerType: 'Sidesmall1',
  //     order: 3,
  //   },
  //   {
  //     id: 12,
  //     agentId: 1,
  //     imageFilePath: 'http://bcom.b2b.pierofcloudtech.com/assets/png/cairo.png',
  //     fileType: 'png',
  //     imageLabel: 'Cairoholidays',
  //     imageReturnUrl:
  //       'https://www.thomascook.in/holidays/international-tour-packages/egypt-tour-packages/egyptian-dhamaka?pkgId=PKG012160&packageClassId=0&destination=PKG012160_egypt_COUNTRY_1&destTag=Egypt&https://www.thomascook.in/holidays/international-tour-packages/egypt-tour-packages',
  //     bannerType: 'Sidesmall2',
  //     order: 3,
  //   },
  // ];

  const imageBanner: ImageBanner[] = [
    {
      id: 1,
      agentId: 1,
      imageFilePath: promoImg,
      fileType: 'png',
      imageLabel: 'Travelrestriction',
      imageReturnUrl: 'https://www.airindia.com/in/en/book/special-offers.html',
      bannerType: 'MainSlider',
      order: 1,
    },
    {
      id: 2,
      agentId: 1,
      imageFilePath: flightsPromoImg,
      fileType: 'png',
      imageLabel: 'Flightpromo',
      imageReturnUrl: 'https://www.airindia.com/in/en/book/special-offers.html',
      bannerType: 'SideBig1',
      order: 1,
    },
    {
      id: 3,
      agentId: 1,
      imageFilePath: dubaiImg,
      fileType: 'png',
      imageLabel: 'DubaiHoliday',
      imageReturnUrl: 'https://www.airindia.com/in/en/manage/web-checkin.html',
      bannerType: 'Sidesmall1',
      order: 1,
    },
    {
      id: 4,
      agentId: 1,
      imageFilePath: carioImg,
      fileType: 'png',
      imageLabel: 'Cairoholidays',
      imageReturnUrl:
        'https://www.thomascook.in/holidays/international-tour-packages/egypt-tour-packages/egyptian-dhamaka?pkgId=PKG012160&packageClassId=0&destination=PKG012160_egypt_COUNTRY_1&destTag=Egypt&https://www.thomascook.in/holidays/international-tour-packages/egypt-tour-packages',
      bannerType: 'Sidesmall2',
      order: 1,
    },
    {
      id: 5,
      agentId: 1,
      imageFilePath: promoImg,
      fileType: 'png',
      imageLabel: 'Travelrestriction',
      imageReturnUrl: 'https://www.airindia.com/in/en/book/special-offers.html',
      bannerType: 'MainSlider',
      order: 2,
    },
    {
      id: 6,
      agentId: 1,
      imageFilePath: flightsPromoImg,
      fileType: 'png',
      imageLabel: 'Flightpromo',
      imageReturnUrl: 'https://www.airindia.com/in/en/book/special-offers.html',
      bannerType: 'SideBig1',
      order: 2,
    },
    {
      id: 7,
      agentId: 1,
      imageFilePath: dubaiImg,
      fileType: 'png',
      imageLabel: 'DubaiHoliday',
      imageReturnUrl: 'https://www.airindia.com/in/en/manage/web-checkin.html',
      bannerType: 'Sidesmall1',
      order: 2,
    },
    {
      id: 8,
      agentId: 1,
      imageFilePath: carioImg,
      fileType: 'png',
      imageLabel: 'Cairoholidays',
      imageReturnUrl:
        'https://www.thomascook.in/holidays/international-tour-packages/egypt-tour-packages/egyptian-dhamaka?pkgId=PKG012160&packageClassId=0&destination=PKG012160_egypt_COUNTRY_1&destTag=Egypt&https://www.thomascook.in/holidays/international-tour-packages/egypt-tour-packages',
      bannerType: 'Sidesmall2',
      order: 2,
    },
    {
      id: 9,
      agentId: 1,
      imageFilePath: promoImg,
      fileType: 'png',
      imageLabel: 'Travelrestriction',
      imageReturnUrl: 'https://www.airindia.com/in/en/book/special-offers.html',
      bannerType: 'MainSlider',
      order: 3,
    },
    {
      id: 10,
      agentId: 1,
      imageFilePath: flightsPromoImg,
      fileType: 'png',
      imageLabel: 'Flightpromo',
      imageReturnUrl: 'https://www.airindia.com/in/en/book/special-offers.html',
      bannerType: 'SideBig1',
      order: 3,
    },
    {
      id: 11,
      agentId: 1,
      imageFilePath: dubaiImg,
      fileType: 'png',
      imageLabel: 'DubaiHoliday',
      imageReturnUrl: 'https://www.airindia.com/in/en/manage/web-checkin.html',
      bannerType: 'Sidesmall1',
      order: 3,
    },
    {
      id: 12,
      agentId: 1,
      imageFilePath: carioImg,
      fileType: 'png',
      imageLabel: 'Cairoholidays',
      imageReturnUrl:
        'https://www.thomascook.in/holidays/international-tour-packages/egypt-tour-packages/egyptian-dhamaka?pkgId=PKG012160&packageClassId=0&destination=PKG012160_egypt_COUNTRY_1&destTag=Egypt&https://www.thomascook.in/holidays/international-tour-packages/egypt-tour-packages',
      bannerType: 'Sidesmall2',
      order: 3,
    },
  ];
  useEffect(() => {
    if (imageBanner && imageBanner.length > 0) {
      setMainSlider(
        imageBanner.filter((item: any) => item.bannerType == 'MainSlider')
      );
      setSideBig1(
        imageBanner.filter((item: any) => item.bannerType == 'SideBig1')
      );
      setSidesmall2(
        imageBanner.filter((item: any) => item.bannerType == 'Sidesmall2')
      );
      setSidesmall1(
        imageBanner.filter((item: any) => item.bannerType == 'Sidesmall1')
      );
    }
  }, []);

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true, // Enable auto-scroll
    autoplaySpeed: 3000,
  };
  return (
    <React.Fragment>
      <section className="promotions">
        <section className="banner-sec py-3">
          <div>
            <Grid container>
              <Grid item xs={6}>
                <div className={styles['padding-right']}>
                  <Grid container>
                    <Grid item xs={12}>
                      <SliderComponent ImageData={mainSlider} />
                    </Grid>
                  </Grid>
                </div>
              </Grid>
              <Grid item xs={6}>
                <div className={styles['padding-left']}>
                  <Grid container>
                    <Grid item xs={12} className="mb-3 ">
                      <SliderComponent ImageData={sideBig1} />
                    </Grid>
                    <Grid item xs={6}>
                      <div className={styles['paddLeft']}>
                        <SliderComponent ImageData={sidesmall2} />
                      </div>
                    </Grid>
                    <Grid item xs={6}>
                      <div className={styles['paddRight']}>
                        <SliderComponent ImageData={sidesmall1} />
                      </div>
                    </Grid>
                  </Grid>
                </div>
              </Grid>
            </Grid>
          </div>
        </section>
      </section>
    </React.Fragment>
  );
};

export default Promotions;
