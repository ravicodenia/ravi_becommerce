import { MainLayout } from '@mfa-travel-app/layout';
// import FlightQueeModal from '../components/tQFilter';

import Paging from 'libs/masters/role-master/src/lib/components/paging';
import ViewPerPage from 'libs/masters/role-master/src/lib/components/viewPerPage';
import { ControlledSelect, ControlledInput, ControlledDatePicker } from '@mfa-travel-app/ui';
import HotelQDropdown from '../../Components/HotelQueue/hotelQDropdown';

export default function HotelQueue() {

    const selectOptions = [
        { id: 1, text: 'First Option' },
        { id: 2, text: 'Second Option' },
    ];

  return (
    <>
    <MainLayout>

      <div className="container">
      <section className="country_section mt-2 mb-3 font_size_90">


      <div className="row mt-3">
   
   <div className="col-lg-3">

   <div className="row align-items-center mb-2">
                  <label htmlFor="fromDate" className="col-lg-5">From Date :</label>
                  <div className="col-lg-7">
                  <ControlledDatePicker
                      id={'fromDate'}
                      value={''}
                      format={'dd/MMM/yyyy'}
                      required={true}
                      onChange={''}
                  />
                  </div>
              </div>

      </div>


      <div className="col-lg-3">

<div className="row align-items-center mb-2">
             <label htmlFor="tomDate" className="col-lg-5">To Date :</label>
             <div className="col-lg-7">
             <ControlledDatePicker
                      id={'tomDate'}
                      value={''}
                      format={'dd/MMM/yyyy'}
                      required={true}
                      onChange={''}
                  />
             </div>
         </div>

 </div>

 <div className="col-lg-3">

<div className="row align-items-center mb-2">
             <label htmlFor="bookingstatus" className="col-lg-5">Booking Status :</label>
             <div className="col-lg-7">
             <ControlledSelect
                 id={'bookingstatus'}
                 value={''}
                 options={selectOptions}
                 required={true}
                 onChange={''}
             />
             </div>
         </div>

 </div>

 <div className="col-lg-3">

<div className="row align-items-center mb-2">
             <label htmlFor="agent" className="col-lg-5">Agent :</label>
             <div className="col-lg-7">
             <ControlledSelect
                 id={'firm'}
                 value={''}
                 options={selectOptions}
                 required={true}
                 onChange={''}
             />
             </div>
         </div>

 </div>

 <div className="col-lg-3">

<div className="row align-items-center mb-2">
             <label htmlFor="b2b" className="col-lg-5">B2B  </label>
             <div className="col-lg-7">
             <ControlledSelect
                 id={'firm'}
                 value={''}
                 options={selectOptions}
                 required={true}
                 onChange={''}
             />
             </div>
         </div>

 </div>

 <div className="col-lg-3">

<div className="row align-items-center mb-2">
             <label htmlFor="b2b2b" className="col-lg-5">B2B2B :</label>
             <div className="col-lg-7">
             <ControlledSelect
                 id={'b2b2b'}
                 value={''}
                 options={selectOptions}
                 required={true}
                 onChange={''}
             />
             </div>
         </div>

 </div>

 <div className="col-lg-3">

<div className="row align-items-center mb-2">
             <label htmlFor="location" className="col-lg-5">Location :</label>
             <div className="col-lg-7">
             <ControlledSelect
                 id={'location'}
                 value={''}
                 options={selectOptions}
                 required={true}
                 onChange={''}
             />
             </div>
         </div>

 </div>



 <div className="col-lg-3">

<div className="row align-items-center mb-2">
             <label htmlFor="confirmation_no" className="col-lg-5">Conf. No. :</label>
             <div className="col-lg-7">
   
             <ControlledInput
                      id={'confirmation_no'}
                      value={''}
                      type={'text'}
                      required={true}
                      onChange={''}
                  />
             </div>
         </div>

 </div>


 <div className="col-lg-3">

<div className="row align-items-center mb-2">
             <label htmlFor="hotel_name" className="col-lg-5">Hotel :</label>
             <div className="col-lg-7">
             <ControlledInput
                      id={'hotel_name'}
                      value={''}
                      type={'text'}
                      required={true}
                      onChange={''}
                  />
             </div>
         </div>

 </div>

 <div className="col-lg-3">

<div className="row align-items-center mb-2">
             <label htmlFor="paxname" className="col-lg-5">Pax Name  :</label>
             <div className="col-lg-7">
             <ControlledInput
                      id={'paxname'}
                      value={''}
                      type={'text'}
                      required={true}
                      onChange={''}
                  />
             </div>
         </div>

 </div>

 <div className="col-lg-3">

<div className="row align-items-center mb-2">
             <label htmlFor="transtype" className="col-lg-5">TransType:</label>
             <div className="col-lg-7">
             <ControlledSelect
                 id={'transtype'}
                 value={''}
                 options={selectOptions}
                 required={true}
                 onChange={''}
             />
             </div>
         </div>

 </div>


 <div className="col-lg-3">

<div className="row align-items-center mb-2">
             <label htmlFor="Supplier " className="col-lg-5">Supplier :</label>
             <div className="col-lg-7">
             <ControlledSelect
                 id={'Supplier '}
                 value={''}
                 options={selectOptions}
                 required={true}
                 onChange={''}
             />
             </div>
         </div>

 </div>

 <div className="col-lg-12 text-end">
         
 <button className='btn btn-sm btn-primary rounded mt-2'>Search </button>

  </div>

      </div>


       <div className="row mt-2">
   
   <div className="col-12">
     <div className="table-responsive">
       <table className="table text-secondary">
   <thead>
  
   <tr className='align-middle'>
   <th scope="col">SN</th>
   <th scope="col">Supplier Ref:</th>
   <th scope="col">Confirmation No:   </th>
   <th scope="col">Status   </th>
   <th scope="col">Hotel   </th>
   <th className='text-center' scope="col">Rooms   </th>
   <th scope="col">Guests   </th>
   <th  className='text-center' scope="col">Provider   </th>
   <th scope="col">Location</th>
   <th scope="col">Created By</th>
   <th scope="col">Pax Name     </th>
   <th scope="col">Total Price</th>
   <th scope="col">Check In   </th>
   <th scope="col">Check Out   </th>
   <th scope="col">Agent Ref:   </th>
   <th scope="col">Actions</th>

  


   <th> </th>
   </tr>
   </thead>
   <tbody>

   <tr>
   <td> 1 </td>
   <td> -- </td>
   <td>15093 </td>
   <td><span className='text-danger'>Pending</span> </td>
   <td>Mount Royal Hotel </td>
   <td className='text-center'><b>1</b> </td>
   <td><b>1 Adults(1) Childs (0)</b></td>
   <td className='text-center'>lbyta </td>
   <td><span>Sharjah </span> </td>
   <td>Admin </td>
   <td>Mr, Pawan Kumar </td>
   <td>139.00 </td>
   <td>20-May-2024 00:00:00 </td>
   <td>21-May-2024 00:00:00 </td>
   <td>HTL-CZ-81095 </td>
   <td className='btnDropMenu'>              
   
   <HotelQDropdown/>
   </td>
   </tr>

   <tr>
   <td> 2 </td>
   <td> -- </td>
   <td>15093 </td>
   <td><span className='text-danger'>Pending</span> </td>
   <td>Mount Royal Hotel </td>
   <td className='text-center'><b>1</b> </td>
   <td><b>1 Adults(1) Childs (0)</b></td>
   <td className='text-center'>lbyta </td>
   <td><span>Sharjah </span> </td>
   <td>Admin </td>
   <td>Mr, Pawan Kumar </td>
   <td>139.00 </td>
   <td>20-May-2024 00:00:00 </td>
   <td>21-May-2024 00:00:00 </td>
   <td>HTL-CZ-81095 </td>
   <td className='btnDropMenu'>              
   
   <HotelQDropdown/>
   </td>
   </tr>


   <tr>
   <td> 3 </td>
   <td> -- </td>
   <td>15093 </td>
   <td><span className='text-danger'>Pending</span> </td>
   <td>Mount Royal Hotel </td>
   <td className='text-center'><b>1</b> </td>
   <td><b>1 Adults(1) Childs (0)</b></td>
   <td className='text-center'>lbyta </td>
   <td><span>Sharjah </span> </td>
   <td>Admin </td>
   <td>Mr, Pawan Kumar </td>
   <td>139.00 </td>
   <td>20-May-2024 00:00:00 </td>
   <td>21-May-2024 00:00:00 </td>
   <td>HTL-CZ-81095 </td>
   <td className='btnDropMenu'>              
   
   <HotelQDropdown/>
   </td>
   </tr>


   <tr>
   <td> 4 </td>
   <td> -- </td>
   <td>15093 </td>
   <td><span className='text-danger'>Pending</span> </td>
   <td>Mount Royal Hotel </td>
   <td className='text-center'><b>1</b> </td>
   <td><b>1 Adults(1) Childs (0)</b></td>
   <td className='text-center'>lbyta </td>
   <td><span>Sharjah </span> </td>
   <td>Admin </td>
   <td>Mr, Pawan Kumar </td>
   <td>139.00 </td>
   <td>20-May-2024 00:00:00 </td>
   <td>21-May-2024 00:00:00 </td>
   <td>HTL-CZ-81095 </td>
   <td className='btnDropMenu'>              
   
   <HotelQDropdown/>
   </td>
   </tr>


   <tr>
   <td> 5 </td>
   <td> -- </td>
   <td>15093 </td>
   <td><span className='text-danger'>Pending</span> </td>
   <td>Mount Royal Hotel </td>
   <td className='text-center'><b>1</b> </td>
   <td><b>1 Adults(1) Childs (0)</b></td>
   <td className='text-center'>lbyta </td>
   <td><span>Sharjah </span> </td>
   <td>Admin </td>
   <td>Mr, Pawan Kumar </td>
   <td>139.00 </td>
   <td>20-May-2024 00:00:00 </td>
   <td>21-May-2024 00:00:00 </td>
   <td>HTL-CZ-81095 </td>
   <td className='btnDropMenu'>              
   
   <HotelQDropdown/>
   </td>
   </tr>



   <tr>
   <td> 6 </td>
   <td> -- </td>
   <td>15093 </td>
   <td><span className='text-danger'>Pending</span> </td>
   <td>Mount Royal Hotel </td>
   <td className='text-center'><b>1</b> </td>
   <td><b>1 Adults(1) Childs (0)</b></td>
   <td className='text-center'>lbyta </td>
   <td><span>Sharjah </span> </td>
   <td>Admin </td>
   <td>Mr, Pawan Kumar </td>
   <td>139.00 </td>
   <td>20-May-2024 00:00:00 </td>
   <td>21-May-2024 00:00:00 </td>
   <td>HTL-CZ-81095 </td>
   <td className='btnDropMenu'>              
   
   <HotelQDropdown/>
   </td>
   </tr>



   <tr>
   <td> 7 </td>
   <td> -- </td>
   <td>15093 </td>
   <td><span className='text-danger'>Pending</span> </td>
   <td>Mount Royal Hotel </td>
   <td className='text-center'><b>1</b> </td>
   <td><b>1 Adults(1) Childs (0)</b></td>
   <td className='text-center'>lbyta </td>
   <td><span>Sharjah </span> </td>
   <td>Admin </td>
   <td>Mr, Pawan Kumar </td>
   <td>139.00 </td>
   <td>20-May-2024 00:00:00 </td>
   <td>21-May-2024 00:00:00 </td>
   <td>HTL-CZ-81095 </td>
   <td className='btnDropMenu'>              
   
   <HotelQDropdown/>
   </td>
   </tr>


   <tr>
   <td> 8 </td>
   <td> -- </td>
   <td>15093 </td>
   <td><span className='text-danger'>Pending</span> </td>
   <td>Mount Royal Hotel </td>
   <td className='text-center'><b>1</b> </td>
   <td><b>1 Adults(1) Childs (0)</b></td>
   <td className='text-center'>lbyta </td>
   <td><span>Sharjah </span> </td>
   <td>Admin </td>
   <td>Mr, Pawan Kumar </td>
   <td>139.00 </td>
   <td>20-May-2024 00:00:00 </td>
   <td>21-May-2024 00:00:00 </td>
   <td>HTL-CZ-81095 </td>
   <td className='btnDropMenu'>              
   
   <HotelQDropdown/>
   </td>
   </tr>



   <tr>
   <td> 9 </td>
   <td> -- </td>
   <td>15093 </td>
   <td><span className='text-danger'>Pending</span> </td>
   <td>Mount Royal Hotel </td>
   <td className='text-center'><b>1</b> </td>
   <td><b>1 Adults(1) Childs (0)</b></td>
   <td className='text-center'>lbyta </td>
   <td><span>Sharjah </span> </td>
   <td>Admin </td>
   <td>Mr, Pawan Kumar </td>
   <td>139.00 </td>
   <td>20-May-2024 00:00:00 </td>
   <td>21-May-2024 00:00:00 </td>
   <td>HTL-CZ-81095 </td>
   <td className='btnDropMenu'>              
   
   <HotelQDropdown/>
   </td>
   </tr>



   <tr>
   <td> 10 </td>
   <td> -- </td>
   <td>15093 </td>
   <td><span className='text-danger'>Pending</span> </td>
   <td>Mount Royal Hotel </td>
   <td className='text-center'><b>1</b> </td>
   <td><b>1 Adults(1) Childs (0)</b></td>
   <td className='text-center'>lbyta </td>
   <td><span>Sharjah </span> </td>
   <td>Admin </td>
   <td>Mr, Pawan Kumar </td>
   <td>139.00 </td>
   <td>20-May-2024 00:00:00 </td>
   <td>21-May-2024 00:00:00 </td>
   <td>HTL-CZ-81095 </td>
   <td className='btnDropMenu'>              
   
   <HotelQDropdown/>
   </td>
   </tr>


   </tbody>
   </table>
   </div>
   </div>

   </div>

   <div className="row align-items-center">

     <div className="col-lg-8">
     <Paging/>
     </div>

     <div className="col-lg-4">

     <ViewPerPage/>

</div> 



           


   </div>

      </section>
  
  </div>
  </MainLayout>
  </>
  )
}
