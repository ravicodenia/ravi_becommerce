
import { useState } from 'react';
// import { PhoneInput } from 'react-international-phone';
// import 'react-international-phone/style.css';

//

import IntlTelInput from "intl-tel-input/react";
import "intl-tel-input/styles";
//



export default function ViewHotelVoucher() {


	// const [phone, setPhone] = useState('');

  
  const style = {
    cursor: "pointer",
    border: "2px solid #b1b1b1",
    borderRadius: "8px",
    padding: "0px 10px 0px 10px",
    backgroundColor: "green"
}


  return (
 


    <>
    
<div className='container mt-5'> 

    <div className='row mt-5'> 

	<div className='col-8'> 


  </div>




	<div className='col-4'>
	
	<div className="input-group mb-3">
  <span style={{background:'none', border:'none'}} className="input-group-text" id="basic-addon1">Phone:</span>
  {/* <PhoneInput
        defaultCountry="ua"
        value={phone}
        onChange={(phone) => setPhone(phone)}
      /> */}

<IntlTelInput 
    initOptions={{
        initialCountry: "in",
        utilsScript: "https://cdn.jsdelivr.net/npm/intl-tel-input@23.8.1/build/js/utils.js",
        
    }}
/>
</div>


		</div>

</div>
    
</div>
    </>



  )
}
