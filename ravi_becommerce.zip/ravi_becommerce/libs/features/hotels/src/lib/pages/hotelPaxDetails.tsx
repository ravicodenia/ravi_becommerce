import { MainLayout } from '@mfa-travel-app/layout';
import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import RdBedChkInOut from '../../Components/HotelResults/RdBedChkInOut';
import RdRtype from '../../Components/HotelResults/RdRtype';
import RdTotalPrice from '../../Components/HotelResults/RdTotalPrice';
import PromoCode from '../../Components/HotelPax/PromoCode';
import AddMarkup from '../../Components/HotelPax/AddMarkup';
import ContactInfo from '../../Components/HotelPax/ContactInfo';
import SearchPax from '../../Components/HotelPax/SearchPax';
import HotelAdultPax from '../../Components/HotelResults/HotelAdultPax';
import HotelPaxAddress from '../../Components/HotelResults/HotelPaxAddress';
import SpecialRequest from '../../Components/HotelResults/SpecialRequest';
import EssentialInfo from '../../Components/HotelResults/EssentialInfo';
import { RootState, useHotelStore } from '@mfa-travel-app/store';
import { bookHotelRoom } from '../service/hotelApi';
import { Loader } from '@mfa-travel-app/ui';
import { toast } from 'react-toastify';
import { getBalance } from '@mfa-travel-app/shared';
import { useStore } from '@mfa-travel-app/store';

import { FiChevronDown } from "react-icons/fi";
import { FiChevronUp } from "react-icons/fi";


export default function hotelPaxDetails() {
  const navigate = useNavigate()
  const { searchPayload, selectedHotelRoom, rooms } =
    useSelector((state: RootState) => state.hotel);
  const { balanceInfo }: any = useSelector(
    (state: RootState) => state.config
  );
  const [contactInfo, setContactInfo] = useState({
    email: '',
    mobileNo: '',
  });
  const [guestInfo, setGuestInfo] = useState([]);
  const [address, setAddress] = useState<any>([]);
  const [hotelInfo, setHotelInfo] = useState<any>([]);
  const [loader, setLoader] = useState(false)
  const { saveHotelBookingDetails, saveHotelBookingPassengerDetails } = useHotelStore();
  const { saveBalanceDetails } = useStore();
  const { saveHotelErrorMessageDetail } = useHotelStore();
  const [markUpVal, setMarkUpVal] = useState(
    { markupType: '', markupValue: '0', markupAmount: 0 }
  );

  useEffect(() => {
    let allGuestsInfo: any = [];
    let guestNo = 0;
    rooms?.map((room: any) => {
      let roomGuests: any = {};
      let adults = [];
      let children = [];
      if (room?.roomPax?.adults > 0) {
        for (let i = 0; i < room?.roomPax?.adults; i++) {
          guestNo++;
          adults.push({
            roomIndex: room?.index,
            guestNo: guestNo,
            title: '01',
            firstName: '',
            lastName: '',
          });
        }
      }
      if (room?.roomPax?.children > 0) {
        for (let i = 0; i < room?.roomPax?.children; i++) {
          guestNo++;
          children.push({
            roomIndex: room?.index,
            guestNo: guestNo,
            title: '01',
            firstName: '',
            lastName: '',
          });
        }
      }
      if (adults.length > 0) {
        roomGuests.adults = adults;
      }
      if (children.length > 0) {
        roomGuests.children = children;
      }
      allGuestsInfo.push(roomGuests);
    });
    setGuestInfo(allGuestsInfo);

    let address: any = [];
    rooms?.map((room: any) => {
      const addr = {
        roomIndex: room?.index,
        address: { address1: '', address2: '' },
      };
      address.push(addr);
    });
    setAddress(address);
  }, []);

  const onContactChange = (value: any) => {
    setContactInfo(value);
  };

  const handleInfoChange = (guestNo: any, data: any) => {
    const updatedGuestInfo: any = guestInfo.map((room: any) => {
      return {
        adults: room?.adults?.map((p: any) => {
          if (p.guestNo === guestNo) {
            return data;
          } else return p;
        }),
        children: room?.children?.map((p: any) => {
          if (p.guestNo === guestNo) {
            return data;
          } else return p;
        }),
      };
    });
    setGuestInfo(updatedGuestInfo);
  };

  const handleAddressChange = (roomNo: any, addressData: any) => {
    const newAddress: any = address?.map((paxAddress: any) => {
      if (paxAddress?.roomIndex === roomNo) {
        return {
          ...paxAddress,
          address: addressData,
        };
      } else return paxAddress;
    });
    setAddress(newAddress);
  };

  const [chkTermsBtn, setChkTermsBtn] = useState(true);

  const toggleChkDisableButton = () => {
    !isNaN(balanceInfo?.currentBalance) && !isNaN(hotelInfo.totalPrice) && balanceInfo?.currentBalance && setChkTermsBtn(!chkTermsBtn);
  };
  useEffect(() => {
    let price = {
      totalPrice: 0,
      currency: '',
      discountprice: 0,
    };
    rooms?.forEach((room: any) => {
      price.totalPrice += room.roomTotalPrice;
      price.totalPrice += room.roomTotalTax;
      price.currency = room.currency;
    });
    setHotelInfo(price);
  }, [rooms]);
  const handleBookRoom = async () => {
    setLoader(true)
    try {
      const response: any = await getBalance(1);
      saveBalanceDetails(response?.data);
    } catch (error) {
      console.error('Error fetching balance:', error);
    }
    const passengersInfo: any = [];
    guestInfo?.forEach((room: any) => {
      const passengers: any = [];
      room?.adults?.forEach((adult: any) => {
        const pax: any = {
          roomIndex: adult?.roomIndex.toString(),
          title: adult?.title === '01' ? 'Mr' : 'Mrs',
          firstname: adult?.firstName,
          lastname: adult?.lastName,
          phoneNo: contactInfo?.mobileNo,
          cityName: (address?.filter((add: any) => add?.roomIndex === adult?.roomIndex))[0]?.address?.address1,
          countryName: (address?.filter((add: any) => add?.roomIndex === adult?.roomIndex))[0]?.address?.address2,
          nationalityCode: searchPayload?.nationalityCode,
          email: contactInfo?.email,
          isLeadpax: adult?.guestNo === 1 ? true : false,
          paxType: 'Adult',
        };
        passengers?.push(pax);
      });
      room?.children?.forEach((child: any) => {
        const pax: any = {
          roomIndex: child?.roomIndex.toString(),
          title: child?.title === '01' ? 'Mr' : 'Mrs',
          firstname: child?.firstName,
          lastname: child?.lastName,
          phoneNo: contactInfo?.mobileNo,
          cityName: (address?.filter((add: any) => add?.roomIndex === child?.roomIndex))[0]?.address?.address1,
          countryName: (address?.filter((add: any) => add?.roomIndex === child?.roomIndex))[0]?.address?.address2,
          nationalityCode: searchPayload?.nationalityCode,
          email: contactInfo?.email,
          isLeadpax: child?.guestNo === 1 ? true : false,
          paxType: 'Child',
        };
        passengers?.push(pax);
      });
      const roomData = { passengers: passengers };
      passengersInfo.push(roomData);
    });
    saveHotelBookingPassengerDetails(passengersInfo)
    const data = {
      sessionId: selectedHotelRoom?.sessionId,
      hotelId: selectedHotelRoom?.hotelId,
      hotelCode: selectedHotelRoom?.hotelCode,
      hotelReferenceCode: rooms[0].roomBookingKey,
      passengerInfo: passengersInfo,
      specialRequest: '',
      addlMarkUpType: markUpVal?.markupType,
      addlMarkUpValue: "" + markUpVal?. markupValue,
      addlMarkupAmount: Number(markUpVal?.markupAmount),
      totalPrice: rooms[0].supplierPrice
    };

    try {
      const response: any = await bookHotelRoom(data);
      if (response.stateCode == 200 || response?.data?.result) {
        setLoader(false);
        saveHotelBookingDetails(response?.data?.result);
        navigate('/hotel-voucher');
      }
      else {
        setLoader(false);
        navigate('/error-page');
        if (response?.data?.errorMessage) {
          if (Array.isArray(response.data.errorMessage)) {
            saveHotelErrorMessageDetail({ message: response.data.errorMessage.join(', ') })
            toast.error(response.data.errorMessage.join(', '));
          } else {
            toast.error(response.data.errorMessage)
          }
        }
      }
    } catch (error) {
      navigate('/error-page');
      setLoader(false);
      toast.error('Please Search Another hotel');
    }
  };
  const onChangeMarkUp = (mark: any) => {
    setMarkUpVal(mark);
  }

    //show hide Itinerary mobile toogle
    const [showItinerary, setShowItinerary] = useState(false)
    const showFilterBlock = () => {
      setShowItinerary(!showItinerary)
    }

  return (
    <>
      <MainLayout>
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="innerContainer border-top-0">
                <div className="row">
                  <div className="col-lg-8 order-lg-0 order-2">
                  <div className="wrapper p_t_0_mb">
                      <div className="row">
                        <div className="col-12">
                          <div className="form_heading">
                            <span className=" title">Contact Info</span>
                          </div>
                        </div>

                        <div className="col-12">
                          <ContactInfo
                            data={contactInfo}
                            onChange={(value: any) => onContactChange(value)}
                          />{' '}
                        </div>
                      </div>

                      {guestInfo?.map((room: any, i: any) => {
                        return (
                          <div id="pax-lead-room-1" className="row" key={i}>
                            <div className="col-12">
                              <div className="form_heading">
                                <span className="title">Room {i + 1}</span>
                              </div>
                            </div>

                            {room?.adults?.map((adult: any, j: any) => {
                              return (
                                <div key={j}>
                                  <div className="row align-items-center">
                                    <div className="col-6 mb-3">
                                      <span className="paxrow">
                                        {' '}
                                        <i className="fa-solid fa-caret-down"></i>{' '}
                                        Guest
                                      </span>{' '}
                                      {adult?.guestNo}:
                                      <span className="paxtype">
                                        <small> Adult</small>{' '}
                                        {adult?.guestNo === 1 && (
                                          <b> Lead Guest</b>
                                        )}
                                      </span>
                                    </div>
                                    {/* <div className="col-6 mb-3 text-end">
                                      <SearchPax />
                                    </div> */}
                                  </div>
                                  <div className="col-12">
                                    <HotelAdultPax
                                      data={adult}
                                      onChange={(data: any) =>
                                        handleInfoChange(adult?.guestNo, data)
                                      }
                                    />
                                    {j === 0 && (
                                      <HotelPaxAddress
                                        roomNo={adult?.roomIndex}
                                        onAddressChange={handleAddressChange}
                                      />
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                            {room?.children?.map((child: any, k: any) => {
                              return (
                                <div key={k}>
                                  <div className="row align-items-center">
                                    <div className="col-6 mb-3">
                                      <span className="paxrow">
                                        {' '}
                                        <i className="fa-solid fa-caret-down"></i>{' '}
                                        Guest
                                      </span>{' '}
                                      {child?.guestNo}:
                                      <span className="paxtype">
                                        <small> Child</small>{' '}
                                        {child?.guestNo === 1 && (
                                          <b>Lead Guest</b>
                                        )}
                                      </span>
                                    </div>
                                    {/* <div className="col-6 mb-3 text-end">
                                      <SearchPax />
                                    </div> */}
                                  </div>
                                  <div className="col-12">
                                    <HotelAdultPax
                                      data={child}
                                      onChange={(data: any) =>
                                        handleInfoChange(child?.guestNo, data)
                                      }
                                    />
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        );
                      })}

                      {/* <SpecialRequest /> */}

                      <EssentialInfo />

                      <div className="row">
                        <div className="col-12 mt-4 mb-4">
                          <div className="chkFlightPayCon mb-4">
                            <label
                              className="chkpleft me-3"
                              htmlFor="onAccount"
                            >
                              <div className="input-group">
                                <div className="input-group-prepend">
                                  <span className="iconholder mt-2">
                                    <i className="fa-regular fa-user"></i>
                                  </span>
                                </div>
                                <span className="title">On Account </span>
                              </div>
                              <input
                                type="checkbox"
                                id="onAccount"
                                name="onAccount"
                                checked
                                disabled
                              />
                              <span className="checkmark"></span>
                            </label>
                          </div>

                          <div className="col-12">
                            <div className="flightPayTbl">
                              <table className="table table-bordered mb-0">
                                <tbody>
                                  <tr>
                                    <td className="align-middle">
                                      Available Balance
                                    </td>
                                    <td>
                                      <strong>
                                        {balanceInfo?.currentBalance?.toFixed(2)}
                                      </strong>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td className="align-middle">
                                      Order Amount
                                    </td>
                                    <td>
                                      <strong>
                                        {hotelInfo?.totalPrice?.toFixed(2)}
                                      </strong>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td className="align-middle">
                                      Remaining Balance
                                    </td>
                                    <td>
                                      <strong>
                                        {!isNaN(balanceInfo?.currentBalance) && !isNaN(hotelInfo?.totalPrice) &&
                                          (balanceInfo?.currentBalance?.toFixed(2) -
                                            hotelInfo?.totalPrice)?.toFixed(2)}
                                      </strong>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>

                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="row">
                        <div className="col-12 mt-4 mb-4">
                          <input
                            className="form-check-input"
                            type="checkbox"
                            id="termconditions"
                            name="termconditions"
                            onChange={toggleChkDisableButton}
                          />

                          <label
                            className="ms-2 font_size_90"
                            htmlFor="termconditions"
                          >
                            I understand and agree to the rules,
                            <Link to="/" className="text-primary">
                              {' '}
                              Privacy Policy
                            </Link>
                            ,
                            <Link to="/" className="text-primary">
                              User Agreement{' '}
                            </Link>{' '}
                            and
                            <Link to="/" className="text-primary">
                              {' '}
                              Terms & Conditions
                            </Link>
                            .
                          </label>
                        </div>

                        <div className="col-12 mt-4 mb-4 text-end">
                          <button
                            disabled={chkTermsBtn }
                            className="btn btn-primary text-uppercase ps-4 pe-4"
                            onClick={() => handleBookRoom()}
                          >
                            Proceed to Book
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="col-lg-4">

                  <div className="col-12 text-end mt-2 show_mobile">
            <button 
            onClick={showFilterBlock} 
            type="button" 
            className="btn btn-sm"
            >
           
            {showItinerary ? (<span>Hide Itinerary <FiChevronUp/></span>) : (<span>Review Itinerary <FiChevronDown/></span>)} 
            
            </button>
                </div>


                <div className={showItinerary ? '' : 'hide_mobile'}>
                    <div className="innerContainerRight">
                      <div className="row">
                      <div className="col-12 mt-md-2">
                          <div className="row">
                            <div className="col-12">
                              <div className="form_heading">
                                <span className="title">Itinerary Details</span>
                              </div>
                            </div>
                            <div className="col-12">
                              <RdBedChkInOut />
                              {rooms?.map((room: any, index: any) => (
                                <RdRtype details={room} key={index} />
                              ))}
                            </div>
                          </div>
                        </div>

                        <div className="col-12 mt-2 mb-2">
                          <div className="row">
                            <div className="col-12">
                              <div className="form_heading">
                                <span className="title">Fare Summary</span>
                              </div>
                            </div>
                            <div className="col-12">
                              <RdTotalPrice priceInfo={hotelInfo} />
                            </div>
                            <div className="col-12 mt-4">
                              <PromoCode />
                            </div>
                          </div>
                        </div>

                        <div className="col-12 mb-2">
                          <div className="row">
                            <div className="col-12">
                              <div className="form_heading">
                                <span className="title">Markup</span>
                              </div>
                            </div>
                            <div className="col-12">
                              <AddMarkup totalFare={hotelInfo?.totalPrice} onChange={onChangeMarkUp} />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </MainLayout>
      {loader && <Loader />}
    </>
  );
}