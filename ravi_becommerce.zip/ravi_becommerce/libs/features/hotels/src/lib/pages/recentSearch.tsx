import React, {  useEffect, useRef } from "react";
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { FaHotel } from "react-icons/fa";
import { getHotelRecentSearch } from '../service/hotelApi';
import { RootState, useHotelStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';


interface CustomSlider extends Slider {
  slickNext: () => void;
  slickPrev: () => void;
}

const RecentSearch: React.FC = () => {
  const sliderRef = useRef<CustomSlider>(null);
  const { saveHotelRecentSearch } = useHotelStore();
  const { recentSearchData } = useSelector((state: RootState) => state.hotel);
  const {  agentProfile } = useSelector(   (state: RootState) => state.config );

  const getRecentSearchData = async () => {
    try {
      const res:any = await getHotelRecentSearch(agentProfile?.id);
      saveHotelRecentSearch (res?.data?.result);
    } catch (error) {
      console.error('Error fetching recent search data:', error);
    }
  };
  
  useEffect(()=>{
    getRecentSearchData()
  },[])

  const formatDate =(isoDateStr:any,) => {
    const date = new Date(isoDateStr);
    const day = date.getDate();
    const month = date.getMonth() + 1; 
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
}
 
  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 6,
    slidesToScroll: 1,


    responsive: [{
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,

      }
    },

    {
      breakpoint: 1100,
      settings: {
        slidesToShow: 4,
        slidesToScroll: 4,

      }
    }


    ]
  };

  const goToNext = () => {
    if (sliderRef.current) {
      sliderRef.current.slickNext();
    }
  };

  const goPrevious = () => {
    if (sliderRef.current) {
      sliderRef.current.slickPrev();
    }
  };

  return (
<> 
    <section className="recentsearchHome mt-4"> 
    <div className="row align-items-center mb-1">
      <div className="col-6 text-start">
        <h6>RECENT SEARCHES</h6>
      </div>
      <div className="col-6 text-end">

        <button className="prev_btn" onClick={goPrevious}><i className="fa-solid fa-angle-left"></i></button>
        <button className="next_btn" onClick={goToNext}><i className="fa-solid fa-angle-right"></i></button>

      </div>
    </div>

        <div className="recentsearchWrap">
          <div className="row justify-content-center">
            <div className="col-12">
             
            <Slider ref={sliderRef} {...settings}>
                      {recentSearchData?.map((slide:any, index:any) => (
                        <div key={index}>
                
                <div className="item">
                    <div className="hotel_country"><FaHotel/> {slide?.cityName } {slide?.searchRequest?.countryName }</div>
                    <p>{formatDate(slide.checkInDate)  }</p>
                </div>

                </div>

                ))}
              </Slider>



       
                    
            </div>
          </div>
        </div>
 
    </section>




      </>
)};

export default RecentSearch;
