import { useEffect, useState } from 'react';
// import { IataLogo, IsoLogo, weAcceptCards } from '@mfa-travel-app/assets';
import { MainLayout } from '@mfa-travel-app/layout';
import ModifySearchCon from '../../Components/HotelResults/ModifySearchCon';
import HotelListing from '../../Components/HotelResults/HotelListing';
import HotelFilters from './hotelFilters';
import { useSelector } from 'react-redux';
import { RootState } from '@mfa-travel-app/store';
import { searchHotelList } from '../service/hotelApi';
import { useHotelStore } from '@mfa-travel-app/store';
import { toast } from 'react-toastify';
import Skeleton, { SkeletonTheme } from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css';

export default function HotelResults() {
  const { searchResults, searchPayload } = useSelector(
    (state: RootState) => state.hotel
  );
  const [filteredResults, setFilterResults] = useState<any>([]);
  const [sortFlag, setSortFlag] = useState('cheapest');
  const [loader, setLoader] = useState(false);

  const { saveHotelSearchResults, saveHotelSearchPayloadResults } =
    useHotelStore();

  useEffect(() => {
    if (searchResults?.length > 1) {
      setFilterResults(searchResults);
      handleCheapestSort();
    }
  }, [searchResults]);

  useEffect(() => {
    SearchReturnFlights();
  }, []);


  const SearchReturnFlights = async () => {
    // const { cityName, checkIn, checkOut, countryName, roomPaxInfo } =
    //   searchPayload;
    // if (!cityName || !checkIn || !checkOut || !countryName || !roomPaxInfo) {
    //   toast.error('Please fill in all the search parameters.');
    //   return;
    // }
    // let adultGuests = 0;
    // roomPaxInfo?.forEach((room: any) => {
    //   adultGuests = adultGuests + room?.adults;
    // });
    // if (roomPaxInfo?.length > adultGuests) {
    //   toast.error('Please fill in all the search parameters.');
    //   return;
    // }
    setLoader(true);
    const response: any = await searchHotelList({...searchPayload, IsOnBehalf: false});
    setLoader(false);
    try {
      if ( response?.data?.statusCode == 200 && response?.data?.result ) {
        saveHotelSearchResults(response?.data?.result);
      } else {
        toast.error(response?.data.error.message);
      }
    } catch {
      toast.error(
        response?.data?.errorMessage && response?.data.errorMessage[0]
      );
    }
  };

  const handleCheapestSort = () => {
    setSortFlag('cheapest');
    if (filteredResults?.length > 0) {
      const sorted = [...filteredResults].sort(
        (a, b) => a.totalPrice - b.totalPrice
      );
      setFilterResults(sorted);
    }
  };

  const handleRatingSort = () => {
    setSortFlag('rating');
    const sorted = [...filteredResults].sort(
      (a, b) => b.hotelRating - a.hotelRating
    );
    setFilterResults(sorted);
  };

  const restoreSearchResults = () => {
    setFilterResults(searchResults);
  };

  const changeFilteredResults = (filters: any) => {
    let filteredArray = [...searchResults];

    if (filters.hotelName && filters.hotelName !== '') {
      filteredArray = filteredArray.filter((hotel: any) =>
        hotel.hotelName.toLowerCase().includes(filters.hotelName.toLowerCase())
      );
    }
    if (filters.location && filters.location !== '') {
      filteredArray = filteredArray.filter((hotel: any) =>
        hotel.address.toLowerCase().includes(filters.location.toLowerCase())
      );
    }
    if (filters.rating) {
      let rating = false;
      let ratingArray: any = [];
      Object.keys(filters.rating).forEach((k) => {
        rating = rating || filters.rating[k];
        if (filters.rating[k]) ratingArray.push(k);
      });
      if (rating) {
        filteredArray = filteredArray.filter((hotel: any) =>
          ratingArray.includes(`${hotel.hotelRating}`)
        );
      }
    }

    setFilterResults(filteredArray);
  };
  const getFilterData = (
    minimum: any,
    maximum: any,
    itenaryFilterResults: any
  ) => {
    let itenaryFilterResult = [...itenaryFilterResults];
    if (!isNaN(minimum) || !isNaN(maximum)) {
      itenaryFilterResult = itenaryFilterResult.filter((item: any) => {
        return item.totalPrice >= minimum && item.totalPrice <= maximum;
      });
    }
    return itenaryFilterResult;
  };
  const onSearchTotalPrice = (minimum: any, maximum: any) => {
    const rangeFilterData = getFilterData(minimum, maximum, searchResults);
    setFilterResults(rangeFilterData);
  };

  return (
    <>
      <MainLayout>
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
             
              <ModifySearchCon />
            </div>
          </div>

          <div className="row">
            {loader ? (
              <div className="col-lg-3 mb-2">
                <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                  <Skeleton height={300} />
                </SkeletonTheme>
              </div>
            ) : (
              <HotelFilters
                changeFilteredResults={changeFilteredResults}
                hotelCount={filteredResults?.length}
                onSearchTotalPrice={onSearchTotalPrice}
                restoreSearchResults={restoreSearchResults}
              />
            )}
            {loader ? (
              <div className="col-lg-9 d-flex flex-column gap-2">
                <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                  <Skeleton height={30} />
                </SkeletonTheme>
                <div className='d-flex flex-column gap-2 mb-3'>
                  <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                    <Skeleton height={100} />
                  </SkeletonTheme>
                  <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                    <Skeleton height={100} />
                  </SkeletonTheme>
                  <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                    <Skeleton height={100} />
                  </SkeletonTheme>
                  <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                    <Skeleton height={100} />
                  </SkeletonTheme>
                  <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                    <Skeleton height={100} />
                  </SkeletonTheme>
                </div>
              </div>
            ) : (
              <div className="col-lg-9">
                <div>
                  <button
                    className={`btn btn-sm rounded me-2 ${sortFlag === 'cheapest'
                        ? 'btn-secondary'
                        : 'btn-outline-secondary'
                      }`}
                    onClick={handleCheapestSort}
                  >
                    Cheapest
                  </button>
                  <button
                    className={`btn btn-sm rounded ${sortFlag === 'rating'
                        ? 'btn-secondary'
                        : 'btn-outline-secondary'
                      }`}
                    onClick={handleRatingSort}
                  >
                    Star Rating
                  </button>
                </div>
                <div className="allhotellist mb-4">
                  {filteredResults?.length > 0 &&
                    filteredResults?.map((hotel: any) => (
                      <HotelListing key={hotel.hotelId} hotel={hotel} />
                    ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </MainLayout>
    </>
  );
}
