import { MainLayout } from '@mfa-travel-app/layout';
import { useSelector } from 'react-redux';
import { RootState } from '@mfa-travel-app/store';
import CancellationCharges from '../../Components/HotelResults/CancellationCharges';
import HotelNorms from '../../Components/HotelResults/HotelNorms';

const months = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
];

export default function hotelVoucher() {
  const {
    hotelBookingDetails,
    selectedHotel,
    rooms,
    hotelCancellationPolicies,
    passengerInfo
  } = useSelector((state: RootState) => state.hotel);
  const { balanceInfo }:any= useSelector(
    (state: RootState) => state.config
  );

  const getBookingDate = (dateString: string) => {
    const dateObj = new Date(dateString);
    return dateObj;
  };

  const getBookingTime = (dateString: string) => {
    const dateObj = new Date(dateString);
    const hoursIn24 = dateObj.getHours();
    let hoursIn12: any = hoursIn24 > 12 ? hoursIn24 % 12 : hoursIn24;
    hoursIn12 = (hoursIn12 % 12 || 12).toString().padStart(2, '0');
    const minutes = dateObj.getMinutes().toString().padStart(2, '0');
    const amOrPm = hoursIn24 >= 12 ? 'PM' : 'AM';
    return `${hoursIn12}:${minutes} ${amOrPm}`;
  };

  const getTotalCustomers = () => {
    let adults = 0;
    let children = 0;
    hotelBookingDetails?.hotelBookingDetails?.rooms?.forEach((room: any) => {
      room?.customerDetails[0]?.customerNames?.forEach((customer: any) => {
        if (customer?.type === 'Adult') {
          adults++;
        } else if (customer?.type === 'Child') {
          children++;
        }
      });
    });
    return { adults: adults, children: children };
  };

  const calculateNights = () => {
    const start = new Date(
      hotelBookingDetails?.hotelBookingDetails?.checkIn
    ).getTime();
    const end = new Date(
      hotelBookingDetails?.hotelBookingDetails?.checkOut
    ).getTime();
    const diff = end - start;
    const hours = diff / (1000 * 60 * 60);
    return hours / 24;
  };

  let leadGuest: any =
    hotelBookingDetails?.hotelBookingDetails?.rooms[0]?.customerDetails[0]
      ?.customerNames[0];

      const onHandlePrintVoucher = () =>{
        window.print();
      }

  return (
    <>
      <MainLayout>
        <div className='container-printer-display'> 
        <div className="container mb-5">
          <div className="row align-items-center">
            <div className="col-md-12 text-center text-uppercase mt-2">
            <h4>Hotel Voucher</h4>
            </div>

            <div className="col-md-12">
              <div className='row'>
              <div className='col-6'>   <img style={{height:'16px'}}
                  src={
                    hotelBookingDetails?.hotelBookingDetails?.agencyDetails
                      ?.agencyLogo
                  }
                /></div>
              <div className='col-6 text-end e_Voucher_inline'>

              <button className="print_button me-3">
                <i className="fa fa-envelope" aria-hidden="true"></i>
              </button>

        

              <button className='print_button' onClick={ onHandlePrintVoucher}>
                        <i className="fa fa-print" aria-hidden="true"></i>
                      </button>

              </div>
              </div>
              </div>
      

            <div className="col-md-6">
         

              <h4>
                {
                  hotelBookingDetails?.hotelBookingDetails?.hotelDetails
                    ?.hotelName
                }
              </h4>

              <div className="text-primary">
                {Array.from({
                  length: selectedHotel?.hotelInfo?.hotelRating || 0,
                }).map((_, index) => (
                  <span key={index}>
                    <i className="fa-solid fa-star"></i>
                  </span>
                ))}
                {Array.from({
                  length: 5 - selectedHotel?.hotelInfo?.hotelRating || 0,
                }).map((_, index) => (
                  <span key={index}>
                    <i className="fa-regular fa-star"></i>
                  </span>
                ))}
              </div>
              <div className="mb-1 mt-1">
                {selectedHotel?.hotelInfo?.address}
              </div>
              <div className="text-muted font_size_90 mb-2">
                Phone Number: {selectedHotel?.hotelInfo?.phoneNumber}{' '}
                {/* ramapramadi@gmail.com */}
                {selectedHotel?.hotelInfo?.email && (
                  <span>{selectedHotel?.hotelInfo?.email}</span>
                )}
              </div>
            </div>

            <div className="col-md-6 text-md-end font_size_90">
    
              <div>
                {' '}
                <span>Confirmation No | </span>{' '}
                <span>
                  <strong>
                    {
                      hotelBookingDetails?.hotelBookingDetails
                        ?.confirmationNumber
                    }
                  </strong>
                </span>
              </div>
              <div>
                <span>Date of Issue:</span>{' '}
                <span>
                  {' '}
                  <strong>
                    {getBookingDate(
                      hotelBookingDetails?.hotelBookingDetails?.bookingDate
                    ).getDate()}{' '}
                    {
                      months[
                        getBookingDate(
                          hotelBookingDetails?.hotelBookingDetails?.bookingDate
                        ).getMonth()
                      ]
                    }{' '}
                    {getBookingDate(
                      hotelBookingDetails?.hotelBookingDetails?.bookingDate
                    ).getFullYear()}{' '}
                    {getBookingTime(
                      hotelBookingDetails?.hotelBookingDetails?.bookingDate
                    )}
                  </strong>
                </span>
              </div>
              <div>
                <span>Status |</span>{' '}
                <span className="text-success">
                  <strong>
                    {hotelBookingDetails?.hotelBookingDetails?.voucherStatus
                      ? 'Vouchered'
                      : 'Confirmed'}
                  </strong>
                </span>{' '}
              </div>
              <div>
                <span className="text-muted">
                  Agency Ref # :{' '}
                  {
                    hotelBookingDetails?.hotelBookingDetails?.agencyDetails
                      ?.agencyReference
                  }
                </span>
              </div>
              {hotelBookingDetails?.hotelBookingDetails?.agencyDetails
                ?.agencyName !== null && (
                <div>
                  <span className="text-muted">
                    Agency Name:{' '}
                    {
                      hotelBookingDetails?.hotelBookingDetails?.agencyDetails
                        ?.agencyName
                    }
                  </span>
                </div>
              )}

              <div>
                {' '}
                <span className="text-muted">
                  Agency Address:{' '}
                  {
                    hotelBookingDetails?.hotelBookingDetails?.agencyDetails
                      ?.agencyAddress
                  }
                </span>
              </div>
              <div>
                <span className="text-muted">
                  Agency Emergency No. :{' '}
                  {
                    hotelBookingDetails?.hotelBookingDetails?.agencyDetails
                      ?.agencyEmergencyNo
                  }
                </span>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-12 mt-2">
              <div className="tblFlightEticket">
                <div className="heading">Lead Guest</div>

                <div style={{ border: 'solid 1px #000' }}>
                  <div className="table-responsive">
                    <table className="table table-bordered e_Voucher_inline">
                      <thead className="align-middle text-center bg-light border border-primary">
                        <th className="text-start">GUEST NAME</th>
                        <th>NATIONALITY</th>
                        <th>CHECK IN DATE</th>
                        <th>CHECK OUT DATE</th>
                        <th>NO. OF GUESTS</th>
                        <th className=''>NO. OF NIGHTS</th>
                      </thead>

                      <tbody>
                        <tr className="text-muted text-center">
                          <td className="text-start">
                            {passengerInfo[0]?.passengers[0]?.firstname} {passengerInfo[0]?.passengers[0]?.lastname}
                          </td>
                          <td>BANGLADESH</td>
                          <td>
                            {getBookingDate(
                              hotelBookingDetails?.hotelBookingDetails?.checkIn
                            )
                              .getDate()
                              .toString()
                              .padStart(2, '0')}
                            {'-'}
                            {months[
                              getBookingDate(
                                hotelBookingDetails?.hotelBookingDetails
                                  ?.checkIn
                              ).getMonth()
                            ]?.toUpperCase()}
                            {'-'}
                            {getBookingDate(
                              hotelBookingDetails?.hotelBookingDetails?.checkIn
                            ).getFullYear()}
                          </td>
                          <td>
                            {getBookingDate(
                              hotelBookingDetails?.hotelBookingDetails?.checkOut
                            )
                              .getDate()
                              .toString()
                              .padStart(2, '0')}
                            {'-'}
                            {months[
                              getBookingDate(
                                hotelBookingDetails?.hotelBookingDetails
                                  ?.checkOut
                              ).getMonth()
                            ]?.toUpperCase()}
                            {'-'}
                            {getBookingDate(
                              hotelBookingDetails?.hotelBookingDetails?.checkOut
                            ).getFullYear()}
                          </td>
                          <td>
                            {getTotalCustomers().adults} (ADULT(s)),{' '}
                            {getTotalCustomers().children} (CHILD(s))
                          </td>
                          <td>{calculateNights()} NIGHTS</td>
                        </tr>
                      </tbody>
                    </table>

                    <table className="table table-bordered border-primary mb-0 e_Voucher_inline">
                      <thead className="align-middle text-center bg-light border-top-0">
                        <tr>
                          <th className="text-start">ROOM NO.</th>
                          <th>ROOM TYPE</th>
                          <th>PAX NAMES(S)</th>
                          <th>MEAL PLAN</th>
                          <th>NO. OF GUESTS</th>
                        </tr>
                      </thead>

                      <tbody>
                        {hotelBookingDetails?.hotelBookingDetails?.rooms?.map(
                          (room: any, index: any) => {
                            return (
                              <tr className="text-muted text-center">
                                <td className="text-start">{index + 1}</td>
                                <td>{room?.name[0]}</td>
                                <td>
                                  {room?.customerDetails[0]?.customerNames?.map(
                                    (customer: any, index: any) => {
                                      return `${customer?.firstName} ${
                                        customer?.lastName
                                      }${
                                        index ===
                                        room?.customerDetails[0]?.customerNames
                                          ?.length
                                          ? ''
                                          : ', '
                                      }`;
                                    }
                                  )}
                                </td>
                                <td>{room?.mealType}</td>
                                <td>
                                  {
                                    (room?.customerDetails[0]?.customerNames?.filter(
                                      (customer: any) =>
                                        customer?.type === 'Adult'
                                    )).length
                                  }{' '}
                                  (ADULT(s)),{' '}
                                  {
                                    (room?.customerDetails[0]?.customerNames?.filter(
                                      (customer: any) =>
                                        customer?.type === 'Child'
                                    )).length
                                  }{' '}
                                  (CHILD(s))
                                </td>
                              </tr>
                            );
                          }
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="row mt-4">
            <div className="border p-3">
              <div className="col-12 mt-2">
                <div className="mb-2 text-uppercase">
                  {' '}
                  <strong>Essential Information </strong>{' '}
                </div>

                <h6 className="text-uppercase ">INCLUSIONS</h6>
              </div>
              <ul>
                {hotelBookingDetails?.hotelBookingDetails?.rateConditions?.map(
                  (condition: any) => (
                    <li>{condition}</li>
                  )
                )}
              </ul>
            </div>
          </div>

          <div className="row mt-4">
            <div className="border p-3">
              <div className="col-12 mt-2">
                <div className="mb-2 text-uppercase">
                  {' '}
                  <strong>Hotel Norms</strong>{' '}
                </div>
              </div>
              <HotelNorms />
            </div>
          </div>

          <div className="row mt-4">
            <div className="border p-3">
              <div className="col-12 mt-3">
                <div className="text-uppercase mb-2">
                  <strong>CANCELLATION & CHARGES</strong>
                </div>
                <CancellationCharges />
              </div>
            </div>
          </div>

          <div className="row mt-4">
            <div className="border p-3">
              <div className="col-12 mt-3">
                <div className="text-uppercase mb-2">
                  <strong>Supplements</strong>
                </div>
                {rooms?.map((room: any, index: any) => (
                  <div>
                    <b>Room {index + 1}</b>
                    {room?.supplements?.map((supplement: any) => (
                      <div className="row">
                        <div className="col-12 col-lg-6">
                          <div className="row">
                            <span className="col">
                              {supplement?.description}
                            </span>
                            <span className="col">{supplement?.type}</span>
                            <span className="col">
                              {supplement?.currency} {supplement?.price}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="row mt-4">
            <div className="border p-3">
              <div className="col-12">
                <div className="mb-2">
                  <h6>Terms & Conditions</h6>
                </div>
                <ul className="mb-0">
                  <li>
                    All rooms are guaranteed on the day of arrival. In the case
                    of no-show, your room(s) will be released and you will
                    subject to the terms and condition of the
                    Cancellation/No-show policy specified at the time you made
                    the booking as well as noted in the confirmation Email.
                  </li>
                  <li>
                    The total price for these booking fees not include mini-bar
                    items, telephone bills, laundry service, etc. The hotel will
                    bill you directly.
                  </li>
                  <li>
                    {' '}
                    In case where breakfast is included with the room rate,
                    please note that certain hotels may charge extra for
                    children travelling with their parents.{' '}
                  </li>
                  <li>
                    If applicable, the hotel will bill you directly. Upon
                    arrival, if you have any questions, please verify with the
                    hotel.
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        </div>
      </MainLayout>
    </>
  );
}
