import { useEffect, useState } from 'react';
import styles from '../../../../flights/src/lib/oneway.module.scss';
import classNames from 'classnames';
import AdditionalSerach from '../pages/additionalSearch';
import { getHotelList, searchHotelList } from '../service/hotelApi';
import SearchHotelBox from '../../Components/searchHotelBox';
import { useHotelStore } from '@mfa-travel-app/store';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { Loader } from '@mfa-travel-app/ui';
import { RootState } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';

const SearchHotal = ({ recentSearch }: any) => {
  const { searchPayload } = useSelector((state: RootState) => state.hotel);
  const [searchPayloads, setSearchPayload] = useState({
    cityName: '',
    checkIn: '',
    checkOut: '',
    countryName: '',
    nationalityCode: '',
    noOfRooms: 1,
    starRating: 0,
    roomPaxInfo: [
      {
        adults: 1,
        children: 0,
        childrenAges: [],
      },
    ],
    sources: ['TBOO'],
  });

  const {
    saveHotelCityList,
    saveHotelSearchResults,
    saveHotelSearchPayloadResults,
  } = useHotelStore();
  const [loader, setLoader] = useState(false);
  const navigate = useNavigate();

  const getAllInitialData = async () => {
    setLoader(true);
    const response: any = await getHotelList();
    setLoader(false);
    try {
      if (response.status == 200 && response?.data) {
        saveHotelCityList(response?.data);
      } else {
        toast.error(response?.data?.errorMessage[0]);
      }
    } catch {
      toast.error(response?.data?.errorMessage[0]);
    }
  };

  useEffect(() => {
    getAllInitialData();
  }, []);

  const onSendsearchHotelData = (
    city: any,
    from: any,
    to: any,
    traveller: any,
    country: any,
    nation: any,
  ) => {
    setSearchPayload({
      ...searchPayloads,
      cityName: city,
      checkIn: from?.toISOString(),
      checkOut: to?.toISOString(),
      countryName: country,
      nationalityCode: nation,
      roomPaxInfo: traveller,
      noOfRooms: traveller?.length,
    });
  };
  const SearchReturnFlights = async () => {
    const { cityName, checkIn, checkOut, countryName, roomPaxInfo ,nationalityCode} =
      searchPayloads;
    if (!cityName || !checkIn || !checkOut || !countryName || !roomPaxInfo || !nationalityCode) {
      toast.error('Please fill in all the search parameters.');
      return;
    }
    let adultGuests = 0;
    roomPaxInfo?.forEach((room: any) => {
      adultGuests = adultGuests + room?.adults;
    });
    if (roomPaxInfo?.length > adultGuests) {
      toast.error('Please fill in all the search parameters.');
      return;
    }
    saveHotelSearchPayloadResults(searchPayloads)
    navigate('/hotel-results');
    // setLoader(true);
    // const response: any = await searchHotelList(searchPayloads);
    // setLoader(false);
    // try {
    //   if (response?.data?.result && response?.data?.statusCode == 200) {
    //     saveHotelSearchResults(response?.data?.result);
    //     saveHotelSearchPayloadResults(searchPayloads);
    //     navigate('/hotel-results');
    //   } else {
    //     toast.error(response?.data.error.message);
    //   }
    // } catch {
    //   toast.error(
    //     response?.data?.errorMessage && response?.data.errorMessage[0]
    //   );
    // }
  };
  const onAdditionalSearch = (
    residence: any,
    propertyName: any,
    starRating: any,
    markup: any,
    suppliers: any
  ) => {
    setSearchPayload((prevState) => ({
      ...prevState,
      sources: suppliers?.map((i: any) => i.value),
      starRating: starRating.value,
      propertyName: propertyName,
      // markup: markup
    }));
  };

  return (
    <>
      <div className="searchForm">
        <div className="flightSearch mt-1">
          <div
            className={classNames(
              `row justify-content-between ${styles['oneway-sec']}`
            )}
            id="oneway"
          >
            <div>
              <SearchHotelBox onSendsearchHotelData={onSendsearchHotelData} />
              <div
                className={classNames('col-lg-2', styles['btn-container'])}
                style={{ float: 'right' }}
              ></div>
            </div>
          </div>

          <div className="row mt-2">
            <div className="col-lg-9 col-sm-12">
              <details>
                <summary className="text-start">
                  <p className="mb-0 d-inline-block">
                    Additional Search Options
                  </p>
                </summary>
                <ul className="additional_searches mt-4">
                  <AdditionalSerach onAdditionalSearch={onAdditionalSearch} />
                </ul>
              </details>
            </div>

            <div className="col-lg-3 text-end">
              <button
                type="button"
                className="btn btn-primary btnHotel"
                onClick={() => SearchReturnFlights()}
              >
                <span>
                  {' '}
                  <i className="fa-solid fa-magnifying-glass"></i> SEARCH
                </span>
              </button>
            </div>
          </div>
          {loader && <Loader />}
        </div>
      </div>
    </>
  );
};

export default SearchHotal;
