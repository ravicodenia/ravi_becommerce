import { useState, useEffect, useRef } from 'react';
import SearchOnMap from '../../Components/HotelResults/SearchOnMap';
import SearchByHotelName from '../../Components/HotelResults/SearchByHotelName';
import SearchByRating from '../../Components/HotelResults/SearchByRating';
import SearchByLocation from '../../Components/HotelResults/SearchByLocation';
import SearchByPrice from '../../Components/HotelResults/SearchByPrice';
import { useSelector } from 'react-redux';
import { RootState } from '@mfa-travel-app/store';
import { Link } from "react-router-dom";


export default function HotelFilters({ changeFilteredResults, hotelCount, onSearchTotalPrice, restoreSearchResults }: any) {
  const { searchResults } = useSelector(
    (state: RootState) => state.hotel
  );
  const [filters, setFilters] = useState({
    hotelName: '',
    rating: {
      1: false,
      2: false,
      3: false,
      4: false,
      5: false,
    },
    price: {
      min: '',
      max: '',
    },
    location: '',
  });

  const handleFilterChange = (e: any) => {
    const { name, value } = e.target;
    let newFilters: any = { ...filters };
    if (name === 'hotelName' || name === 'location') {
      newFilters = { ...newFilters, [name]: value };
    } else if (['1', '2', '3', '4', '5'].includes(name)) {
      newFilters = {
        ...newFilters,
        rating: { ...newFilters.rating, [name]: !newFilters.rating[name] },
      };
    }
    setFilters(newFilters);
    changeFilteredResults(newFilters);
  };

  
  const [minimumTotalPrice, setMinimumTotalPrice] = useState();
  const [maximumTotalPrice, setMaximumTotalPrice] = useState(1);
  const [range, setRange] = useState([1, 10000]);
  const prevRangeRef = useRef(range);
  const [priceRangeMin, setPriceRangeMin] = useState<any>(
    [...(searchResults ?? [])].sort((a: any, b: any) => a.totalPrice - b.totalPrice)[0]?.totalPrice
  );
  
  const [priceRangeMax, setPriceRangeMax] = useState<any>();

  useEffect(() => {
    let sortSearchResult = searchResults || [] && searchResults?.sort((a: any, b: any) => a.totalPrice - b.totalPrice);
    setMinimumTotalPrice(sortSearchResult[0]?.totalPrice);
    setMaximumTotalPrice(sortSearchResult[sortSearchResult.length - 1]?.totalPrice);
    setPriceRangeMax(sortSearchResult[sortSearchResult.length - 1]?.totalPrice);
  }, [])

  useEffect(() => {
    let resultForMinimum: any;
    let resultForMaximum: any;
    const prevRange = prevRangeRef.current;
    let diffMaximumMinimumTotalFare =
      Number(maximumTotalPrice) - Number(minimumTotalPrice);
    let ratio = diffMaximumMinimumTotalFare / 100;
    if (prevRange[0] !== range[0]) {
      resultForMinimum = Number(minimumTotalPrice) + ratio * range[0];
      onSearchTotalPrice(resultForMinimum, priceRangeMax);
      setPriceRangeMin(resultForMinimum);
    }
    if (prevRange[1] !== range[1]) {
      resultForMaximum = maximumTotalPrice - ratio * (100 - range[1]);
      onSearchTotalPrice(priceRangeMin, resultForMaximum);
      setPriceRangeMax(resultForMaximum);
    }

  }, [range]);

  const clearFilters = () => {
    setFilters({
      hotelName: '',
      rating: {
        1: false,
        2: false,
        3: false,
        4: false,
        5: false,
      },
      price: {
        min: '',
        max: '',
      },
      location: '',
    });

    restoreSearchResults()
  };


    //show hide filter
    const [isFilter, setIsFilter] = useState(false)
    const showFilterBlock = () => {
      setIsFilter(true)
    }
  
    const hideFilterBlock = () => {
      setIsFilter(false)
    }

  return (
    <div className="col-lg-3">

<div id="filterFRMb" className="row show_mobile">
    <div className="col-12 mb-3">
      <button onClick={showFilterBlock}
      
      id="filterFRlink" className="btn btn-sm btn-outline-secondary" type="button"> 
        <small><i className="fa-solid fa-filter"></i> Filters</small></button>
    </div>
  </div>

  <div className={isFilter ? '' : 'hide_mobile'}>
      <div className="filterLeft">
        <div className="filterWrapper">
        <div className="row d-lg-none align-items-center mb-3">
            <div className="col-6">
              <span className='filtertitle'>Filters</span>
            </div>
            <div className="col-6">
              <div className="col-12 text-end">
                <button onClick={hideFilterBlock}
                  id="filtercllink"
                  className="btn btn-lg cursor_pointer"
                  type="button"
                >
                  <small>
                    <i className="fa-solid fa-xmark"></i>
                  </small>
                </button>
              </div>
            </div>
          </div>
          <SearchOnMap />
          <div className="row">
            <div className="col-12">
              <div className="filterDarkBlock">
                <div className="total_result text-center">
                  <span>{hotelCount}</span> Hotel found in <span>Dubai</span>
                </div>

                <div className="filcil">
                  <div className="row">
                    <div className="col-5">
                     <span className='text-primary'>Filter By</span>
                    </div>
                    <div className="col-2">|</div>
                    <div className="col-5">
                      
                      <Link className='text-primary' to=''  onClick={() => clearFilters()}>Clear All </Link>
                     
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="borderedBlock">
            <div className="row">
              <div className="col-12">
                <div className="accordion" id="accordionFilter">
                  <div className="accordion-item">
                    <h2 className="accordion-header" id="headingflightnum">
                      <button
                        className="accordion-button"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#collapseheadingflightnum"
                        aria-expanded="false"
                        aria-controls="collapseheadingflightnum"
                      >
                        Search by Hotel Name
                      </button>
                    </h2>

                    <div
                      id="collapseheadingflightnum"
                      className="accordion-collapse collapse show"
                      aria-labelledby="headingflightnum"
                      data-bs-parent="#accordionFilter"
                    >
                      <div className="accordion-body">
                        <SearchByHotelName
                          hotelName={filters.hotelName}
                          handleFilterChange={handleFilterChange}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="accordion-item">
                    <h2 className="accordion-header" id="headingstarrating">
                      <button
                        className="accordion-button"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#collapseairline"
                        aria-expanded="false"
                        aria-controls="collapseairline"
                      >
                        Search By Star Rating
                      </button>
                    </h2>
                    <div
                      id="collapseairline"
                      className="accordion-collapse collapse show"
                      aria-labelledby="headingstarrating"
                      data-bs-parent="#accordionFilter"
                    >
                      <div className="accordion-body">
                        <SearchByRating
                          rating={filters.rating}
                          handleFilterChange={handleFilterChange}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="accordion-item">
                    <h2 className="accordion-header" id="headingprice">
                      <button
                        className="accordion-button"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#collapseheadingprice"
                        aria-expanded="false"
                        aria-controls="collapseheadingprice"
                      >
                        Price
                      </button>
                    </h2>
                    <div
                      id="collapseheadingprice"
                      className="accordion-collapse collapse show"
                      aria-labelledby="headingprice"
                      data-bs-parent="#accordionFilter"
                    >
                      <div className="accordion-body">
                        <div style={{ paddingTop: '26px' }}>
                          <SearchByPrice range={range} setRange={setRange} />
                          <div style={{ padding: '17px' }}>{priceRangeMin} &nbsp; &nbsp; &nbsp;{priceRangeMax} </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="accordion-item">
                    <h2 className="accordion-header" id="headinglocation">
                      <button
                        className="accordion-button"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#collapseheadinglocation"
                        aria-expanded="false"
                        aria-controls="collapseheadinglocation"
                      >
                        Location
                      </button>
                    </h2>
                    <div
                      id="collapseheadinglocation"
                      className="accordion-collapse collapse show"
                      aria-labelledby="headinglocation"
                      data-bs-parent="#accordionFilter"
                    >
                      <div className="accordion-body">
                        <SearchByLocation
                          location={filters.location}
                          handleFilterChange={handleFilterChange}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
</div>
    </div>
  );
}
