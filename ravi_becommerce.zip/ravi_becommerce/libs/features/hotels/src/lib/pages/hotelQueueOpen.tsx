import { MainLayout } from '@mfa-travel-app/layout';
import { GoHistory } from "react-icons/go";
import { Link } from 'react-router-dom';
import  { useState } from "react";
import { MdOutlineClose } from "react-icons/md";

export default function HotelQueueOpen() {

    const [showHistory, setShowHistory] = useState(false); 

  return (

    <>
    <MainLayout>
    <div className="container mt-3 mb-3">

        <div className='row'>

<div className='col-lg-8'>
 
<div className='row'>


<div className='col-12  mt-2 mb-2'>


<table className="table border">
  <thead>

<tr className='table-secondary'>

    <th>Booking Details  </th>
</tr>


  </thead>
  <tbody>
    <tr>
    

      <td>

<h5>Fortune Pearl Hotel, Deira, Dubai</h5>
<p>Omar Bin Khattab Road, After Naif Signal, behind Al Baraha, Dubai, 95661, AE</p>
      </td>
    </tr>


    <tr>

        <td> 

        <div className='row'>


            <div className='col-lg-4'> <b>Check In:</b> 2024-05-15T00:00:00</div>
            <div className='col-lg-4'> <b>Check Out: </b>2024-05-16T00:00:00</div>
            <div className='col-lg-4'> 1 Nights</div>
        </div>



        </td>
    </tr>

  </tbody>
</table>
</div>


<div className='col-12  mt-2 mb-2'>

<table className="table table-bordered mb-0">
           
           <thead className="align-middle text-center bg-light">
           <tr className='table-secondary'>

           <th>ROOM TYPE</th>
           <th>Room 1</th>
           </tr>
           </thead>       
           <tbody>
           <tr className="text-muted text-center">
           <td>Double Room,1 King Bed,Nonsmoking</td>
           <td>2 (ADULT(s)), 0 (CHILD(s))</td>
           </tr>
           </tbody>


           <thead className="align-middle text-center bg-light">
           <tr className='table-secondary'>

           <th>ROOM TYPE</th>
           <th>Room 2</th>
           </tr>
           </thead>       
           <tbody>
           <tr className="text-muted text-center">
           <td>Double Room,1 King Bed,Nonsmoking</td>
           <td>2 (ADULT(s)), 0 (CHILD(s))</td>
           </tr>
           </tbody>


           <thead className="align-middle text-center bg-light">
          <tr className='table-secondary'>

          <th>No. of Rooms</th>
          <th>No. of Guests</th>
          </tr>
          </thead>
         
          <tbody>
          <tr className="text-muted text-center">
          <td>2</td>
          <td>4</td>
          </tr>

          </tbody>


           </table>

</div>


<div className='col-12  mt-2 mb-2'>


   

<table className="table border">
  <thead>

<tr className='table-secondary'>

    <th colSpan={4}>Lead Guest  </th>
</tr>

    <tr>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Phone No.</th>
      <th scope="col">Nationality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
    
      <td>Mr. Sneha Sonawane</td>
      <td>ssonawane@accelaero.com</td>
      <td>0501234567</td>
      <td>INDIA</td>
    </tr>

  </tbody>
</table>
</div>


<div className='col-12  mt-2 mb-2'>


<table className="table border">
  <thead>

<tr className='table-secondary'>

    <th>Hotel Norms  </th>
</tr>


  </thead>
  <tbody>
    <tr>
    

      <td>

<div className='leTxtFit'>
No name change for existing bookings Estimated total amount of taxes & fees for this booking:20.00 Utd. Arab Emir. Dirham payable on arrival. Please note
that the city tax for accommodations with more than 1 bedroom shall be charged per bedroom per night. Check-in hour 14:00-12:00.Deposit on
arrivalidentification card at arrival.Car park YES (With additional debit notes).<br/><b>IMPORTANT NOTE:</b> Compulsory Tourism Dirham Fee (per room
per night) to be paid by guest directly at the time of check out to the hotel.   

</div>

      </td>
    </tr>

  </tbody>
</table>
</div>


<div className='col-12  mt-2 mb-2'>


<table className="table border">
  <thead>

<tr className='table-secondary'>

    <th>Cancellation and Charges </th>
</tr>


  </thead>
  <tbody>
    <tr>
    

      <td>

<div className='leTxtFit'>
AED 138.00 will be charged between 03-May-2024 and 14-May-2024 <br></br>
AED 138.00 will be charged between 03-May-2024 and 14-May-2024

</div>

      </td>
    </tr>

  </tbody>
</table>
</div>




<div className='col-12  mt-2 mb-2'>

<div className='row'>

    
<div className="col-12 mb-3">

<Link className='text-primary' to='' onClick={() => setShowHistory(true)}>Show Booking History</Link>
  </div>


  <div className='col-12'> 

  <div className="form-floating">
<textarea className="form-control" placeholder="Leave a comment here" id="floatingTextarea2" 
style={{height:'100px'}}></textarea>
<label htmlFor="floatingTextarea2">Enter Comments</label>
</div>

<div className="col-12 text-end mt-3 mb-2">

<button className='btn btn-sm btn-primary'>
Submit
</button>


</div>

  </div>

{showHistory ? 
(
<div className='col-12  mt-2 mb-2'>


<table className="table border">
  <thead>

<tr className='table-secondary'>

    <th colSpan={3}>Booking History  </th>

    <th className='text-end'> 
    <Link className='text-dark' to='' onClick={() => setShowHistory(false)}><MdOutlineClose /></Link>

    </th>
</tr>

<tr>
<th>Date</th>
<th>Time (Local)</th>
<th>Narration </th>
<th>Consultant</th>

</tr>


  </thead>
  <tbody>
    <tr>
    

      <td> 07May 2024 </td>
      <td> 05:37AM </td>
      <td> 

    <div className='leTxtFit'>
    Booking is Ready(IP address: 10.200.414) FORWARDED IP : 10.200414 , REMOTE IP : 1050.20.72 , BROWSER NAME : Edge 124.0.0.0 , VERSION : 124.0 0S : WinNT REQUESTED DATE TIME Central
    2024 5/7/2024 9:37:45 AM, LOGIN INFO ID: 0, LOGIN USER NAME : Central Administrator Administrator
    </div>


      </td>
      <td> Central Administrator  </td>

       


      
    </tr>


    <tr>
    

      <td> 07May 2024 </td>
      <td> 05:37AM </td>
      <td> 

    <div className='leTxtFit'>
    Booking is Ready(IP address: 10.200.414) FORWARDED IP : 10.200414 , REMOTE IP : 1050.20.72 , BROWSER NAME : Edge 124.0.0.0 , VERSION : 124.0 0S : WinNT REQUESTED DATE TIME Central
    2024 5/7/2024 9:37:45 AM, LOGIN INFO ID: 0, LOGIN USER NAME : Central Administrator Administrator
    </div>


      </td>
      <td> Central Administrator  </td>

       


      
    </tr>


  </tbody>
</table>
</div>

) 

: (null)}







</div>



</div>





</div>





</div>




<div className='col-lg-4'>


<div className='col-12  mt-2 mb-2'>


<table className="table border">
  <thead>

<tr className='table-secondary'>

    <th colSpan={2}>Sales Summary  </th>
</tr>


<tr>
    <th>Room Type</th>
    <th>TOTAL (in AED)</th>
     </tr>


  </thead>
  <tbody>
   
    <tr>    
      <td> Double or twin standard </td>
      <td> 127.98 </td>
    </tr>

    <tr>    
      <td> Double or twin standard </td>
      <td> 127.98 </td>
    </tr>

    <tr>    
      <td> MARKUP</td>
      <td> 25.60 </td>
    </tr>
    
    <tr>    
      <td> VAT</td>
      <td> 1.28</td>
    </tr>

    <tr>    
      <td> TOTAL</td>
      <td> 282.84</td>
    </tr>

    <tr>    
      <td> GRAND TOTAL</td>
      <td> 283.00</td>
    </tr>

  </tbody>
</table>
</div>


</div>

        </div>

        </div>


    </MainLayout>
    </>

  )
}
