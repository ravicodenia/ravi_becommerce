import { Logo } from '@mfa-travel-app/assets';
import  { useRef } from 'react';
import { useReactToPrint } from 'react-to-print';

export default function ViewHotelInvoice() {
    const contentToPrint = useRef(null);

    const handlePrint = useReactToPrint({
      documentTitle: "Print This Document",
      removeAfterPrint: true,
    });

    
  return (
   
   
<>

<div style={{padding:'0 10px'}}> 
<table ref={contentToPrint} style={{fontSize:'13px', width:'96%', margin:'auto'}}>
  <tbody>



   <tr>
    <td style={{textAlign:'start'}}>
    <img style={{height:'16px'}} src={Logo} alt="logo" />
    </td>

    <td style={{textAlign:'center'}}> <h4 style={{margin:'0'}}>Invoice</h4> </td>

    <td style={{textAlign:'end'}}> 

      <table style={{display:'inline'}}>
        <tbody>

        <tr>
<td style={{textAlign:'end'}}> 
  <button onClick={() => {
        handlePrint(null, () => contentToPrint.current);
      }}>Print</button>

<button>Email</button>
  
   </td>

        </tr>

           <tr> 
         
            <td>Agent Name: B-Commerce</td>
           </tr> 

           <tr> 
           
            <td>Agent eMail: Support@bcommerce.com </td>
           </tr> 

           <tr> 
           
            <td>Phone: +1 618 7785580 </td>
           </tr> 

          </tbody>
        </table>

  
    </td>
   </tr>






<tr>

<td colSpan={3}> 

<table style={{fontSize:'13px', width:'100%', border:'solid 1px #ccc', marginBottom:'20px'}}>
<thead>

<tr style={{background:'#f2aa3b', color:'white'}}>
<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>Invoice Details</th>
</tr>
</thead>

<tbody> 


<tr>
<td style={{borderRight:'solid 1px #ccc'}}>

<table style={{fontSize:'13px', width:'100%'}}>


<thead>

<tr>

<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}> Invoice No.</th>
<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>Date </th>
<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}> Confirmation No. </th>
<th style={{paddingLeft:'10px'}}> Voucher No. </th>

</tr>


</thead>

<tbody>

<tr style={{height:'30px'}}>

<td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>HW9540</td>
<td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>11 June 2024</td>
<td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>46_46-2401519_1</td>
<td style={{paddingLeft:'10px'}}>HTL-CT-81557</td>

</tr>



</tbody>



</table>



</td>


</tr>




</tbody>




</table>



</td>

</tr>



<tr>

<td colSpan={3}> 

<table style={{fontSize:'13px', width:'100%', border:'solid 1px #ccc', marginBottom:'20px'}}>
<thead>

<tr style={{background:'#173540', color:'white'}}>
<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>Client Details</th>
</tr>
</thead>

<tbody> 


<tr>
<td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>

<table style={{fontSize:'13px', width:'100%'}}>


<thead>

<tr>

<th style={{ borderRight:'solid 1px #ccc'}}>Agency Name</th>
<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>	Agency Code </th>
<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>Agency Address </th>
<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}> TelePhone No </th>
<th style={{paddingLeft:'10px'}}> TRN Number </th>

</tr>


</thead>

<tbody>

<tr style={{height:'30px'}}>

<td style={{borderRight:'solid 1px #ccc'}}>Akbar Travel LLC</td>
<td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>AERCPETR1</td>
<td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>address</td>
<td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>Phone: 0097165074592, Fax: 6454788</td>
<td style={{paddingLeft:'10px'}}>6454878</td>

</tr>



</tbody>



</table>



</td>


</tr>




</tbody>




</table>



</td>

</tr>


<tr>

<td colSpan={3}> 

<table style={{fontSize:'13px', width:'100%', border:'solid 1px #ccc', marginBottom:'20px'}}>
<thead>

<tr style={{background:'#173540', color:'white'}}>
<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>Booking Details</th>
</tr>
</thead>

<tbody> 


<tr>
<td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>

<table style={{fontSize:'13px', width:'100%'}}>



<tbody>

<tr style={{height:'30px'}}>
    <th>Booking Date: </th>
    <td>11 Jun 24 </td>
</tr>

<tr style={{height:'30px'}}>
    <th>Check In: </th>
    <td>25 Jun 24 </td>
    <th>Check Out: </th>
    <td>26 Jun 24 </td>
</tr>

<tr style={{height:'30px'}}>
    <th>No. of Night(s): </th>
    <td>1 </td>
    <th>No. of Room(s): </th>
    <td>1 </td>
</tr>


</tbody>



</table>



</td>


</tr>




</tbody>




</table>



</td>

</tr>


<tr>

<td colSpan={3}> 

<table style={{fontSize:'13px', width:'100%', border:'solid 1px #ccc', marginBottom:'20px'}}>
<thead>

<tr style={{background:'#173540', color:'white'}}>
<th style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>Hotel Details</th>
</tr>
</thead>

<tbody> 


<tr>
<td style={{paddingLeft:'10px', borderRight:'solid 1px #ccc'}}>

<table style={{fontSize:'13px', width:'100%'}}>



<tbody>




<tr style={{height:'30px'}}>
    <th>Hotel Name: </th>
    <td>Deccan Comforts</td>
</tr>

<tr style={{height:'30px'}}>
    <th>Address1: </th>
    <td>No. 5-9-19/14, 15 Old Secretariat Road, Green Gates, Saifabad, Hyderabad, Telangana, 500022, IN</td>
</tr>


<tr style={{height:'30px'}}>
    <th>City:  </th>
    <td>Hyderabad</td>
</tr>


</tbody>



</table>



</td>


</tr>




</tbody>




</table>



</td>

</tr>





<tr>

<td colSpan={3}> 

<table style={{fontSize:'13px', width:'100%', border:'solid 1px #ccc'}}>
<thead>

  <tr style={{background:'#ddd'}}>

<th style={{paddingLeft:'10px'}}>Lead Passanger Details</th>


  </tr>
</thead>

<tbody> 


  <tr>
<td style={{paddingLeft:'10px', height:'30px'}}>MR.JAMES FLANAGAN</td>




  </tr>


</tbody>




</table>



</td>

</tr>





<tr>

<td style={{textAlign:'end'}} colSpan={3}> 

<table style={{fontSize:'13px', width:'190px', display:'inline-block'}}>



<tbody> 
  <tr>
    <td style={{paddingLeft:'10px', textAlign:'right', width:'100px', borderBottom:'solid 1px #ccc'}}>Net Amount:</td>
    <td style={{paddingLeft:'10px', textAlign:'left',  borderBottom:'solid 1px #ccc'}}>AED 57.45</td>
</tr>

<tr>
    <td style={{paddingLeft:'10px', textAlign:'right',  borderBottom:'solid 1px #ccc'}}>Markup:</td>
    <td style={{paddingLeft:'10px', textAlign:'left',  borderBottom:'solid 1px #ccc'}}>AED 5.75</td>
</tr>



<tr>
    <td style={{paddingLeft:'10px', textAlign:'right', borderBottom:'solid 1px #ccc'}}>Discount:</td>
    <td style={{paddingLeft:'10px', textAlign:'left',  borderBottom:'solid 1px #ccc'}}>AED 4.00</td>
</tr>
<tr>
    <td style={{paddingLeft:'10px', textAlign:'right',  borderBottom:'solid 1px #ccc'}}>In Vat:</td>
    <td style={{paddingLeft:'10px', textAlign:'left',  borderBottom:'solid 1px #ccc'}}>AED 0.00</td>
</tr>
<tr>
    <td style={{paddingLeft:'10px', textAlign:'right',  borderBottom:'solid 1px #ccc'}}>Gross Amount:</td>
    <td style={{paddingLeft:'10px', textAlign:'left',  borderBottom:'solid 1px #ccc'}}>AED 60.00</td>
</tr>
<tr>
    <td style={{paddingLeft:'10px', textAlign:'right', borderBottom:'solid 1px #ccc'}}>Out Vat:</td>
    <td style={{paddingLeft:'10px', textAlign:'left', borderBottom:'solid 1px #ccc'}}>AED 0.00</td>
</tr>


<tr>
    <td style={{paddingLeft:'10px', textAlign:'right',  borderBottom:'solid 1px #ccc'}}>Total Amount:</td>
    <td style={{paddingLeft:'10px', textAlign:'left',  borderBottom:'solid 1px #ccc'}}><b>AED 60.00</b></td>
</tr>

</tbody>



</table>



</td>

</tr>



<tr>

<td style={{textAlign:'end'}} colSpan={3}> 

<table style={{fontSize:'13px', width:'100%', marginTop:'6px', marginBottom:'30px'}}>



<tbody> 
  <tr>
    <td style={{paddingLeft:'10px', textAlign:'left'}}>    
    Invoiced By: Akbar Travels of India Pvt Ltd
    </td>
</tr>

<tr>
    <td style={{paddingLeft:'10px', textAlign:'left'}}>
    Created by: Admin</td>

</tr>

<tr>
    <td style={{paddingLeft:'10px', textAlign:'left'}}>
    Place: Mumbai </td>

</tr>









</tbody>



</table>



</td>

</tr>


  </tbody>
</table>

</div>






</>



  )
}
