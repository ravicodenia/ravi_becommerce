import { useEffect, useState } from 'react';
import Select from 'react-select';
import styles from '../../../../flights/src/lib/oneway.module.scss';
import classNames from 'classnames';
import { useSelector } from 'react-redux';
import { RootState, useStore } from '@mfa-travel-app/store';
import { getCountries } from 'libs/features/flights/src/lib/service/homeApi';
import { Loader } from '@mfa-travel-app/ui';

interface Supplier {
  value: string;
  label: string;
}

const AdditionalSerach = ({ onAdditionalSearch }: any) => {
  const { suppliers } = useSelector((state: RootState) => state?.config);
  const { hotelNames } = useSelector((state: RootState) => state?.hotel);
  const { saveCountriesDetails } = useStore();

  const [loader, setLoader] = useState<any>(false);
  const [supplierOptions, setSupplierOptions] = useState<Supplier[]>([]);
  const [showSuppliers, setShowSuppliers] = useState<boolean>(false);
  const [starOptions] = useState<any[]>([
    { value: 0, label: 'All' },
    { value: 1, label: '1 Star' },
    { value: 2, label: '2 Star' },
    { value: 3, label: '3 Star' },
    { value: 4, label: '4 Star' },
    { value: 5, label: '5 Star' },
  ]);
  const [countryResidence, setCountryResidence] = useState<any>();
  const [countryList, setCountryList] = useState<any>([]);
  const [propertyName, setPropertyName] = useState<any>('');
  const [starRating, setStarRating] = useState<any>({ value: 0, label: 'All' });
  const [selectedSupplier, setSelectedSupplier] = useState<any>([
    { value: 'TBO HOLIDAYS', label: 'TBO HOLIDAYS' },
  ]);
  const [markup, setMarkup] = useState<any>('');

  useEffect(() => {
    if (suppliers && suppliers.length > 0) {
      setSupplierOptions(
        suppliers
          .filter((s: any) => s.productId === 2)
          .map((supplier: any) => ({
            value: supplier.code,
            label: supplier.text,
          }))
      );
    }
    getCountriesList();
  }, [suppliers]);

  const getCountriesList = async () => {
    setLoader(true);
    const response: any = await getCountries();
    setLoader(false);
    if (response?.status == 200) {
      const countries = response?.data?.map((country: any) => {
        return {
          label: country?.text,
          value: country?.value,
        };
      });
      setCountryList(countries);
      saveCountriesDetails(response?.data);
    }
  };

  const fareTypeOptions = [
    { value: 'published', label: 'Published' },
    { value: 'published', label: 'Published' },
    { value: 'published', label: 'Published' },
  ];

  const handleOutsideClick = (event: MouseEvent) => {
    const target = event.target as HTMLElement;
    if (!target.closest || !target.classList) {
      return;
    }

    if (
      !target.closest('#selectSuppliers') &&
      !target.classList.contains('supplier')
    ) {
      setShowSuppliers(false);
    }
  };

  useEffect(() => {
    document.body.addEventListener('click', handleOutsideClick);
    return () => {
      document.body.removeEventListener('click', handleOutsideClick);
    };
  }, []);
const hotelOptions = hotelNames.map((hotel:any) => ({
  value: hotel.hotelCode,
  label: hotel.hotelName
}));
  return (
    <>
      <div id="div_additional_flight_search">
        <div className="row">
          <div className="col-lg-3">
            <div
              className="mb-3 position-relative oneway_input-text-left__n4aco"
              style={{ padding: '0 10px' }}
            >
              <label
                htmlFor="preferred-airline"
                className={styles['form-label']}
              >
                Country of Residence
              </label>
              <Select
                isMulti
                options={countryList}
                value={countryResidence}
                onChange={(selectedOptions: any) => {
                  const options = selectedOptions as { value: string }[];
                  setCountryResidence(options);
                  onAdditionalSearch(
                    options,
                    propertyName,
                    starRating,
                    markup,
                    selectedSupplier
                  );
                }}
              />
            </div>
          </div>
          <div className="col-lg-3">
            <div className={classNames('mb-3', styles['input-text-left'])}>
              <label htmlFor="markupin" className={styles['form-label']}>
                Property Name
              </label>
              {hotelNames ? (
                <Select
                  isMulti
                  options={hotelOptions}
                  value={propertyName}
                  onChange={(selectedOptions: any) => {
                    const options = selectedOptions as { value: string }[];
                    setPropertyName(options)
                    onAdditionalSearch(
                      countryResidence,
                      options,
                      starRating,
                      markup,
                      selectedSupplier
                    );
                  }}
                />
              ) : (
                <input
                  type="text"
                  className={classNames(
                    'form-control',
                    styles['input-padd-markup']
                  )}
                  id="markupin"
                  placeholder="Property Name"
                  value={propertyName}
                  onChange={(e) => {
                    setPropertyName(e.target.value);
                    onAdditionalSearch(
                      countryResidence,
                      e.target.value,
                      starRating,
                      markup,
                      selectedSupplier
                    );
                  }}
                />
              )}
            </div>
          </div>
          <div className="col-lg-3">
            <div
              className="mb-3 position-relative oneway_input-text-left__n4aco"
              style={{ padding: '0 10px' }}
            >
              <label
                htmlFor="preferred-airline"
                className={styles['form-label']}
              >
                Star Rating
              </label>
              <Select
                options={starOptions}
                value={starRating}
                onChange={(selectedOptions) => {
                  setStarRating(selectedOptions as { value: string }[]);
                  onAdditionalSearch(
                    countryResidence,
                    propertyName,
                    selectedOptions as { value: string }[],
                    markup,
                    selectedSupplier
                  );
                }}
              />
            </div>
          </div>

          {/* <div className="col-lg-3">
            <div className={classNames('mb-3', styles['input-text-left'])}>
              <label htmlFor="markupin" className={styles['form-label']}>
                Markup in %
              </label>
              <input
                type="text"
                className={classNames(
                  'form-control',
                  styles['input-padd-markup']
                )}
                id="markupin"
                placeholder="mark in"
                value={markup}
                onChange={(e) => {
                  setMarkup(e.target.value);
                  onAdditionalSearch(
                    countryResidence,
                    propertyName,
                    starRating,
                    e.target.value,
                    selectedSupplier
                  );
                }}
              />
            </div>
          </div> */}

          <div className="col-lg-3">
            <div
              className="mb-3 position-relative oneway_input-text-left__n4aco"
              style={{ padding: '0 10px' }}
            >
              <label htmlFor="supplierslist" className={styles['form-label']}>
                Select Suppliers
              </label>
              <Select
                isMulti
                options={supplierOptions}
                value={selectedSupplier}
                onChange={(selectedOptions) => {
                  setSelectedSupplier(
                    selectedOptions as { value: string; label: string }[]
                  );
                  onAdditionalSearch(
                    countryResidence,
                    propertyName,
                    starRating,
                    markup,
                    selectedOptions as { value: string; label: string }[]
                  );
                }}
              />
            </div>
          </div>
        </div>
      </div>
      {loader && <Loader />}
    </>
  );
};

export default AdditionalSerach;
