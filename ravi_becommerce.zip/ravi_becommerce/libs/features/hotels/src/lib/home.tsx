import RecentSearch from './pages/recentSearch';
import Promotions from './pages/promotion';
import BookingsTables from './pages/bookingStable';
import SearchHotal from './pages/searchHotal';

export const Hotel = () => {

  return (
    <>
      <SearchHotal />
      <RecentSearch />
      <Promotions />
      <BookingsTables />
    </>

  );
};

export default Hotel;