import { postGatewayAPI, getGatewayAPI } from '@mfa-travel-app/services';
import {
  HOTEL_CITIES,
  HOTEL_SEARCH_DATA,
  HOTEL_INFO_DATA,
  HOTEL_CANCELLATION_POLICY,
  HOTEL_ROOM_DATA,
  HOTEL_BOOK,
  HOTEL_NAMES,
  HOTEL_RECENT_SEARCH 
} from '../constants';

export const getHotelList = async () => {
  try {
    const response = await postGatewayAPI(HOTEL_CITIES, {});
    return response;
  } catch (error) {
    return error;
  }
};

export const searchHotelList = async (data: any) => {
  try {
    const response = await postGatewayAPI(HOTEL_SEARCH_DATA, {
      ...data,
    });
    return response;
  } catch (error) {
    return error;
  }
};

export const searchHotelInformation = async (
  sessionId: String,
  hotelId: String,
  hotelCode: String
) => {
  try {
    const response = await postGatewayAPI(HOTEL_INFO_DATA, {
      sessionId: sessionId,
      hotelId: hotelId,
      hotelCode: hotelCode,
    });
    return response;
  } catch (error) {
    return error;
  }
};

export const searchHotelRoomInformation = async (
  sessionId: String,
  hotelId: String,
  hotelCode: String,
  hotelReferenceCode: String,
  roomPaxInfo: any
) => {
  try {
    const response = await postGatewayAPI(HOTEL_ROOM_DATA, {
      sessionId: sessionId,
      hotelId: hotelId,
      hotelCode: hotelCode,
      hotelReferenceCode: hotelReferenceCode,
      roomPaxInfo: roomPaxInfo,
    });
    return response;
  } catch (error) {
    return error;
  }
};

export const getHotelCancellationPolicy = async (
  sessionId: String,
  hotelId: String,
  hotelCode: String,
  hotelReferenceCode: String,
  noOfRooms: number,
  roomReferences: any
) => {
  try {
    const response = await postGatewayAPI(HOTEL_CANCELLATION_POLICY, {
      sessionId: sessionId,
      hotelId: hotelId,
      hotelCode: hotelCode,
      hotelReferenceCode: hotelReferenceCode,
      noOfRooms: noOfRooms,
      roomReferences: roomReferences,
    });
    return response;
  } catch (error) {
    return error;
  }
};

export const bookHotelRoom = async (payload: any) => {
  try {
    const response = await postGatewayAPI(HOTEL_BOOK, {
      ...payload,
    });
    return response;
  } catch (error) {
    return error;
  }
};

export const getHotelNames = async (city: string) => {
  try {
    const response = await postGatewayAPI(HOTEL_NAMES, null, {
      params: {
        city: city
      }
    });
    return response;
  } catch (error) {
    return error;
  }
};

export const getHotelRecentSearch = async (agentId: number | string) => {
  try {
    const response = await getGatewayAPI( HOTEL_RECENT_SEARCH + '/' +agentId);
    return response;
  } catch (error) {
    return error;
  }
};
