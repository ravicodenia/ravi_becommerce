// HOTEL APIs
export const HOTEL_CITIES  ="hotel/Hotel/GetHotelCities";
export const HOTEL_SEARCH_DATA ="hotel/Hotel/GetHotelResults";
export const HOTEL_INFO_DATA ="hotel/Hotel/GetHotelInfo";
export const HOTEL_ROOM_DATA ="hotel/Hotel/GetHotelRoomInfo";
export const HOTEL_CANCELLATION_POLICY ="hotel/Hotel/GetHotelRoomCancelPolicy";
export const HOTEL_BOOK ="hotel/Hotel/HotelBook";
export const HOTEL_NAMES = "hotel/Hotel/GetHotelNamesByCity"
export const HOTEL_RECENT_SEARCH = "hotel/HotelSearchInfo/GetHotelSearchHistoryByAgentd"