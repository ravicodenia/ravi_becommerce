export * from './lib/auth';
export {default as Login} from './lib/compoents/login';
export { default as SignUp} from './lib/pages/signUp';
export { default as Otp} from './lib/pages/otp';
export { default as ResetPassword} from './lib/modal/resetPassword';
export { default as AuthProvider } from './lib/compoents/authProvider';
export {default as PrivateRoutes} from './lib/compoents/protectedRouter';
export { logoutUser } from './lib/service/authApi';