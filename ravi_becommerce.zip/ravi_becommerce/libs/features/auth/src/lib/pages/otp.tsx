import { AuthLayout } from "@mfa-travel-app/layout";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { resetOtp, verifyOtp } from "../service/authApi";
import { useStore } from "@mfa-travel-app/store";
import { toast } from 'react-toastify';
import { useLocation } from 'react-router-dom';
import { Loader } from "@mfa-travel-app/ui";
import { TO_MILLISECONDS } from "../service/constants";
import { MuiOtpInput } from "mui-one-time-password-input";

export const Otp = () => {
    const [loader, setLoader] = useState(false);
    const [otpInput, setOtpInput] = useState('');
    const { saveAuthDetails, saveAuthTokenExpiryAt } = useStore();

    const navigate = useNavigate();
    const location = useLocation();
    const { username, email } = location.state || {};

    const handleOptInput = (newValue: any) => {
        setOtpInput(newValue);
    }

    const verifyOtpFunc = async (value: any) => {
        try {
            setLoader(true);
            const logInUser: any = await verifyOtp(username, Number(value));

            if (logInUser?.data?.result && logInUser?.data?.statusCode === 200) {
                if (logInUser?.data?.result?.accessToken) {
                    let expiresAt = logInUser?.headers['request-receive-time'];
                    expiresAt = expiresAt + (logInUser?.data?.result?.expiresIn * TO_MILLISECONDS);

                    saveAuthTokenExpiryAt(expiresAt);
                    saveAuthDetails(logInUser?.data?.result);

                    toast.success('OTP Verified, Login Successful.');
                    navigate('/home');
                    setLoader(false);
                } else {
                    toast.error(logInUser?.data?.message);
                    setLoader(false);
                }
            } else {
                toast.error(logInUser?.data?.message);
                setLoader(false);
            }
        } catch (error) {
            console.error("An error occurred:", error);
            toast.error("An error occurred. Please try again later.");
            setLoader(false);
        }
    };

    const resetOtpForUser = async () => {
        try {
            setLoader(true);
            const response: any = await resetOtp(username);

            if (response?.data?.statusCode === 200) {
                toast.success(response?.data?.message);
                setLoader(false);
            } else {
                toast.error('An error occurred. Please try again later.');
                setLoader(false);
            }
        } catch {
            toast.error('An error occurred. Please try again later.');
            setLoader(false);
        }
    }

    return (
        <AuthLayout>
            <>
                <div className="row">
                    <div className="col-12 mt-2">
                        <div className="formfields">
                            <div className="otpContainer">
                                <div className="row justify-content-center">
                                    <div className="col-12">
                                        <div className="mb-5 mt-5 border-0"></div>
                                    </div>
                                    <div className="card-body text-center">
                                        <h5>OTP Verification</h5>
                                        <div className="text-muted">{`Enter OTP Code sent to ${email}`}</div>
                                        <div className="otp-field">
                                            <MuiOtpInput
                                                autoFocus
                                                length={6}
                                                value={otpInput}
                                                onChange={handleOptInput}
                                                onComplete={(value) => verifyOtpFunc(value)}
                                                TextFieldsProps={{
                                                    type: 'number',
                                                    inputProps: {
                                                        inputMode: 'numeric',
                                                        pattern: '[0-9]*',
                                                    },
                                                }}
                                            />
                                        </div>
                                        <div className="mb-1 text-muted">Didn't receive OTP code? </div>
                                        <div className="resendOTP"> <a onClick={resetOtpForUser}>Resend Code </a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {loader && <Loader />}
            </>
        </AuthLayout>
    );
};

export default Otp;
