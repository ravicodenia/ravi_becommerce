import { Link } from "react-router-dom";
import "react-datepicker/dist/react-datepicker.css";
import { useState } from "react";
// import { Layout, LoginFooter } from "../../../../../layout/src";
import { CustomInput,CheckboxInput,  CustomSelect, FileInput, NumberInput} from "@mfa-travel-app/ui";


export const SignUp = () => {
    const [selectedValues, setSelectedValues] = useState<string[]>([]);

    const handleChange = (newValues: string[]) => {
        setSelectedValues(newValues);
    };
    const options = [
        { value: '1', label: 'Option 1' },
        { value: '2', label: 'Option 2' },
        { value: '3', label: 'Option 3' },
        // Add more options as needed
    ];
    return (
        <>
       <div className="container mb-5 mt-5">
            <section className="user_master_section">


                <div className="innerContainer border-end-0 border-top-0"> 
                
                    <form>

                     

                            <div className="row">


                                <div className="col-12"><h5>Sign Up </h5></div>

                                    <div className="col-12">
                                    <div className="form_heading">
                                    <span className=" title">Agency Info</span>
                                    </div>

                                    </div>

                                    </div>
                          
                                <div className="row">
                             
            


                                    <div className="col-md-4 px-2">
                                    <label className="form-label">Agency Name <i className="text-danger">*</i></label>
                                   
                                        <div className="mb-3 text-start">
                                            <CustomInput
                                                id="agencyname"
                                                placeholder="Name of your Agency"
                                                ariaDescribedby="description"
                                                register={() => { console.log("agencyname") }}
                                                signUp={{ agencyname: 'defaultValue' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.agencyname?.message} */}
                                            </p>
                                        </div>
                                     
                                        <div className="mb-3 text-start">
                                        <label className="form-label">Address <i className="text-danger">*</i></label>

                                        <CustomInput
                                                id="Address"
                                                placeholder=""
                                                ariaDescribedby="Address"
                                                register={() => { console.log("Address") }}
                                                signUp={{ agencyname: 'defaultValue' }}
                                            />

                                            


                                            <p className="form_errors">
                                                {/* {errors.address?.message} */}
                                            </p>
                                        </div>
                                        <div className="mb-3 text-start">
                                        <label className="form-label">P.O. Box <i className="text-danger">*</i></label>
                                            <CustomInput
                                                id="pobox"
                                                placeholder="P.O Box"
                                                ariaDescribedby="description"
                                                register={() => { console.log("pobox") }}
                                                signUp={{ agencyname: 'defaultValue' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.pobox?.message} */}
                                            </p>
                                        </div>
                                        <div className="mb-3 text-start">
                                        <label className="form-label">Preferred Language <i className="text-danger">*</i></label>
                                            <CustomSelect
                                                id="Preferredlang"
                                                defaultValue=""
                                                options={[
                                                    { value: "", label: "Preferred Language" },
                                                    { value: "1", label: "English" },
                                                    { value: "2", label: "Telugu" },
                                                    { value: "3", label: "Hindi" }
                                                ]}
                                                register={() => { console.log("Preferred Language") }}
                                                signUp={{ language: 'defaultValue' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.errors?.message} */}
                                            </p>
                                        </div>
                                        <div className="mb-3 text-start">
                                        <label className="form-label">Email  <i className="text-danger">*</i></label>
                                            <CustomInput
                                                id="email"
                                                placeholder="Email "
                                                ariaDescribedby="email"
                                                register={() => { console.log("email") }}
                                                signUp={{ agencyname: 'email' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.errors?.message} */}
                                            </p>
                                        </div>
                                        <div className="mb-3 text-start">
                                        <label className="form-label">Land Phone <i className="text-danger">*</i></label>
                                            <NumberInput
                                                id="landPhone"
                                                placeholder="Land Phone"
                                            />
                                            <p className="form_errors">
                                                {/* {errors.?.message} */}
                                            </p>
                                        </div>
                                    </div>

                                    <div className="col-md-4 px-2">
                                    <label className="form-label">Country <i className="text-danger">*</i></label>
                                        <div className="mb-3 text-start">
                                            <CustomSelect
                                                id="country1"
                                                defaultValue=""
                                                options={[
                                                    { value: "", label: "Country " },
                                                    { value: "1", label: "India" },
                                                    { value: "2", label: "America" },
                                                    { value: "3", label: "Singapore" }
                                                ]}
                                                register={() => { console.log("Country") }}
                                                signUp={{ language: 'defaultValue' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.country?.message} */}
                                            </p>
                                        </div>
                                        <div className="mb-3 text-start">

                                        <label className="form-label">State <i className="text-danger">*</i></label>
                                            <CustomSelect
                                                id="satate1"
                                                defaultValue=""
                                                options={[
                                                    { value: "", label: "State " },
                                                    { value: "1", label: "Telangana" },
                                                    { value: "2", label: "Andhra pradesh" },
                                                    { value: "3", label: "karnataka" }
                                                ]}
                                                register={() => { console.log("state") }}
                                                signUp={{ language: 'defaultValue' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.state?.message} */}
                                            </p>
                                        </div>
                                        <div className="mb-3 text-start">
                                        <label className="form-label">City <i className="text-danger">*</i></label>
                                            <CustomInput
                                                id="city1"
                                                placeholder="City"
                                                ariaDescribedby=""
                                                register={() => { console.log("city") }}
                                                signUp={{ agencyname: 'city' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.city?.message} */}
                                            </p>
                                        </div>
                                        <div className="mb-3 text-start">
                                        <label className="form-label">Business Currency <i className="text-danger">*</i></label>

                                            <CustomSelect
                                                id="business_currency"
                                                defaultValue=""
                                                options={[
                                                    { value: "", label: " Business Currency " },
                                                    { value: "1", label: "Dollar" },
                                                    { value: "2", label: "Pound" },
                                                    { value: "3", label: "Euro" }
                                                ]}
                                                register={() => { console.log("Business Currency") }}
                                                signUp={{ language: 'defaultValue' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.businesscurrency?.message} */}
                                            </p>
                                        </div>
                                        <div className="mb-3 text-start">
                                        <label className="form-label">Website <i className="text-danger">*</i></label>
                                            <CustomInput
                                                id="wesbite1"
                                                placeholder="Website "
                                                ariaDescribedby="Website"
                                                register={() => { console.log("Website") }}
                                                signUp={{ agencyname: 'Website' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.?.message} */}
                                            </p>
                                        </div>
                                        <div className="mb-3 text-start">

                                        <label className="form-label">Fax <i className="text-danger">*</i></label>

                                            <NumberInput
                                                id="fax1"
                                                placeholder="Fax"
                                            />
                                            <p className="form_errors">
                                                {/* {errors.?.message} */}
                                            </p>
                                        </div>
                                    </div>

                                    <div className="col-md-4 px-2">
                                    <label className="form-label">Registration / Trade License No <i className="text-danger">*</i></label>

                                        <div className="mb-3 text-start">
                                            <CustomInput
                                                id="trade_licence_no"
                                                placeholder="Registration / Trade License No"
                                                ariaDescribedby=""
                                                register={() => { console.log("Website") }}
                                                signUp={{ agencyname: 'Registration' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.licence?.message} */}
                                            </p>
                                        </div>
                                        <div className="mb-3 text-start">
                                        <label className="form-label">Name of Authorized Person on Trade License <i className="text-danger">*</i></label>

                                            <CustomInput
                                                id="authperson1"
                                                placeholder="Name of Authorized Person on Trade License"
                                                ariaDescribedby=""
                                                register={() => { console.log("authperson") }}
                                                signUp={{ agencyname: 'authperson' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.authperson?.message} */}
                                            </p>
                                        </div>
                                        <div className="mb-3 text-start">
                                            {/* <div className="form-control datepicker_section"> */}
                                            {/* <DatePicker className="datepicker" 
                                                selected={date} 
                                                onChange={(date) => setStartDate(date)}
                                                 /> */}

                                        <label className="form-label">License Issued On <i className="text-danger">*</i></label>

                                        <CustomInput
                                                id="licence_issued_on"
                                                placeholder="License Issued On"
                                                ariaDescribedby=""
                                                register={() => { console.log("License Issued On") }}
                                                signUp={{ agencyname: 'License Issued On' }}
                                            />


                                            {/* </div> */}
                                        </div>
                                        <div className="mb-3 text-start">
                                        <label className="form-label">IATA Code <i className="text-danger">*</i></label>
                                            <CustomInput
                                                id="iatacode"
                                                placeholder="IATA Code"
                                                ariaDescribedby=""
                                                register={() => { console.log("iatacode") }}
                                                signUp={{ agencyname: 'iatacode' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.iatacode?.message} */}
                                            </p>
                                        </div>
                                        <div className="mb-3 text-start">
                                        <label className="form-label">Time Zone <i className="text-danger">*</i></label>

                                            <CustomSelect
                                                id="timeZone"
                                                defaultValue=""
                                                options={[
                                                    { value: "", label: " Time Zone" },
                                                    { value: "1", label: "Time Zone1" },
                                                    { value: "2", label: "Time Zone2" },
                                                    { value: "3", label: "Time Zone3" }
                                                ]}
                                                register={() => { console.log("pobox") }}
                                                signUp={{ language: 'defaultValue' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.?.message} */}
                                            </p>
                                        </div>
                                        <div className="mt-4 text-start">
                                            <div className="mt-4 text-start">
                                                <div className="form-check form-switch from-switch-section text-start  mt-md-5">
                                                    <CheckboxInput
                                                        id="flexSwitchCheckChecked"
                                                        label="Is IATA *"
                                                        register={() => { console.log("clicked") }}
                                                        signUp={{ isIATA: false }} // Set the default value for isIATA
                                                    />
                                                    <p className="form_errors">
                                                        {/* {errors.isIATA?.message} */}
                                                    </p>
                                                </div>
                                            </div>
                                            {" "}
                                        </div>
                                    </div>

                                    
                                </div>





    
                      
            
                           
                                <div className="row">
                                <div className="col-12">
                                    <div className="form_heading">
                                    <span className=" title">Point of Contact ( Finance Manager )
                                    </span>
                                    </div>

                                    </div>

                                    <div className="col-md-4 px-2">

                                        <div className="mb-3 text-start">
                                        <label className="form-label">Salutation <i className="text-danger">*</i></label>
                                            <CustomSelect
                                                id="Salutation1"
                                                defaultValue=""
                                                options={[
                                                    { value: "", label: " Salutation" },
                                                    { value: "1", label: "Mr" },
                                                    { value: "2", label: "MS" },
                                                    { value: "3", label: "Mrs" }
                                                ]}
                                                register={() => { console.log("pobox") }}
                                                signUp={{ language: 'defaultValue' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.?.message} */}
                                            </p>
                                        </div>

                                        <div className="mb-3 text-start">

                                        <label className="form-label">Designation <i className="text-danger">*</i></label>
                                            <CustomInput
                                                id="Designation1"
                                                placeholder="Designation "
                                                ariaDescribedby=""
                                                register={() => { console.log("Designation") }}
                                                signUp={{ agencyname: 'Designation' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.pocdesignation?.message} */}
                                            </p>
                                        </div>

                                        <div className="mb-3 text-start">
                                        <label className="form-label">Email <i className="text-danger">*</i></label>
                                            <CustomInput
                                                id="Email1"
                                                placeholder="Email "
                                                ariaDescribedby=""
                                                register={() => { console.log("Email") }}
                                                signUp={{ agencyname: 'Email' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.pocemail?.message} */}
                                            </p>
                                        </div>
                                    </div>

                                    <div className="col-md-4 px-2">

                                        <div className="mb-3 text-start">

                                        <label className="form-label">First Name <i className="text-danger">*</i></label>

                                            <CustomInput
                                                id="pocfirstname"
                                                placeholder="First Name"
                                                ariaDescribedby=""
                                                register={() => { console.log("pocfirstname") }}
                                                signUp={{ agencyname: 'pocfirstname' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.pocfirstname?.message} */}
                                            </p>
                                        </div>

                                        <div className="mb-3 text-start">

                                        <label className="form-label">Land Phone <i className="text-danger">*</i></label>

                                            <NumberInput
                                                id="landphone2"
                                                placeholder="Land Phone"
                                            />
                                            <p className="form_errors">
                                                {/* {errors.pocemail?.message} */}
                                            </p>
                                        </div>
                                    </div>


                                    <div className="col-md-4 px-2">

                                        <div className="mb-3 text-start">

                                        <label className="form-label">Last Name <i className="text-danger">*</i></label>
                                            <CustomInput
                                                id="poclastname"
                                                placeholder="Last Name"
                                                ariaDescribedby=""
                                                register={() => { console.log("poclastname") }}
                                                signUp={{ agencyname: 'poclastname' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.poclastname?.message} */}
                                            </p>
                                        </div>

                                        <div className="mb-3 text-start">

                                        <label className="form-label">Mobile <i className="text-danger">*</i></label>

                                            <NumberInput
                                                id="mobile2"
                                                placeholder="Mobile"
                                            />
                                            {/* <p className="form_errors">
                            {errors.pocemail?.message}
                          </p> */}
                                        </div>
                                        {" "}
                                    </div>
                                </div>
                         
                                <div className="row">
                                <div className="col-12">
                                    <div className="form_heading">
                                    <span className=" title">System Access - User Details

                                    </span>
                                    </div>

                                    </div>
                                    
                                    <div className="col-md-4 px-2">

                                        <div className="mb-3 text-start">
                                        <label className="form-label">Salutation <i className="text-danger">*</i></label>
                                            <CustomSelect
                                                id="Salutation2"
                                                defaultValue=""
                                                options={[
                                                    { value: "", label: " Salutation" },
                                                    { value: "1", label: "Mr" },
                                                    { value: "2", label: "MS" },
                                                    { value: "3", label: "Mrs" }
                                                ]}
                                                register={() => { console.log("pobox") }}
                                                signUp={{ language: 'defaultValue' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.?.message} */}
                                            </p>
                                        </div>

                                        <div className="mb-3 text-start">

                                        <label className="form-label">Designation <i className="text-danger">*</i></label>
                                            <CustomInput
                                                id="Designation2"
                                                placeholder="Designation "
                                                ariaDescribedby=""
                                                register={() => { console.log("pocdesignation") }}
                                                signUp={{ agencyname: 'pocdesignation' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.pocdesignation?.message} */}
                                            </p>
                                        </div>

                                        <div className="mb-3 text-start">
                                        <label className="form-label">Email <i className="text-danger">*</i></label>
                                            <CustomInput
                                                id="email3"
                                                placeholder="Email "
                                                ariaDescribedby=""
                                                register={() => { console.log("pocemail") }}
                                                signUp={{ agencyname: 'pocemail' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.pocemail?.message} */}
                                            </p>
                                        </div>
                                    </div>

                                    <div className="col-md-4 px-2">

                                        <div className="mb-3 text-start">

                                        <label className="form-label">First Name <i className="text-danger">*</i></label>

                                            <CustomInput
                                                id="firstname3"
                                                placeholder="First Name "
                                                ariaDescribedby=""
                                                register={() => { console.log("pocfirstname") }}
                                                signUp={{ agencyname: 'pocfirstname' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.pocfirstname?.message} */}
                                            </p>
                                        </div>

                                        <div className="mb-3 text-start">

                                        <label className="form-label">Land Phone <i className="text-danger">*</i></label>

                                            <NumberInput
                                                id="landphone3"
                                                placeholder="Land Phone"
                                            />
                                            <p className="form_errors">
                                                {/* {errors.pocemail?.message} */}
                                            </p>
                                        </div>
                                    </div>


                                    <div className="col-md-4 px-2">

                                        <div className="mb-3 text-start">

                                        <label className="form-label">Last Name <i className="text-danger">*</i></label>
                                            <CustomInput
                                                id="lastname3"
                                                placeholder="Last Name "
                                                ariaDescribedby=""
                                                register={() => { console.log("poclastname") }}
                                                signUp={{ agencyname: 'poclastname' }}
                                            />
                                            <p className="form_errors">
                                                {/* {errors.poclastname?.message} */}
                                            </p>
                                        </div>

                                        <div className="mb-3 text-start">

                                        <label className="form-label">Mobile <i className="text-danger">*</i></label>

                                            <NumberInput
                                                id="mobile4"
                                                placeholder="Mobile"
                                            />
                                            {/* <p className="form_errors">
                            {errors.pocemail?.message}
                          </p> */}
                                        </div>
                                        {" "}
                                    </div>
                                </div>        
             
                         
                          
                                <div className="row">

                                <div className="col-12">
                                    <div className="form_heading">
                                    <span className=" title">Documents
                                    </span>
                                    </div>

                                </div>

                                   



                                    <div className="col-md-4 px-2">
                                        <div className="mb-3 text-start">
                                            <FileInput
                                                id="customFile"
                                                label="Trade license Copy"
                                                accept=".pdf,.doc,.docx" // Set the accepted file types if needed
                                                onChange={(e) => {
                                                    // Handle file change event if required
                                                    const file = e.target.files && e.target.files[0];
                                                    console.log(file);
                                                }}
                                            />
                                        </div>
                                        <div className="mb-3 text-start">
                                            <FileInput
                                                id="customFile"
                                                label="TAX Registration Copy"
                                                accept=".pdf,.doc,.docx" // Set the accepted file types if needed
                                                onChange={(e) => {
                                                    // Handle file change event if required
                                                    const file = e.target.files && e.target.files[0];
                                                    console.log(file);
                                                }}
                                            />
                                        </div>
                                    </div>
                                    <div className="col-md-4 px-2">
                                        <div className="mb-3 text-start">
                                            <FileInput
                                                id="customFile"
                                                label=" ID Copy of Sponsor"
                                                accept=".pdf,.doc,.docx" // Set the accepted file types if needed
                                                onChange={(e) => {
                                                    // Handle file change event if required
                                                    const file = e.target.files && e.target.files[0];
                                                    console.log(file);
                                                }}
                                            />
                                        </div>
                                        <div className="mb-3 text-start">
                                            <FileInput
                                                id="customFile"
                                                label="ID Copy of Owner"
                                                accept=".pdf,.doc,.docx" // Set the accepted file types if needed
                                                onChange={(e) => {
                                                    // Handle file change event if required
                                                    const file = e.target.files && e.target.files[0];
                                                    console.log(file);
                                                }}
                                            />
                                        </div>
                                    </div>
                                    <div className="col-md-4 px-2">
                                        <div className="mb-3 text-start">
                                            <FileInput
                                                id="customFile"
                                                label="ID Copy of Authorized Signatory"
                                                accept=".pdf,.doc,.docx" // Set the accepted file types if needed
                                                onChange={(e) => {
                                                    // Handle file change event if required
                                                    const file = e.target.files && e.target.files[0];
                                                    console.log(file);
                                                }}
                                            />
                                        </div>
                                    </div>
                                </div>
                           
                           
                                <div className="row">
                                    <div className="form-check text-start mx-2">
                                        <input className="form-check-input" type="checkbox" value="" id="flexCheckDefault" />
                                        <label className="form-check-label" htmlFor="flexCheckDefault">
                                            I Accept Terms and Conditions
                                        </label>
                                    </div>
                                    <div className="recaptcha_section mx-2">
                                        {/* <ReCAPTCHA sitekey="Your client site key" />, */}
                                    </div>
                                    <div className="submit_btn text-end">
                                        <button
                                            type="submit"
                                            className="btn btn-primary w-40 mt-3 signin_btn"
                                        >
                                            Submit
                                        </button>
                                    </div>
                                    {/* <div className="success_msg">
                                        <p>Thank you for providing the registration details! One of our representative will
                                            contact you shortly.
                                        </p>
                                    </div> */}
                                </div>
                         
                        
                       
                    </form>
                    </div>
            </section>
            </div>
  
        </>
    )

}
export default SignUp;