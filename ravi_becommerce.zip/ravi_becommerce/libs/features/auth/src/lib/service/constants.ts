//Auth APIs
export const GET_LOGIN_AUTH = "keycloak/Auth/Login";
export const GET_REFRESH_TOKEN = "keycloak/Auth/GetRefreshToken";
export const VERIFY_OTP = "keycloak/Auth/VerifyOtpAndGetToken";
export const RESEND_OTP = "keycloak/Auth/ResendOtp";
export const REGISTER_USER = "keycloak/Auth/RegisterUser";
export const LOGOUT_USER = "keycloak/Auth/Logout";

// CONSTANST
export const TO_MILLISECONDS = 1000;
export const LEGAL_IDLE_TIME = 5 * 60 * 1000; // FIVE MINUTES

// GOOGLE_TRANSLATE
export const LANGUAGES_FOR_TRANSLATION = [
    { text: 'Select Language', value: '' },
    { text: 'Arabic', value: 'ar' },
    { text: 'French', value: 'fr' },
    { text: 'Hindi', value: 'hi' },
];