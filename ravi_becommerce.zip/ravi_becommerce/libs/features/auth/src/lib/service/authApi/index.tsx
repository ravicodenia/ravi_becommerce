import { getGatewayAPI, postGatewayAPI } from "@mfa-travel-app/services";
import { GET_LOGIN_AUTH, VERIFY_OTP, GET_REFRESH_TOKEN, REGISTER_USER, RESEND_OTP, LOGOUT_USER } from "../constants";

export const getUser = async (username: string, password: string | number) => {
    try {
        const response = await getGatewayAPI(GET_LOGIN_AUTH, {
            params: {
                username: username,
                password: password
            }
        });
        return response;
    } catch (error) {
        return error;
    }
};

export const verifyOtp = async (userName: string, otp: number) => {
    try {
        const response = await postGatewayAPI(VERIFY_OTP, null, {
            params: {
                username: userName,
                otp: otp
            }
        });
        return response;
    } catch (error) {
        return error;
    }
}

export const resetOtp = async (userName: string) => {
    try {
        const response = await postGatewayAPI(RESEND_OTP, null, {
            params: {
                username: userName
            }
        });
        return response;
    } catch (error) {
        return error;
    }
}

export const refreshOtp = async (refreshToken: string) => {
    try {
        const response = await getGatewayAPI(GET_REFRESH_TOKEN, {
            params: {
                refreshToken: refreshToken
            }
        });
        return response;
    } catch (error) {
        return error;
    }
}

export const registerUser = async (userName: string, password: string, confirmpassword: string, email: string, firstname: string, lastname: string) => {
    try {
        const response = await postGatewayAPI(REGISTER_USER, {
            username: userName,
            password: password,
            confirmPassword: confirmpassword,
            email: email,
            firstName: firstname,
            lastName: lastname
        });
        return response;
    } catch (error) {
        return error;
    }
}

export const logoutUser = async (refreshToken: string) => {
    try {
        const response = await postGatewayAPI(LOGOUT_USER, {
            refreshToken: refreshToken,
            loginSessionId: undefined
        });
        return response;
    } catch (error) {
        return error;
    }
}