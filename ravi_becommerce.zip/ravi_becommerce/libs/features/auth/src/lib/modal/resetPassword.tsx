export const ResetPassword = () => {
    return (
        <>
        {/* <div className="modal show"> */}
        <div className="modal-dialog modal-dialog-centered login_reset_popup" id="forgot_password">
            <div className="modal-dialog modal-dialog-centered login_reset_popup">
                <div className="modal-content">
                    <div className="modal-header">
                        <div className="modal-title"><strong>Reset Password</strong></div>
                        <button type="button" className="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div className="modal-body">

                        <div className="restPasswordContainer">
                            <div className="mb-3">
                                <label htmlFor="resetInputfield" className="form-label">
                                    Enter your e-mail address and we will send you the link for restoring the password.</label>
                                <input type="email" className="form-control" id="resetInputfield" placeholder="example@gmail.com" />
                            </div>
                            <div>
                                <button id="resetInputbtn" type="button" className="btn btn-primary w-100">
                                    Reset Password
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        {/* </div> */}
        </>
    )
}
export default ResetPassword;