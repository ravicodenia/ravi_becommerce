declare function originalPageLanguage(): any;

export default originalPageLanguage;