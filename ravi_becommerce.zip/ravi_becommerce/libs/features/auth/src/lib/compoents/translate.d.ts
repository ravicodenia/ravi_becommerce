declare function Translate(): any;

export default Translate;