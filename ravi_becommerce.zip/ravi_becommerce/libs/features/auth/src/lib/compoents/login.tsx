import React, { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { useStore, useHotelStore } from '@mfa-travel-app/store';
import { getUser } from '../service/authApi';
import { AuthLayout } from '@mfa-travel-app/layout';
import { toast } from 'react-toastify';
import { getAgentConfig } from '@mfa-travel-app/shared';
import { Loader } from '@mfa-travel-app/ui';
import { TO_MILLISECONDS } from '../service/constants';
import originalPageLanguage from './originalPageLanguage';

interface FormData {
    username: string;
    password: string;
}

export const Login = () => {
    const navigate = useNavigate();
    const {
        saveAuthDetails,
        saveAuthTokenExpiryAt,
        clearAllRedux,
        saveConfig,
        saveFlightSearchResults,
        saveSearchPayloadResults,
        refreshAirlineData,
    } = useStore();
    const {
        refreshHotelData,
        saveHotelSearchPayloadResults,
        saveHotelSearchResults,
    } = useHotelStore();

    useEffect(() => {
        clearAllRedux();
        originalPageLanguage();
        saveSearchPayloadResults({});
        saveHotelSearchPayloadResults({});
        saveHotelSearchResults([]);
        saveFlightSearchResults([]);
        refreshAirlineData();
        refreshHotelData();
    }, []);

    const [loader, setLoader] = useState(false);

    const loginSubmit = async (data: FormData) => {
        const { username, password } = data;
        setLoader(true);
        const logInUser: any = await getUser(username.trim(), password);
        setLoader(false);

        try {
            if (logInUser?.data?.result && logInUser?.data?.statusCode === 200) {
                if (logInUser?.data?.result?.accessToken) {
                    let expiresAt = logInUser?.headers['request-receive-time'];
                    expiresAt = expiresAt + (logInUser?.data?.result?.expiresIn * TO_MILLISECONDS);

                    saveAuthTokenExpiryAt(expiresAt);
                    saveAuthDetails(logInUser?.data?.result);
                    navigate('/home');

                    setLoader(true);
                    const config: any = await getAgentConfig(1);
                    setLoader(false);
                    saveConfig(config?.data);
                } else {
                    const { email } = logInUser?.data?.result;
                    navigate('/otp', { state: { username: username, email: email } });
                    // toast.success(logInUser?.data?.message);
                }
            } else {
                toast.error(logInUser?.data?.message);
            }
        } catch (error) {
            // Handle any errors that occur during the execution of the code above
            console.error('An error occurred:', error);
            // You can display an error toast or handle the error in any other way you prefer
            toast.error('An error occurred. Please try again later.');
        }
    }

    const {
        register,
        formState: { errors },
        handleSubmit,
    } = useForm<FormData>();

    return (
        <AuthLayout>
            {
                <>
                    <div className="formfields">
                        <div className="row g-0">
                            <div className="col-6">
                                <div className="btncon">
                                    <Link to="/login" className="btn btn-primary">
                                        Sign In
                                    </Link>
                                </div>
                            </div>
                            <div className="col-6">
                                <div className="btncon">
                                    <Link to="/signup" className="btn btn-register">
                                        New Agent? Register
                                    </Link>
                                </div>
                            </div>
                        </div>
                        <div className="col-12 text-center mt-4 mb-3">
                            <h5>Welcome back</h5>
                        </div>
                        <form onSubmit={handleSubmit(loginSubmit)}>
                            <div className="mb-4">
                                <div className="mb-1 text-start"> Email address / User ID</div>
                                <div>
                                    <input
                                        type="text"
                                        className="form-control"
                                        autoComplete="off"
                                        autoFocus
                                        id="username"
                                        aria-placeholder="Enter your email address or User ID"
                                        placeholder="Enter your email address or User ID"
                                        aria-describedby="emailHelp"
                                        {...register('username', {
                                            required: 'UserId is required',
                                        })}
                                    />
                                </div>
                                <div id="emailHelp" className="form-text">
                                    We'll never share your email with anyone else.
                                </div>
                                <p className="form_errors">
                                    {errors.username && errors.username.message}
                                </p>
                            </div>
                            <div className="d-flex">
                                <div className="flex-fill text-start">Password</div>
                            </div>
                            <div className="mb-3 mt-1">
                                <div>
                                    <input
                                        type="password"
                                        className="form-control"
                                        id="exampleInputPassword1"
                                        aria-placeholder="Enter your password"
                                        placeholder="Enter your password"
                                        {...register('password', {
                                            required: 'password is required',
                                        })}
                                    />
                                </div>
                                <p className="form_errors">
                                    {errors.password && errors.password.message}
                                </p>
                            </div>
                            <div className="col-12 mb-1">
                                <div className="row align-items-center">
                                    <div className="col-md-6 text-start">
                                        <div className="form-check form-switch">
                                            <input
                                                className="form-check-input"
                                                type="checkbox"
                                                id="flexSwitchCheckChecked"
                                            />
                                            <label
                                                className="form-check-label"
                                                htmlFor="flexSwitchCheckChecked"
                                            >
                                                Remember me
                                            </label>
                                        </div>
                                    </div>
                                    <div className="col-md-6 text-end">
                                        <a className="password" href="#">
                                            Forgot Password?
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div className="col-12 mb-1">
                                <button type="submit" className="btn btn-lg btn-primary w-100">
                                    {' '}
                                    Sign In{' '}
                                </button>
                            </div>
                        </form>
                    </div>
                    {loader && <Loader />}
                </>
            }
        </AuthLayout>
    );
};

export default Login;
