
import { Navigate, Outlet } from 'react-router-dom';
import { RootState } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';

const PrivateRoutes = () => {
    const { accessToken } = useSelector((state: RootState) => state.auth);
    return (
        accessToken ? <Outlet /> : <Navigate to='/' />
    )
}
export default PrivateRoutes;