import * as React from 'react';
import { useSelector } from 'react-redux';
import { useStore, RootState } from '@mfa-travel-app/store';
import { logoutUser, refreshOtp } from '../service/authApi';
import { useIdleTimer } from 'react-idle-timer'
import { ConfirmationModal, Loader } from '@mfa-travel-app/ui';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
import { LEGAL_IDLE_TIME, TO_MILLISECONDS } from '../service/constants';
import { getBalance, SESSION_EXPIRE_SUBTITLE, SESSION_EXPIRE_TITLE } from '@mfa-travel-app/shared';
import Translate from './translate';
import originalPageLanguage from './originalPageLanguage';

export const AuthProvider = ({ children }: any) => {
    const [loader, setLoader] = React.useState(false);
    const [showConfirmationModal, setShowConfirmationModal] = React.useState(false);

    const { saveAuthDetails, saveAuthTokenExpiryAt, saveTimerExpiry, saveBalanceDetails } = useStore();
    const { refreshToken, timerExpires, accessToken } = useSelector((state: RootState) => state.auth);
    const { balanceInfo } = useSelector((state: RootState) => state.config);

    const { getLastIdleTime }: any = useIdleTimer({ timeout: 10000, throttle: 100 });
    const navigate = useNavigate();

    React.useEffect(() => {
        if (timerExpires) {
            checkForIdle();
        } else {
            // auto logout after timeout
            setShowConfirmationModal(false);
        }
    }, [timerExpires]);

    const checkForIdle = () => {
        let lastIdleTime = new Date(getLastIdleTime()).getTime();
        let now = new Date().getTime();
        let distance = now - lastIdleTime;

        if (lastIdleTime) {     // moved to home page from url
            if (distance > LEGAL_IDLE_TIME) {
                setShowConfirmationModal(true);
            } else {
                refreshAuthDetails();
            }
        }
    }

    const refreshAuthDetails = async () => {
        setShowConfirmationModal(false);
        try {
            const response: any = await refreshOtp(refreshToken);

            if (response?.data?.result && response?.data?.statusCode === 200) {
                if (response?.data?.result?.accessToken) {
                    let expiresAt = response?.headers['request-receive-time'];
                    expiresAt = expiresAt + (response?.data?.result?.expiresIn * TO_MILLISECONDS);

                    saveTimerExpiry(0);
                    saveAuthTokenExpiryAt(expiresAt);
                    saveAuthDetails(response?.data?.result);
                } else {
                    toast.error(response?.data?.message);
                }
            } else {
                toast.error(response?.data?.message);
            }
        } catch (error) {
            console.error('An error occurred:', error);
            toast.error('An error occurred. Please try again later.');
        }
    }

    const handleUserLogout = async () => {
        setShowConfirmationModal(false);
        setLoader(true);
        try {
            const response: any = await logoutUser(refreshToken);
            if (response.status === 200) {
                navigate('/');
                toast.success('Logout Successful.');
                setLoader(false);
            } else {
                toast.error('An error occurred. Please try again later.');
                setLoader(false);
            }
        } catch {
            toast.error('An error occurred. Please try again later.');
            setLoader(false);
        }
    }

    const findBalance = async () => {
        try {
            const response: any = await getBalance(1);
            saveBalanceDetails(response?.data);
        } catch (error) {
            console.error('Error fetching balance:', error);
        }
    };

    // React.useEffect(() => {
    //     findBalance();
    // }, [accessToken])

    return (
        <>

            <div className='translate-google-web'>
                <div style={{ display: accessToken ? '' : 'none' }}>

                    <div className='d-flex'>
                        <div>
                            <Translate />
                        </div>

                        <div>
                            <button style={{ position: 'relative', top: '-4px' }} type='button' onClick={originalPageLanguage}
                                className='btn'>
                                {/* <i className="fa-solid fa-flag"></i> */}

                                <img style={{height:'24px'}} src='https://cdn-icons-png.flaticon.com/128/330/330425.png' alt='' />
                            </button>
                        </div>
                    </div>

                </div>
            </div>

            {children}

            {
                showConfirmationModal && <ConfirmationModal
                    size='sm' show={showConfirmationModal}
                    onHide={() => setShowConfirmationModal(false)}
                    title={SESSION_EXPIRE_TITLE}
                    subTitle={SESSION_EXPIRE_SUBTITLE}
                    okButtonText={'Continue'}
                    cancelButtonText={'Logout'}
                    okButtonOnClick={refreshAuthDetails}
                    cancelButtonOnClick={handleUserLogout}
                />
            }

            {loader && <Loader />}
        </>
    );
};

export default AuthProvider;
