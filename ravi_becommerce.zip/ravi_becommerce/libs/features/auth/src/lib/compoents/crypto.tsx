import sjcl from 'sjcl';

const credentialsKey = 'bcomm';

export const encrypt = (data:any) => {
  return sjcl.encrypt(credentialsKey, data);
};

export const decrypt = (data:any) => {
  return sjcl.decrypt(credentialsKey, data);
};