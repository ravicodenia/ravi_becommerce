import { IataLogo, IsoLogo, weAcceptCards } from '@mfa-travel-app/assets';
import styles from '../layout.module.scss';
import React from 'react';
import classNames from 'classnames';
const Footer: React.FC = () => {
  return (
    <>


<footer>
  <div className={classNames(`footerMini , ${styles['no-print']}`)}>

      <div className="container">
        
        <div className="row align-items-center"> 
          <div className="col-lg-6 col-md-6 col-12 mb-2 mt-2"> 

            <div className="copyright"> Copyright © 2023 All Rights Reserved | Powered by <a href="#">PCT</a>      </div>
           </div>

           <div className="col-lg-3 col-md-3 col-4 mb-2 mt-2">
             <div className="partnered"> 


             <div className='d-flex'>

              <div className='me-3'> 
              <img
                  alt="iso-logo"
                  src={IsoLogo}
                  style={{ height: '40px' }}
                />
              </div>

    <div>
<img alt="IATA-logo"
                  src={IataLogo}
                  style={{ height: '30px' }}
                /></div>

             </div>
             




              </div>
             
           </div>

           <div className="col-lg-3 col-md-3 col-8 mb-2 mt-2">

              <img src={weAcceptCards} alt="we accept cards" />

           </div>


 

        </div>



      </div>
    
    </div>

</footer>



    </>
  );
};

export default Footer;
