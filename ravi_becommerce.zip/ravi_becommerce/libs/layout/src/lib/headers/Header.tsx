import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from '../layout.module.scss';
import classNames from 'classnames';
import { FaLocationDot } from 'react-icons/fa6';
import { useStore, RootState } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import MenuHeader from './menuHeader';
import { Tooltip } from 'react-tooltip'
import { getBalance } from '@mfa-travel-app/shared';
import { IoWalletOutline } from "react-icons/io5";
import { CiCircleMore } from "react-icons/ci";
import { FaHeadphonesAlt } from "react-icons/fa";
import { MdOutlineContactSupport } from "react-icons/md";
import { RiBankLine } from "react-icons/ri";



const Header: React.FC = () => {
  const { homeScreenShowHide, bankData, contactData, supportData, balanceInfo, agentProfile }: any = useSelector(
    (state: RootState) => state.config
  );
  const { saveBalanceDetails } = useStore();
  // const bankData = '<p>  <br />  United Arab Emirates<br />  Bank Name&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;EMIRATES NBD<br />  Account Name&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;BCOM LLC<br />  Account Number&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;2 1 1 9 0 5 0 8 8 5 7 1 2<br />  IBAN No&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;AE89898989898989898<br />  Currency&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;AED<br />  Branch&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;Al Souk<br />  SWIFT CODE&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;EBILAEADSUK</p> ';
  // const supportData = '<p>  Contact No.<br />  Landline&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;+971 6 8989898<br />  Mobile&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;+971 50 8978676<br />  Email:<br />  For any Support Contact&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;b2bsupport@cozmotravel.com<br />  For cancellations, refunds, reissuance&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;bCOMsupport@BCOM.COM<br />  For Hotels, Packages, Tours, Insurance&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;bCOM@BCOM.COM<br />  For Sales&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;bCOMsales@BCOMl.com<br />  For Topup:&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;BCOMACCOUNTSk@BCOM.com<br />  &nbsp;<br />  Click Here To Download </p> ';

  const [showWallet, setShowWallet] = useState(false);
  const [showContact, setShowContact] = useState(false);
  const [showSupport, setShowSupport] = useState(false);
  const [showBankDetails, setShowBankDetails] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  const [bankDetails, setBankDetails] = useState<any[]>([]);
  const [supportDetails, setSupportDetails] = useState<any[]>([]);
  const walletRef: any = useRef();
  const contactSaleRef: any = useRef();
  const supportRef: any = useRef();
  const bankDetailRef: any = useRef();
  const mobileMenuRef: any = useRef();

  const [showMobleMenus, setShowMobleMenus] = useState(false);

  const handleMobileTopMenu = () => {

    setShowMobleMenus(!showMobleMenus)
  }


  const [tokenExpiryTime, setTokenExpiryTime] = React.useState({
    minutes: '',
    seconds: ''
  });

  const { tokenExpiresAt, timerExpires } = useSelector((state: RootState) => state.auth);
  const { saveTimerExpiry } = useStore();

  const CHECK_IDLE_AT_LAST_MINUTE = 60 * 1000;

  const navigate = useNavigate();

  const notificationsJson = [
    {
      id: 1,
      toAgencyId: 1,
      toUserId: 0,
      subject: 'New Air Integration',
      message: 'Airarabia content is now available on our portal',
      readStatus: false,
    },
    {
      id: 2,
      toAgencyId: 1,
      toUserId: 0,
      subject: 'New Product',
      message: 'Hotel product is now added',
      readStatus: false,
    },
    {
      id: 3,
      toAgencyId: 1,
      toUserId: 0,
      subject: 'New Slider',
      message: 'Slider images an now be uploaded from CMS',
      readStatus: false,
    },
    {
      id: 4,
      toAgencyId: 1,
      toUserId: 0,
      subject: 'User Reset Passoword',
      message: 'New IDM added to login and reset password',
      readStatus: false,
    },
    {
      id: 5,
      toAgencyId: 1,
      toUserId: 0,
      subject: 'New Deisgn',
      message:
        'Design changes for Flight Search and Flight results now available',
      readStatus: false,
    },
    {
      id: 6,
      toAgencyId: 1,
      toUserId: 1,
      subject: 'Reports',
      message: 'More reports added ',
      readStatus: false,
    },
  ];

  useEffect(() => {
    let timer = setInterval(() => {
      updateTimeToShow();
    }, 1000);

    return () => clearInterval(timer);
  }, [timerExpires, tokenExpiresAt]);

  const updateTimeToShow = () => {
    if (tokenExpiresAt) {
      let now = new Date().getTime();
      let distance = tokenExpiresAt - now;

      if (distance < CHECK_IDLE_AT_LAST_MINUTE) {
        if (!timerExpires) {
          saveTimerExpiry(new Date().getTime());
        }
      }

      if (now > tokenExpiresAt) {
        setTokenExpiryTime({ minutes: 'Session', seconds: 'Expired' });
        navigate('/');
      } else {
        let minutes = Math.floor(distance / (1000 * 60));
        let seconds = Math.floor((distance % (1000 * 60)) / 1000);

        let minutesToShow = `${minutes < 10 ? `0${minutes}` : minutes}`;
        let secondsToShow = `${seconds < 10 ? `0${seconds}` : seconds}`;
        setTokenExpiryTime({ minutes: minutesToShow, seconds: secondsToShow });
      }
    }
  }

  useEffect(() => {
    // const bankDetailsResponse = {
    //   data: '<p>  <br />  United Arab Emirates<br />  Bank Name&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;EMIRATES NBD<br />  Account Name&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;BCOM LLC<br />  Account Number&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;2 1 1 9 0 5 0 8 8 5 7 1 2<br />  IBAN No&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;AE89898989898989898<br />  Currency&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;AED<br />  Branch&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;Al Souk<br />  SWIFT CODE&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;EBILAEADSUK</p> ',
    // };

    // const supportDetailsResponse = {
    //   data: '<p>  Contact No.<br />  Landline&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;+971 6 8989898<br />  Mobile&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;+971 50 8978676<br />  Email:<br />  For any Support Contact&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;b2bsupport@cozmotravel.com<br />  For cancellations, refunds, reissuance&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;bCOMsupport@BCOM.COM<br />  For Hotels, Packages, Tours, Insurance&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;bCOM@BCOM.COM<br />  For Sales&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;bCOMsales@BCOMl.com<br />  For Topup:&nbsp;&nbsp; &nbsp;:&nbsp;&nbsp; &nbsp;BCOMACCOUNTSk@BCOM.com<br />  &nbsp;<br />  Click Here To Download </p> ',
    // };

    const parser = new DOMParser();
    if (bankData) {
      const bankHtmlDoc = parser.parseFromString(bankData, 'text/html');
      const bankRows = Array.from(bankHtmlDoc.querySelectorAll('br'))
        .map((br) => {
          const text =
            br.previousSibling?.textContent
              ?.trim()
              ?.split('&nbsp;')
              .join(' ') || '';
          return text.includes(':') ? text : null;
        })
        .filter(Boolean);
      setBankDetails(bankRows);
    }

    if (supportData) {
      const supportHtmlDoc = parser.parseFromString(supportData, 'text/html');
      const supportRows = Array.from(supportHtmlDoc.querySelectorAll('br'))
        .map((br) => {
          const text =
            br.previousSibling?.textContent
              ?.trim()
              ?.split('&nbsp;')
              .join(' ') || '';
          return text.includes(':') ? text : null;
        })
        .filter(Boolean);
      setSupportDetails(supportRows);
    }
  }, [bankData, supportData]);

  const handleShowWallet = async () => {

    console.log("i am cliked");
    if (!showWallet) {
      try {
        const response: any = await getBalance(1);
        saveBalanceDetails(response?.data);
      } catch (error) {
        console.error('Error fetching balance:', error);
      }
    }
    setShowWallet(!showWallet);
    setShowContact(false);
    setShowSupport(false);
    setShowBankDetails(false);
    setShowNotifications(false);
    setShowMobleMenus(false)
  };

  const handleShowContact = () => {
    setShowWallet(false);
    setShowContact(!showContact);
    setShowSupport(false);
    setShowBankDetails(false);
    setShowNotifications(false);
    setShowMobleMenus(false)
  };

  const handleShowSupport = () => {
    setShowWallet(false);
    setShowContact(false);
    setShowSupport(!showSupport);
    setShowBankDetails(false);
    setShowNotifications(false);
    setShowMobleMenus(false)
  };

  const handleShowBankDetails = () => {
    setShowWallet(false);
    setShowContact(false);
    setShowSupport(false);
    setShowBankDetails(!showBankDetails);
    setShowNotifications(false);
    setShowMobleMenus(false)
  };

  const handleShowNotifications = () => {
    setShowWallet(false);
    setShowContact(false);
    setShowSupport(false);
    setShowBankDetails(false);
    setShowNotifications(!showNotifications);
  };

  // useEffect(() => {
  //   const script = document.createElement('script');
  //   script.src = "http://bcom.b2b.pierofcloudtech.com/assets/multimenu/ozmenu.js";
  //   script.async = true;
  //   document.body.appendChild(script);

  //   return () => {
  //     document.body.removeChild(script);
  //   }
  // }, []);


  const handleClickOutside = (event: any) => {

    const isClickOutside = (ref: React.RefObject<HTMLElement>) => {
      return ref.current && !ref.current.contains(event.target);
    };

    if (isClickOutside(walletRef) && event.target.tagName !== 'BUTTON') {
      setShowWallet(false);
    }

    if (isClickOutside(contactSaleRef) && event.target.tagName !== 'BUTTON') {
      setShowContact(false);
    }

    if (isClickOutside(supportRef) && event.target.tagName !== 'BUTTON') {
      setShowSupport(false);
    }

    if (isClickOutside(bankDetailRef) && event.target.tagName !== 'BUTTON') {
      setShowBankDetails(false);
    }

    if (isClickOutside(mobileMenuRef) && event.target.tagName !== 'BUTTON') {
      setShowMobleMenus(false);
    }

  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [walletRef, contactSaleRef, supportRef, bankDetailRef, mobileMenuRef]);

  const showBankDetailsHomeSreen = homeScreenShowHide?.some((item: any) => item.text === "SHOW BANK DETAILS" && item.show);
  const showSalesSupportHomeSreen = homeScreenShowHide?.some((item: any) => item.text === "SHOW SALES SUPPORT" && item.show);
  const showContactHomeSreen = homeScreenShowHide?.some((item: any) => item.text === "SHOW CONTACT" && item.show);





  return (
    <>
      <header className={styles["no-print"]} >
        <section className="headerMini">
          <div className="container">
            <div className="row">
              <div className="col-8 col-lg-3">
                {/* <div className="switchLanguage">
                  <div className="language-menu">
                    <div className="select-wrapper">
                      <select name="picklanguage" className="select">
                        <option>English</option>
                        <option value="1">Telugu</option>
                        <option value="2">Hindi</option>
                        <option value="3">Tamil</option>
                      </select>
                    </div>
                  </div>
                </div> */}

                <div className="switchTheme ms-2 hide_mobile">
                  <div className="form-check form-switch">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexSwitchCheckChecked"
                    />
                    <label
                      className="form-check-label"
                      htmlFor="flexSwitchCheckChecked"
                    >
                      DARK
                    </label>
                  </div>
                </div>


                <div style={{ fontSize: '90%' }} className="switchTheme ms-lg-4">

                  <small className='text-light'>
                    <span className='notranslate'>
                      {tokenExpiryTime.minutes}
                    </span>
                    <span style={{ display: tokenExpiryTime.minutes ? '' : 'none' }}>
                      m&nbsp;
                    </span>

                    <span className='notranslate'>
                      {tokenExpiryTime.seconds}
                    </span>
                    <span style={{ display: tokenExpiryTime.seconds ? '' : 'none' }}>
                      s
                    </span>
                  </small>

                </div>




              </div>

              <div className="col-4 col-lg-9">
                <div className="topLinks">
                  <ul>

                    <li className='my_wallet'>
                      <div className="dropdown show">
                        <button
                          className="linkSml hide_mobile"
                          onClick={() => handleShowWallet()}
                        >
                        <span className="hide_mobile">  My Wallet{' '}</span> 
                        {/* <span className='show_mobile'><IoWalletOutline /></span> */}

                          <span className="d-none" id="fetchwalletbalance">
                            {' '}
                            {`${balanceInfo?.currentBalance?.toFixed(2)}`}
                          </span>
                        </button>
                        {/* <a className="dropdown-toggle" href="#"  role="button" id="drMenuMyWallet" 
          data-bs-toggle='dropdown' aria-haspopup="true" aria-expanded="false">
      
          </a> */}

                        {/* <div style={{width:'200px'}} className="dropdown-menu" aria-labelledby="drMenuMyWallet"> */}

                        <div
                          ref={walletRef}
                        
                          className={classNames(
                            showWallet ? 'd-block' : 'd-none',
                            'dropdown-menu', 'showMobleMenus' 
                          )}
                          aria-labelledby="drMenuMyWallet"
                        >
                          <div className="dr_container">
                            <table className="table table-borderless">
                              <tbody>

                                <tr>
                                  <th scope="row">Wallet Balance: </th>
                                  <td> {agentProfile?.currency} {balanceInfo?.currentBalance?.toFixed(2) || 0}</td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        </div>


                      </div>
                    </li>

                    {showContactHomeSreen &&
                      <li>
                        <div className="dropdown show">
                          {/* <a className="dropdown-toggle" href="#"  role="button" id="drMenucontactsales" 
          data-bs-toggle='dropdown' aria-haspopup="true" aria-expanded="false">
          Contact Sales
          </a> */}

                          <button
                            className="linkSml hide_mobile"
                            onClick={() => handleShowContact()}
                          >
                            Contact Sales
                          </button>

                          <div
                            ref={contactSaleRef}
                          
                            className={classNames(
                              showContact ? 'd-block' : 'd-none',
                              'dropdown-menu', 'contactSaleRef'
                            )}
                            aria-labelledby="drMenucontactsales"
                          >
                            {/* <div className="dropdown-menu dropdown-menu-right" aria-labelledby="drMenucontactsales"> */}

                            <div className="dr_container">
                              <div className="row">
                                {contactData && contactData.length > 0 && contactData?.map((user: any, index: any) => (
                                  <div key={user.userId} className="col-lg-6">
                                    <table className="table table-borderless">
                                      <tbody>
                                        <tr>
                                          <th>{user.designation}</th>
                                          <td> : {user.title} {user.firstName} {user.middleName ? user.middleName + ' ' : ''}{user.lastName}</td>
                                        </tr>
                                        <tr>
                                          <th>Land Phone</th>
                                          <td> : Not Available</td>
                                        </tr>
                                        <tr>
                                          <th>Mobile</th>
                                          <td> : {user.mobile}</td>
                                        </tr>
                                        <tr>
                                          <th>eMail</th>
                                          <td> : {user.email}</td>
                                        </tr>
                                      </tbody>
                                    </table>
                                  </div>
                                ))}
                              </div>
                            </div>

                          </div>
                        </div>
                      </li>
                    }
                   
                    {showSalesSupportHomeSreen &&
                    
                    <li>
                        <div className="dropdown show">
                          {/* <a className="dropdown-toggle" href="#" onClick={() => handleShowSupport()} role="button" id="drMenuSupport" 
          data-bs-toggle='dropdown' aria-haspopup="true" aria-expanded="false">
          Support
          </a> */}

                          <button
                            className="linkSml hide_mobile"
                            onClick={() => handleShowSupport()}
                          >
                            Support
                          </button>

                          {/* <div style={{width:'280px'}} className="dropdown-menu" aria-labelledby="drMenuSupport"> */}

                          <div
                            ref={supportRef}
                          
                            className={classNames(
                              showSupport ? 'd-block' : 'd-none',
                              'dropdown-menu supportRef'
                            )}
                            aria-labelledby="drMenuSupport"
                          >
                            <div className="dr_container">
                              {supportDetails.map((row, index) => (
                                <div className="row mb-2" key={index}>
                                  {row
                                    .split(':')
                                    .map((cell: any, cellIndex: any) => (
                                      <div
                                        key={cellIndex}
                                        className={
                                          cellIndex === 0 ? 'col-6' : 'col-6'
                                        }
                                      >
                                        {cellIndex === 0 ? (
                                          <b> {cell.trim()}</b>
                                        ) : (
                                          <div>:{cell.trim()} </div>
                                        )}
                                      </div>
                                    ))}
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </li>
                      }


                    {showBankDetailsHomeSreen &&
                      <li>
                        <div className="dropdown show">
                          {/* <a className="dropdown-toggle" href="#"  role="button" id="drMenubankdetails" 
          data-bs-toggle='dropdown' aria-haspopup="true" aria-expanded="false">
          Bank Details
          </a> */}

                          <button
                            className="linkSml hide_mobile"
                            onClick={() => handleShowBankDetails()}
                          >
                            Bank Details
                          </button>

                          {/* <div style={{width:'250px'}} className="dropdown-menu" aria-labelledby="drMenubankdetails"> */}

                          <div
                            ref={bankDetailRef}
                       
                            className={classNames(
                              showBankDetails ? 'd-block' : 'd-none',
                              'dropdown-menu supportRef'
                            )}
                            aria-labelledby="drMenubankdetails"
                          >
                            <div className="dr_container">
                              {bankDetails.map((row, index) => (
                                <div
                                  className="row d-flex justify-content-between mb-2"
                                  key={index}
                                >
                                  {row
                                    .split(':')
                                    .map((cell: any, cellIndex: any) => (
                                      // <div
                                      //   key={cellIndex}
                                      //   // className={
                                      //   //   cellIndex === 0 ? 'col-6' : 'col-6'
                                      //   // }
                                      //   className="row"
                                      // >
                                      cellIndex === 0 ? (
                                        <b className="col-6">{cell.trim()}:</b>
                                      ) : (
                                        <span className="col-6">
                                          {cell.trim()}
                                        </span>
                                      )
                                      // </div>
                                    ))}
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </li>
                      }



                    <li className="user_notification hide_mobile">
                      <div className="dropdown show">
                        {/* <a className="dropdown-toggle" href="#"  onClick={() => handleShowNotifications()} role="button" id="drMenunotification" 
  data-bs-toggle='dropdown' aria-haspopup="true" aria-expanded="false">
  <span className="notification"><i className="fa-regular fa-bell"></i> 
    <span  className="nc">12</span> </span>
    <span className="visually-hidden">unread messages</span>
  </a> */}

                        <button style={{ border: 'none' }}
                          className="linkSml"
                          onClick={() => handleShowNotifications()}
                        >
                          <span className="notification">
                            <i className="fa-regular fa-bell"></i>
                            <span className="nc">12</span>{' '}
                          </span>
                          <span className="visually-hidden">
                            unread messages
                          </span>
                        </button>

                        {/* 
  <div style={{width:'250px'}} className="dropdown-menu" aria-labelledby="drMenunotification"> */}

                        <div
                          style={{ width: '250px' }}
                          className={classNames(
                            showNotifications ? 'd-block' : 'd-none',
                            'dropdown-menu'
                          )}
                          aria-labelledby="drMenunotification"
                        >
                          <div className="dr_container">
                            <div className="msgforuser">
                              {notificationsJson.map((notification, index) => (
                                <div key={index}>

                                  <Link to=''
                                    data-tooltip-id="price-tooltip" data-tooltip-place="left"
                                    data-tooltip-html={'<b>' + notification.subject + '</b>' + '<div style="width:200px">' + notification.message + '</div>'}
                                  >
                                    <div className='row align-items-center'>

                                      <div className='col-8'>
                                        <div className="title mt-1">
                                          {notification.subject}
                                        </div>
                                        <div className="description">
                                          {notification.message}
                                        </div>
                                      </div>

                                      <div className='col-4'>
                                        <span className='text-muted'>4.21 PM </span>
                                      </div>
                                    </div>

                                  </Link>
                                  <Tooltip id="price-tooltip" clickable />


                                  {/* <Link to="/">
                                    <div className="title">
                                      {notification.subject}
                                    </div>
                                    <div className="description">
                                      {notification.message}
                                    </div>
                                  </Link> */}

                                  {index !== notificationsJson.length - 1 ? (
                                    <hr className={styles['divider']} />
                                  ) : (
                                    ''
                                  )}
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    </li>

                    <li className="my_wallet show_mobile">
                    <div className="dropdown show">
                    <button  ref={mobileMenuRef}  
                      onClick={() => handleMobileTopMenu()}
                       className="linkSml"
                    
                    >
                      <CiCircleMore />
                               

                      </button>

                      <div
                       
                        
                          className={classNames(
                            showMobleMenus ? 'd-block' : 'd-none',
                            'dropdown-menu'
                          )}
                          aria-labelledby="drMenuMobile"
                        >
                          <div className="dr_container">
                           <div className='mobileMenusTop'> 
                          <button className='mb-1 btnlnk'  onClick={() => handleShowWallet()}> <IoWalletOutline/> My Wallet </button>
                          <button className='mb-1 btnlnk'   onClick={() => handleShowContact()}><FaHeadphonesAlt/> Contact Sales </button>
                          <button className='mb-1 btnlnk'  onClick={() => handleShowSupport()}><MdOutlineContactSupport/> Support</button>
                          <button className='btnlnk' onClick={() => handleShowBankDetails()}><RiBankLine/> Bank Details</button>
                          </div>
                          </div>
                        </div>


                        

                      </div>
                    </li>

                 
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        <MenuHeader />
      </header>

      {/* <section className="header">

          <div className="container">
            
            <nav className="navbar navbar-expand-lg navbar-light">
              <div className="container-fluid">
                <div className="logo_section mb-1">
                  <img src={Logo} className="signin_logo" alt="logo" />
                </div>

                <div className="collapse navbar-collapse" id="navbarScroll">
                  <ul className="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll menu-dropdown-menu">
                    <li className="nav-item">
                      <a className="nav-link" aria-current="page" href="#">
                        SETTINGS
                      </a>
                    </li>
                    <li className="nav-item">
                      <a className="nav-link" href="#">
                        OPS
                      </a>
                    </li>
                    <li className="nav-item dropdown">
                      <a
                        className="nav-link dropdown-toggle"
                        href="#"
                        id="navbarScrollingDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        USER MANAGEMENT
                      </a>
                      <ul
                        className="dropdown-menu"
                        aria-labelledby="navbarScrollingDropdown"
                      >
                        <li>
                          <a className="dropdown-item" href="#">
                            User control &raquo;
                          </a>
                          <ul className="dropdown-menu dropdown-submenu">
                            <li>
                              <a className="dropdown-item" href="#">
                                Create Master
                              </a>
                            </li>
                            <li>
                              <a className="dropdown-item" href="#">
                                Role Master
                              </a>
                            </li>
                            <li>
                              <a className="dropdown-item" href="#">
                                Change Password
                              </a>
                            </li>
                          </ul>
                        </li>
                      </ul>
                    </li>

                    <li className="nav-item">
                      <a className="nav-link" href="#">
                        FIN
                      </a>
                    </li>

                    <li className="nav-item dropdown profile_section">
                      <button
                        type="button"
                        className="btn"
                        data-bs-toggle="dropdown"
                      >
                        <div className="profile_img">
                          <img
                            src={userLogo}
                            alt="user_img"
                            className="img-fluid"
                          />
                        </div>
                        <div className="profile_data">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            fill="currentColor"
                            className="bi bi-box-arrow-right"
                            viewBox="0 0 16 16"
                          >
                            <path
                              fillRule="evenodd"
                              d="M10 12.5a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v2a.5.5 0 0 0 1 0v-2A1.5 1.5 0 0 0 9.5 2h-8A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-2a.5.5 0 0 0-1 0v2z"
                            />
                            <path
                              fillRule="evenodd"
                              d="M15.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 0 0-.708.708L14.293 7.5H5.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"
                            />
                          </svg>
                          <span className="ms-1">Sign Out</span>
                        </div>
                      </button>
                      <ul className="dropdown-menu">
                        <li>
                          <a className="dropdown-item" href="#">
                            <span className='fw-medium'>Company:</span> BCOM
                          </a>
                        </li>
                        <li>
                          <a className="dropdown-item" href="#">
                            <span className='fw-medium'>Location:</span> {userProfile.locationName}
                          </a>
                        </li>
                        <li onClick={() => setShowProfileModal(true)}>
                          <span className={classNames('dropdown-item', styles['pointer-cursor'])}> View Profile</span>
                        </li>
                        <li>
                          <a className="dropdown-item" href="#">
                            {' '}
                            Change Password{' '}
                          </a>
                        </li>
                        <li>
                          <a className="dropdown-item" href="#">
                            {' '}
                            Help{' '}
                          </a>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </div>
              </div>
            </nav>



          </div>
        </section> */}
    </>
  );
};

export default Header;
