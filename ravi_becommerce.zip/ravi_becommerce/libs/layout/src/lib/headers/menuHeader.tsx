import React, { useState, useEffect, useRef } from 'react';
import { Logo, userFemale, userMale } from '@mfa-travel-app/assets';
import { Modal } from 'react-bootstrap';
import {
  recursiveMenuList,
  getAgentConfig,
  API_ERROR_TOAST_TEXT,
} from '@mfa-travel-app/shared';
import { Link, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { useStore, RootState } from '@mfa-travel-app/store';
import { toast } from 'react-toastify';
import { Loader } from '@mfa-travel-app/ui';
import { logoutUser } from '@mfa-travel-app/auth';

const MenuHeader = () => {
    const [loader, setLoader] = React.useState(false);
    const [showMenu, setShowMenu] = React.useState(false);
    const [showProfileModal, setShowProfileModal] = React.useState(false);
    const [menuList, setMenuList] = React.useState([]);
    const mobileMenuRef: any = useRef();
    const { menuItems, userProfile } = useSelector((state: RootState) => state.config);
    const { refreshToken } = useSelector((state: RootState) => state.auth);
    const { saveConfig, clearAllRedux } = useStore();
    const menuRef: any = useRef();
    const navigate = useNavigate();

    React.useEffect(() => {
        if (menuItems.length === 0) {
            fetchMenuList();
        } else {
            buildMenuList(menuItems);
        }
    }, []);

  const fetchMenuList = async () => {
    const config: any = await getAgentConfig(1);
    try {
      if (config.status == 200 && config?.data) {
        saveConfig(config?.data);
        buildMenuList(config?.data?.menuItems);
      } else {
        toast.error(config?.errorMessage);
      }
    } catch (error) {
      console.error('An error occurred:', error);
      toast.error(API_ERROR_TOAST_TEXT);
    }
  };

  const buildMenuList = (menuItems: any) => {
    let menuList = JSON.parse(JSON.stringify(menuItems));
    let parentChildList: any = recursiveMenuList(menuList);
    setMenuList(parentChildList);
  };

  const handleUserLogout = async () => {
    setLoader(true);
    try {
      const response: any = await logoutUser(refreshToken);
      if (response?.data?.statusCode === 200) {
        navigate('/');
        clearAllRedux();
        setLoader(false);
        toast.success(response?.data?.message);
      } else {
        setLoader(false);
        toast.error(response?.data?.message);
      }
    } catch (error) {
      setLoader(false);
      console.error('An error occurred:', error);
      toast.error(API_ERROR_TOAST_TEXT);
    }
  };


  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    document.body.classList.toggle('mobile-menu-active', isOpen);
  }, [isOpen]);


   

      const handleNonLeafMenuItemClick = (e: any) => {
        e.preventDefault();

        if (e.target.classList?.value?.includes('opened')) {
            e.target.classList.remove('opened');
        } else {
            e.target.classList.add('opened');
        }
    }

      const handleClickOutside = (event: any) => {

        const isClickOutside = (ref: React.RefObject<HTMLElement>) => {
            return ref.current && !ref.current.contains(event.target);
          };
    
        if (isClickOutside(mobileMenuRef) && event.target.tagName !== 'BUTTON') {
            setShowMenu(false);
        }
    
      };
    
      useEffect(() => {
        document.addEventListener('mousedown', handleClickOutside);
    
        return () => {
          document.removeEventListener('mousedown', handleClickOutside);
        };
      }, [mobileMenuRef]);
    
  

    const getMenuBody = (item: any) => {
        return (
            <ul>
                {item.childItems?.map((child: any, index: any) => {
                    if (child.childItems?.length === 0) {
                        return (
                            <li className="item" key={index}>
                                <Link to={`/${child.name.split(' ').join('-').toLowerCase()}`}>
                                    {child.name}
                                </Link>
                            </li>
                        );
                    } else {
                        return (
                            <li className="item dropdownitem" key={index}>
                                <a href="#" onClick={(e) => handleNonLeafMenuItemClick(e)} className="nav-dropdown">
                                    {child.name}
                                </a>
                                <div className="dropdown">{getMenuBody(child)}</div>
                            </li>
                        );
                    }
                })}
            </ul>
        );
    }

    return (
        <>
            <div className="headerMain">
                <div className="navbar_lg">
                    <div className="container">
                        <div className="row align-items-center">

                            <div className="col-6 col-md-6 col-lg-2">
                                <Link to="/home" className="navbar_brand">
                                    <img src={Logo} className="signin_logo" alt="logo" />
                                </Link>
                            </div>

                            <div className="col-6 col-md-6 col-lg-10">
                                <div className="menu-open">
                                

                                   <span 
                                //onClick={() => setIsOpen(true)} 
                                onClick={()=> setIsOpen(!isOpen)}
                                  > <i className="fa-solid fa-bars"></i>
                                  </span>


                                 
                                </div>

                                <div className={`ozmenu ${isOpen ? "active" : ""}`} >
                                    <div className="menu-close">

                                    <span style={{border:'none', background:'transparent'}}
                                   onClick={() => setIsOpen(false)} 
                                  > <span className="close"></span>
                                  </span>

                                  
                                        
                                    </div>

                                    <ul className="ozmenu-nav">
                                        {menuList?.map((item: any, index: any) => {
                                            return (
                                                <li className="item dropdownitem" key={index}>
                                                    <a href="#" onClick={(e) => handleNonLeafMenuItemClick(e)} className="nav-dropdown">
                                                        {item.name}
                                                    </a>
                                                    <div className="dropdown">{getMenuBody(item)}</div>
                                                </li>
                                            );
                                        })}

                                        <li className="item ms-xl-4">
                                            <div className="ozuser">
                                                <div className="loginbtn">

                                                    <div className="d-inline">



                                                        <img
                                                            src={userFemale}
                                                            alt="user_img"
                                                            className="userpic me-1"
                                                            onClick={() => setShowMenu(true)}
      


                                                        />

                                                


                                                    </div>

                                                    <span className="logout" onClick={handleUserLogout}>
                                                        <i className="fa-solid fa-right-from-bracket"></i>
                                                        <small> Sign Out</small>
                                                    </span>





                                                    <div ref={mobileMenuRef}  style={{ width: '200px', marginTop: '30px' }} className={showMenu ? 'dropdown-menu d-block' : 'd-none'}
                                                        aria-labelledby="dropdownMenuUsers">

                                                        <div >
                                                            <div className="username trimtextfull">
                                                                <span><i className="fa-solid fa-building"></i> B-COMMERCE LLC</span></div>

                                                            <div className="user_location trimtextfull">

                                                                <span>  <i className="fa-solid fa-location-dot"></i> {userProfile?.locationName}</span>
                                                            </div>

                                                            <div>
                                                                <a
                                                                    href="#" className="dropdown-item"
                                                                    onClick={(e) => { e.preventDefault(); setShowProfileModal(true); setShowMenu(false); }}
                                                                >
                                                                    <i className="fa-regular fa-user"></i> View Profile
                                                                </a>
                                                            </div>

                                                            <div>
                                                                <a
                                                                    className="dropdown-item"
                                                                    href="#" onClick={(e) => e.preventDefault()}
                                                                >
                                                                    <i className="fa-regular fa-pen-to-square"></i> Change Password
                                                                </a>
                                                            </div>
                                                            <div>
                                                                <a
                                                                    className="dropdown-item"
                                                                    href="#" onClick={(e) => e.preventDefault()}
                                                                >
                                                                    <i className="fa-solid fa-circle-question"></i> Help
                                                                </a>
                                                            </div>
                                                        </div>

                                                    </div>
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Modal
        centered
        show={showProfileModal}
        onHide={() => setShowProfileModal(false)}
      >
        <Modal.Body>
          <h5>View Profile</h5>
          <div>
            <span className="fw-medium">Name: </span>
            <span>{`${userProfile?.title}. ${userProfile?.firstName} ${
              userProfile?.middleName === null ? '' : userProfile?.middleName
            } ${userProfile?.lastName}`}</span>
          </div>
          <div>
            <span className="fw-medium">Email: </span>
            <span>{userProfile?.email}</span>
          </div>
        </Modal.Body>
      </Modal>

      {loader && <Loader />}
    </>
  );
};

export default MenuHeader;
