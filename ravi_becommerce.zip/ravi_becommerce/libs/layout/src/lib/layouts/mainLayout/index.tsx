import React, { ReactNode, useEffect } from "react";
import Layout from "../layout";
import Header from "../../headers/Header";

export interface MainLayoutProps {
  children: ReactNode;
}

export const MainLayout: React.FC<MainLayoutProps> = ({ children }) => {
  useEffect(() => {window.scrollTo(0, 0)},[]);
  return (
    <React.Fragment>
      <Layout>
        <Header/>
        {children}
      </Layout>
    </React.Fragment>

  )
}
export default MainLayout;
