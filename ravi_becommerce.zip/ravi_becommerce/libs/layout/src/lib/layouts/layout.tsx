import { ReactNode } from 'react';
import Footer from '../footers/Footer';

export interface LayoutProps {
  children: ReactNode;
}

export const Layout : React.FC<LayoutProps>=({children}) =>{
  return (
    <div className="App">
    {children}
    <Footer />
    </div>
  );
}

export default Layout;
