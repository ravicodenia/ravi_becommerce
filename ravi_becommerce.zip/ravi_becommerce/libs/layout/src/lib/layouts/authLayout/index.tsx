import React, { ReactNode } from "react";
import { Logo, loginImg } from "@mfa-travel-app/assets";
import Layout from "../layout";
import LoginFooter from "../../footers/loginFooter";

interface AuthWrapperProps {
    children: ReactNode;
}
export const AuthLayout: React.FC<AuthWrapperProps> = ({ children }) => {
    return (
        <React.Fragment>
            <Layout >
               
            <div className="container">

<div className="loginContainer"> 
<div className="row align-items-center g-0">
  <div className="col-xl-5 col-lg-6 col-md-6 d-none d-lg-block"> 
    <img className="img-fluid" src={loginImg} alt="" />

  </div>

  <div className="col-xl-7 col-lg-6 text-center"> 
  <div className="loginWrapper">
      
      <div className="logoTop"> 
        <img src={Logo} alt="" />
      </div>


  {children}

</div>
  </div>

  
</div>

</div>




</div>

                <LoginFooter />
            </Layout>
        </React.Fragment>
    );
}

export default AuthLayout;
