export { default as IsoLogo} from './iso-logo.svg';
export { default as IataLogo} from './IATA-logo.svg';
export { default as weAcceptCards} from './we-accept-cards.svg';
export { default as Logo} from './logo.svg';
export { default as userLogo} from './user.jpeg';
export { default as userFemale} from './woman.jpg';
export { default as userMale} from './man.jpg';
export { default as carioImg} from './cairo.png';
export { default as dubaiImg} from './dubai.png';
export { default as flightsPromoImg} from './flights-promo-img.png';
export { default as promoImg} from './promo-img.png';
export { default as loginImg} from './login-img.png';
export { default as sendArrow} from './send-arrow.svg';
export { default as ailogo} from './AIlogo.jpg';
export { default as searchOnMap} from './search-on-map-hotel.jpg';

export { default as flightFront} from './flightfront.png';
export { default as flightBack} from './flightback.png';
export { default as flightExit} from './exit.png';
export { default as flightKitchen} from './kitchen.png';
export { default as scarecrow} from './scarecrow.png';

export { default as hotelimgnotavail} from './hotel-image-not-availble.png';