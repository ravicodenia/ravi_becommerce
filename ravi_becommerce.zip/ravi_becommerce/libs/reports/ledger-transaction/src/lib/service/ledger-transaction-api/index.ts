import { getGatewayAPI, putGatewayAPI,postGatewayAPI } from '@mfa-travel-app/services';
import { LEDGER_TRANSACTION  } from '../constants';

export const createLedgerTransaction = async (payload: any) => {
    try {
        const response = await postGatewayAPI( LEDGER_TRANSACTION , payload);
        return response;
    } catch (error) {
        return error;
    }
}