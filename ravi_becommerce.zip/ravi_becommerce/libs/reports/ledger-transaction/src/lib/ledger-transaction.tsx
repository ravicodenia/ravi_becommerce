import { MainLayout } from '@mfa-travel-app/layout';
import { ControlledSelect, ControlledDatePicker } from '@mfa-travel-app/ui';
import { useState, useEffect } from 'react';
import { RootState } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { useLedgerTransactionStore, useMastersDropdownStore } from '@mfa-travel-app/store';
import {  agentIdAndTypeForFilters, getParentAgentOptions, differentAgentTypeLists } from '@mfa-travel-app/shared';
import { createLedgerTransaction } from '../lib/service/ledger-transaction-api/index';
import { toast } from 'react-toastify';



export const LedgerTransaction = () => {
    const { saveParentAgentList } = useMastersDropdownStore();
    const { parentAgentList } = useSelector((state: RootState) => state.mastersDropdown);
    const { saveAgentAndBaseAgentList, saveLedgerTransactionFilters, saveBToBList, saveBToBToBList } = useLedgerTransactionStore();
    const { ledgerTransactionFilters, agentAndBaseAgentList, bToBList, bToBToBList, } = useSelector((state: RootState) => state.ledgerTransaction);
    const [ledgerTransactionValue, setLedgerTransactionValue] = useState<any>({ transactionInfo: [], balanceInfo: [] })
   
    const accountType = [
        { id: 0, text: 'All' },
        { id: 1, text: "On Account " }
    ];
    const transType = [
        { id: '', text: 'All' },
        { id: 'B2B', text: 'B2B' },
        { id: 'B2C', text: 'B2C' },
    ]
    const [submit, setSubmit] = useState(
        {
            startDate: ledgerTransactionFilters?.startDate ? ledgerTransactionFilters?.startDate : new Date(),
            endDate: ledgerTransactionFilters?.endDate ? ledgerTransactionFilters?.endDate : new Date(),
            agentId: ledgerTransactionFilters?.agentId,
            agentType: 'BASE',
            transType: ledgerTransactionFilters.transType,
            paymentMode: ledgerTransactionFilters.accountType,
        });

    const filterDifferentAgents = (agentList: any) => {
        const agentTypeLists = differentAgentTypeLists(agentList);

        saveAgentAndBaseAgentList(agentTypeLists.agentAndBaseAgent);
        saveBToBList(agentTypeLists.bToB);
        saveBToBToBList(agentTypeLists.bToBToB);
    }

    useEffect(() => {
        getDropdownOptions();

    }, []);

    const getDropdownOptions = async () => {
        if (parentAgentList.length === 0) {
            getParentAgentOptions().then((options) => {
                saveParentAgentList(options);
                filterDifferentAgents(options);
            }).catch((error) => {
                console.error('error', error);
            });
        } else {
            if (agentAndBaseAgentList.length === 0) {
                filterDifferentAgents(parentAgentList);
            }
        }
    }
    const handleFlightQueueFiltersChange = (value: any, param: string) => {
        let filters = JSON.parse(JSON.stringify(ledgerTransactionFilters));
        filters[param] = value;
        filters['startDate'] = filters.startDate ? filters.startDate : new Date();
        filters['endDate'] = filters.endDate ? filters.endDate : new Date();
        saveLedgerTransactionFilters(filters);
        setSubmit(filters);
    };
    

    const handleFlightQueueFilterAgentIdChange = async (filters: any, value: any, param: string) => {
        try {
            const filtersWithAgentIdAndType: any = await agentIdAndTypeForFilters(filters, value, param);
            saveLedgerTransactionFilters(filtersWithAgentIdAndType);
            setSubmit({ ...submit, agentId: filtersWithAgentIdAndType.selectedAgentId })
        } catch (error) {
            console.error('An error occurred:', error);
        }
    }
    const adjustDates = (data: any) => {
        let startDate = new Date(data.startDate);
        let endDate = new Date(data.endDate);
        startDate.setUTCHours(0, 0, 0, 0);
        endDate.setUTCHours(23, 59, 59, 999);
        data.startDate = startDate.toISOString();
        data.endDate = endDate.toISOString();
    
        return data;
    };
    const onSubmit = async () => {
        console.log('onSubmit')
        try {
            const mutableSubmit: Record<string, any> = submit; // Type assertion
            delete mutableSubmit.selectedB2bId;
            delete mutableSubmit.selectedB2b2bId;
            delete mutableSubmit.selectedAgentId;
            delete mutableSubmit.fromDate;
            delete mutableSubmit.toDate;
            const mutableSubmitData = adjustDates(mutableSubmit);
    
            const res: any = await createLedgerTransaction(mutableSubmitData);
            console.log('res', res);
            if (res.data && res.status === 200) {
                setLedgerTransactionValue(res?.data);
            } else {
                toast.error('Transaction failed');
            }
        } catch (error) {
            toast.error('Transaction failed');
            console.error('Transaction failed:', error);
        }
    };
    

    const getMatchingData = (transactionInfo: any, balanceInfo: any) => {
        return balanceInfo?.map((balance: any) => {
            const matchedTransactions = transactionInfo.filter(
                (transaction: any) => transaction.ledgerId === balance.agentId
            );
            return {
                balance,
                transactions: matchedTransactions,
            };
        }).filter((item: any) => item.transactions.length > 0);
    };
    const matchedData = getMatchingData(ledgerTransactionValue?.transactionInfo, ledgerTransactionValue?.balanceInfo);

    return (
        <>
            <MainLayout>

                <div style={{ minHeight: '500px' }} className="container">
                    <section className="country_section mt-2 mb-3 font_size_90 rule_section">

                        <div className="row mt-3">

                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="fromDate" className="col-lg-5">From Date:</label>
                                    <div className="col-lg-7">
                                        <ControlledDatePicker
                                            id={'fromDate'}
                                            value={ledgerTransactionFilters.startDate ? ledgerTransactionFilters.startDate : new Date()}
                                            format={'dd/MMM/yyyy'}
                                            required={true}
                                            disablePostDates={true}
                                            onChange={(date: any) => handleFlightQueueFiltersChange(date.toISOString(), 'startDate')}
                                        />
                                    </div>
                                </div>

                            </div>


                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="toDate" className="col-lg-5">To Date:</label>
                                    <div className="col-lg-7">
                                        <ControlledDatePicker
                                            id={'toDate'}
                                            value={ledgerTransactionFilters.endDate ? ledgerTransactionFilters.endDate : new Date()}
                                            format={'dd/MMM/yyyy'}
                                            required={true}
                                            onChange={(date: any) => handleFlightQueueFiltersChange(date.toISOString(), 'endDate')}

                                        />
                                    </div>
                                </div>

                            </div>



                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="agent" className="col-lg-5">Agent:</label>
                                    <div className="col-lg-7">
                                        <ControlledSelect
                                            id={'agent'}
                                            value={ledgerTransactionFilters.selectedAgentId ? ledgerTransactionFilters.selectedAgentId : ''}
                                            options={agentAndBaseAgentList}
                                            required={true}
                                            onChange={(e: any) => handleFlightQueueFilterAgentIdChange(ledgerTransactionFilters, e.target.value, 'agent')}
                                        />
                                    </div>
                                </div>

                            </div>


                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="b2bagent" className="col-lg-5">B2BAgent:</label>
                                    <div className="col-lg-7">
                                        <ControlledSelect
                                            id={'b2b'}
                                            value={ledgerTransactionFilters.selectedB2bId ? ledgerTransactionFilters.selectedB2bId : ''}
                                            options={bToBList}
                                            required={true}
                                            onChange={(e: any) => handleFlightQueueFilterAgentIdChange(ledgerTransactionFilters, e.target.value, 'b2b')}
                                        />
                                    </div>
                                </div>

                            </div>


                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="b2b2bagent" className="col-lg-5">B2B2B Agent:</label>
                                    <div className="col-lg-7">
                                        <ControlledSelect
                                            id={'b2b2b'}
                                            value={ledgerTransactionFilters.selectedB2b2bId ? ledgerTransactionFilters.selectedB2b2bId : ''}
                                            options={bToBToBList}
                                            required={true}
                                            onChange={(e: any) => handleFlightQueueFilterAgentIdChange(ledgerTransactionFilters, e.target.value, 'b2b2b')}
                                        />
                                    </div>
                                </div>

                            </div>



                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="transtype" className="col-lg-5">Trans Type:</label>
                                    <div className="col-lg-7">
                                        <ControlledSelect
                                            id={'transtype'}
                                            value={ledgerTransactionFilters.transType ? ledgerTransactionFilters.transType : ''}
                                            options={transType}
                                            required={true}
                                            onChange={(e: any) => handleFlightQueueFiltersChange(e.target.value, 'transType')}
                                        />
                                    </div>
                                </div>

                            </div>


                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="accounttype" className="col-lg-5">Account Type:</label>
                                    <div className="col-lg-7">
                                        <ControlledSelect
                                            id={'accounttype'}
                                            value={ledgerTransactionFilters.paymentMode ? ledgerTransactionFilters.paymentMode : ''}
                                            options={accountType}
                                            required={true}
                                            onChange={(e: any) => handleFlightQueueFiltersChange(e.target.value, 'paymentMode')}
                                        />
                                    </div>
                                </div>

                            </div>

                            <div className="col-lg-3 text-end">
                                <button className='btn btn-primary btn-sm rounded mt-2' onClick={onSubmit}>Submit</button>

                            </div>






                        </div>




                        <div className="row mt-3">

                            <div className='col-12'>
                                <div className="table-responsive">

                                    <table className="table table-bordered tbl_grid_heading">
                                        <thead>
                                            <tr>
                                                <th scope="col">Agent Name/Date</th>
                                                <th scope="col">Ref #</th>
                                                <th className='text-center' scope="col">Perticulars</th>
                                                <th scope="col">Debit</th>
                                                <th scope="col">Credit</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            {matchedData?.map(({ balance, transactions }: any, index: any) => (
                                                <>
                                                    <tr>
                                                        <td><strong>{balance?.agentName || "Unknown Agent"}</strong></td>
                                                        <td colSpan={2}><strong>Opening Current Balance (All values are in AED)</strong></td>
                                                        <td></td>
                                                        <td><strong>{balance?.openingBalance.toFixed(3)}</strong></td>
                                                    </tr>

                                                    {transactions.map((transaction: any, transIndex: any) => (
                                                        <tr key={transIndex}>
                                                            <td><strong>{new Date(transaction?.date).toLocaleDateString()}</strong></td>
                                                            <td className='text-muted'>{transaction?.invoiceNumber}</td>
                                                            <td>
                                                                <strong>{transaction.narration.split(',|')[0]}:</strong>
                                                                <span className='text-muted ms-1'>
                                                                    {transaction.narration.split(',|').slice(1).join(' , ')}
                                                                </span>
                                                                <span className='text-muted ms-1'>
                                                                    {transaction.notes}
                                                                </span>
                                                            </td>
                                                            <td className='text-muted'>{transaction.debit.toFixed(2)}</td>
                                                            <td>{transaction.credit === 0 ? '-' : transaction.credit.toFixed(2)}</td>
                                                        </tr>
                                                    ))}

                                                    <tr>
                                                        <td colSpan={3}><strong>Total</strong></td>
                                                        <td><strong>{balance.totalDebit?.toFixed(2)}</strong></td>
                                                        <td><strong>{balance.totalCredit?.toFixed(2)}</strong></td>
                                                    </tr>

                                                    <tr>
                                                        <td colSpan={4}><strong>Closing Balance</strong></td>
                                                        <td><strong>{balance.currentBalance?.toFixed(2)}</strong></td>
                                                    </tr>
                                                </>
                                            ))}
                                        </tbody>



                                    </table>


                                </div>

                            </div>


                        </div>

                    </section>

                </div>

            </MainLayout>

        </>
    )
}
export default LedgerTransaction;


