import { getGatewayAPI, postGatewayAPI } from "@mfa-travel-app/services";
import {GET_PRODUCT_LIST, GET_MARK_UP } from '../constant';

export const getProductList = async () => {
    try {
        const response = await getGatewayAPI(GET_PRODUCT_LIST,
            // { params: { page: 'agentmaster' } }
        );
        return response;
    } catch (error) {
        return error;
    }
}

export const createMarkUp = async (payload: any) => {
    try {
        const response = await postGatewayAPI( GET_MARK_UP, payload);
        return response;
    } catch (error) {
        return error;
    }
}