export const GET_PRODUCT_LIST = 'common/Product/GetAll';
export const GET_MARK_UP = "common/MarkupRuleMaster/Create";
