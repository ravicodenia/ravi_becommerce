import { MainLayout } from '@mfa-travel-app/layout';
import { ControlledSelect, ControlledInput, ControlledDatePicker } from '@mfa-travel-app/ui';
import { useEffect, useState } from 'react';
import { FiTrash2 } from "react-icons/fi";
import { FiEdit } from "react-icons/fi";
import { IoMdAdd } from "react-icons/io";
import { getProductList, createMarkUp } from '../lib/service/markup-section-api/index';

export const AgentMarkUp = () => {

  const selectTypeOptions = [
    { id: 'p', text: 'Percentage' },
    { id: 'F', text: 'Fixed' },
  ]
  const selectApplyOptions = [
    { id: 'BF', text: 'Base Fare ' },
    { id: 'TX', text: 'TAX' },
    { id: 'TF', text: 'NetFare' },
  ]


  const selectOptions3 = [
    { id: 'Any', text: 'Any' },
    { id: '=', text: '=' },
    { id: 'In', text: 'In' },
    { id: 'Between', text: 'Between' },
    { id: 'LMB', text: 'LMB' },
  ];


  const [status, setStatus] = useState('');
  const [productOptionsData, setProductOptionsData] = useState<any>([]);
  const [selectedOption, setSelectedOption] = useState(null);
  const [selectedType, setSelectedType] = useState(null);
  const [selectedAdult, setSelectedAdult] = useState<any>(null);
  const [selectedChild, setSelectedChild] = useState(null);
  const [selectedInfant, setSelectedInfant] = useState(null);
  const [selectedApply, setselectedApply] = useState(null);
  const [selectedRulName, setSelectedRulName] = useState(null);
  const [selectedDescription, setSelectedDescription] = useState(null);
  const [fromDate, setFromDate] = useState(new Date());
  const [toDate, setToDate] = useState(new Date());
  const [rows, setRows] = useState<any>([
    {
      attribute: null,
      operator: null,
      fromValue: null,
    },
  ]);
  const selectOptions2 = selectedOption == 1 ? [
    { id: 'Traffic Source', text: 'Traffic Source' },
    { id: 'Sales Channel', text: 'Sales Channel' },
    { id: 'Journey Type', text: 'Journey Type' },
    { id: 'Supplier', text: 'Supplier' },
    { id: 'Booking Date', text: 'Booking Date' },
    { id: 'Travel Date', text: 'Travel Date' },
    { id: 'Travel Type', text: 'Travel Type' },
    { id: 'Origin', text: 'Origin' },
    { id: 'Destination', text: 'Destination' },
    { id: 'Last Minute Booking', text: 'Last Minute Booking' }
  ] : [
    { id: 'Traffic Source', text: 'Traffic Source' },
    { id: 'Suppliers', text: 'Suppliers' },
    { id: 'City', text: 'City' },
    { id: 'Country', text: 'Country' },
    { id: 'Booking Date', text: 'Booking Date' },
    { id: 'Travel Date', text: 'Travel Date' }];
  const [submitPayload, setSubmitPayload] = useState({
    ruleName: selectedRulName,
    description: selectedDescription,
    ruleType: 'MARKUP',
    type: selectedType,
    adultCount: selectedAdult,
    childCount: selectedChild,
    infantCount: selectedInfant,
    ruleTypeOn: selectedApply,
    productId: selectedOption,
    markupRuleAttributes: [
      {
        attribute: 'Traffic Source',
        toValue: '',
        fromValue: '',
        operator: '',
        dataType: ''
      }
    ]
  });

  const getProductData = async () => {
    const res: any = await getProductList();
    setProductOptionsData(res?.data?.items)
  }
  useEffect(() => {
    getProductData()
  }, [])

  const radioHandler = (status: any) => {
    setStatus(status.target.value);
  };


  const handleSelectChange = (event: any) => {
    const selectedId = event.target.value;
    if (event.target.id == 'rulename') {
      const selectedProduct = selectedId
      setSubmitPayload({ ...submitPayload, ruleName: selectedId })
      setSelectedRulName(selectedProduct);
    }
    if (event.target.id == 'product') {
      const selectedProduct = productOptionsData.find((option: any) => option.id === parseInt(selectedId))?.id;
      setSubmitPayload({ ...submitPayload, productId: selectedProduct })
      setSelectedOption(selectedProduct);
    }
    if (event.target.id == 'typedrop') {
      const selectedProduct = selectedId;
      setSubmitPayload({ ...submitPayload, type: selectedProduct })
      setSelectedType(selectedProduct);
    }
    if (event.target.id == 'adult') {
      const selectedProduct = selectedId;
      const adultValue = parseInt(selectedProduct);
      if (isNaN(adultValue) || adultValue <= 1 || adultValue > 99) {
        alert("Please enter a valid number of adults between 1 and 99.");
        setSelectedAdult(null);
        return;
      }
      setSelectedAdult(adultValue);
      setSubmitPayload({ ...submitPayload, adultCount: selectedProduct })
    }
    if (event.target.id == 'child') {
      const selectedProduct = selectedId;
      const childValue = parseInt(selectedProduct, 10);
      if (isNaN(childValue) || childValue < 1 || childValue > 18) {
        alert("Please enter a valid number of children between 1 and 18.");
        setSelectedChild(null);
        return;
      }
      setSubmitPayload({ ...submitPayload, childCount: selectedProduct })
      setSelectedChild(selectedProduct);
    }
    if (event.target.id == 'infant') {
      const selectedProduct = selectedId;
      setSubmitPayload({ ...submitPayload, infantCount: selectedProduct })
      setSelectedInfant(selectedProduct);
    }
    if (event.target.id == 'applyon') {
      const selectedProduct = selectedId;
      setSubmitPayload({ ...submitPayload, ruleTypeOn: selectedProduct })
      setselectedApply(selectedProduct);
    }
    if (event.target.id == 'description') {
      const selectedProduct = selectedId;
      setSubmitPayload({ ...submitPayload, description: selectedProduct })
      setSelectedDescription(selectedProduct);
    }
  };

  const selectOptions = productOptionsData.map((item: any) => ({
    id: item.id,
    text: item.name,
  }));

  const handleAddRow = () => {
    setRows([...rows, { attribute: null, operator: null, fromValue: null }]);
  };

  const handleRowChange = (e: any, index: number, field: string) => {
    const { value } = e.target;
    const updatedRows: any = [...rows];

    if (field === 'attribute') {
      updatedRows[index].attribute = value;
      if (value === 'Booking Date' || value === "Travel Date") {
        updatedRows[index].operator = 'Between';
        updatedRows[index].fromValue = fromDate;
        updatedRows[index].toValue = toDate;
      }
    } else if (field === 'operator') {
      updatedRows[index].operator = value;
      updatedRows[index].fromValue = value === 'Between' ? fromDate : '';
      updatedRows[index].toValue = value === 'Between' ? toDate : '';
    } else if (field.includes('.')) {
      const [mainField, subField] = field.split('.');
      updatedRows[index][mainField] = {
        ...updatedRows[index][mainField],
        [subField]: value,
      };
    } else {
      if (updatedRows[index].operator == "In" || '=') {
        updatedRows[index].fromValue = value;
      }
      if (updatedRows[index][field] !== 'value') {
        updatedRows[index][field] = value;
      }
    }
    const data = updatedRows?.map((item: any) => {
      if (item.hasOwnProperty('value')) {
        delete item.value;
      }
      return item;
    });
    setSubmitPayload({ ...submitPayload, markupRuleAttributes: data })
    setRows(updatedRows);
  };


  const handleDeleteRow = (index: any) => {
    const updatedRows = rows.filter((_: any, rowIndex: any) => rowIndex !== index);
    setRows(updatedRows);
  };

  const onSubmitMarkUp = async () => {
    try {
      const res = await createMarkUp(submitPayload);
      console.log('Markup created successfully:', res);
    } catch (error) {
      console.error('Failed to create markup:', error);
    }
  }


  return (



    <>
      <MainLayout>

        <div style={{ minHeight: '500px' }} className="container">
          <section className="country_section mt-2 mb-3 font_size_90 rule_section">

            <div className="row mt-3">

              <div className="col-lg-4">

                <div className="row align-items-center mb-2">
                  <label htmlFor="rulename" className="col-lg-3">Rule Name :</label>
                  <div className="col-lg-9">
                    <ControlledInput
                      id={'rulename'}
                      value={selectedRulName}
                      type={'text'}
                      required={true}
                      onChange={handleSelectChange}
                    />
                  </div>
                </div>

              </div>

              <div className='col-lg-4'>



                <div className='row'>

                  <div className='col-6'>
                    <label>

                      <input type="radio" name="release" checked={status === 'MARKUP'} value={'MARKUP'} onClick={(e) => radioHandler(e)} />  Markup
                    </label>
                  </div>

                  <div className='col-6'>
                    <label>
                      <input type="radio" name="release" checked={status === 'DISCOUNT'} value={'DISCOUNT'} onClick={(e) => radioHandler(e)} />  Discount
                    </label>
                  </div>

                </div>


              </div>


              <div className="col-lg-4">

                <div className="row align-items-center mb-2">
                  <label htmlFor="product" className="col-lg-3">Product  :</label>
                  <div className="col-lg-9">
                    <ControlledSelect
                      id={'product'}
                      value={selectedOption}
                      options={selectOptions}
                      required={true}
                      onChange={handleSelectChange}
                    />
                  </div>
                </div>

              </div>

              <div className="col-lg-12">

                <div className="row align-items-center mb-2">
                  <label htmlFor="description" className="col-lg-1">Description :</label>
                  <div className="col-lg-11">

                    <ControlledInput
                      id={'description'}
                      value={selectedDescription}
                      type={'text'}
                      required={true}
                      onChange={handleSelectChange}
                    />
                  </div>
                </div>

              </div>


              <div className='col-lg-12'>





                {status === 'MARKUP' && (
                  <div className='markup mt-3'>
                    <div className='row'>


                      <div className='col-12'>
                        <div className='markupheading'>Markup</div>

                        <div className='markupWrapper'>

                          <div className='row'>

                            <div className="col-lg-3">

                              <div className="row align-items-center mb-2">
                                <label htmlFor="typedrop" className="col-lg-5">Type :</label>
                                <div className="col-lg-7">
                                  <ControlledSelect
                                    id={'typedrop'}
                                    value={selectedType}
                                    options={selectTypeOptions}
                                    required={true}
                                    onChange={handleSelectChange}
                                  />
                                </div>
                              </div>

                            </div>



                            <div className='col-lg-6'>

                              <div className='row'>
                                <div className="col-lg-4">

                                  <div className="row align-items-center mb-2">
                                    <label htmlFor="adult" className="col-lg-5">Adult :</label>
                                    <div className="col-lg-7">
                                      <ControlledInput
                                        id={'adult'}
                                        value={selectedAdult}
                                        type={'text'}
                                        required={true}
                                        onChange={handleSelectChange}
                                      />
                                    </div>
                                  </div>

                                </div>


                                <div className="col-lg-4">

                                  <div className="row align-items-center mb-2">
                                    <label htmlFor="child" className="col-lg-5">Child :</label>
                                    <div className="col-lg-7">
                                      <ControlledInput
                                        id={'child'}
                                        value={selectedChild}
                                        type={'text'}
                                        required={true}
                                        onChange={handleSelectChange}
                                      />
                                    </div>
                                  </div>

                                </div>



                                <div className="col-lg-4">

                                  <div className="row align-items-center mb-2">
                                    <label htmlFor="infant" className="col-lg-5">Infant :</label>
                                    <div className="col-lg-7">
                                      <ControlledInput
                                        id={'infant'}
                                        value={selectedInfant}
                                        type={'text'}
                                        required={true}
                                        onChange={handleSelectChange}
                                      />
                                    </div>
                                  </div>

                                </div>
                              </div>


                            </div>




                            <div className="col-lg-3">

                              <div className="row align-items-center mb-2">
                                <label htmlFor="applyon" className="col-lg-5">Apply On :</label>
                                <div className="col-lg-7">
                                  <ControlledSelect
                                    id={'applyon'}
                                    value={selectedApply}
                                    options={selectApplyOptions}
                                    required={true}
                                    onChange={handleSelectChange}
                                  />
                                </div>
                              </div>

                            </div>


                          </div>

                        </div>
                      </div>
                    </div>

                  </div>

                )}


              </div>


              <div className='col-lg-12'>

                {status === 'DISCOUNT' && (
                  <div className='markup mt-3'>
                    <div className='row'>


                      <div className='col-12'>
                        <div className='markupheading'>Markup</div>

                        <div className='markupWrapper'>

                          <div className='row'>

                            <div className="col-lg-3">

                              <div className="row align-items-center mb-2">
                                <label htmlFor="typedrop" className="col-lg-5">Type :</label>
                                <div className="col-lg-7">
                                  <ControlledSelect
                                    id={'typedrop'}
                                    value={selectedType}
                                    options={selectTypeOptions}
                                    required={true}
                                    onChange={handleSelectChange}
                                  />
                                </div>
                              </div>

                            </div>



                            <div className='col-lg-6'>

                              <div className='row'>
                                <div className="col-lg-4">

                                  <div className="row align-items-center mb-2">
                                    <label htmlFor="adult" className="col-lg-5">Adult :</label>
                                    <div className="col-lg-7">
                                      <ControlledInput
                                        id={'adult'}
                                        value={selectedAdult}
                                        type={'text'}
                                        required={true}
                                        onChange={handleSelectChange}
                                      />
                                    </div>
                                  </div>

                                </div>


                                <div className="col-lg-4">

                                  <div className="row align-items-center mb-2">
                                    <label htmlFor="child" className="col-lg-5">Child :</label>
                                    <div className="col-lg-7">
                                      <ControlledInput
                                        id={'child'}
                                        value={selectedChild}
                                        type={'text'}
                                        required={true}
                                        onChange={handleSelectChange}
                                      />
                                    </div>
                                  </div>

                                </div>



                                <div className="col-lg-4">

                                  <div className="row align-items-center mb-2">
                                    <label htmlFor="infant" className="col-lg-5">Infant :</label>
                                    <div className="col-lg-7">
                                      <ControlledInput
                                        id={'infant'}
                                        value={selectedInfant}
                                        type={'text'}
                                        required={true}
                                        onChange={handleSelectChange}
                                      />
                                    </div>
                                  </div>

                                </div>
                              </div>


                            </div>




                            <div className="col-lg-3">

                              <div className="row align-items-center mb-2">
                                <label htmlFor="applyon" className="col-lg-5">Apply On :</label>
                                <div className="col-lg-7">
                                  <ControlledSelect
                                    id={'applyon'}
                                    value={selectedApply}
                                    options={selectApplyOptions}
                                    required={true}
                                    onChange={handleSelectChange}
                                  />
                                </div>
                              </div>

                            </div>

                            <div className="col-lg-3">

                              {/* <div className="row align-items-center mb-2">
               <label htmlFor="applymarkup" className="col-lg-5">Apply Discount :</label>
               <div className="col-lg-7">
               <ControlledSelect
                   id={'applymarkup'}
                   value={''}
                   options={selectOptions}
                   required={true}
                   onChange={handleSelectChange}
               />
               </div>
           </div> */}

                            </div>


                          </div>




                        </div>
                      </div>




                    </div>

                  </div>

                )}
              </div>


              {selectedOption &&
                <div className='col-lg-12'>


                  <div className='markup mt-3'>
                    <div className='row'>
                      <div className='col-12'>
                        <div className='markupheading'>Criteria</div>
                        <div className='markupWrapper'>

                          <div className='row'>

                            <div className="col-lg-12">
                              <table className="table">
                                <thead>
                                  <tr>
                                    <th scope="col">Attribute</th>
                                    <th scope="col">Operator</th>
                                    <th scope="col">Value</th>
                                    <th></th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {rows.map((row: any, index: any) => (
                                    <tr className="align-middle" key={index}>
                                      <td>
                                        <ControlledSelect
                                          id={`attribute-${index}`}
                                          value={row.attribute}
                                          options={selectOptions2}
                                          required={true}
                                          onChange={(e: any) => handleRowChange(e, index, 'attribute')}
                                        />
                                      </td>
                                      <td>
                                        <ControlledSelect
                                          id={`operator-${index}`}
                                          value={row.operator}
                                          options={selectOptions3}
                                          required={true}
                                          onChange={(e: any) => handleRowChange(e, index, 'operator')}
                                        />
                                      </td>
                                      <td>
                                        {row.operator !== 'Between' ? (
                                          <ControlledInput
                                            id={`value-${index}`}
                                            value={row.value}
                                            disabled={row.operator == 'Any'}
                                            type={row.operator == 'LMB' ? 'number' : 'text'}
                                            required={true}
                                            onChange={(e: any) => handleRowChange(e, index, 'value')}
                                          />
                                        ) : (
                                          <>
                                            {/* <div className='d-flex justify-content-evenly'>
                                            <div className='d-flex'>
                                              <label htmlFor={`from-${index}`} className="col-lg-3">
                                                From :
                                              </label>
                                              <ControlledInput
                                                id={`from-${index}`}
                                                value={row?.value?.from}
                                                type={'text'}
                                                required={true}
                                                onChange={(e: any) => handleRowChange(e, index, 'value.from')}
                                              />
                                            </div>
                                            <div className='d-flex'>
                                              <label htmlFor={`to-${index}`} className="col-lg-3">
                                                To :
                                              </label>
                                              <ControlledInput
                                                id={`to-${index}`}
                                                value={row?.value?.to}
                                                type={'text'}
                                                required={true}
                                                onChange={(e: any) => handleRowChange(e, index, 'value.to')}
                                              />
                                            </div>
                                          </div> */}

                                            <div className="row">
                                              <div className="col-lg-6">
                                                <div className="row align-items-center mb-3">
                                                  <label className="col-sm-5 text-lg-end">
                                                    {' '}
                                                    From Date:
                                                  </label>
                                                  <div className="col-sm-7">
                                                    <ControlledDatePicker
                                                      id={'fromDate'}
                                                      value={fromDate}
                                                      format={'dd/MMM/yyyy'}
                                                      required={true}
                                                      disablePostDates={true}
                                                      onChange={(date: any) =>
                                                        setFromDate(date.toISOString())
                                                      }
                                                    />
                                                  </div>
                                                </div>
                                              </div>

                                              <div className="col-lg-6">
                                                <div className="row align-items-center mb-3">
                                                  <label className="col-sm-5 text-lg-end"> To Date:</label>
                                                  <div className="col-sm-7">
                                                    <ControlledDatePicker
                                                      id={'toDate'}
                                                      value={toDate}
                                                      format={'dd/MMM/yyyy'}
                                                      required={true}
                                                      onChange={(date: any) =>
                                                        setToDate(date.toISOString())
                                                      }
                                                    />
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                          </>
                                        )}
                                      </td>
                                      <td>
                                        <button className="btn me-2">
                                          <FiEdit />
                                        </button>
                                        <button
                                          className="btn me-2"
                                          onClick={() => handleDeleteRow(index)}
                                        >
                                          <FiTrash2 />
                                        </button>
                                      </td>
                                    </tr>
                                  ))}
                                  <tr className="align-middle">
                                    <td >
                                      <button
                                        className="btn btn-secondary rounded btn-sm"
                                        onClick={handleAddRow}
                                      >
                                        <IoMdAdd /> Add
                                      </button>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              }
              <div className='col-lg-12 text-end mt-4 mb-4'>
                <button className='btn btn-primary' onClick={onSubmitMarkUp}>Submit</button>
              </div>
            </div>
          </section>
        </div>
      </MainLayout>

    </>





  )
}
export default AgentMarkUp;
