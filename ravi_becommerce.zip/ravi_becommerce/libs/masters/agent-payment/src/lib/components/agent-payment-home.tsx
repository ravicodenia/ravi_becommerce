import * as React from 'react';
import { MainLayout } from '@mfa-travel-app/layout';
import PaymentMainSection from './payment-main-section';
import { useSelector } from 'react-redux';
import {
  RootState,
  useMastersDropdownStore,
  useAgentPaymentStore,
} from '@mfa-travel-app/store';
import { Loader } from '@mfa-travel-app/ui';
import {
  API_ERROR_TOAST_TEXT,
  getLocationOptionsByAgentId,
  getParentAgentOptions,
  convertDateForApi,
} from '@mfa-travel-app/shared';
import { toast } from 'react-toastify';
import { createAgentPayment } from '../service/agent-payment-api';

const AgentPaymentHome = () => {
  const [loader, setLoader] = React.useState(false);
  const { parentAgentList, locationList } = useSelector(
    (state: RootState) => state.mastersDropdown
  );
  const { updatedAgentPaymentData } = useSelector(
    (state: RootState) => state.agentPayment
  );
  const { currency } = useSelector(
    (state: RootState) => state.config.agentProfile
  );
  const { saveUpdatedAgentPayment } = useAgentPaymentStore();
  const { saveParentAgentList, saveLocationList } = useMastersDropdownStore();

  React.useEffect(() => {
    getParentAgentList();
  }, []);

  React.useEffect(() => {
    getLocationList();
  }, [updatedAgentPaymentData.AgentId]);

  const getParentAgentList = async () => {
    if (parentAgentList.length === 0) {
      getParentAgentOptions()
        .then((options) => {
          saveParentAgentList(options);
        })
        .catch((error) => {
          console.error('error', error);
          toast.error(API_ERROR_TOAST_TEXT);
        });
    }
  };
  const getLocationList = async () => {
    if (updatedAgentPaymentData.AgentId) {
      getLocationOptionsByAgentId(updatedAgentPaymentData.AgentId)
        .then((options) => {
          saveLocationList(options);
        })
        .catch((error) => {
          console.error('error', error);
          toast.error(API_ERROR_TOAST_TEXT);
        });
    }
  };

  const SuccessToastMsg = ({ receiptNo, msg }: any) => (
    <div>
      <div>Receipt No: {receiptNo}</div>
      <div>{msg}</div>
    </div>
  );

  const handleSaveAgentPayment = async (e: any) => {
    e.preventDefault();
    // let agentPaymentMaster = structuredClone(updatedAgentPaymentData);
    let agentPaymentMaster = {...updatedAgentPaymentData};
    agentPaymentMaster.currency = currency;
    agentPaymentMaster.date = convertDateForApi(new Date());
    saveUpdatedAgentPayment(agentPaymentMaster); 

    try {
      setLoader(true);
      let agentPaymentFormData = new FormData();
      Object.keys(updatedAgentPaymentData).forEach((k:any) => {
        agentPaymentFormData.append(k, updatedAgentPaymentData[k]);
      })
      const response: any = await createAgentPayment(agentPaymentFormData);
      // const response: any = await createAgentPayment(updatedAgentPaymentData);
      if (response?.data?.statusCode === 200) {
        const depositSlipInput = document.getElementById('deposit-slip');
        if (depositSlipInput) {
            (depositSlipInput as HTMLInputElement).value = ''; // Manually reset file input
        }
        saveUpdatedAgentPayment({});
        setLoader(false);
        toast.success(<SuccessToastMsg receiptNo={response?.data?.result} msg={response?.data?.message}/>)
      } else {
        setLoader(false);
        toast.error(response?.data?.message);
      }
    } catch (error) {
      setLoader(false);
      console.error('An error occurred:', error);
      toast.error(API_ERROR_TOAST_TEXT);
    }
  };

  return (
    <MainLayout>
      <form onSubmit={handleSaveAgentPayment}>
        <div className="container mt-4 mb-5">
          <div className="row">
            <PaymentMainSection />
          </div>
          <div className="row">
            <div className="col-12 text-end">
              <button type="submit" className="btn btn-primary">
                Submit
              </button>
            </div>
          </div>
        </div>
        {loader && <Loader />}
      </form>
    </MainLayout>
  );
};

export default AgentPaymentHome;
