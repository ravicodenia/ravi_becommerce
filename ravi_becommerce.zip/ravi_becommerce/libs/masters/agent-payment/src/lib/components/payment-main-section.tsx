import { ControlledDatePicker, ControlledFileInput, ControlledInput, ControlledSelect, ControlledTextarea } from '@mfa-travel-app/ui';
import { convertDateForApi } from '@mfa-travel-app/shared';
import { useSelector } from 'react-redux';
import { RootState, useAgentPaymentStore } from '@mfa-travel-app/store';
import { useEffect, useState } from 'react';

const PaymentMainSection = () => {
    const { parentAgentList, locationList } = useSelector((state: RootState) => state.mastersDropdown);
    const { updatedAgentPaymentData } = useSelector((state: RootState) => state.agentPayment);
    const { currency } = useSelector((state: RootState) => state.config.agentProfile)
    const { saveUpdatedAgentPayment } = useAgentPaymentStore()

    useEffect(() => {
        saveUpdatedAgentPayment({})
    }, [])

    const transactionTypeOptions = [
        { id: 'ADD', text: 'Add' },
        { id: 'REDUCE', text: 'Reduce' },
    ];

    const paymentModeOptions = [
        { id: 'CASH', text: 'Cash' },
        { id: 'CHEQUE', text: 'Cheque' },
        { id: 'NET BANKING', text: 'Net Banking' },
    ];

    const agentListWithCode = parentAgentList?.map((agent: any) => {
        return {
            ...agent,
            text: `${agent?.code} - ${agent?.text}`
        }
    })

    const handleAgentPaymentChanges = (value: any, param: string) => {
        let agentPaymentMaster = { ...updatedAgentPaymentData };
        if (param === 'DepositSlip') {
            if (value.target.files[0]) {
                agentPaymentMaster[param] = value.target.files[0];
            } else {
                agentPaymentMaster[param] = undefined;
            }
        } else if (param === 'LocationId' && value === '') {
            delete agentPaymentMaster.LocationId
        } else {
            agentPaymentMaster[param] = value;
        }
        saveUpdatedAgentPayment(agentPaymentMaster);
    }

    return (
        <div className="mdlContainer">
            <div className="container mb-5">
                <section className="user_master_section">
                    <div className="innerContainer border-end-0 border-top-0">

                        <div className="wrapper">

                            <div className="row">
                                <div className="col-12"> <h5>Add or Reduce Balance </h5> </div>

                                <div className="col-12">
                                    <div className="form_heading">
                                        <span className=" title">Firm Add / Reduce Balance</span>
                                    </div>

                                </div>
                            </div>

                            <div className="row align-items-center">

                                <div className="col-lg-4">
                                    <div className="row align-items-center mb-3">
                                        <label className="col-sm-5">Firm <span className="text-danger">*</span> :</label>
                                        <div className="col-sm-7">
                                            <ControlledSelect
                                                id={'firm'}
                                                value={updatedAgentPaymentData.AgentId ? updatedAgentPaymentData.AgentId : ''}
                                                options={agentListWithCode}
                                                required={true}
                                                onChange={(e: any) => handleAgentPaymentChanges(Number(e.target.value), 'AgentId')}
                                            />
                                        </div>
                                    </div>
                                </div>

                                <div className="col-lg-4">
                                    <div className="row align-items-center mb-3">
                                        <label className="col-sm-5">Branch :</label>
                                        <div className="col-sm-7">
                                            <ControlledSelect
                                                id={'branchselect'}
                                                value={updatedAgentPaymentData.LocationId ? updatedAgentPaymentData.LocationId : ''}
                                                options={locationList}
                                                onChange={(e: any) => handleAgentPaymentChanges(e.target.value, 'LocationId')}
                                            />
                                        </div>
                                    </div>
                                </div>

                                <div className="col-lg-4">
                                    <div className="row align-items-center mb-3">
                                        <label className="col-sm-5">Transaction Type <span className="text-danger">*</span> :</label>
                                        <div className="col-sm-7">
                                            <ControlledSelect
                                                id={'transtype'}
                                                value={updatedAgentPaymentData.TransactionType ? updatedAgentPaymentData.TransactionType : ''}
                                                options={transactionTypeOptions}
                                                required={true}
                                                onChange={(e: any) => handleAgentPaymentChanges(e.target.value, 'TransactionType')}
                                            />
                                        </div>
                                    </div>
                                </div>

                                <div className="col-lg-4">
                                    <div className="row align-items-center mb-3">
                                        <label className="col-sm-5">Date :</label>
                                        <div className="col-sm-7">
                                            <ControlledDatePicker
                                                id={'date-incorp'}
                                                value={convertDateForApi(new Date())}
                                                format={'dd/MMM/yyyy'}
                                                required={true}
                                                disabled={true}
                                            // onChange={(date:any) => handleAgentPaymentChanges(convertDateForApi(date), 'date')}
                                            />
                                        </div>
                                    </div>
                                </div>

                                <div className="col-lg-4">
                                    <div className="row align-items-center mb-3">
                                        <label className="col-sm-5">Details <span className="text-danger">*</span> :</label>
                                        <div className="col-sm-7">
                                            <ControlledInput
                                                id={'deatils'}
                                                value={updatedAgentPaymentData.Details ? updatedAgentPaymentData.Details : ''}
                                                type={'text'}
                                                required={true}
                                                onChange={(e: any) => handleAgentPaymentChanges(e.target.value, 'Details')}
                                            />
                                        </div>
                                    </div>
                                </div>

                                <div className="col-lg-4">
                                    <div className="row align-items-center mb-3">
                                        <label className="col-sm-5">Payment Mode <span className="text-danger">*</span> :</label>
                                        <div className="col-sm-7">
                                            <ControlledSelect
                                                id={'firm'}
                                                value={updatedAgentPaymentData.PaymentMode ? updatedAgentPaymentData.PaymentMode : ''}
                                                options={paymentModeOptions}
                                                required={true}
                                                onChange={(e: any) => handleAgentPaymentChanges(e.target.value, 'PaymentMode')}
                                            />
                                        </div>
                                    </div>
                                </div>

                                <div className="col-lg-4">
                                    <div className="row align-items-center mb-3">
                                        <label className="col-sm-5">Currency :</label>
                                        <div className="col-sm-7">
                                            <ControlledInput
                                                id={'currency'}
                                                value={currency}
                                                type={'text'}
                                                required={true}
                                                disabled={true}
                                            // onChange={(e:any) => handleAgentPaymentChanges(e.target.value, 'currency')}
                                            />
                                        </div>
                                    </div>
                                </div>

                                <div className="col-lg-4">
                                    <div className="row align-items-center mb-3">
                                        <label className="col-sm-5">Amount <span className="text-danger">*</span> :</label>
                                        <div className="col-sm-7">
                                            <ControlledInput
                                                id={'currency'}
                                                value={updatedAgentPaymentData.Amount ? updatedAgentPaymentData.Amount : ''}
                                                type={'text'}
                                                required={true}
                                                onChange={(e: any) => handleAgentPaymentChanges(Number(e.target.value), 'Amount')}
                                            />
                                        </div>
                                    </div>
                                </div>

                                {updatedAgentPaymentData.PaymentMode == 'CHEQUE' && (
                                    <>
                                        <div id="divaorb_cheque_date" className="col-lg-4">
                                            <div className="row align-items-center mb-3">
                                                <label className="col-sm-5">Cheque Date <span className="text-danger">*</span> :</label>
                                                <div className="col-sm-7">
                                                    <ControlledDatePicker
                                                        id={'date-incorp'}
                                                        value={updatedAgentPaymentData.ChequeDate ? updatedAgentPaymentData.ChequeDate : ''}
                                                        format={'dd/MMM/yyyy'}
                                                        required={true}
                                                        onChange={(date: any) => handleAgentPaymentChanges(date.toISOString(), 'ChequeDate')}
                                                    />
                                                </div>
                                            </div>
                                        </div>

                                        <div id="divaorb_cheque_number" className="col-lg-4">
                                            <div className="row align-items-center mb-3">
                                                <label className="col-sm-5">Cheque Number <span className="text-danger">*</span> :</label>
                                                <div className="col-sm-7">
                                                    <ControlledInput
                                                        id={'chequeno'}
                                                        value={updatedAgentPaymentData.ChequeNo ? updatedAgentPaymentData.ChequeNo : ''}
                                                        type={'text'}
                                                        required={true}
                                                        onChange={(e: any) => handleAgentPaymentChanges(e.target.value, 'ChequeNo')}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </>
                                )}

                                {updatedAgentPaymentData.PaymentMode == 'NET BANKING' && (
                                    <div id="divaorb_transfer_ref" className="col-lg-4">
                                        <div className="row align-items-center mb-3">
                                            <label className="col-sm-5">Transfer Reference <span className="text-danger">*</span> :</label>
                                            <div className="col-sm-7">
                                                <ControlledInput
                                                    id={'tref'}
                                                    value={updatedAgentPaymentData.TransferReference ? updatedAgentPaymentData.TransferReference : ''}
                                                    type={'text'}
                                                    required={true}
                                                    onChange={(e: any) => handleAgentPaymentChanges(e.target.value, 'TransferReference')}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                )}

                                {updatedAgentPaymentData.PaymentMode == 'NET BANKING' || updatedAgentPaymentData.PaymentMode == 'CHEQUE' && (
                                    <div id="divaorb_bank_name" className="col-lg-4">
                                        <div className="row align-items-center mb-3">
                                            <label className="col-sm-5">Bank Name <span className="text-danger">*</span> :</label>
                                            <div className="col-sm-7">
                                                <ControlledInput
                                                    id={'bankname'}
                                                    value={updatedAgentPaymentData.BankName ? updatedAgentPaymentData.BankName : ''}
                                                    type={'text'}
                                                    required={true}
                                                    onChange={(e: any) => handleAgentPaymentChanges(e.target.value, 'BankName')}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                )}

                                {updatedAgentPaymentData.PaymentMode == 'NET BANKING' && (
                                    <div id="divaorb_account_no" className="col-lg-4">
                                        <div className="row align-items-center mb-3">
                                            <label className="col-sm-5">Account No <span className="text-danger">*</span> :</label>
                                            <div className="col-sm-7">
                                                <ControlledInput
                                                    id={'accountno'}
                                                    value={updatedAgentPaymentData.BankAccount ? updatedAgentPaymentData.BankAccount : ''}
                                                    type={'text'}
                                                    required={true}
                                                    onChange={(e: any) => handleAgentPaymentChanges(e.target.value, 'BankAccount')}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                )}

                                {updatedAgentPaymentData.PaymentMode == 'CHEQUE' && (
                                    <div id="divaorb_branch" className="col-lg-4">
                                        <div className="row align-items-center mb-3">
                                            <label className="col-sm-5">Branch <span className="text-danger">*</span> :</label>
                                            <div className="col-sm-7">
                                                <ControlledInput
                                                    id={'branch'}
                                                    value={updatedAgentPaymentData.BankBranch ? updatedAgentPaymentData.BankBranch : ''}
                                                    type={'text'}
                                                    required={true}
                                                    onChange={(e: any) => handleAgentPaymentChanges(e.target.value, 'BankBranch')}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                )}

                                <div className="col-lg-4">
                                    <div className="row align-items-center mb-3">
                                        <label className="col-sm-5">Remarks :</label>
                                        <div className="col-sm-7">
                                            <ControlledTextarea
                                                id={'remarks'}
                                                value={updatedAgentPaymentData.Remarks ? updatedAgentPaymentData.Remarks : ''}
                                                type={'text'}
                                                required={true}
                                                onChange={(e: any) => handleAgentPaymentChanges(e.target.value, 'Remarks')}
                                            />
                                        </div>
                                    </div>
                                </div>

                            </div>

                            <div className="row">

                                <div className="col-lg-7">
                                    <div className="input-group mb-3 align-items-center">
                                        <label className="col-sm-3">Upload Payment reference slip <span className="text-danger">*</span> :</label>
                                        <div className="col-lg-7">
                                            <ControlledFileInput
                                                id={'deposit-slip'}
                                                value={updatedAgentPaymentData.DepositSlip ? updatedAgentPaymentData.DepositSlip : null}
                                                type={'file'}
                                                required={true}
                                                accept={true}
                                                onChange={(file: any) => handleAgentPaymentChanges(file, 'DepositSlip')}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    );
}

export default PaymentMainSection;