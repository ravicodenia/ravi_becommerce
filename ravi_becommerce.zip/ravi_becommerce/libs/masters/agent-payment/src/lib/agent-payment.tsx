import AgentPaymentHome from "./components/agent-payment-home";

export const AgentPayment = () => {
    return (
        <AgentPaymentHome />
    );
}

export default AgentPayment;