import { CREATE_AGENT_PAYMENT } from "../constants";
import { postGatewayAPI } from "@mfa-travel-app/services";

export const createAgentPayment = async (payload: FormData) => {
    try {
        const response = await postGatewayAPI(CREATE_AGENT_PAYMENT, payload, {
            headers: {
                "Content-Type": "multipart/form-data"
            }
        });
        return response;
    } catch (error) {
        return error;
    }
}