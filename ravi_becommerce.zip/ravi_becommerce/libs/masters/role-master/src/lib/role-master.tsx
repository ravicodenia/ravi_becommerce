import { MainLayout } from '@mfa-travel-app/layout';
import FunctionList from './components/function-list';
import RoleName from './components/role-name';

export const RoleMaster = () => {
    return (
        <MainLayout>
            <div className="container">
                <section className="master_section">
                    <RoleName />
                    <FunctionList />
                </section>
            </div>
        </MainLayout>
    );
}

export default RoleMaster;
