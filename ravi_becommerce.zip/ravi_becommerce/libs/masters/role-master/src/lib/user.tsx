import { MainLayout } from '@mfa-travel-app/layout';
import CrudeEdmodel from './components/crudeEdmodel';
import { Link } from "react-router-dom";
import { ControlledInput} from "@mfa-travel-app/ui";
import Paging from './components/paging';
import ViewPerPage from './components/viewPerPage';
import FilterCom from './components/filterCom';

export default function User() {
  return (
   
    <>
    <MainLayout>
   
    <div className="container">
       <section className="country_section mt-2 mb-3">
         
         <div className="row">
         <div className="col-12">
         <nav className="navbar navbar-light bg-light">
     
         <nav aria-label="breadcrumb">
         <ol className="breadcrumb">
         <li className="breadcrumb-item"><a href="index.html">HOME</a></li>
         <li className="breadcrumb-item"><a href="#">USER MANAGEMENT</a></li>
         <li className="breadcrumb-item active" aria-current="page">ROLE LIST</li>
         </ol>
         </nav>
     
         <form className="d-flex text-start">
   
          <ControlledInput
                           id={'deatils'}
                           value={'Search'}
                           type={'text'}
                           required={true}
                           onChange={''}
                       />
   
         <button className="btn btn-outline-success ms-2" type="button">
         Search
         </button>
         </form>
     
         <div className="options_section">
         <ul>
        
         <li> 
           <Link to="/user-master">
             <i className="fa fa-plus-circle" aria-hidden="true"></i> Add
             </Link>
             
             </li>
         
         <li>
   
     
         <FilterCom/>
    
     
         </li>
         <li> 
           <a href="#"><i className="fa-solid fa-file-export"></i> Export</a>
         </li>
     
         <li>
           <a href="#"><i className="fa-solid fa-rotate-right"></i> Refresh</a>
         </li>
         </ul>
         </div>
     
         </nav>
         </div>
         </div>
     
     
         <div className="row">
     
         <div className="col-12">
           <div className="table-responsive">
             <table className="table text-secondary font_size_90">
         <thead>
        
         <tr>
         <th scope="col">SN</th>
         <th scope="col">Title</th>
         <th scope="col">First Name	</th>
         <th scope="col">Last Name</th>
         <th scope="col">Login</th>
         <th scope="col">eMail</th>
         <th scope="col">Contact No.	</th>
         <th scope="col">Agent</th>
         <th scope="col">Location</th>
         <th scope="col">Role</th>
         <th scope="col">Config</th>
         <th scope="col">User Type	</th>
         <th scope="col">Last Login	</th>
         <th scope="col">Status</th>
         <th> </th>
         </tr>
         </thead>
         <tbody>
     
         <tr>
         <td> 1 </td>
         <td> Mr.	 </td>
         <td> James </td>
         <td> Bond </td>
         <td> - - </td>
         <td> james@outlook.com	 </td>
         <td> +91 9189342310	 </td>
         <td> - - </td>
         <td> Dallas, USA </td>
         <td> Admin </td>
         <td> - - </td>
         <td> - - </td>
         <td> 04/05/2014	 </td>
         <td> Active </td>   
         <td className='btnDropMenu'>              
         <CrudeEdmodel/>    
         </td>
         </tr>
      
         <tr>
         <td> 2 </td>
         <td> Mr.	 </td>
         <td> James </td>
         <td> Bond </td>
         <td> - - </td>
         <td> james@outlook.com	 </td>
         <td> +91 9189342310	 </td>
         <td> - - </td>
         <td> Dallas, USA </td>
         <td> Admin </td>
         <td> - - </td>
         <td> - - </td>
         <td> 04/05/2014	 </td>
         <td> Active </td>   
         <td className='btnDropMenu'>              
         <CrudeEdmodel/>    
         </td>
         </tr>
      
         <tr>
         <td> 3 </td>
         <td> Mr.	 </td>
         <td> James </td>
         <td> Bond </td>
         <td> - - </td>
         <td> james@outlook.com	 </td>
         <td> +91 9189342310	 </td>
         <td> - - </td>
         <td> Dallas, USA </td>
         <td> Admin </td>
         <td> - - </td>
         <td> - - </td>
         <td> 04/05/2014	 </td>
         <td> Active </td>   
         <td className='btnDropMenu'>              
         <CrudeEdmodel/>    
         </td>
         </tr>
        
         <tr>
         <td> 4 </td>
         <td> Mr.	 </td>
         <td> James </td>
         <td> Bond </td>
         <td> - - </td>
         <td> james@outlook.com	 </td>
         <td> +91 9189342310	 </td>
         <td> - - </td>
         <td> Dallas, USA </td>
         <td> Admin </td>
         <td> - - </td>
         <td> - - </td>
         <td> 04/05/2014	 </td>
         <td> Active </td>   
         <td className='btnDropMenu'>              
         <CrudeEdmodel/>    
         </td>
         </tr>
     
         <tr>
         <td> 5 </td>
         <td> Mr.	 </td>
         <td> James </td>
         <td> Bond </td>
         <td> - - </td>
         <td> james@outlook.com	 </td>
         <td> +91 9189342310	 </td>
         <td> - - </td>
         <td> Dallas, USA </td>
         <td> Admin </td>
         <td> - - </td>
         <td> - - </td>
         <td> 04/05/2014	 </td>
         <td> Active </td>   
         <td className='btnDropMenu'>              
         <CrudeEdmodel/>    
         </td>
         </tr>

         <tr>
         <td> 6 </td>
         <td> Mr.	 </td>
         <td> James </td>
         <td> Bond </td>
         <td> - - </td>
         <td> james@outlook.com	 </td>
         <td> +91 9189342310	 </td>
         <td> - - </td>
         <td> Dallas, USA </td>
         <td> Admin </td>
         <td> - - </td>
         <td> - - </td>
         <td> 04/05/2014	 </td>
         <td> Active </td>   
         <td className='btnDropMenu'>              
         <CrudeEdmodel/>    
         </td>
         </tr>


         <tr>
         <td> 7 </td>
         <td> Mr.	 </td>
         <td> James </td>
         <td> Bond </td>
         <td> - - </td>
         <td> james@outlook.com	 </td>
         <td> +91 9189342310	 </td>
         <td> - - </td>
         <td> Dallas, USA </td>
         <td> Admin </td>
         <td> - - </td>
         <td> - - </td>
         <td> 04/05/2014	 </td>
         <td> Active </td>   
         <td className='btnDropMenu'>              
         <CrudeEdmodel/>    
         </td>
         </tr>


         <tr>
         <td> 8 </td>
         <td> Mr.	 </td>
         <td> James </td>
         <td> Bond </td>
         <td> - - </td>
         <td> james@outlook.com	 </td>
         <td> +91 9189342310	 </td>
         <td> - - </td>
         <td> Dallas, USA </td>
         <td> Admin </td>
         <td> - - </td>
         <td> - - </td>
         <td> 04/05/2014	 </td>
         <td> Active </td>   
         <td className='btnDropMenu'>              
         <CrudeEdmodel/>    
         </td>
         </tr>

         <tr>
         <td> 9 </td>
         <td> Mr.	 </td>
         <td> James </td>
         <td> Bond </td>
         <td> - - </td>
         <td> james@outlook.com	 </td>
         <td> +91 9189342310	 </td>
         <td> - - </td>
         <td> Dallas, USA </td>
         <td> Admin </td>
         <td> - - </td>
         <td> - - </td>
         <td> 04/05/2014	 </td>
         <td> Active </td>   
         <td className='btnDropMenu'>              
         <CrudeEdmodel/>    
         </td>
         </tr>


         <tr>
         <td> 10 </td>
         <td> Mr.	 </td>
         <td> James </td>
         <td> Bond </td>
         <td> - - </td>
         <td> james@outlook.com	 </td>
         <td> +91 9189342310	 </td>
         <td> - - </td>
         <td> Dallas, USA </td>
         <td> Admin </td>
         <td> - - </td>
         <td> - - </td>
         <td> 04/05/2014	 </td>
         <td> Active </td>   
         <td className='btnDropMenu'>              
         <CrudeEdmodel/>    
         </td>
         </tr>

     
     
         </tbody>
         </table>
         </div>
         </div>
     
         </div>
     
         <div className="row align-items-center">
     
           <div className="col-lg-8">
           <Paging/>
           </div>
     
           <div className="col-lg-4">
     
           <ViewPerPage/>
     
     </div> 
     
     
     
                 
     
     
         </div>
     
     
     </section>
    </div>
   
       </MainLayout>
   
       </>


  )
}
