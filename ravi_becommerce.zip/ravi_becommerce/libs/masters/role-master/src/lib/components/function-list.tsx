import * as React from 'react';
import { getFunctionList } from '../service/function-list-api';
import { API_ERROR_TOAST_TEXT, recursiveMenuList } from '@mfa-travel-app/shared';
import { RootState, useRoleMasterStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { ControlledCheckbox } from '@mfa-travel-app/ui';
import { toast } from 'react-toastify';

const FunctionList = () => {
    const { functionList, updatedFunctionList } = useSelector((state: RootState) => state.roleMaster);
    const { saveFunctionList, saveUpdatedFunctionList } = useRoleMasterStore();

    React.useEffect(() => {
        if (functionList.length === 0) {
            fetchFunctionList();
        } else {
            saveUpdatedFunctionList(JSON.parse(JSON.stringify(functionList)));
        }
    }, []);

    const fetchFunctionList = async () => {
        try {
            const functionList: any = await getFunctionList();
            let accordionMenu = recursiveMenuList(functionList?.data);

            saveFunctionList(accordionMenu);
            saveUpdatedFunctionList(accordionMenu);
        } catch (error) {
            console.error('An error occurred:', error);
            toast.error(API_ERROR_TOAST_TEXT);
        }
    }

    const handleRoleMasterCheckboxChange = (item: any, accessFor: string) => {
        let functionList = JSON.parse(JSON.stringify(updatedFunctionList));

        functionList?.forEach((listItem: any) => {
            searchFunctionItem(listItem, item, accessFor);
        });

        saveUpdatedFunctionList(functionList);
    }

    const searchFunctionItem = (item: any, itemToSearch: any, accessFor: string) => {
        if (item.id === itemToSearch.id) {
            item[accessFor] = itemToSearch[accessFor] ? !itemToSearch[accessFor] : true;

            if (accessFor === 'allAccess') {
                item.viewAccess = itemToSearch[accessFor] ? !itemToSearch[accessFor] : true;
                item.saveAccess = itemToSearch[accessFor] ? !itemToSearch[accessFor] : true;
                item.updateAccess = itemToSearch[accessFor] ? !itemToSearch[accessFor] : true;
                item.deleteAccess = itemToSearch[accessFor] ? !itemToSearch[accessFor] : true;
                item.exportAccess = itemToSearch[accessFor] ? !itemToSearch[accessFor] : true;
            }
        } else {
            item?.childItems?.forEach((child: any) => {
                searchFunctionItem(child, itemToSearch, accessFor);
            });
        }
    }

    const getAccordionBody = (item: any, index: any, parent: boolean) => {
        return (
            <div id={`${item.name.split(' ').join('')}collapse${index}`} className="accordion-collapse collapse" aria-labelledby={`${item.name.split(' ').join('')}heading${index}`}
                data-bs-parent={parent ? '#roleMasterAccordion' : `#${item.name.split(' ').join('')}Accordion`}>

                <div className="accordion-body">
                    <div className='role_Master_acdn'>
                        <div className='param_container'>
                            <table className="table branchtbl">
                                {
                                    item.childItems?.map((child: any, index: any) => {
                                        if (child.childItems?.length === 0) {
                                            return (
                                                <React.Fragment key={index}>
                                                    <thead>
                                                        {
                                                            index === 0 ? <>
                                                                <tr>
                                                                    <th scope="col">Program</th>
                                                                    <th scope="col">All Access</th>
                                                                    <th scope="col">View Access</th>
                                                                    <th scope="col">Save Access </th>
                                                                    <th scope="col">Update Access </th>
                                                                    <th scope="col">Delete Access </th>
                                                                    <th scope="col">Export Access </th>
                                                                </tr>
                                                            </> : <></>
                                                        }
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>{child.name}</td>
                                                            <td>
                                                                <ControlledCheckbox
                                                                    isChecked={child.allAccess ? child.allAccess : false}
                                                                    id={`allAccess${child.id}`}
                                                                    canCheckedByOther={true}
                                                                    onChange={() => handleRoleMasterCheckboxChange(child, 'allAccess')}
                                                                />
                                                            </td>
                                                            <td>
                                                                <ControlledCheckbox
                                                                    isChecked={child.viewAccess ? child.viewAccess : false}
                                                                    id={`viewAccess${child.id}`}
                                                                    canCheckedByOther={true}
                                                                    onChange={() => handleRoleMasterCheckboxChange(child, 'viewAccess')}
                                                                />
                                                            </td>
                                                            <td>
                                                                <ControlledCheckbox
                                                                    isChecked={child.saveAccess ? child.saveAccess : false}
                                                                    id={`saveAccess${child.id}`}
                                                                    canCheckedByOther={true}
                                                                    onChange={() => handleRoleMasterCheckboxChange(child, 'saveAccess')}
                                                                />
                                                            </td>
                                                            <td>
                                                                <ControlledCheckbox
                                                                    isChecked={child.updateAccess ? child.updateAccess : false}
                                                                    id={`updateAccess${child.id}`}
                                                                    canCheckedByOther={true}
                                                                    onChange={() => handleRoleMasterCheckboxChange(child, 'updateAccess')}
                                                                />
                                                            </td>
                                                            <td>
                                                                <ControlledCheckbox
                                                                    isChecked={child.deleteAccess ? child.deleteAccess : false}
                                                                    id={`deleteAccess${child.id}`}
                                                                    canCheckedByOther={true}
                                                                    onChange={() => handleRoleMasterCheckboxChange(child, 'deleteAccess')}
                                                                />
                                                            </td>
                                                            <td>
                                                                <ControlledCheckbox
                                                                    isChecked={child.exportAccess ? child.exportAccess : false}
                                                                    id={`exportAccess${child.id}`}
                                                                    canCheckedByOther={true}
                                                                    onChange={() => handleRoleMasterCheckboxChange(child, 'exportAccess')}
                                                                />
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </React.Fragment>
                                            )
                                        } else {
                                            return (
                                                <tbody key={index}>
                                                    <tr>
                                                        <td>
                                                            <div className="accordion accordion_master_product" id={`${child.name.split(' ').join('')}Accordion`}>
                                                                <div className="accordion-item0">
                                                                    <h2 className="accordion-header" id={`${child.name.split(' ').join('')}heading${index}`}>
                                                                        <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                                                            data-bs-target={`#${child.name.split(' ').join('')}collapse${index}`} aria-expanded="false" aria-controls={`${child.name.split(' ').join('')}collapse${index}`}>

                                                                            {child.name}

                                                                        </button>
                                                                    </h2>
                                                                    {getAccordionBody(child, index, false)}
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            )
                                        }
                                    })
                                }
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <>
            <div className='row'>
                <div className='col-12 mb-4'>
                    <div className="accordion accordion_master_product" id="roleMasterAccordion">
                        {
                            updatedFunctionList?.map((item: any, index: any) => {
                                return (
                                    <div className="accordion-item" key={index}>
                                        <h2 className="accordion-header" id={`${item.name.split(' ').join('')}heading${index}`}>
                                            <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                                data-bs-target={`#${item.name.split(' ').join('')}collapse${index}`} aria-expanded="false" aria-controls={`${item.name.split(' ').join('')}collapse${index}`}>
                                                {item.name}

                                            </button>
                                        </h2>
                                        {getAccordionBody(item, index, true)}
                                    </div>
                                )
                            })
                        }
                    </div>
                </div>
            </div>
        </>
    );
}

export default FunctionList;