import { Link } from "react-router-dom";

import { ControlledInput, ControlledSelect } from "@mfa-travel-app/ui";

export default function FilterCom() {

  const selectOptions = [
    { id: 1, text: 'First Option' },
    { id: 2, text: 'Second Option' },
];

  return (
    
<>
<div className="dropdown show">                
          <Link to="" className="dropdown-toggle" 
          role="button" id="dropfilter" data-bs-toggle='dropdown' data-bs-auto-close="outside" 
          aria-haspopup="true" aria-expanded="false">  <i className="fa-solid fa-filter"></i> Filter
          </Link>
  
          <div style={{width:'250px'}} className="dropdown-menu">
           <div className="p-2">
            <div className="row">
  
              <div className="col-12 mb-2">
                <label className="form-label">Select Column Name<sup className="text-danger">*</sup></label>
              
                <ControlledSelect
                        id={'username'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />


     


              </div>
  
              <div className="col-12 mb-2">
                <label  className="form-label">Select Operator Below<sup className="text-danger">*</sup></label>
               
                <ControlledSelect
                        id={'operator'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />

              </div>
  
              <div className="col-12 mb-2">
              <ControlledInput
                        id={'entervaluetxt'}
                        value={'Enter Value'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
              </div>
              <div className="col-12 mt-2">
                <button type="button" className="btn btn-primary">Apply</button>
                <button type="button" className="btn btn-secondary">Cancel</button>
  
              </div>
               
            </div>
          </div>
          </div>
      </div>

</>


  )
}
