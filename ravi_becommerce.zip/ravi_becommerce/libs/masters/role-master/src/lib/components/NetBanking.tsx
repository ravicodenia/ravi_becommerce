

export default function NetBanking() {
  return (
    
    <>


<div id="transfer_ref" className="col-lg-4">

<div className="row align-items-center mb-3">
  <label className="col-sm-5">Transfer Reference :</label>
  <div className="col-sm-7">
   <input className="form-control" type="text" />
  </div>

</div>

</div> 

<div id="transfer_ref_bank_name" className="col-lg-4">

<div className="row align-items-center mb-3">
  <label className="col-sm-5">Bank Name  :</label>
  <div className="col-sm-7">
   <input className="form-control" type="text" />
  </div>

</div>

</div> 

<div id="transfer_ref_account_no"  className="col-lg-4">

<div className="row align-items-center mb-3">
  <label className="col-sm-5">Account No :</label>
  <div className="col-sm-7">
   <input className="form-control" type="text" />
  </div>

</div>

</div> 



    
    
    </>


  )
}
