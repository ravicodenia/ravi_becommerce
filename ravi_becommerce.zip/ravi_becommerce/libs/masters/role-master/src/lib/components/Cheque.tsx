
export default function Cheque() {
  return (
    
    
<>


<div id="cheque_date" className="col-lg-4">
    
    <div className="row align-items-center mb-3">
      <label className="col-sm-5">Cheque Date :</label>
      <div className="col-sm-7">
      <input className="form-control" value="07/-9/2024" type="text" />
      </div>

    </div>

  </div>  


  <div id="cheque_number"  className="col-lg-4">

    <div className="row align-items-center mb-3">
      <label className="col-sm-5">Cheque Number  :</label>
      <div className="col-sm-7">
      <input className="form-control" type="text" />

     
      </div>

    </div>

  </div> 



  <div id="bank_name" className="col-lg-4">
    <div className="row align-items-center mb-3">
    <label className="col-sm-5">Bank Name :</label>
    <div className="col-sm-7">
    <input className="form-control" type="text" />
    </div>

    </div>
</div> 

  <div id="branch" className="col-lg-4">
    <div className="row align-items-center mb-3">
    <label className="col-sm-5">Branch  :</label>
    <div className="col-sm-7">
    <input className="form-control" type="text" />
    </div>

    </div>
</div> 


</>



  )
}
