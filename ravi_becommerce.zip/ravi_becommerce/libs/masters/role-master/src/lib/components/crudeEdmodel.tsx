
import  { useState } from "react";
import Dropdown from 'react-bootstrap/Dropdown';
import { Modal } from 'react-bootstrap';
import { Link   } from "react-router-dom";

export default function crudeEdmodel() {
  
  const [branchDeleteModal, setBranchDeleteModal] = useState(false);


  return (
    
<>
<Dropdown>
      <Dropdown.Toggle id="dropdown-basic" className="more_icon rounded-circle">
      <i className="fa-solid fa-ellipsis-vertical"></i>       
      </Dropdown.Toggle>

      <Dropdown.Menu>
      <Link className="dropdown-item" to=""><i className="fa-regular fa-pen-to-square"></i> Edit</Link>
      <Link  className="dropdown-item" to=""> <i className="fa-solid fa-eye"></i> View</Link>
        <button className="dropdown-item" onClick={() => setBranchDeleteModal(true)} ><i className="fa-regular fa-trash-can"></i> Delete </button>
      </Dropdown.Menu>
    </Dropdown>
      
           
       
    <Modal
        size="sm"
        centered
        show={branchDeleteModal}
        onHide={() => setBranchDeleteModal(false)}
      >
    
        
<div className="text-center p-2"> 

    <div className="row">

<div className="col-12 mt-3">
  <svg className="animate__animated animate__shakeY bi bi-exclamation-circle" xmlns="http://www.w3.org/2000/svg" width="70" height="70" fill="#f2aa3b" fill-opacity="0.5" 
viewBox="0 0 16 16">
    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
    <path d="M7.002 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0M7.1 4.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0z"/>
  </svg>
</div>
<div className="col-12 mt-3">
         
<h2>Are you sure?</h2>
<p className="mt-2">You won't be able to revert this!</p>
</div>

<div className="col-12 mt-3 mb-2">
  <button type="button" className="btn btn-danger text-light me-2">Yes, delete it!</button>
  <button  onClick={() => setBranchDeleteModal(false)} type="button" className="btn btn-secondary">Cancel</button>
</div>
  </div>

  </div>
</Modal>
       


        

</>


  )
}
