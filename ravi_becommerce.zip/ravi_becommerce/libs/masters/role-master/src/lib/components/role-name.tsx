import * as React from 'react';
import { RootState, useRoleMasterStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { createRoleMaster } from '../service/role-master-api';
import { toast } from 'react-toastify';
import { API_ERROR_TOAST_TEXT, NO_ROLE_SELECTED_ALERT } from '@mfa-travel-app/shared';
import { ControlledInput, Loader } from '@mfa-travel-app/ui';

const RoleName = () => {
    const [loader, setLoader] = React.useState(false);
    const { functionList, updatedFunctionList } = useSelector((state: RootState) => state.roleMaster);
    
    const { saveUpdatedFunctionList } = useRoleMasterStore();
    const [nameState, setNameState] = React.useState({
        roleName: '',
        remarks: ''
    });

    const handleRoleNameChange = (value: any) => {
        setNameState({ ...nameState, roleName: value });
    }

    const handleRemarksChange = (value: any) => {
        setNameState({ ...nameState, remarks: value });
    }

    const handleSaveRoleMaster = async (e: any) => {
        e.preventDefault();

        let itemsWithAccess = updatedFunctionList?.map((item: any) => {
            return searchItemsWithAccess(item);
        });

        if (itemsWithAccess?.flat()?.length === 0) {
            toast.warning(NO_ROLE_SELECTED_ALERT);
            return;
        }

        try {
            setLoader(true);
            const response: any = await createRoleMaster(nameState.roleName, nameState.remarks, itemsWithAccess?.flat());

            if (response?.data?.statusCode === 200) {
                setNameState({ ...nameState, roleName: '', remarks: '' });
                saveUpdatedFunctionList(functionList);
                setLoader(false);
                toast.success(response?.data?.message);
            } else {
                setLoader(false);
                toast.error(response?.data?.message);
            }
        } catch (error) {
            setLoader(false);
            console.error('An error occurred:', error);
            toast.error(API_ERROR_TOAST_TEXT);
        }

    }

    const searchItemsWithAccess = (item: any) => {
        if (item.childItems?.length === 0 && (item.allAccess === true || item.viewAccess === true ||
            item.saveAccess === true || item.updateAccess === true || item.deleteAccess === true)
        ) {
            if (item.allAccess) {
                return {
                    functionId: item.id,
                    viewAccess: true,
                    saveAccess: true,
                    updateAccess: true,
                    deleteAccess: true
                }
            } else {
                return {
                    functionId: item.id,
                    viewAccess: item.viewAccess ? item.viewAccess : undefined,
                    saveAccess: item.saveAccess ? item.saveAccess : undefined,
                    updateAccess: item.updateAccess ? item.updateAccess : undefined,
                    deleteAccess: item.deleteAccess ? item.deleteAccess : undefined
                }
            }
        } else {
            let innerChild = item?.childItems?.map((child: any) => {
                let returnItem = searchItemsWithAccess(child);

                if (returnItem.length !== 0) {
                    return returnItem;
                }

                return undefined;
            }).filter(Boolean).flat();

            if (innerChild.length !== 0) {
                let receivedAccessItems = JSON.parse(JSON.stringify(innerChild));

                receivedAccessItems?.forEach((accessItem: any) => {
                    accessItem.functionId = item.id;
                });

                innerChild = innerChild.concat(receivedAccessItems);
                return [...new Set(innerChild.map(JSON.stringify))].map((m: any) => JSON.parse(m));
            }

            return innerChild;
        }
    }

    return (
        <form onSubmit={handleSaveRoleMaster}>

            <div className="row align-items-center mt-3">
                <div className="col-lg-4">
                    <div className="input-group">
                        <label htmlFor="role-master-name" className="me-2">Role Name <span className="text-danger">*</span> :</label>
                        <ControlledInput
                            id={'role-master-name'}
                            value={nameState.roleName}
                            type={'text'}
                            required={true}
                            onChange={(e: any) => handleRoleNameChange(e.target.value)}
                        />
                    </div>
                </div>

                <div className="col-lg-4">
                    <div className="input-group">
                        <label htmlFor="role-master-remarks" className="me-2">Remarks: </label>
                        <ControlledInput
                            id={'role-master-remarks'}
                            value={nameState.remarks}
                            type={'text'}
                            onChange={(e: any) => handleRemarksChange(e.target.value)}
                        />
                    </div>
                </div>

                <div className="col-lg-4 text-end">
                    <button type="submit" className="btn btn-primary rounded"> SAVE </button>
                </div>
            </div>

            {loader && <Loader />}
        </form>
    );
}

export default RoleName;