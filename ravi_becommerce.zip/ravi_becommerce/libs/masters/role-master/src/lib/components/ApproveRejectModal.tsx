
import { Modal, ModalBody } from 'react-bootstrap';
import { useState } from 'react';

export default function ApproveRejectModal() {

    const [approveRejectModal, setApproveRejectModal] = useState(false);
    const [showButtons, setShowButtons] = useState(true);
    const [textArea, setTextArea] = useState(false);


    const showCommentSection = () => {
        setTextArea(true)
        setShowButtons(false)
    }
 
    return (
    
    
<>



<button
          onClick={() => setApproveRejectModal(true)}
          className="btn text-secondary"
        >
       <i className="fa-solid fa-eye"></i>
        </button>


<Modal
        size="sm"
        centered
        show={approveRejectModal}
        onHide={() => setApproveRejectModal(false)}
      >
        <Modal.Header closeButton>
          <Modal.Title>Action </Modal.Title>
        </Modal.Header>


        <ModalBody>
       
        <div className="row"> 

            {showButtons && 
          <div className="col-12">

            <button onClick={showCommentSection} type="button" className="btn btn-danger me-2"> 
              <i className="fa-solid fa-xmark"></i> Reject
            </button>

            <button type="button" className="btn btn-success text-light me-2"> 
              <i className="fa-solid fa-check"></i> Approve
            </button>

          </div>
        }


        {textArea && 
          <div className="col-12">
            <div className="form-floating">
              <textarea className="form-control" placeholder="Leave a comment here"></textarea>
              <label htmlFor="floatingTextarea">Comments</label>
            </div>

            <div className="mt-3 mb-2 text-end">       
              <button type="button"  onClick={() => setApproveRejectModal(false)}
              className="btn btn-primary rounded" > Submit </button> </div>

          </div>
         }

        </div>

        </ModalBody>
     
     
      </Modal>


</>



  )
}
