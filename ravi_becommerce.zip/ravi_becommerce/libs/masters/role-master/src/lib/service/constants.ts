// FUNCTION_LIST APIs
export const GET_FUNCTION_LIST = 'common/Function/GetFunctionList';

// ROLE_MASTER APIs
export const CREATE_ROLE_MASTER = 'common/Role/Create';