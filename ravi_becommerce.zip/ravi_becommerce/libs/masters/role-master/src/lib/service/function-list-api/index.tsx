import { getGatewayAPI } from "@mfa-travel-app/services";
import { GET_FUNCTION_LIST } from "../constants";

export const getFunctionList = async () => {
    try {
        const response = await getGatewayAPI(GET_FUNCTION_LIST);
        return response;
    } catch (error) {
        return error;
    }
}