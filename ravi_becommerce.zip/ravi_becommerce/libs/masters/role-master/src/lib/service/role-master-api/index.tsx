import { postGatewayAPI } from "@mfa-travel-app/services";
import { CREATE_ROLE_MASTER } from "../constants";

export const createRoleMaster = async (roleName: string, remarks: string, roleDetails: any) => {
    try {
        const response = await postGatewayAPI(CREATE_ROLE_MASTER, {
            name: roleName,
            remarks: remarks,
            roleDetails: roleDetails
        });
        return response;
    } catch (error) {
        return error;
    }
}