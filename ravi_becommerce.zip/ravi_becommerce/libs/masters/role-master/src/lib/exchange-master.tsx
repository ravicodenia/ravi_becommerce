import { MainLayout } from '@mfa-travel-app/layout';

import { ControlledInput, ControlledSelect, ControlledDatePicker, ControlledInputDisabled  } from "@mfa-travel-app/ui";

export default function ExchangeMaster() {


  const selectOptions = [
    { id: 1, text: 'First Option' },
    { id: 2, text: 'Second Option' },
];


  return (
    
    
    <>
 <MainLayout>

 <div className="container">
     
   
        <div className="row align-items-center mt-4 form_with_select2 font_size_90">

                    <div className="col-lg-3">

                      <div className="row align-items-center mb-3">
                        <label className="col-sm-6 text-lg-end">Base Currency:</label>
                        <div className="col-sm-6">
                        
                        <ControlledSelect
                        id={'basecurrency'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />


                        </div>
                      </div>
  
                    </div>         

                    <div className="col-lg-3">

                      <div className="row align-items-center mb-3">
                        <label className="col-sm-6 text-lg-end">Agent:</label>
                        <div className="col-sm-6">
                          
                        <ControlledSelect
                        id={'agent'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />



                        </div>
                      </div>
  
                    </div>
    
                    <div className="col-lg-3">

                      <div className="row align-items-center mb-3">
                        <label className="col-sm-6 text-lg-end">Product:</label>
                        <div className="col-sm-6">
                       
                        <ControlledSelect
                        id={'product'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />


                        </div>
                      </div>
  
                    </div>

  
                    <div className="col-lg-3 text-end">
                      <div className="mb-3"> 
                        <button type="button" className="btn btn-sm btn-primary rounded">SUBMIT</button>
                      </div>

                    </div>                    
                    
        </div>
        



        <div className="row">

          <div className="col-12 mt-2 mb-5">
            <div className="table-responsive">
               								

              <table className="table table-striped table-bordered font_size_90">
                <thead>
                  <tr className="align-middle">
                    <th scope="col">Conversion</th>
                    <th scope="col">To Currency</th>
                    <th scope="col">To Currency Name</th>
                    <th scope="col">Base Currency</th>
                    <th scope="col">Selling Conversion Rate</th>
                    <th scope="col">Buffer Type</th>
                    <th scope="col">Buffer Value</th>
                    <th scope="col">Applied Conversion Rate</th>
                    <th scope="col">Valid from</th>
                  </tr>
                </thead>
                <tbody>

                  <tr className="align-middle">
                    <td>
                    <ControlledInputDisabled
                        id={'conversion'}
                        value={'AED->AED'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

                    </td>
                    <td>         <ControlledInputDisabled
                        id={'tocurrency'}
                        value={'GBP'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    /></td>
                    <td>
                    <ControlledInputDisabled
                        id={'tocurrencyname'}
                        value={'UAE Dirham'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

                    </td>
                    <td> 
                    <ControlledInputDisabled
                        id={'basecurrency'}
                        value={'AED'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      
                      </td>
                    <td className="text-end"> 
                      
                    <ControlledInput
                        id={'sellingconversionrate'}
                        value={'5.79'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      </td>
                    <td className="text-start">

                    <ControlledSelect
                        id={'buffertype'}
                        value={'%'}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />

                  </td>
                    <td>

                        <ControlledInput
                        id={'buffervalue'}
                        value={'1.01'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      </td>
                    <td>
                      
                    <ControlledInput
                        id={'applied-conversation-rate'}
                        value={'5.8479'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      
                      </td>
                    <td> 
                    <ControlledDatePicker
                        id={'fromDate'}
                        value={''}
                        format={'dd/MMM/yyyy'}
                        required={true}
                        onChange={''}
                    />
                    
                    
                    </td>
                  </tr>
                  <tr className="align-middle">
                    <td>
                    <ControlledInputDisabled
                        id={'conversion'}
                        value={'AED->AED'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

                    </td>
                    <td>         <ControlledInputDisabled
                        id={'tocurrency'}
                        value={'GBP'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    /></td>
                    <td>
                    <ControlledInputDisabled
                        id={'tocurrencyname'}
                        value={'UAE Dirham'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

                    </td>
                    <td> 
                    <ControlledInputDisabled
                        id={'basecurrency'}
                        value={'AED'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      
                      </td>
                    <td className="text-end"> 
                      
                    <ControlledInput
                        id={'sellingconversionrate'}
                        value={'5.79'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      </td>
                    <td className="text-start">

                    <ControlledSelect
                        id={'buffertype'}
                        value={'%'}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />

                  </td>
                    <td>

                        <ControlledInput
                        id={'buffervalue'}
                        value={'1.01'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      </td>
                    <td>
                      
                    <ControlledInput
                        id={'applied-conversation-rate'}
                        value={'5.8479'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      
                      </td>
                    <td> 
                    <ControlledDatePicker
                        id={'fromDate'}
                        value={''}
                        format={'dd/MMM/yyyy'}
                        required={true}
                        onChange={''}
                    />
                    
                    
                    </td>
                  </tr>


                  <tr className="align-middle">
                    <td>
                    <ControlledInputDisabled
                        id={'conversion'}
                        value={'AED->AED'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

                    </td>
                    <td>         <ControlledInputDisabled
                        id={'tocurrency'}
                        value={'GBP'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    /></td>
                    <td>
                    <ControlledInputDisabled
                        id={'tocurrencyname'}
                        value={'UAE Dirham'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

                    </td>
                    <td> 
                    <ControlledInputDisabled
                        id={'basecurrency'}
                        value={'AED'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      
                      </td>
                    <td className="text-end"> 
                      
                    <ControlledInput
                        id={'sellingconversionrate'}
                        value={'5.79'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      </td>
                    <td className="text-start">

                    <ControlledSelect
                        id={'buffertype'}
                        value={'%'}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />

                  </td>
                    <td>

                        <ControlledInput
                        id={'buffervalue'}
                        value={'1.01'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      </td>
                    <td>
                      
                    <ControlledInput
                        id={'applied-conversation-rate'}
                        value={'5.8479'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      
                      </td>
                    <td> 
                    <ControlledDatePicker
                        id={'fromDate'}
                        value={''}
                        format={'dd/MMM/yyyy'}
                        required={true}
                        onChange={''}
                    />
                    
                    
                    </td>
                  </tr>

                  <tr className="align-middle">
                    <td>
                    <ControlledInputDisabled
                        id={'conversion'}
                        value={'AED->AED'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

                    </td>
                    <td>         <ControlledInputDisabled
                        id={'tocurrency'}
                        value={'GBP'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    /></td>
                    <td>
                    <ControlledInputDisabled
                        id={'tocurrencyname'}
                        value={'UAE Dirham'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

                    </td>
                    <td> 
                    <ControlledInputDisabled
                        id={'basecurrency'}
                        value={'AED'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      
                      </td>
                    <td className="text-end"> 
                      
                    <ControlledInput
                        id={'sellingconversionrate'}
                        value={'5.79'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      </td>
                    <td className="text-start">

                    <ControlledSelect
                        id={'buffertype'}
                        value={'%'}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />

                  </td>
                    <td>

                        <ControlledInput
                        id={'buffervalue'}
                        value={'1.01'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      </td>
                    <td>
                      
                    <ControlledInput
                        id={'applied-conversation-rate'}
                        value={'5.8479'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      
                      </td>
                    <td> 
                    <ControlledDatePicker
                        id={'fromDate'}
                        value={''}
                        format={'dd/MMM/yyyy'}
                        required={true}
                        onChange={''}
                    />
                    
                    
                    </td>
                  </tr>

                  <tr className="align-middle">
                    <td>
                    <ControlledInputDisabled
                        id={'conversion'}
                        value={'AED->AED'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

                    </td>
                    <td>         <ControlledInputDisabled
                        id={'tocurrency'}
                        value={'GBP'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    /></td>
                    <td>
                    <ControlledInputDisabled
                        id={'tocurrencyname'}
                        value={'UAE Dirham'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

                    </td>
                    <td> 
                    <ControlledInputDisabled
                        id={'basecurrency'}
                        value={'AED'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      
                      </td>
                    <td className="text-end"> 
                      
                    <ControlledInput
                        id={'sellingconversionrate'}
                        value={'5.79'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      </td>
                    <td className="text-start">

                    <ControlledSelect
                        id={'buffertype'}
                        value={'%'}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />

                  </td>
                    <td>

                        <ControlledInput
                        id={'buffervalue'}
                        value={'1.01'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      </td>
                    <td>
                      
                    <ControlledInput
                        id={'applied-conversation-rate'}
                        value={'5.8479'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      
                      </td>
                    <td> 
                    <ControlledDatePicker
                        id={'fromDate'}
                        value={''}
                        format={'dd/MMM/yyyy'}
                        required={true}
                        onChange={''}
                    />
                    
                    
                    </td>
                  </tr>

                  <tr className="align-middle">
                    <td>
                    <ControlledInputDisabled
                        id={'conversion'}
                        value={'AED->AED'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

                    </td>
                    <td>         <ControlledInputDisabled
                        id={'tocurrency'}
                        value={'GBP'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    /></td>
                    <td>
                    <ControlledInputDisabled
                        id={'tocurrencyname'}
                        value={'UAE Dirham'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

                    </td>
                    <td> 
                    <ControlledInputDisabled
                        id={'basecurrency'}
                        value={'AED'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      
                      </td>
                    <td className="text-end"> 
                      
                    <ControlledInput
                        id={'sellingconversionrate'}
                        value={'5.79'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      </td>
                    <td className="text-start">

                    <ControlledSelect
                        id={'buffertype'}
                        value={'%'}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />

                  </td>
                    <td>

                        <ControlledInput
                        id={'buffervalue'}
                        value={'1.01'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      </td>
                    <td>
                      
                    <ControlledInput
                        id={'applied-conversation-rate'}
                        value={'5.8479'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      
                      </td>
                    <td> 
                    <ControlledDatePicker
                        id={'fromDate'}
                        value={''}
                        format={'dd/MMM/yyyy'}
                        required={true}
                        onChange={''}
                    />
                    
                    
                    </td>
                  </tr>

                  <tr className="align-middle">
                    <td>
                    <ControlledInputDisabled
                        id={'conversion'}
                        value={'AED->AED'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

                    </td>
                    <td>         <ControlledInputDisabled
                        id={'tocurrency'}
                        value={'GBP'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    /></td>
                    <td>
                    <ControlledInputDisabled
                        id={'tocurrencyname'}
                        value={'UAE Dirham'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

                    </td>
                    <td> 
                    <ControlledInputDisabled
                        id={'basecurrency'}
                        value={'AED'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      
                      </td>
                    <td className="text-end"> 
                      
                    <ControlledInput
                        id={'sellingconversionrate'}
                        value={'5.79'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      </td>
                    <td className="text-start">

                    <ControlledSelect
                        id={'buffertype'}
                        value={'%'}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />

                  </td>
                    <td>

                        <ControlledInput
                        id={'buffervalue'}
                        value={'1.01'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      </td>
                    <td>
                      
                    <ControlledInput
                        id={'applied-conversation-rate'}
                        value={'5.8479'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      
                      </td>
                    <td> 
                    <ControlledDatePicker
                        id={'fromDate'}
                        value={''}
                        format={'dd/MMM/yyyy'}
                        required={true}
                        onChange={''}
                    />
                    
                    
                    </td>
                  </tr>

                  <tr className="align-middle">
                    <td>
                    <ControlledInputDisabled
                        id={'conversion'}
                        value={'AED->AED'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

                    </td>
                    <td>         <ControlledInputDisabled
                        id={'tocurrency'}
                        value={'GBP'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    /></td>
                    <td>
                    <ControlledInputDisabled
                        id={'tocurrencyname'}
                        value={'UAE Dirham'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

                    </td>
                    <td> 
                    <ControlledInputDisabled
                        id={'basecurrency'}
                        value={'AED'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      
                      </td>
                    <td className="text-end"> 
                      
                    <ControlledInput
                        id={'sellingconversionrate'}
                        value={'5.79'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      </td>
                    <td className="text-start">

                    <ControlledSelect
                        id={'buffertype'}
                        value={'%'}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />

                  </td>
                    <td>

                        <ControlledInput
                        id={'buffervalue'}
                        value={'1.01'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      </td>
                    <td>
                      
                    <ControlledInput
                        id={'applied-conversation-rate'}
                        value={'5.8479'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      
                      
                      </td>
                    <td> 
                    <ControlledDatePicker
                        id={'fromDate'}
                        value={''}
                        format={'dd/MMM/yyyy'}
                        required={true}
                        onChange={''}
                    />
                    
                    
                    </td>
                  </tr>

       

                  




                </tbody>
              </table>


            </div>




          </div>



        </div>
    
    

    </div>

</MainLayout>

</>



  )
}
