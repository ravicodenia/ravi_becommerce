import { MainLayout } from '@mfa-travel-app/layout';

import { ControlledInput, ControlledSelect, ControlledDatePicker, ControlledFileInput } from "@mfa-travel-app/ui";
// import Cheque from './components/Cheque';
// import NetBanking from './components/NetBanking';


export default function collection() {
  // const [addReduceBalance, setAdReduceBalance] = useState(null);

  const selectOptions = [
    { id: 1, text: 'First Option' },
    { id: 2, text: 'Second Option' },
];

  return (
    
    <>
 <MainLayout>


 <div className="mdlContainer"> 
    <div className="container mb-5">
        <section className="user_master_section">
          <div className="innerContainer border-end-0 border-top-0">
        
          <div className="wrapper"> 
    
    
    <div className="row">
        <div className="col-12"> <h5>Add or Reduce Balance </h5> </div>

        <div className="col-12">
            <div className="form_heading">
            <span className=" title">Firm Add / Reduce Balance</span>
            </div>
            
          </div>

      </div>

   
        
        <div className="row align-items-center">     
              

              <div className="col-lg-4">
                


                <div className="row align-items-center mb-3">
                  <label className="col-sm-5"> Firm :</label>
                  <div className="col-sm-7">

                  <ControlledSelect
                        id={'firm'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />


                  </div>
      
                </div>

            
                </div>
            
                <div className="col-lg-4">


                  <div className="row align-items-center mb-3">
                    <label className="col-sm-5"> Branch :</label>
                    <div className="col-sm-7">

                    <ControlledSelect
                        id={'branchselect'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />


                    </div>
        
                  </div>

              
                  </div>

                  <div className="col-lg-4">


                    <div className="row align-items-center mb-3">
                      <label className="col-sm-5">Transaction Type :</label>
                      <div className="col-sm-7">
                       
                      <ControlledSelect
                        id={'transtype'}
                        value={''}
                        options={selectOptions} 
                        required={true}
                        onChange={''}
                    />



                      </div>
          
                    </div>

                
                    </div>


                <div className="col-lg-4">

                  <div className="row align-items-center mb-3">
                    <label className="col-sm-5">Date: <span className="text-danger">*</span> :</label>
                    <div className="col-sm-7">
              
                     <ControlledDatePicker
                        id={'date-incorp'}
                        value={''}
                        format={'dd/MMM/yyyy'}
                        required={true}
                        onChange={''}
                    />
                     
                    </div>
        
                  </div>

                </div>   

            
                <div className="col-lg-4">

                  <div className="row align-items-center mb-3">
                    <label className="col-sm-5">Details:</label>
                    <div className="col-sm-7">

                    <ControlledInput
                        id={'deatils'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />


 

                  
                    </div>
        
                  </div>

                </div>   


                <div className="col-lg-4">

                  <div className="row align-items-center mb-3">
                    <label className="col-sm-5">Payment Mode :</label>
                    <div className="col-sm-7">
                     
      

                       <ControlledSelect
                        id={'firm'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />





                    </div>
        
                  </div>

              
                  </div>
     

                  <div className="col-lg-4">

                    <div className="row align-items-center mb-3">
                      <label className="col-sm-5">Currency :</label>
                      <div className="col-sm-7">



                      <ControlledInput
                        id={'currency'}
                        value={'USD'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

                        
           
                      </div>
          
                    </div>

                  </div>  


                  <div className="col-lg-4">

                    <div className="row align-items-center mb-3">
                      <label className="col-sm-5">Amount :</label>
                      <div className="col-sm-7">


                 

                       <ControlledInput
                        id={'currency'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />


                      </div>
          
                    </div>

                  </div>  

                  <div id="divaorb_cheque_date" className="col-lg-4">

                    <div className="row align-items-center mb-3">
                      <label className="col-sm-5">Cheque Date :</label>
                      <div className="col-sm-7">
                       
        


                        <ControlledDatePicker
                        id={'date-incorp'}
                        value={''}
                        format={'dd/MMM/yyyy'}
                        required={true}
                        onChange={''}
                    />

                      </div>
          
                    </div>

                  </div>  


                  <div id="divaorb_cheque_number" className="col-lg-4">

                    <div className="row align-items-center mb-3">
                      <label className="col-sm-5">Cheque Number  :</label>
                      <div className="col-sm-7">


                   <ControlledInput
                        id={'chequeno'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

                     
                      </div>
          
                    </div>

                  </div> 

                  <div id="divaorb_transfer_ref" className="col-lg-4">

                    <div className="row align-items-center mb-3">
                      <label className="col-sm-5">Transfer Reference :</label>
                      <div className="col-sm-7">

              

                      <ControlledInput
                        id={'tref'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

                    
                      </div>
          
                    </div>

                  </div> 

                  <div id="divaorb_bank_name"  className="col-lg-4">

                    <div className="row align-items-center mb-3">
                      <label className="col-sm-5">Bank Name  :</label>
                      <div className="col-sm-7">


                      <ControlledInput
                        id={'bankname'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />


                      </div>
          
                    </div>

                  </div> 

                  <div id="divaorb_account_no" className="col-lg-4">

                    <div className="row align-items-center mb-3">
                      <label className="col-sm-5">Account No :</label>
                      <div className="col-sm-7">


                      <ControlledInput
                        id={'accountno'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />


                      </div>
          
                    </div>

                  </div> 

                  <div id="divaorb_branch" className="col-lg-4">

                    <div className="row align-items-center mb-3">
                      <label className="col-sm-5">Branch  :</label>
                      <div className="col-sm-7">

                      <ControlledInput
                        id={'branch'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />


                      </div>
          
                    </div>

                  </div> 

                  <div className="col-lg-4">

                    <div className="row align-items-center mb-3">
                      <label className="col-sm-5">Remarks :</label>
                      <div className="col-sm-7">
                      <ControlledInput
                        id={'remarks'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />


                      </div>
          
                    </div>

                  </div>  


      
        </div>
        


        <div className="row">


          <div className="col-lg-7">
                    
            <div className="input-group mb-3 align-items-center">
              <label className="col-sm-3">Upload Payment reference slip  : </label> 
              <div className="col-lg-7">
       

              <ControlledFileInput
                        id={'remarks'}
                        value={''}
                        type={'file'}
                        accept={true}
                        multiple={''}
                    />


              </div>
            </div>
          



          </div>  


          <div className="col-lg-5 text-end">
            <button type="button" className="btn btn-primary">SUBMIT</button>
            </div>

        </div>


      


        </div>
    
            </div>
    
    </section>
    </div>
  </div>

    </MainLayout>

    </>

  )
}
