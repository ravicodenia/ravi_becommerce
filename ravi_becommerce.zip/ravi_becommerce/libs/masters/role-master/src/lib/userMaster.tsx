
import { MainLayout } from '@mfa-travel-app/layout';
import { ControlledInput, ControlledSelect  } from "@mfa-travel-app/ui";
import  { useState } from "react";

export default function UserMaster() {

  const [twoFA, setTwoFa] = useState(false);

  const handleChangeToogle = () => {
    setTwoFa(!twoFA);
}

  const selectOptions = [
    { id: 1, text: 'First Option' },
    { id: 2, text: 'Second Option' },
];

  return (
    
    <>
 <MainLayout>

 <div className="container mb-5">
    <section className="user_master_section">
      <div className="innerContainer border-end-0 border-top-0 form_with_select2">
    
        <div className="row">


          <div className="col-lg-12"> 


            <div className="wrapper"> 


        <div className="row">
            <div className="col-12"> <h5>User Master </h5> </div>
            </div>



            <div  className="row">
              <div className="col-12">
                <div className="form_heading">
                <span className=" title">User Profile</span>
                </div>
                
              </div>
        
        
              <div className="col-12">
               
              

                <div className="row align-items-center">     
                  

                  <div className="col-lg-4">


                    <div className="row align-items-center mb-2">
                      <label className="col-sm-5"> Title <span className="text-danger">*</span> :</label>
                      <div className="col-sm-7">
                        
                      <ControlledSelect
                        id={'title'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />


                      </div>
          
                    </div>

                
                    </div>
                
                    <div className="col-lg-4">

                      <div className="row align-items-center mb-2">
                        <label className="col-sm-5">First Name: <span className="text-danger">*</span> :</label>
                        <div className="col-sm-7">

                        <ControlledInput
                        id={'firstname'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />


                        </div>
            
                      </div>

                    </div>   
  
                
                    <div className="col-lg-4">

                      <div className="row align-items-center mb-2">
                        <label className="col-sm-5">Last Name <span className="text-danger">*</span> :</label>
                        <div className="col-sm-7">

                        <ControlledInput
                        id={'lastname'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />


                        </div>
                      </div>

                    </div>  

          
                  <div className="col-lg-4">

                    <div className="row align-items-center mb-2">
                      <label className="col-sm-5">Mobile <span className="text-danger">*</span> :</label>
                      <div className="col-sm-7">
                        <div className="itl_phone_input">



                        <ControlledInput
                        id={'mobileno'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />


                      </div>
                      </div>
          
                    </div>

                  </div>

                  <div className="col-lg-4">


                    <div className="row align-items-center mb-2">
                      <label className="col-sm-5"> Email Address <span className="text-danger">*</span> :</label>
                      <div className="col-sm-7">

                      <ControlledInput
                        id={'emailaddress'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />


                      </div>
          
                    </div>
  
          
                  </div>

                  <div className="col-lg-4">
 
                    <div className="row align-items-center mb-2">
                      <label  className="col-sm-5">Work Type <span className="text-danger">*</span> :</label>
                      <div className="col-sm-7">
                        <div className="select2_m_c_wrapper">
  
                        <ControlledSelect
                        id={'worktype'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />
                
                          </div> 
                      </div>
          
                    </div>     
          
          
                  </div>
    
              
                  <div className="col-lg-4">

                    <div className="row align-items-center mb-2">
                      <label  className="col-sm-5">Agent <span className="text-danger">*</span> :</label>
                      <div className="col-sm-7">

                      <ControlledSelect
                        id={'agent'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />


                      </div>
          
                    </div>
          
                  </div>


                  <div className="col-lg-4">

                    <div className="row align-items-center mb-2">
                      <label  className="col-sm-5">Location <span className="text-danger">*</span> :</label>
                      <div className="col-sm-7">

                      <ControlledSelect
                        id={'location'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />


                      </div>
          
                    </div>

                  </div>



                  <div className="col-lg-4">


                    <div className="row align-items-center mb-2">
                      <label className="col-sm-5"> User Address <span className="text-danger">*</span> :</label>
                      <div className="col-sm-7">

                      <ControlledInput
                        id={'useraddress'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

                      </div>
          
                    </div>      

                  </div>

              
                  <div className="col-lg-4">


                    <div className="row align-items-center mb-2">
                      <label  className="col-sm-5">Sales Channel <span className="text-danger">*</span> :</label>
                      <div className="col-sm-7">

                      <ControlledSelect
                        id={'saleschannel'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />


                      </div>
          
                    </div>

          
                  </div>


                  <div className="col-lg-4">


                    <div className="row align-items-center mb-2">
                      <label className="col-sm-5">Primary Agent <span className="text-danger">*</span> :</label>
                      <div className="col-sm-7">

                      <ControlledSelect
                        id={'primaryagent'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />



                        
                      </div>
          
                    </div>


          
          
                  </div>


                  <div className="col-lg-4">


                    <div className="row align-items-center mb-2">
                      <label className="col-sm-5">Integration Code <span className="text-danger">*</span> :</label>
                      <div className="col-sm-7">

                      <ControlledInput
                        id={'integcode'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />


                      </div>
          
                    </div>

          
                  </div>
 
                  <div className="col-lg-4">

                    <div className="row align-items-center mb-2">
                      <label className="col-sm-5">User Name <span className="text-danger">*</span> :</label>
                      <div className="col-sm-7">

                      <ControlledInput
                        id={'usernametxt'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />


                      </div>
          
                    </div>
          
                  </div>


                  <div className="col-lg-4">
                    <div className="row align-items-center mb-2">
                      <label  className="col-sm-5">Password <span className="text-danger">*</span> :</label>
                      <div className="col-sm-7">

                      <ControlledInput
                        id={'passwordtxt'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />


                      </div>
          
                    </div>
          
                  </div>


                  <div className="col-lg-4">


                    <div className="row align-items-center mb-2">
                      <label  className="col-sm-5">Confirm Password <span className="text-danger">*</span></label>
                      <div className="col-sm-7">

                      <ControlledInput
                        id={'passwordtxtconfirm'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

                      </div>
          
                    </div>
          
                  </div>



          
            </div>
            
              <div className="row align-items-center">


                <div className="col-lg-4">
                  <div className="row align-items-center mb-2">
        

                    <label className="col-sm-5 form-check-label" htmlFor="2fatoogle">2FA</label>
                    <div className="col-sm-7">

                      <div className="toogleRadioBtn"> 
  
                        <div className="form-check form-switch">
                          <input className="form-check-input mt-2" 
                          type="checkbox" name="userm-2fatoogle" id="2fatoogle"
                          checked={twoFA} 
                          onChange={handleChangeToogle}
                          
                          />
                        </div>

                      </div>
                    </div>
        
                  </div>


                </div>

                { twoFA && (
                <div id="master_user_2facomm" className="col-lg-4">
                  <div className="row align-items-center mb-2">
                    <label className="col-sm-5">2FA Comm</label>
                    <div className="col-sm-7">

                    <ControlledSelect
                        id={'2facomm'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />



                    </div>
        
                  </div>
                </div>
                )}


              </div>

            
            </div>
        
        
            </div>


            <div className="row">
              <div className="col-12">
                <div className="form_heading">
                <span className=" title">Access Other Locations</span>
                </div>
                
              </div>
        
        
              <div className="col-12">
     

                <div className="row align-items-center">


                  <div className="col-lg-4">

                    <div className="row align-items-center mb-2">
                      <label className="col-sm-5">Loactions <span className="text-danger">*</span> :</label>
                      <div className="col-sm-7">
                        <div className="select2_m_c_wrapper">
  
                        <ControlledSelect
                        id={'locationselect'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />
                
                          </div> 
                      </div>
          
                    </div>

                  </div>
  
  
                </div>



                </div>



            </div>    


            <div  className="row">
              <div className="col-12">
                <div className="form_heading">
                <span className=" title">App Config</span>
                </div>
                
              </div>
        
        
              <div id="appcondivB" className="col-12">


                <div id="appConfigDivrpt" className="row">
        
                  <div className="col-lg-8">
        
                    <div  className="row">
                      <div className="col-lg-6">
        
                        <div className="row mb-2 align-items-center">
                          <label  className="col-sm-5">Config Key:</label>
                          <div className="col-sm-7">

                          <ControlledSelect
                        id={'configkey'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />



                          </div>
              
                        </div>
            
                      </div>
                      
                      <div className="col-lg-6">
            
                        <div className="row mb-2 align-items-center">
                          <label className="col-sm-5">Config Value:</label>
                          <div className="col-sm-7">

                          <ControlledSelect
                        id={'configvalue'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />



                          </div>
              
                        </div>
            
                      </div>
                    </div>
        
        
                    
        
        
                  </div>
        
                  <div className="col-lg-4">
        
                    <div className="row mb-2">
                
                      <div className="col-sm-12">
                        <button id="j_add_config" type="button" className="btn btn-sm btn-success mt-1"><i className="fa-solid fa-plus"></i> Add </button>
                      </div>
          
                    </div>
        
                  </div>
        
                </div>
        
        
        
                </div>



            </div>    



            <div className="row">
              <div className="col-12">
                <div className="form_heading">
                <span className=" title">User Type</span>
                </div>
                
              </div>
        
        
              <div className="col-12">
     

                <div className="col-lg-4">

                  <div className="row align-items-center mb-2">
                    <label className="col-sm-5">User Type:</label>
                    <div className="col-sm-7">
                      <div className="select2_m_c_wrapper">
  
                      <ControlledSelect
                        id={'usertypeselect'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />
              
                        </div> 
                    </div>
        
                  </div>

                </div>



                </div>



            </div>    


            <div className="row">
              <div className="col-12">
                <div className="form_heading">
                <span className=" title">Role</span>
                </div>
                
              </div>
        
      
                <div className="col-12">

                  <div className="row">
                  
                    <div  id="roleAddedDiv" className="col-lg-12 mb-4 mt-2">
                      <h6 className="mb-3">Roles</h6>
                      <div className="user_master_role_links">
                        
                      </div>
            
                    </div>
    
    
                    <div className="col-lg-4">
    
                      <div className="row mb-2 align-items-center">
                        <label className="col-sm-5">Add Role:</label>
                        <div className="col-sm-7 form_with_select2">
                          <select id="selectrol2" className="form-select">
                            <option value="Employee">Employee</option>
                            <option value="Manager">Manager</option>
                            <option value="CEO">CEO</option>
                            <option value="Director">Director</option>
                          </select>
                        </div>
        
                      </div>
                
                
                
                
                    </div>
                
                    <div className="col-lg-4">
                      <button id="j_add_role" type="button" className="btn btn-sm btn-success mt-1"><i className="fa-solid fa-plus"></i> ADD </button>
                    </div>
                    

                    <div className="col-lg-4 text-end">
                  
                      <button type="button" className="btn btn-primary mt-2">SUBMIT</button>
                    </div>
                  </div>

                </div>
    

     


            </div>    



    
            </div>


            </div>



        </div>


        </div>

</section>
</div>




 </MainLayout>

</>
  )
}
