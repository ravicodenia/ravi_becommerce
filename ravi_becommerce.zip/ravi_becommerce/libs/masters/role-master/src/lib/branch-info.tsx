import { MainLayout } from '@mfa-travel-app/layout';
import { ControlledInput, ControlledSelect, MobileNo } from "@mfa-travel-app/ui";

import { useNavigate   } from "react-router-dom";

export default function Branchinfo() {
    const navigate = useNavigate()

    const selectOptions = [
      { id: 1, text: 'First Option' },
      { id: 2, text: 'Second Option' },
  ];

const handelCancel = () => {

    navigate('/branch-master')
}




  return (
    
    <>
 <MainLayout>
   
   
<div className='container mt-4 mb-5'>

<div className="row">

                      

<div className="col-lg-6">

  <div className="row align-items-center mb-2">
    <div className="col-lg-5">Parent Firm <sup className="text-danger">*</sup> </div>
    <div className="col-lg-7">
    
    <ControlledInput
                        id={'parentfirm'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
        
        
        </div>
  </div>

  <div className="row align-items-center mb-2">
    <div className="col-lg-5">Agent <sup className="text-danger">*</sup> </div>
    <div className="col-lg-7">
     

    <ControlledSelect
                        id={'agent'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />


    </div>
  </div>

  <div className="row align-items-center mb-2">
    <div className="col-lg-5">Branch Code <sup className="text-danger">*</sup> </div>
    <div className="col-lg-7">

       <ControlledInput
                        id={'branchinfo'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

        
        
         </div>
  </div>

  <div className="row align-items-center mb-2">
    <div className="col-lg-5">Branch Name <sup className="text-danger">*</sup> </div>
    <div className="col-lg-7">

       <ControlledInput
                        id={'branchname'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

        
        </div>
  </div>

  <div className="row align-items-center mb-2">
    <div className="col-lg-5">Address 1 <sup className="text-danger">*</sup> </div>
    <div className="col-lg-7">
      

    <ControlledInput
                        id={'address'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

        
         </div>
  </div>

  <div className="row align-items-center mb-2">
    <div className="col-lg-5">Address 2  </div>
    <div className="col-lg-7">
    <ControlledInput
                        id={'address2'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

        
         </div>
  </div>

  <div className="row align-items-center mb-2">
    <div className="col-lg-5">Country <sup className="text-danger">*</sup> </div>
   
    <div className="col-lg-7">
     
    <ControlledSelect
                        id={'country'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />



    </div>
  </div>

  <div className="row align-items-center mb-2">
    <div className="col-lg-5">State <sup className="text-danger">*</sup> </div>
    <div className="col-lg-7">
    
    <ControlledSelect
                        id={'state'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />


    </div>
  </div>
  <div className="row align-items-center mb-2">
    <div className="col-lg-5">City <sup className="text-danger">*</sup> </div>
    <div className="col-lg-7">
     
    <ControlledInput
                        id={'city'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

        
         </div>
  </div>




</div>

<div className="col-lg-6">
  <div className="row align-items-center mb-2">
    <div className="col-lg-5">TRN </div>
    <div className="col-lg-7">


       <ControlledInput
                        id={'trntxt'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

        
         </div>
  </div>



  

  <div className="row align-items-center mb-2">
    <div className="col-lg-5">Business Currency <sup className="text-danger">*</sup> </div>
    <div className="col-lg-7">
    <ControlledSelect
                        id={'businesscurrency'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />

    </div>
  </div>

  <div className="row align-items-center mb-2">
    <div className="col-lg-5">Land Phone <sup className="text-danger">*</sup> </div>
    <div className="col-lg-7">


       <ControlledInput
                        id={'landphone'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

        
        </div>
  </div>

  <div className="row align-items-center mb-2">
    <div className="col-lg-5">Mobile <sup className="text-danger">*</sup> </div>
    <div className="col-lg-7">

    <MobileNo id="mobileno" placeholder="" name='mobileNo' />
        
        </div>
  </div>

  <div className="row align-items-center mb-2">
    <div className="col-lg-5">Fax <sup className="text-danger">*</sup> </div>
    <div className="col-lg-7">

        <ControlledInput
                        id={'faxtxt'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
        
         </div>
  </div>

  <div className="row align-items-center mb-2">
    <div className="col-lg-5">Ledger Code <sup className="text-danger">*</sup> </div>
    <div className="col-lg-7">
       

    <ControlledInput
                        id={'ledgercode'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
        
        
        </div>
  </div>

  <div className="row align-items-center mb-2">
    <div className="col-lg-5">Email <sup className="text-danger">*</sup> </div>
    <div className="col-lg-7">
    <ControlledInput
                        id={'emailtxt'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
        
        </div>
  </div>


  <div className="row  mb-2">
    <div className="col-lg-5">Terms & Condition <sup className="text-danger">*</sup> </div>
    <div className="col-lg-7">

      <textarea className="form-control" rows={3}></textarea>
    
    </div>
  </div>


</div>

</div>




<div className='row'>
<div className='col-12 text-end mt-3'>
<button onClick={handelCancel}  type="button" className="btn btn-secondary">Cancel</button>
<button type="button" className="btn btn-primary">Save</button>

</div>

</div>
</div>
    


    </MainLayout>
    </>

  )
}
