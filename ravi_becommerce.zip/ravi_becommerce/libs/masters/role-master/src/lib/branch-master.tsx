import { MainLayout } from '@mfa-travel-app/layout';
import CrudeEdmodel from './components/crudeEdmodel';
import { Link } from "react-router-dom";
import { ControlledInput} from "@mfa-travel-app/ui";
import Paging from './components/paging';
import ViewPerPage from './components/viewPerPage';
import FilterCom from './components/filterCom';



export default function BranchMaster() {
  return (
    
    
    <>
 <MainLayout>

 <div className="container">
    <section className="country_section mt-2 mb-3">
      
      <div className="row">
      <div className="col-12">
      <nav className="navbar navbar-light bg-light">
  
      <nav aria-label="breadcrumb">
      <ol className="breadcrumb">
      <li className="breadcrumb-item"><a href="index.html">HOME</a></li>
      <li className="breadcrumb-item"><a href="#">SETTINGS</a></li>
      <li className="breadcrumb-item active" aria-current="page">Branch Master</li>
      </ol>
      </nav>
  
      <form className="d-flex text-start">

       <ControlledInput
                        id={'deatils'}
                        value={'Search'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

      <button className="btn btn-outline-success ms-2" type="button">
      Search
      </button>
      </form>
  
      <div className="options_section">
      <ul>
     
      <li> 
        <Link to="/branch-info">
          <i className="fa fa-plus-circle" aria-hidden="true"></i> Add
          </Link>
          
          </li>
      
      <li>

  
      <FilterCom/>
 
  
      </li>
      <li> 
        <a href="#"><i className="fa-solid fa-file-export"></i> Export</a>
      </li>
  
      <li>
        <a href="#"><i className="fa-solid fa-rotate-right"></i> Refresh</a>
      </li>
      </ul>
      </div>
  
      </nav>
      </div>
      </div>
  
  
      <div className="row">
  
      <div className="col-12">
        <div className="table-responsive">
          <table className="table text-secondary font_size_90">
      <thead>
      <tr>
      <th scope="col">SN</th>
      <th scope="col">Branch Name</th>
      <th scope="col">Branch Code</th>
      <th scope="col">Country</th>
      <th scope="col">City</th>
      <th scope="col">Agent Code</th>
      <th scope="col">Agent Name</th>
      <th scope="col">Currency</th>
      <th scope="col">Email</th>
      <th scope="col">Land Phone</th>
      <th scope="col">Parent Agent Name</th>
      <th scope="col">Branch Status</th>
      <th> </th>
      </tr>
      </thead>
      <tbody>
  
      <tr>
      <td>1</td>
      <td>Greek Travel LLC</td>
      <td>TMC</td>
      <td>UAE</td>
      <td>Dubai</td>
      <td>A0001</td>
      <td>Parent</td>
      <td>AED</td>
      <td>name@gmail.com</td>
      <td>9949137724</td>
      <td>John Kirby</td>
      <td>Active</td>
  
      <td className='btnDropMenu'>  
             
      <CrudeEdmodel/>
  
      </td>
      </tr>
   
      <tr>
        <td>2</td>
        <td>Greek Travel LLC</td>
        <td>TMC</td>
        <td>UAE</td>
        <td>Dubai</td>
        <td>A0001</td>
        <td>Parent</td>
        <td>AED</td>
        <td>name@gmail.com</td>
        <td>9949137724</td>
        <td>John Kirby</td>
        <td>Active</td>
    
        <td className='btnDropMenu'>  
               
         <CrudeEdmodel/>
    
        </td>
      </tr>
  
      <tr>
        <td>3</td>
        <td>Greek Travel LLC</td>
        <td>TMC</td>
        <td>UAE</td>
        <td>Dubai</td>
        <td>A0001</td>
        <td>Parent</td>
        <td>AED</td>
        <td>name@gmail.com</td>
        <td>9949137724</td>
        <td>John Kirby</td>
        <td>Active</td>
    
        <td className='btnDropMenu'>  
               
        <CrudeEdmodel/>
    
        </td>
      </tr>
  
      <tr>
        <td>4</td>
        <td>Greek Travel LLC</td>
        <td>TMC</td>
        <td>UAE</td>
        <td>Dubai</td>
        <td>A0001</td>
        <td>Parent</td>
        <td>AED</td>
        <td>name@gmail.com</td>
        <td>9949137724</td>
        <td>John Kirby</td>
        <td>Active</td>
    
        <td className='btnDropMenu'>  
               
        <CrudeEdmodel/>
    
        </td>
      </tr>
  
      <tr>
        <td>5</td>
        <td>Greek Travel LLC</td>
        <td>TMC</td>
        <td>UAE</td>
        <td>Dubai</td>
        <td>A0001</td>
        <td>Parent</td>
        <td>AED</td>
        <td>name@gmail.com</td>
        <td>9949137724</td>
        <td>John Kirby</td>
        <td>Active</td>
    
        <td className='btnDropMenu'>  
               
        <CrudeEdmodel/>
    
        </td>
      </tr>
  
  
      <tr>
        <td>6</td>
        <td>Greek Travel LLC</td>
        <td>TMC</td>
        <td>UAE</td>
        <td>Dubai</td>
        <td>A0001</td>
        <td>Parent</td>
        <td>AED</td>
        <td>name@gmail.com</td>
        <td>9949137724</td>
        <td>John Kirby</td>
        <td>Active</td>
    
        <td className='btnDropMenu'>  
               
        <CrudeEdmodel/>
    
        </td>
      </tr>
  
  
      <tr>
        <td>7</td>
        <td>Greek Travel LLC</td>
        <td>TMC</td>
        <td>UAE</td>
        <td>Dubai</td>
        <td>A0001</td>
        <td>Parent</td>
        <td>AED</td>
        <td>name@gmail.com</td>
        <td>9949137724</td>
        <td>John Kirby</td>
        <td>Active</td>
    
        <td className='btnDropMenu'>  
               
        <CrudeEdmodel/>
    
        </td>
      </tr>
  
  
      <tr>
        <td>8</td>
        <td>Greek Travel LLC</td>
        <td>TMC</td>
        <td>UAE</td>
        <td>Dubai</td>
        <td>A0001</td>
        <td>Parent</td>
        <td>AED</td>
        <td>name@gmail.com</td>
        <td>9949137724</td>
        <td>John Kirby</td>
        <td>Active</td>
    
        <td className='btnDropMenu'>  
               
        <CrudeEdmodel/>
    
        </td>
      </tr>
  
  
      <tr>
        <td>9</td>
        <td>Greek Travel LLC</td>
        <td>TMC</td>
        <td>UAE</td>
        <td>Dubai</td>
        <td>A0001</td>
        <td>Parent</td>
        <td>AED</td>
        <td>name@gmail.com</td>
        <td>9949137724</td>
        <td>John Kirby</td>
        <td>Active</td>
    
        <td className='btnDropMenu'>  
               
        <CrudeEdmodel/>
    
        </td>
      </tr>
  
  
      <tr>
        <td>10</td>
        <td>Greek Travel LLC</td>
        <td>TMC</td>
        <td>UAE</td>
        <td>Dubai</td>
        <td>A0001</td>
        <td>Parent</td>
        <td>AED</td>
        <td>name@gmail.com</td>
        <td>9949137724</td>
        <td>John Kirby</td>
        <td>Active</td>
    
        <td className='btnDropMenu'>  
               
        <CrudeEdmodel/>
    
        </td>
      </tr>
  
  
  
  
  
      </tbody>
      </table>
      </div>
      </div>
  
      </div>
  
      <div className="row align-items-center">
  
        <div className="col-lg-8">
        <Paging/>
        </div>
  
        <div className="col-lg-4">
  
        <ViewPerPage/>
  
  </div> 
  
  
  
              
  
  
      </div>
  
  
  </section>
 </div>

    </MainLayout>

    </>



  )
}
