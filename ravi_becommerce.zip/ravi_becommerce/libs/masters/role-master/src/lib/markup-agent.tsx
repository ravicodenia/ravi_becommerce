import { MainLayout } from '@mfa-travel-app/layout';
import { ControlledSelect, ControlledInput } from '@mfa-travel-app/ui';
import { useState } from 'react';
import { FiTrash2 } from "react-icons/fi";
import { FiEdit } from "react-icons/fi";
import { IoMdAdd } from "react-icons/io";



export default function MarkupAgent() {


    const selectOptions = [
        { id: 1, text: 'First Option' },
        { id: 2, text: 'Second Option' },
    ];

    const selectOptions2 = [
        { id: 1, text: 'Sales Type' },
        { id: 2, text: 'Supplier' },
        { id: 3, text: 'Booking Date' },
        { id: 4, text: 'Travel Date' },
        { id: 5, text: 'Sales Channel' },
        { id: 6, text: 'Travel Type' },
        { id: 7, text: 'Fare Type' },
        { id: 8, text: 'Operating Carrier' },
    ];


    const selectOptions3 = [
        { id: 1, text: 'Any' },
        { id: 2, text: 'Sabre' },
        { id: 3, text: 'Gold' },
        { id: 4, text: 'Date' },
        { id: 5, text: 'Active' },
        { id: 6, text: 'Void' },
        { id: 7, text: 'Modification' },
        { id: 8, text: 'Cancellation' },
    ];


    const [status, setStatus] = useState('');

    const radioHandler = (status: any) => {
        setStatus(status.target.value);
      };
    

    

  return (
    
    
    
    <>
 <MainLayout>

 <div style={{minHeight:'500px'}} className="container">
 <section className="country_section mt-2 mb-3 font_size_90 rule_section">

 <div className="row mt-3">
     
 <div className="col-lg-4">

<div className="row align-items-center mb-2">
               <label htmlFor="rulename" className="col-lg-3">Rule Name :</label>
               <div className="col-lg-9">
                <ControlledInput
                        id={'rulename'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
               </div>
           </div>

   </div>

   <div className='col-lg-4'>



    <div className='row'>

        <div className='col-6'>
        <label> 
   
   <input type="radio" name="release" checked={status === 'MARKUP'} value= {'MARKUP'} onClick={(e) => radioHandler(e)} />  Markup
   </label>
        </div>

        <div className='col-6'>
        <label>
    <input type="radio" name="release" checked={status === 'DISCOUNT'} value = {'DISCOUNT'} onClick={(e) => radioHandler(e)} />  Discount 
    </label>    
        </div>
        
    </div>


   </div>


   <div className="col-lg-4">

<div className="row align-items-center mb-2">
               <label htmlFor="product" className="col-lg-3">Product  :</label>
               <div className="col-lg-9">
               <ControlledSelect
                   id={'product'}
                   value={''}
                   options={selectOptions}
                   required={true}
                   onChange={''}
               />
               </div>
           </div>

   </div>

   <div className="col-lg-12">

<div className="row align-items-center mb-2">
<label  htmlFor="description" className="col-lg-1">Description :</label>
               <div className="col-lg-11">
     
               <ControlledInput
                        id={'description'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
               </div>
           </div>

   </div>


   <div className='col-lg-12'>

    



   {status === 'MARKUP' && (
      <div className='markup mt-3'> 
      <div className='row'>
      
      
      <div className='col-12'>
      <div className='markupheading'>Markup</div>
      
      <div className='markupWrapper'>
      
<div className='row'>

<div className="col-lg-3">

<div className="row align-items-center mb-2">
               <label htmlFor="typedrop" className="col-lg-5">Type :</label>
               <div className="col-lg-7">
               <ControlledSelect
                   id={'typedrop'}
                   value={''}
                   options={selectOptions}
                   required={true}
                   onChange={''}
               />
               </div>
           </div>

   </div>



<div className='col-lg-6'>

<div className='row'>
<div className="col-lg-4">

<div className="row align-items-center mb-2">
               <label htmlFor="adult" className="col-lg-5">Adult :</label>
               <div className="col-lg-7">
               <ControlledInput
                        id={'adult'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
               </div>
           </div>

   </div>

   
   <div className="col-lg-4">

<div className="row align-items-center mb-2">
               <label htmlFor="child" className="col-lg-5">Child :</label>
               <div className="col-lg-7">
               <ControlledInput
                        id={'child'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
               </div>
           </div>

   </div>


      
   <div className="col-lg-4">

<div className="row align-items-center mb-2">
               <label htmlFor="infant" className="col-lg-5">Infant :</label>
               <div className="col-lg-7">
               <ControlledInput
                        id={'infant'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
               </div>
           </div>

   </div>
</div>


</div>




   <div className="col-lg-3">

<div className="row align-items-center mb-2">
               <label htmlFor="applyon" className="col-lg-5">Apply On :</label>
               <div className="col-lg-7">
               <ControlledSelect
                   id={'applyon'}
                   value={''}
                   options={selectOptions}
                   required={true}
                   onChange={''}
               />
               </div>
           </div>

   </div>

   <div className="col-lg-3">

<div className="row align-items-center mb-2">
               <label htmlFor="applymarkup" className="col-lg-5">Apply Markup :</label>
               <div className="col-lg-7">
               <ControlledSelect
                   id={'applymarkup'}
                   value={''}
                   options={selectOptions}
                   required={true}
                   onChange={''}
               />
               </div>
           </div>

   </div>


</div>



      
      </div>
      </div>
      
      
      
      
      </div>
      
      </div>
        
        )}
     

   </div>


<div className='col-lg-12'>

    


  
   {status === 'DISCOUNT' && (
      <div className='markup mt-3'> 
      <div className='row'>
      
      
      <div className='col-12'>
      <div className='markupheading'>Markup</div>
      
      <div className='markupWrapper'>
      
<div className='row'>

<div className="col-lg-3">

<div className="row align-items-center mb-2">
               <label htmlFor="typedrop" className="col-lg-5">Type :</label>
               <div className="col-lg-7">
               <ControlledSelect
                   id={'typedrop'}
                   value={''}
                   options={selectOptions}
                   required={true}
                   onChange={''}
               />
               </div>
           </div>

   </div>



<div className='col-lg-6'>

<div className='row'>
<div className="col-lg-4">

<div className="row align-items-center mb-2">
               <label htmlFor="adult" className="col-lg-5">Adult :</label>
               <div className="col-lg-7">
               <ControlledInput
                        id={'adult'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
               </div>
           </div>

   </div>

   
   <div className="col-lg-4">

<div className="row align-items-center mb-2">
               <label htmlFor="child" className="col-lg-5">Child :</label>
               <div className="col-lg-7">
               <ControlledInput
                        id={'child'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
               </div>
           </div>

   </div>


      
   <div className="col-lg-4">

<div className="row align-items-center mb-2">
               <label htmlFor="infant" className="col-lg-5">Infant :</label>
               <div className="col-lg-7">
               <ControlledInput
                        id={'infant'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
               </div>
           </div>

   </div>
</div>


</div>




   <div className="col-lg-3">

<div className="row align-items-center mb-2">
               <label htmlFor="applyon" className="col-lg-5">Apply On :</label>
               <div className="col-lg-7">
               <ControlledSelect
                   id={'applyon'}
                   value={''}
                   options={selectOptions}
                   required={true}
                   onChange={''}
               />
               </div>
           </div>

   </div>

   <div className="col-lg-3">

<div className="row align-items-center mb-2">
               <label htmlFor="applymarkup" className="col-lg-5">Apply Discount :</label>
               <div className="col-lg-7">
               <ControlledSelect
                   id={'applymarkup'}
                   value={''}
                   options={selectOptions}
                   required={true}
                   onChange={''}
               />
               </div>
           </div>

   </div>


</div>



      
      </div>
      </div>
      
      
      
      
      </div>
      
      </div>
     
     )}
 </div>



<div className='col-lg-12'>


<div className='markup mt-3'> 
      <div className='row'>
      
      
      <div className='col-12'>
      <div className='markupheading'>Criteria</div>
      
      <div className='markupWrapper'>
      
<div className='row'>



   <div className="col-lg-12">

   <table className="table">
  <thead>
    <tr>
      <th scope="col">Attribute</th>
      <th scope="col">Operator</th>
      <th scope="col">Value</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
  
    <tr className='align-middle'>
      <td>        
        <ControlledSelect
                   id={'attribute'}
                   value={''}
                   options={selectOptions2}
                   required={true}
                   onChange={''} />
               
               </td>
      <td>
      <ControlledSelect
                   id={'operator'}
                   value={''}
                   options={selectOptions3}
                   required={true}
                   onChange={''} />


      </td>
      <td>
      <ControlledInput
                        id={'value'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />


      </td>

                <td> 
                  

                    <button className='btn me-2'><FiEdit /></button>

                    <button className='btn me-2'><FiTrash2 /></button>

             
                    
            </td>


    </tr>

    <tr className='align-middle'>
      <td>        
        <ControlledSelect
                   id={'attribute'}
                   value={''}
                   options={selectOptions2}
                   required={true}
                   onChange={''} />
               
               </td>
      <td>
      <ControlledSelect
                   id={'operator'}
                   value={''}
                   options={selectOptions3}
                   required={true}
                   onChange={''} />


      </td>
      <td>
      <ControlledInput
                        id={'value'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />


      </td>

                <td> 
                  



                    <button className='btn btn-secondary rounded btn-sm'><IoMdAdd />Add</button>
                    
            </td>


    </tr>

  </tbody>
</table>


   </div>




</div>



      
      </div>
      </div>
      
      
      
      
      </div>
      
      </div>


</div>


<div className='col-lg-12 text-end mt-4 mb-4'>

<button className='btn btn-primary'>Submit</button>

</div>


  
    </div>

</section>

    </div>

    </MainLayout>

    </>





  )
}
