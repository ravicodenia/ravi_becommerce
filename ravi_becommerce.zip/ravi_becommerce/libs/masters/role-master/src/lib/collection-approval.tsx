import { MainLayout } from '@mfa-travel-app/layout';
import { ControlledSelect, ControlledDatePicker} from "@mfa-travel-app/ui";
import Paging from './components/paging';
import ViewPerPage from './components/viewPerPage';
import ApproveRejectModal from './components/ApproveRejectModal';



export default function CollectionApproval() {

    const selectOptions = [
        { id: 1, text: 'First Option' },
        { id: 2, text: 'Second Option' },
    ];

  return (
    
    <>
 <MainLayout>

 <div className="container">
    <section className="country_section mt-2 mb-3">
      
      <div className="row">
      <div className="col-12">
      <nav className="navbar navbar-light bg-light">
  
      <nav aria-label="breadcrumb">
      <ol className="breadcrumb">
      <li className="breadcrumb-item"><a href="index.html">HOME</a></li>
      <li className="breadcrumb-item"><a href="#">SETTINGS</a></li>
      <li className="breadcrumb-item active" aria-current="page">BALANCE APPROVAL</li>
      </ol>
      </nav>
  

  
      <div className="options_section">
      <ul>

     
      <li> 
        <a href="#"><i className="fa-solid fa-file-export"></i> Export</a>
      </li>
  
      <li>
        <a href="#"><i className="fa-solid fa-rotate-right"></i> Refresh</a>
      </li>
      </ul>
      </div>
  
      </nav>
      </div>
      </div>
  

      <div className="row mt-3 mb-3 font_size_90">


                <div className="col-lg-5">


                <div className="row">
                <div className="col-lg-6">
                <div className="row align-items-center mb-3">
                    <label className="col-sm-5 text-lg-end"> From Date:</label>
                    <div className="col-sm-7">

                    <ControlledDatePicker
                        id={'fromDate'}
                        value={''}
                        format={'dd/MMM/yyyy'}
                        required={true}
                        onChange={''}
                    />

                    </div>

                </div>

                </div>


                <div className="col-lg-6">
                
                <div className="row align-items-center mb-3">
                    <label className="col-sm-5 text-lg-end"> To Date:</label>
                    <div className="col-sm-7">
                    <ControlledDatePicker 
                        id={'toDate'}
                        value={''}
                        format={'dd/MMM/yyyy'}
                        required={true}
                        onChange={''}
                    />
                    </div>

                </div>
                </div>

                </div>




                </div>

                <div className="col-lg-3">


                <div className="row align-items-center mb-3">
                    <label className="col-sm-4 text-lg-end">Firm:</label>
                    <div className="col-sm-8">
                    


     <ControlledSelect
                        id={'firm'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />


                    </div>

                </div>





                </div>

                <div className="col-lg-3">


                    <div className="row align-items-center mb-3">
                    <label className="col-sm-4 text-lg-end">Status:</label>
                    <div className="col-sm-8">


                    <ControlledSelect
                        id={'status'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />





                    </div>
                
                    </div>


                </div>

                <div className="col-lg-1 text-end">

                <button type="button" className="btn btn-sm btn-primary rounded mt-1">SUBMIT</button>


                </div>

</div>


  
      <div className="row">
  
      <div className="col-12">
        <div className="table-responsive">
          <table className="table text-secondary">
    
      <thead>
      <tr>
      <th scope="col">SN</th>
      <th scope="col">Reference ID	</th>
      <th scope="col">Trans Type	</th>
      <th scope="col">Details</th>
      <th scope="col">Pay Mode	</th>
      <th scope="col">Amount</th>
      <th scope="col">Status</th>
      <th scope="col">Firm</th>
      <th scope="col">Requested By	</th>
      <th scope="col">Requested Date	</th>
      <th scope="col">Action</th>
      </tr>
      </thead>

      <tbody>
  
      <tr>
      <td>1</td>
      <td>00000012</td>
      <td>Credit Account</td>
      <td>dwdwd</td>
      <td>Cash</td>
      <td>90.00</td>
      <td>Approved</td>
      <td>Greek Travel LLC	</td>
      <td>name@gmail.com</td>
      <td>16/05/2024 14:010 PM	      </td>
     
      <td>           
     <ApproveRejectModal/>
      </td>
      </tr>


      <tr>
      <td>2</td>
      <td>00000012</td>
      <td>Credit Account</td>
      <td>dwdwd</td>
      <td>Cash</td>
      <td>90.00</td>
      <td>Approved</td>
      <td>Greek Travel LLC	</td>
      <td>name@gmail.com</td>
      <td>16/05/2024 14:010 PM	      </td>
     
      <td>         
      <ApproveRejectModal/>
      </td>
      </tr>


      <tr>
      <td>3</td>
      <td>00000012</td>
      <td>Credit Account</td>
      <td>dwdwd</td>
      <td>Cash</td>
      <td>90.00</td>
      <td>Approved</td>
      <td>Greek Travel LLC	</td>
      <td>name@gmail.com</td>
      <td>16/05/2024 14:010 PM	      </td>
     
      <td>         
      <ApproveRejectModal/>
      </td>
      </tr>


      <tr>
      <td>4</td>
      <td>00000012</td>
      <td>Credit Account</td>
      <td>dwdwd</td>
      <td>Cash</td>
      <td>90.00</td>
      <td>Approved</td>
      <td>Greek Travel LLC	</td>
      <td>name@gmail.com</td>
      <td>16/05/2024 14:010 PM	      </td>
     
      <td>         
      <ApproveRejectModal/>
      </td>
      </tr>


      <tr>
      <td>5</td>
      <td>00000012</td>
      <td>Credit Account</td>
      <td>dwdwd</td>
      <td>Cash</td>
      <td>90.00</td>
      <td>Approved</td>
      <td>Greek Travel LLC	</td>
      <td>name@gmail.com</td>
      <td>16/05/2024 14:010 PM	      </td>
     
      <td>         
      <ApproveRejectModal/>
      </td>
      </tr>


      <tr>
      <td>6</td>
      <td>00000012</td>
      <td>Credit Account</td>
      <td>dwdwd</td>
      <td>Cash</td>
      <td>90.00</td>
      <td>Approved</td>
      <td>Greek Travel LLC	</td>
      <td>name@gmail.com</td>
      <td>16/05/2024 14:010 PM	      </td>
     
      <td>         
      <ApproveRejectModal/>
      </td>
      </tr>


      <tr>
      <td>7</td>
      <td>00000012</td>
      <td>Credit Account</td>
      <td>dwdwd</td>
      <td>Cash</td>
      <td>90.00</td>
      <td>Approved</td>
      <td>Greek Travel LLC	</td>
      <td>name@gmail.com</td>
      <td>16/05/2024 14:010 PM	      </td>
     
      <td>         
      <ApproveRejectModal/>
      </td>
      </tr>



      <tr>
      <td>8</td>
      <td>00000012</td>
      <td>Credit Account</td>
      <td>dwdwd</td>
      <td>Cash</td>
      <td>90.00</td>
      <td>Approved</td>
      <td>Greek Travel LLC	</td>
      <td>name@gmail.com</td>
      <td>16/05/2024 14:010 PM	      </td>
     
      <td>         
      <ApproveRejectModal/>
      </td>
      </tr>




      <tr>
      <td>9</td>
      <td>00000012</td>
      <td>Credit Account</td>
      <td>dwdwd</td>
      <td>Cash</td>
      <td>90.00</td>
      <td>Approved</td>
      <td>Greek Travel LLC	</td>
      <td>name@gmail.com</td>
      <td>16/05/2024 14:010 PM	      </td>
     
      <td>         
      <ApproveRejectModal/>
      </td>
      </tr>

  
      <tr>
      <td>10</td>
      <td>00000012</td>
      <td>Credit Account</td>
      <td>dwdwd</td>
      <td>Cash</td>
      <td>90.00</td>
      <td>Approved</td>
      <td>Greek Travel LLC	</td>
      <td>name@gmail.com</td>
      <td>16/05/2024 14:010 PM	      </td>
     
      <td>         
      <ApproveRejectModal/>
      </td>
      </tr>



      </tbody>
      </table>
      </div>
      </div>
  
      </div>
  



      <div className="row align-items-center">
  
        <div className="col-lg-8">
        <Paging/>
        </div>
  
        <div className="col-lg-4">
  
        <ViewPerPage/>
  
  </div> 
  
  
  
              
  
  
      </div>
  
  
  </section>
 </div>

    </MainLayout>

    </>
  )
}
