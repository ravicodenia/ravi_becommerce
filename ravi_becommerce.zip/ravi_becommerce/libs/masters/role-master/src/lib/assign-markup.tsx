import { MainLayout } from '@mfa-travel-app/layout';
import { ControlledSelect } from '@mfa-travel-app/ui';

export default function AssignMarkup() {

    const selectOptions = [
        { id: 1, text: 'First Option' },
        { id: 2, text: 'Second Option' },
    ];


  return (
    <>
 <MainLayout>

 <div style={{minHeight:'500px'}} className="container">
 <section className="country_section mt-2 mb-3 font_size_90 rule_section">

 <div className="row mt-3">
     
 <div className="col-lg-3">

<div className="row align-items-center mb-2">
               <label htmlFor="rulename" className="col-lg-5">Rule Name:</label>
               <div className="col-lg-7">
               <ControlledSelect
                   id={'rulename'}
                   value={''}
                   options={selectOptions}
                   required={true}
                   onChange={''}
               />
               </div>
           </div>

   </div>



   <div className="col-lg-3">

<div className="row align-items-center mb-2">
               <label htmlFor="agent" className="col-lg-5">Agent:</label>
               <div className="col-lg-7">
               <ControlledSelect
                   id={'agent'}
                   value={''}
                   options={selectOptions}
                   required={true}
                   onChange={''}
               />
               </div>
           </div>

   </div>


   <div className="col-lg-3">

<div className="row align-items-center mb-2">
               <label htmlFor="bookingtype" className="col-lg-5">Booking Type:</label>
               <div className="col-lg-7">
               <ControlledSelect
                   id={'bookingtype'}
                   value={''}
                   options={selectOptions}
                   required={true}
                   onChange={''}
               />
               </div>
           </div>

   </div>


   <div className="col-lg-3">

<div className="row align-items-center mb-2">
               <label htmlFor="order" className="col-lg-5">Order:</label>
               <div className="col-lg-7">
               <ControlledSelect
                   id={'order'}
                   value={''}
                   options={selectOptions}
                   required={true}
                   onChange={''}
               />
               </div>
           </div>

   </div>



   <div className="col-lg-3">

<div className="row align-items-center mb-2">
               <label htmlFor="ruletype" className="col-lg-5">Rule Type:</label>
               <div className="col-lg-7">
               <ControlledSelect
                   id={'ruletype'}
                   value={''}
                   options={selectOptions}
                   required={true}
                   onChange={''}
               />
               </div>
           </div>

   </div>


   <div className="col-lg-9 text-end">
   <button className='btn btn-primary mt-2'>Submit</button>

   </div>





  
    </div>

</section>

    </div>

    </MainLayout>

    </>
  )
}
