import { MainLayout } from '@mfa-travel-app/layout';
import { ControlledInput, ControlledSelect, ControlledFileInput, ControlledCheckbox  } from "@mfa-travel-app/ui";
import { useState } from 'react';

export default function AgentRegister() {

const [chkTermsBtn, setChkTermsBtn] = useState(true);

    const selectOptions = [
        { id: 1, text: 'First Option' },
        { id: 2, text: 'Second Option' },
    ];


    const toggleChkDisableButton = () => {
        setChkTermsBtn(!chkTermsBtn);
      };


  return (

    <>
    <MainLayout>


    <div className="container mb-5">
        <section className="user_master_section">
          <div className="innerContainer border-end-0 border-top-0 form_with_select2">
        
            <div className="wrapper"> 
    
    
              <div className="row">
                  <div className="col-12"> <h5>Sign Up </h5> </div>
                  </div>
      
      
      
                  <div  className="row">
                    <div className="col-12">
                      <div className="form_heading">
                      <span className=" title">Agency Info</span>
                      </div>
                      
                    </div>
              
              
                    <div className="col-12">
                     
                    
                  <div className="row">
    
    
                    <div className="col-md-4">  
    
                      <div className="mb-3">
                        <label className="form-label">Agency Name <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'agencyname'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>   
    
                      
                      <div className="mb-3">
                        <label className="form-label">Address <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'adress'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div> 
                      
                      <div className="mb-3">
                        <label className="form-label">P.O. Box <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'poboxno'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div> 
    
                                        
                      <div className="mb-3">
                        <label className="form-label">Preferred Language <i className="text-danger">*</i></label>
                       
                       
                        <ControlledSelect
                        id={'preflanguage'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />


                      </div> 
    
                                        
                      <div className="mb-3">
                        <label className="form-label">Email <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'email'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div> 
    
                                        
                      <div className="mb-3">
                        <label className="form-label">Land Phone <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'landphone'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div> 
                      
                      
                    </div>
    
    
                    <div className="col-md-4">  
    
                      <div className="mb-3">
                        <label className="form-label">Country <i className="text-danger">*</i></label>
                      
                        <ControlledSelect
                        id={'countrylist'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />


                      </div>       
    
    
                      <div className="mb-3">
                        <label className="form-label">State <i className="text-danger">*</i></label>
                       
                        <ControlledSelect
                        id={'statelist'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />

                      </div>    
    
    
    
                      <div className="mb-3">
                        <label className="form-label">City <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'citytxt'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>  
    
    
                      <div className="mb-3">
                        <label className="form-label">Business Currency <i className="text-danger">*</i></label>
                       
                        <ControlledSelect
                        id={'businesscurrency'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />


                      </div>  
    
    
                      <div className="mb-3">
                        <label className="form-label">Website <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'websitename'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>  
    
                      <div className="mb-3">
                        <label className="form-label">Fax <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'faxtxt2'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>  
    
    
    
    
    
                    </div>
    
                    <div className="col-md-4">  
    
    
                      <div className="mb-3">
                        <label className="form-label">Registration / Trade License No <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'registrationno'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>  
    
    
                      <div className="mb-3">
                        <label className="form-label">Name of Authorized Person on Trade License <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'authorizedperson'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>  
    
    
                      <div className="mb-3">
                        <label className="form-label">License Issued On <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'licenceissuedon'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div> 
    
                      
                      <div className="mb-3">
                        <label className="form-label">IATA Code <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'iatacode'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div> 
    
    
    
                      <div className="mb-3">
                        <label className="form-label">Time Zone <i className="text-danger">*</i></label>
                        
                        <ControlledSelect
                        id={'timezone'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />



                      </div>  
    
                
                      <div className="mb-3 mt-md-5">
    
                      
                        <div className="mt-3">
                          <div className="form-check form-switch">
                        

                            <ControlledCheckbox
                        id={'flexSwitchCheckDefault'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />

                            <label className="form-label" htmlFor="flexSwitchCheckDefault">Is IATA</label>
                          </div>
                        </div>
    
                      </div> 
    
                      
    
    
                      
                  </div>
    
    
    
    
    
                  </div>
         
          
                  
                  </div>
              
    
    
    
              
                  </div>
      
          
                  <div className="row">
                    <div className="col-12">
                      <div className="form_heading">
                      <span className=" title">Point of Contact (Finance Manager)</span>
                      </div>
                      
                    </div>
              
              
                    <div className="col-md-4">
                     
                      <div className="mb-3">
                        <label className="form-label">Salutation <i className="text-danger">*</i></label>
                      
                        <ControlledSelect
                        id={'salutation'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />



                      </div>   
         
          
                  
                    </div>
              
                    <div className="col-md-4">
                     
                      <div className="mb-3">
                        <label className="form-label">First Name <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'firstname2'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>   
    
                  
                    </div>
              
    
    
                    <div className="col-md-4">
                     
                      <div className="mb-3">
                        <label className="form-label">Last Name <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'lastname2'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>   
    
                  
                    </div>
              
                    
                    <div className="col-md-4">
                     
                      <div className="mb-3">
                        <label className="form-label">Designation <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'designation'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>   
    
                  
                    </div>
    
    
                    <div className="col-md-4">
                     
                      <div className="mb-3">
                        <label className="form-label">Land Phone <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'landphone'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>   
    
                  
                    </div>
    
    
                    <div className="col-md-4">
                     
                      <div className="mb-3">
                        <label className="form-label">Mobile <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'mobiletxt2'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>   
    
                  
                    </div>
    
                    
                    <div className="col-md-4">
                     
                      <div className="mb-3">
                        <label className="form-label">Email <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'emailtxt2'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>   
    
                  
                    </div>
    
    
    
              
                  </div>
    
    
                  <div className="row">
                    <div className="col-12">
                      <div className="form_heading">
                      <span className=" title">Point of Contact (General Manager)</span>
                      </div>
                      
                    </div>
              
              
                    <div className="col-md-4">
                     
                      <div className="mb-3">
                        <label className="form-label">Salutation <i className="text-danger">*</i></label>
                       
                        <ControlledSelect
                        id={'salutation2'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />



                      </div>   
         
          
                  
                    </div>
              
                    <div className="col-md-4">
                     
                      <div className="mb-3">
                        <label className="form-label">First Name <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'firstname3'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>   
    
                  
                    </div>
              
    
    
                    <div className="col-md-4">
                     
                      <div className="mb-3">
                        <label className="form-label">Last Name <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'lastname3'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>   
    
                  
                    </div>
              
                    
                    <div className="col-md-4">
                     
                      <div className="mb-3">
                        <label className="form-label">Designation <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'designation3'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>   
    
                  
                    </div>
    
    
                    <div className="col-md-4">
                     
                      <div className="mb-3">
                        <label className="form-label">Land Phone <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'landphone3'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>   
    
                  
                    </div>
    
    
                    <div className="col-md-4">
                     
                      <div className="mb-3">
                        <label className="form-label">Mobile <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'mobiletxt3'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>   
    
                  
                    </div>
    
                    
                    <div className="col-md-4">
                     
                      <div className="mb-3">
                        <label className="form-label">Email <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'emailtxt3'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>   
    
                  
                    </div>
    
    
    
              
                  </div>
    
    
                  <div className="row">
                    <div className="col-12">
                      <div className="form_heading">
                      <span className=" title">System Access - User Details</span>
                      </div>
                      
                    </div>
              
              
                    <div className="col-md-4">
                     
                      <div className="mb-3">
                        <label className="form-label">Salutation <i className="text-danger">*</i></label>
                      
                        <ControlledSelect
                        id={'salutation3'}
                        value={''}
                        options={selectOptions}
                        required={true}
                        onChange={''}
                    />


                      </div>   
         
          
                  
                    </div>
              
                    <div className="col-md-4">
                     
                      <div className="mb-3">
                        <label className="form-label">First Name <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'firstname4'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>   
    
                  
                    </div>
              
    
    
                    <div className="col-md-4">
                     
                      <div className="mb-3">
                        <label className="form-label">Last Name <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'lastname4'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>   
    
                  
                    </div>
              
                    
                    <div className="col-md-4">
                     
                      <div className="mb-3">
                        <label className="form-label">Designation <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'designation4'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>   
    
                  
                    </div>
    
    
                    <div className="col-md-4">
                     
                      <div className="mb-3">
                        <label className="form-label">Land Phone <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'landphone4'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>   
    
                  
                    </div>
    
    
                    <div className="col-md-4">
                     
                      <div className="mb-3">
                        <label className="form-label">Mobile <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'mobiletxt4'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>   
    
                  
                    </div>
    
                    
                    <div className="col-md-4">
                     
                      <div className="mb-3">
                        <label className="form-label">Login User Name <i className="text-danger">*</i></label>
                        <ControlledInput
                        id={'loginusernametxt'}
                        value={''}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />
                      </div>   
    
                  
                    </div>
    
    
    
              
                  </div>
    
    
                  <div  className="row">
                    <div className="col-12">
                      <div className="form_heading">
                      <span className=" title">Documents</span>
                      </div>
                      
                    </div>
              
              
                    <div className="col-md-4">
                      <div className="mb-3">
                        <label className="form-label">Trade license Copy</label>

                        <ControlledFileInput
                        id={'tradeliccopy'}
                        value={''}
                        type={'file'}
                        accept={true}
                        multiple={''}
                    />



                      </div>
                  
                    </div>
              
                    <div className="col-md-4">
                      <div className="mb-3">
                        <label className="form-label">ID Copy of Sponsor</label>

                        <ControlledFileInput
                        id={'sponoridcopy'}
                        value={''}
                        type={'file'}
                        accept={true}
                        multiple={''}
                    />



                      </div>
                  
                    </div>
           
                    <div className="col-md-4">
                      <div className="mb-3">
                        <label className="form-label">ID Copy of Authorized Signatory</label>

                        <ControlledFileInput
                        id={'idcopyofauthorizedperson'}
                        value={''}
                        type={'file'}
                        accept={true}
                        multiple={''}
                    />


                      </div>
                  
                    </div>
    
                    <div className="col-md-4">
                      <div className="mb-3">
                        <label className="form-label">TAX Registration Copy</label>

                               <ControlledFileInput
                        id={'registrationcopy'}
                        value={''}
                        type={'file'}
                        accept={true}
                        multiple={''}
                    />

                      </div>
                  
                    </div>
    
                    <div className="col-md-4">
                      <div className="mb-3">
                        <label className="form-label">ID Copy of Owner</label>

                        <ControlledFileInput
                        id={'idcopyofowner'}
                        value={''}
                        type={'file'}
                        accept={true}
                        multiple={''}
                    />



                      </div>
                  
                    </div>
    
                    <div className="col-12 mt-4 mb-4">
                          <input
                            className="form-check-input"
                            type="checkbox"
                            id="termconditions"
                            name="termconditions"
                            onChange={toggleChkDisableButton}
                          />

                          <label
                            className="ms-2 font_size_90"
                            htmlFor="termconditions"
                          >
                           I Accept Terms and Conditions
                          </label>
                        </div>
    
    
    
    
    
    
      
      
          
                  </div>
    
    
                  <div className="row align-items-center">
                <div className="col-lg-8">
                  <form action="?" method="POST">
                    <div className="g-recaptcha" data-sitekey="your_site_key"></div>
                  </form>
                  
                </div>
    
    
                <div className="col-lg-4 text-end">
                <button
                            disabled={chkTermsBtn}
                            className="btn btn-primary text-uppercase ps-4 pe-4">
                            SUBMIT{' '}
                          </button>
                </div>
    
    
                <div className="col-lg-12 mt-5 text-center">
                  <div className="alert alert-success d-md-inline" role="alert">
                    <strong>Thank you!</strong> for providing the registration details! One of our representative 
                    will contact you shortly.
                  </div>
                </div>
    
                  </div>
    
    
    
    
    
            </div>
    </div>
    </section>
    </div>

        </MainLayout>

        </>



  )
}
