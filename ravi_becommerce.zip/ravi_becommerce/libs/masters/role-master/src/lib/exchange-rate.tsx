import { MainLayout } from '@mfa-travel-app/layout';
import CrudeEdmodel from './components/crudeEdmodel';
import { Link } from "react-router-dom";
import { ControlledInput} from "@mfa-travel-app/ui";
import Paging from './components/paging';
import ViewPerPage from './components/viewPerPage';
import FilterCom from './components/filterCom';

export default function ExchnageRate() {
  return (


    <>
 <MainLayout>

 <div className="container">
    <section className="country_section mt-2 mb-3">
      
      <div className="row">
      <div className="col-12">
      <nav className="navbar navbar-light bg-light">
  
      <nav aria-label="breadcrumb">
      <ol className="breadcrumb">
      <li className="breadcrumb-item"><a href="index.html">HOME</a></li>
      <li className="breadcrumb-item"><a href="#">SETTINGS</a></li>
      <li className="breadcrumb-item active" aria-current="page">EXCHNAGE RATE LIST</li>
      </ol>
      </nav>
  
      <form className="d-flex text-start">

       <ControlledInput
                        id={'deatils'}
                        value={'Search'}
                        type={'text'}
                        required={true}
                        onChange={''}
                    />

      <button className="btn btn-outline-success ms-2" type="button">
      Search
      </button>
      </form>
  
      <div className="options_section">
      <ul>
     
      <li> 
        <Link to="/exchnage-master">
          <i className="fa fa-plus-circle" aria-hidden="true"></i> Add
          </Link>
          
          </li>
      
      <li>

  
      <FilterCom/>
 
  
      </li>
      <li> 
        <a href="#"><i className="fa-solid fa-file-export"></i> Export</a>
      </li>
  
      <li>
        <a href="#"><i className="fa-solid fa-rotate-right"></i> Refresh</a>
      </li>
      </ul>
      </div>
  
      </nav>
      </div>
      </div>
  
  
      <div className="row">
  
      <div className="col-12">
        <div className="table-responsive">
          <table className="table text-secondary font_size_90">
      <thead>
      <tr className='align-middle'>
      <th scope="col">SN</th>
      <th scope="col">Currency</th>
      <th scope="col">Base Currency</th>
      <th scope="col">To Currency</th>
      <th scope="col">Selling Conversion Rate</th>
      <th scope="col">Buffer Type</th>
      <th scope="col">Buffer Value</th>
      <th scope="col">Applied Conversion Rate</th>
      <th scope="col">Valid From	</th>
      <th scope="col">Agent</th>
      <th scope="col">Remarks</th>
      <th scope="col">Product</th>

      <th scope="col">Supplier</th>
      <th scope="col">Status</th>
      <th scope="col">Modified On	</th>
      <th scope="col">Modified By</th>
      <th> </th>
      </tr>
      </thead>
      <tbody>
  
      <tr className='align-middle'>
      <td>1</td>
      <td>AED-GBP</td>
      <td>AED</td>
      <td>GBP</td>
      <td>5.79</td>
      <td>%	</td>
      <td>1.01</td>
      <td>5.8479</td>
      <td>2024-04-25 17:56:55.506784+308</td>
      <td>All</td>
      <td>UK Pound</td>
      <td>All</td>



      <td>Manual</td>
      <td>A</td>
      <td>2024-04-25 17:56:55.506784+308</td>
      <td>1</td>
  
      <td className='btnDropMenu'>              
      <CrudeEdmodel/> 
      </td>


      </tr>
   
      <tr className='align-middle'>
      <td>2</td>
      <td>AED-GBP</td>
      <td>AED</td>
      <td>GBP</td>
      <td>5.79</td>
      <td>%	</td>
      <td>1.01</td>
      <td>5.8479</td>
      <td>2024-04-25 17:56:55.506784+308</td>
      <td>All</td>
      <td>UK Pound</td>
      <td>All</td>



      <td>Manual</td>
      <td>A</td>
      <td>2024-04-25 17:56:55.506784+308</td>
      <td>1</td>
  
      <td className='btnDropMenu'>              
      <CrudeEdmodel/> 
      </td>


      </tr>

  
      <tr className='align-middle'>
      <td>3</td>
      <td>AED-GBP</td>
      <td>AED</td>
      <td>GBP</td>
      <td>5.79</td>
      <td>%	</td>
      <td>1.01</td>
      <td>5.8479</td>
      <td>2024-04-25 17:56:55.506784+308</td>
      <td>All</td>
      <td>UK Pound</td>
      <td>All</td>



      <td>Manual</td>
      <td>A</td>
      <td>2024-04-25 17:56:55.506784+308</td>
      <td>1</td>
  
      <td className='btnDropMenu'>              
      <CrudeEdmodel/> 
      </td>


      </tr>

  
      <tr className='align-middle'>
      <td>4</td>
      <td>AED-GBP</td>
      <td>AED</td>
      <td>GBP</td>
      <td>5.79</td>
      <td>%	</td>
      <td>1.01</td>
      <td>5.8479</td>
      <td>2024-04-25 17:56:55.506784+308</td>
      <td>All</td>
      <td>UK Pound</td>
      <td>All</td>



      <td>Manual</td>
      <td>A</td>
      <td>2024-04-25 17:56:55.506784+308</td>
      <td>1</td>
  
      <td className='btnDropMenu'>              
      <CrudeEdmodel/> 
      </td>


      </tr>
  
      <tr className='align-middle'>
      <td>5</td>
      <td>AED-GBP</td>
      <td>AED</td>
      <td>GBP</td>
      <td>5.79</td>
      <td>%	</td>
      <td>1.01</td>
      <td>5.8479</td>
      <td>2024-04-25 17:56:55.506784+308</td>
      <td>All</td>
      <td>UK Pound</td>
      <td>All</td>



      <td>Manual</td>
      <td>A</td>
      <td>2024-04-25 17:56:55.506784+308</td>
      <td>1</td>
  
      <td className='btnDropMenu'>              
      <CrudeEdmodel/> 
      </td>


      </tr>
  
  
      <tr className='align-middle'>
      <td>6</td>
      <td>AED-GBP</td>
      <td>AED</td>
      <td>GBP</td>
      <td>5.79</td>
      <td>%	</td>
      <td>1.01</td>
      <td>5.8479</td>
      <td>2024-04-25 17:56:55.506784+308</td>
      <td>All</td>
      <td>UK Pound</td>
      <td>All</td>



      <td>Manual</td>
      <td>A</td>
      <td>2024-04-25 17:56:55.506784+308</td>
      <td>1</td>
  
      <td className='btnDropMenu'>              
      <CrudeEdmodel/> 
      </td>


      </tr>
  
  
      <tr className='align-middle'>
      <td>7</td>
      <td>AED-GBP</td>
      <td>AED</td>
      <td>GBP</td>
      <td>5.79</td>
      <td>%	</td>
      <td>1.01</td>
      <td>5.8479</td>
      <td>2024-04-25 17:56:55.506784+308</td>
      <td>All</td>
      <td>UK Pound</td>
      <td>All</td>



      <td>Manual</td>
      <td>A</td>
      <td>2024-04-25 17:56:55.506784+308</td>
      <td>1</td>
  
      <td className='btnDropMenu'>              
      <CrudeEdmodel/> 
      </td>


      </tr>


      <tr className='align-middle'>
      <td>8</td>
      <td>AED-GBP</td>
      <td>AED</td>
      <td>GBP</td>
      <td>5.79</td>
      <td>%	</td>
      <td>1.01</td>
      <td>5.8479</td>
      <td>2024-04-25 17:56:55.506784+308</td>
      <td>All</td>
      <td>UK Pound</td>
      <td>All</td>



      <td>Manual</td>
      <td>A</td>
      <td>2024-04-25 17:56:55.506784+308</td>
      <td>1</td>
  
      <td className='btnDropMenu'>              
      <CrudeEdmodel/> 
      </td>


      </tr>


      <tr className='align-middle'>
      <td>9</td>
      <td>AED-GBP</td>
      <td>AED</td>
      <td>GBP</td>
      <td>5.79</td>
      <td>%	</td>
      <td>1.01</td>
      <td>5.8479</td>
      <td>2024-04-25 17:56:55.506784+308</td>
      <td>All</td>
      <td>UK Pound</td>
      <td>All</td>



      <td>Manual</td>
      <td>A</td>
      <td>2024-04-25 17:56:55.506784+308</td>
      <td>1</td>
  
      <td className='btnDropMenu'>              
      <CrudeEdmodel/> 
      </td>


      </tr>


      <tr className='align-middle'>
      <td>10</td>
      <td>AED-GBP</td>
      <td>AED</td>
      <td>GBP</td>
      <td>5.79</td>
      <td>%	</td>
      <td>1.01</td>
      <td>5.8479</td>
      <td>2024-04-25 17:56:55.506784+308</td>
      <td>All</td>
      <td>UK Pound</td>
      <td>All</td>



      <td>Manual</td>
      <td>A</td>
      <td>2024-04-25 17:56:55.506784+308</td>
      <td>1</td>
  
      <td className='btnDropMenu'>              
      <CrudeEdmodel/> 
      </td>


      </tr>



  
      </tbody>
      </table>
      </div>
      </div>
  
      </div>
  
      <div className="row align-items-center">
  
        <div className="col-lg-8">
        <Paging/>
        </div>
  
        <div className="col-lg-4">
  
        <ViewPerPage/>
  
  </div> 
  
  
  
              
  
  
      </div>
  
  
  </section>
 </div>

    </MainLayout>

    </>


  )
}
