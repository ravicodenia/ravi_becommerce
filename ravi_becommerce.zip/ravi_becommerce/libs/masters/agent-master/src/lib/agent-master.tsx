import { MainLayout } from '@mfa-travel-app/layout';
import AgentMasterTabs from './components/agent-master-tabs';

export const AgentMaster = () => {
    return (
        <MainLayout>
            <div className="container">
                <section className="master_section">
                    <AgentMasterTabs />
                </section>
            </div>
        </MainLayout>
    );
}

export default AgentMaster;
