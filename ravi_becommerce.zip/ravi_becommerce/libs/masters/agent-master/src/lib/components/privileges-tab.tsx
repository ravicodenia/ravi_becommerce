import * as React from 'react';
import PrivilegesSection from './privileges-section';
import { RootState, useAgentMasterStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { createAgentMaster } from '../service/privileges-section-api';
import { Loader } from '@mfa-travel-app/ui';
import { toast } from 'react-toastify';
import { API_ERROR_TOAST_TEXT } from '@mfa-travel-app/shared';
import { ABOUT_TAB } from '../service/constants';

const PrivilegesTab = () => {
    const [loader, setLoader] = React.useState(false);
    const { updatedAgentMasterData, agentMasterTabsData } = useSelector((state: RootState) => state.agentMaster);

    const { saveAgentMasterTabsData } = useAgentMasterStore();

    const isSaveButtonDisabled = () => {
        if (agentMasterTabsData?.isAboutTabCompleted &&
            agentMasterTabsData?.isFinanceTabCompleted &&
            agentMasterTabsData?.isProductsTabCompleted
        ) {
            return false;
        }

        return true;
    }

    const handleSaveAgentMaster = async (e: any) => {
        e.preventDefault();
        let agentSuppliers = structuredClone(updatedAgentMasterData?.agentSuppliers?.flat());
        let agentSuppliersForPayload = agentSuppliers?.map((supplier: any) => {
            if (supplier.supplierCheckbox) {
                supplier.supplierId = JSON.parse(JSON.stringify(supplier.id));
                supplier.id = undefined;
                return supplier;
            }

            return undefined;
        }).filter(Boolean);

        let payload = structuredClone(updatedAgentMasterData);
        payload.agentDocs?.forEach((doc: any) => {
            delete doc.mandatoryFile;
            delete doc.mandatoryDate;
        });

        payload.agentSuppliers = agentSuppliersForPayload;
        payload.agentDocs = structuredClone(payload.agentDocs?.filter((d: any) => Object.keys(d).length !== 0));
        payload.agentFOPs = structuredClone(payload.agentFOPs?.filter((p: any) => Object.keys(p).length !== 0));

        try {
            setLoader(true);
            const response: any = await createAgentMaster(payload);

            if (response?.data?.statusCode === 200) {
                let tabsData = structuredClone(agentMasterTabsData);
                tabsData.clearAgentMaster = true;
                tabsData.isAboutTabCompleted = false;
                tabsData.isFinanceTabCompleted = false;
                tabsData.isProductsTabCompleted = false;
                tabsData.activeTab = ABOUT_TAB;

                saveAgentMasterTabsData(tabsData);
                setLoader(false);
                toast.success(response?.data?.message);
            } else {
                setLoader(false);
                toast.error(response?.data?.message);
            }
        } catch (error) {
            setLoader(false);
            console.error('An error occurred:', error);
            toast.error(API_ERROR_TOAST_TEXT);
        }
    }

    return (
        <form onSubmit={handleSaveAgentMaster}>
            <div className="row">
                <div className="col-12">
                    <div className="innerContainer border-end-0">

                        <div className="wrapper">

                            <div className="row">
                                <div className="col-12"> <h5>Agent Master </h5> </div>
                            </div>

                            <div className="row">
                                <div className="col-12">
                                    <div className="form_heading">
                                        <span className="title">Privileges</span>
                                    </div>
                                </div>
                            </div>

                            <PrivilegesSection />

                            <div className="text-end mt-4 mb-4">
                                <button type="submit" disabled={isSaveButtonDisabled()} className="btn btn-primary rounded"><i className="fa-solid fa-download"></i> SAVE</button>
                            </div>

                        </div>

                    </div>
                </div>
            </div>

            {loader && <Loader />}
        </form>
    );
}

export default PrivilegesTab;