import { ControlledInput, ControlledSelect } from '@mfa-travel-app/ui';
import { RootState, useAgentMasterStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';

const ContactSection = () => {
    const { updatedAgentMasterData } = useSelector((state: RootState) => state.agentMaster);
    const { contactTypeList, salutationList } = useSelector((state: RootState) => state.mastersDropdown);

    const { saveUpdatedAgentMaster } = useAgentMasterStore();

    const handleAddPoc = () => {
        let agentMaster = structuredClone(updatedAgentMasterData);
        agentMaster.agentPOCs.push({});

        saveUpdatedAgentMaster(agentMaster);
    }

    const handleDeletePoc = (index: any) => {
        let agentMaster = structuredClone(updatedAgentMasterData);
        agentMaster.agentPOCs.splice(index, 1);

        saveUpdatedAgentMaster(agentMaster);
    }

    const handleAgentMasterContactSectionChanges = (index: number, value: any, param: string) => {
        let agentMaster = structuredClone(updatedAgentMasterData);
        agentMaster.agentPOCs[index][param] = value;

        saveUpdatedAgentMaster(agentMaster);
    }

    return (
        <>
            <div className="row">
                <div className="col-12">
                    <div className="form_heading">
                        <span className="title">Point of Contact</span>
                    </div>
                </div>
            </div>

            {
                updatedAgentMasterData?.agentPOCs?.map((poc: any, index: any) => {
                    return (
                        <div key={index}>
                            <div className="row mb-2 align-items-center" style={{ display: updatedAgentMasterData?.agentPOCs?.length > 1 ? '' : 'none' }}>
                                <div className="col-sm-6">
                                    {index + 1}.
                                </div>
                                <div className="col-sm-6 text-end">
                                    <button type="button" onClick={() => handleDeletePoc(index)} className="btn btn-danger rounded mt-2"><i className="fa-solid fa-trash"></i> Delete </button>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-lg-6">
                                    <div className="row mb-2">
                                        <label htmlFor={`contact-type-${index}`} className="col-sm-4 col-form-label">Contact Type <span className="text-danger">*</span> :</label>
                                        <div className="col-sm-8">
                                            <ControlledSelect
                                                id={`contact-type-${index}`}
                                                value={poc.fieldTypeId ? poc.fieldTypeId : ''}
                                                options={contactTypeList}
                                                required={true}
                                                onChange={(e: any) => handleAgentMasterContactSectionChanges(index, Number(e.target.value), 'fieldTypeId')}
                                            />
                                        </div>
                                    </div>

                                    <div className="row mb-2">
                                        <label htmlFor={`salutation-${index}`} className="col-sm-4 col-form-label">Salutation <span className="text-danger">*</span> :</label>
                                        <div className="col-sm-8">
                                            <ControlledSelect
                                                id={`salutation-${index}`}
                                                value={poc.title ? poc.title : ''}
                                                options={salutationList}
                                                required={true}
                                                onChange={(e: any) => handleAgentMasterContactSectionChanges(index, e.target.value, 'title')}
                                            />
                                        </div>
                                    </div>

                                    <div className="row mb-2">
                                        <label htmlFor={`firstname-${index}`} className="col-sm-4 col-form-label">First Name <span className="text-danger">*</span> :</label>
                                        <div className="col-sm-8">
                                            <ControlledInput
                                                id={`firstname-${index}`}
                                                value={poc.firstName ? poc.firstName : ''}
                                                type={'text'}
                                                required={true}
                                                onChange={(e: any) => handleAgentMasterContactSectionChanges(index, e.target.value, 'firstName')}
                                            />
                                        </div>
                                    </div>

                                    <div className="row mb-2">
                                        <label htmlFor={`lastname-${index}`} className="col-sm-4 col-form-label">Last Name <span className="text-danger">*</span> :</label>
                                        <div className="col-sm-8">
                                            <ControlledInput
                                                id={`lastname-${index}`}
                                                value={poc.lastName ? poc.lastName : ''}
                                                type={'text'}
                                                required={true}
                                                onChange={(e: any) => handleAgentMasterContactSectionChanges(index, e.target.value, 'lastName')}
                                            />
                                        </div>
                                    </div>
                                </div>

                                <div className="col-lg-6">
                                    <div className="row mb-2">
                                        <label htmlFor={`land-phone-${index}`} className="col-sm-4 col-form-label">Land Phone <span className="text-danger">*</span> :</label>
                                        <div className="col-sm-8">
                                            <ControlledInput
                                                id={`land-phone-${index}`}
                                                value={poc.landPhone ? poc.landPhone : ''}
                                                type={'number'}
                                                required={true}
                                                onChange={(e: any) => handleAgentMasterContactSectionChanges(index, e.target.value, 'landPhone')}
                                            />
                                        </div>
                                    </div>

                                    <div className="row mb-2">
                                        <label htmlFor={`mobile-${index}`} className="col-sm-4 col-form-label">Mobile <span className="text-danger">*</span> :</label>
                                        <div className="col-sm-8">
                                            <ControlledInput
                                                id={`mobile-${index}`}
                                                value={poc.mobile ? poc.mobile : ''}
                                                type={'number'}
                                                required={true}
                                                onChange={(e: any) => handleAgentMasterContactSectionChanges(index, e.target.value, 'mobile')}
                                            />
                                        </div>
                                    </div>

                                    <div className="row mb-2">
                                        <label htmlFor={`email-${index}`} className="col-sm-4 col-form-label">Email <span className="text-danger">*</span> :</label>
                                        <div className="col-sm-8">
                                            <ControlledInput
                                                id={`email-${index}`}
                                                value={poc.email ? poc.email : ''}
                                                type={'text'}
                                                required={true}
                                                onChange={(e: any) => handleAgentMasterContactSectionChanges(index, e.target.value, 'email')}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )
                })
            }

            <div className="row mb-2" style={{ display: updatedAgentMasterData?.agentPOCs?.length > 2 ? 'none' : '' }}>
                <div className="col-sm-12 text-end">
                    <button type="button" onClick={handleAddPoc} className="btn btn-primary rounded mt-2"><i className="fa-solid fa-plus"></i> ADD </button>
                </div>
            </div>
        </>
    );
}

export default ContactSection;