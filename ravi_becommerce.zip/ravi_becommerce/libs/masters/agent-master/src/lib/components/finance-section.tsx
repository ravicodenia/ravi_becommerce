import { ControlledDatePicker, ControlledInput, ControlledRadioButton, ControlledSelect } from '@mfa-travel-app/ui';
import { RootState, useAgentMasterStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { convertDateForApi } from '@mfa-travel-app/shared';

const FinanceSection = () => {
    const { updatedAgentMasterData } = useSelector((state: RootState) => state.agentMaster);
    const { paymentTypeList, securityTypeList, payPeriodList } = useSelector((state: RootState) => state.mastersDropdown);

    const { saveUpdatedAgentMaster } = useAgentMasterStore();

    const handleAgentMasterFinanceSectionChanges = (index: number, value: any, param: string) => {
        let agentMaster = structuredClone(updatedAgentMasterData);
        agentMaster.agentFinances[index][param] = value;

        saveUpdatedAgentMaster(agentMaster);
    }

    return (
        <>
            <div className="row">
                <div className="col-12">
                    <div className="form_heading">
                        <span className="title">Finance Details</span>
                    </div>
                </div>
            </div>

            {
                updatedAgentMasterData?.agentFinances?.map((finance: any, index: any) => {
                    return (
                        <div className="row" key={index}>
                            <div className="col-lg-6">

                                <div className="row mb-2">
                                    <label htmlFor={`payment-type-${index}`} className="col-sm-5 col-form-label">Payment Type <span className="text-danger">*</span> :</label>
                                    <div className="col-sm-7">
                                        <ControlledSelect
                                            id={`payment-type-${index}`}
                                            value={finance.paymentTypeFieldTypeId ? finance.paymentTypeFieldTypeId : ''}
                                            options={paymentTypeList}
                                            required={true}
                                            onChange={(e: any) => handleAgentMasterFinanceSectionChanges(index, Number(e.target.value), 'paymentTypeFieldTypeId')}
                                        />
                                    </div>
                                </div>

                                <div className="row mb-2">
                                    <label htmlFor={`credit-limit-${index}`} className="col-sm-5 col-form-label">Credit Limit <span className="text-danger">*</span> :</label>
                                    <div className="col-sm-7">
                                        <ControlledInput
                                            id={`credit-limit-${index}`}
                                            value={finance.creditLimit ? finance.creditLimit : ''}
                                            type={'number'}
                                            required={true}
                                            onChange={(e: any) => handleAgentMasterFinanceSectionChanges(index, e.target.value, 'creditLimit')}
                                        />
                                    </div>
                                </div>

                                <div className="row mb-2">
                                    <label htmlFor={`credit-alert-${index}`} className="col-sm-5 col-form-label">Credit Alert% <span className="text-danger">*</span> :</label>
                                    <div className="col-sm-7">
                                        <ControlledInput
                                            id={`credit-alert-${index}`}
                                            value={finance.creditLimitAlert ? finance.creditLimitAlert : ''}
                                            type={'number'}
                                            required={true}
                                            onChange={(e: any) => handleAgentMasterFinanceSectionChanges(index, e.target.value, 'creditLimitAlert')}
                                        />
                                    </div>
                                </div>

                                <div className="row mb-2 items-align-center radio_grp">
                                    <label htmlFor={`security-type-${index}`} className="col-sm-5 col-form-label">Credit Security Type <span className="text-danger">*</span> :</label>
                                    <div className="col-sm-7">
                                        <ControlledRadioButton 
                                            name={`security-type-${index}`}
                                            value={finance.security ? finance.security : null}
                                            options={securityTypeList}
                                            required={true}
                                            onChange={(value: any) => handleAgentMasterFinanceSectionChanges(index, value, 'security')}
                                        />
                                    </div>
                                </div>

                                <div className="row mb-2">
                                    <label htmlFor={`temp-credit-limit-${index}`} className="col-sm-5 col-form-label">Temp Credit Limit <span className="text-danger">*</span> :</label>
                                    <div className="col-sm-7">
                                        <ControlledInput
                                            id={`temp-credit-limit-${index}`}
                                            value={finance.tempCreditLimit ? finance.tempCreditLimit : ''}
                                            type={'number'}
                                            required={true}
                                            onChange={(e: any) => handleAgentMasterFinanceSectionChanges(index, e.target.value, 'tempCreditLimit')}
                                        />
                                    </div>
                                </div>
                            </div>

                            <div className="col-lg-6">

                                <div className="row mb-2">
                                    <label htmlFor={`temp-credit-sdate-${index}`} className="col-sm-5 col-form-label">Temp Credit Limit Start Date <span className="text-danger">*</span> :</label>
                                    <div className="col-sm-7">
                                        <ControlledDatePicker
                                            id={`temp-credit-sdate-${index}`}
                                            value={finance.tempStart ? finance.tempStart : null}
                                            format={'dd/MMM/yyyy'}
                                            disablePastDates={true}
                                            isClearable={true}
                                            required={true}
                                            onChange={(date: any) => handleAgentMasterFinanceSectionChanges(index, convertDateForApi(date), 'tempStart')}
                                        />
                                    </div>
                                </div>

                                <div className="row mb-2">
                                    <label htmlFor={`temp-credit-edate-${index}`} className="col-sm-5 col-form-label">Temp Credit Limit End Date <span className="text-danger">*</span> :</label>
                                    <div className="col-sm-7">
                                        <ControlledDatePicker
                                            id={`temp-credit-edate-${index}`}
                                            value={finance.tempEnd ? finance.tempEnd : null}
                                            format={'dd/MMM/yyyy'}
                                            disablePastDates={true}
                                            isClearable={true}
                                            required={true}
                                            onChange={(date: any) => handleAgentMasterFinanceSectionChanges(index, convertDateForApi(date), 'tempEnd')}
                                        />
                                    </div>
                                </div>

                                <div className="row mb-2">
                                    <label htmlFor={`pay-period-${index}`} className="col-sm-5 col-form-label">Pay Period <span className="text-danger">*</span> :</label>
                                    <div className="col-sm-7">
                                        <ControlledSelect
                                            id={`pay-period-${index}`}
                                            value={finance.payPeriodFieldTypeId ? finance.payPeriodFieldTypeId : ''}
                                            options={payPeriodList}
                                            required={true}
                                            onChange={(e: any) => handleAgentMasterFinanceSectionChanges(index, Number(e.target.value), 'payPeriodFieldTypeId')}
                                        />
                                    </div>
                                </div>

                                <div className="row text-center">
                                    <div className="col-sm-12 mt-4 mb-1">
                                        <a className="link_underlined" href="#">Temp Credit Limit History</a>
                                    </div>

                                    <div className="col-sm-12">
                                        <a className="link_underlined" href="#">Cash Payment History</a>
                                    </div>
                                </div>

                            </div>
                        </div>
                    )
                })
            }
        </>
    );
}

export default FinanceSection;