import * as React from 'react';
import { ControlledFileInput, Loader } from '@mfa-travel-app/ui';
import { RootState, useAgentMasterStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import { API_ERROR_TOAST_TEXT, ERROR_IN_FILE_UPLOAD, ILLEGAL_DOCUMENT_UPLOADED_ALERT, SUCCESS_TOAST_TEXT } from '@mfa-travel-app/shared';
import { uploadLogo } from '../service/documents-section-api';

const UploadSection = () => {
    const [loader, setLoader] = React.useState(false);
    const { updatedAgentMasterData } = useSelector((state: RootState) => state.agentMaster);
    const { saveUpdatedAgentMaster } = useAgentMasterStore();

    const handleAgentMasterUploadSectionChanges = async (value: any, param: string) => {
        let agentMaster = structuredClone(updatedAgentMasterData);

        if (param === 'logoPath') {
            if (value.target.files[0]) {
                if (!'image/jpeg image/png image/svg+xml'.includes(value.target.files[0]?.type)) {
                    toast.warning(`${ILLEGAL_DOCUMENT_UPLOADED_ALERT} jpg, png, svg.`);
                    value.target.value = null;
                    return;
                }

                const formData = new FormData();
                formData.append('file', value.target.files[0]);

                try {
                    setLoader(true);
                    const response: any = await uploadLogo(formData, agentMaster?.agentDocGuid);

                    if (response?.status === 200 && response?.data?.documentUrl) {
                        agentMaster[param] = response?.data?.documentUrl;

                        setLoader(false);
                        toast.success(SUCCESS_TOAST_TEXT);
                    } else {
                        setLoader(false);
                        toast.error(ERROR_IN_FILE_UPLOAD);
                    }
                } catch (error) {
                    setLoader(false);
                    console.error('An error occurred:', error);
                    toast.error(API_ERROR_TOAST_TEXT);
                }
            } else {
                // remove details of uploaded file if any
                agentMaster[param] = undefined;
            }
        }

        saveUpdatedAgentMaster(agentMaster);
    }

    return (
        <>
            <div className="row">
                <div className="col-12 mt-3"> <h5>Upload Logo files </h5> </div>
            </div>

            <div className="row">
                <div className="col-12">
                    <div className="form-group fileuplaod_section">
                        <ControlledFileInput
                            id={'logo-upload'}
                            accept={'image/jpeg, image/png, image/svg+xml'}
                            onChange={(file: any) => handleAgentMasterUploadSectionChanges(file, 'logoPath')}
                        />
                        <p className="text-start">Supported formates: JPG, PNG, SVG</p>
                    </div>
                </div>
            </div>

            {loader && <Loader />}
        </>
    );
}

export default UploadSection;