import { NO_FORM_OF_PAYMENT_ALERT } from '@mfa-travel-app/shared';
import { PRODUCTS_TAB } from '../service/constants';
import FinanceSection from './finance-section';
import PaymentSection from './payment-section';
import { RootState, useAgentMasterStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';

const FinanceTab = () => {
    const { updatedAgentMasterData, agentMasterTabsData } = useSelector((state: RootState) => state.agentMaster);
    const { saveAgentMasterTabsData } = useAgentMasterStore();

    const moveToNextTab = (e: any) => {
        e.preventDefault();
        let isNoFormOfPaymentSelected = true;

        updatedAgentMasterData?.agentFOPs?.forEach((payment: any) => {
            if (payment.settlementTypeFieldTypeId && payment.settlementTypeFieldTypeId !== 0) {
                isNoFormOfPaymentSelected = false;
            }
        });

        if (isNoFormOfPaymentSelected) {
            toast.warning(NO_FORM_OF_PAYMENT_ALERT);
            return;
        }

        let tabsData = JSON.parse(JSON.stringify(agentMasterTabsData));
        tabsData.activeTab = PRODUCTS_TAB;
        tabsData.isFinanceTabCompleted = true;

        saveAgentMasterTabsData(tabsData);
    }

    return (
        <form onSubmit={moveToNextTab}>
            <div className="row">
                <div className="col-12">
                    <div className="innerContainer border-end-0">
                        <div className="row">

                            <div className="col-lg-12">
                                <div className="wrapper">

                                    <div className="row">
                                        <div className="col-12"> <h5>Agent Master </h5> </div>
                                    </div>

                                    <FinanceSection />

                                    <PaymentSection />

                                    <div className="text-end mx-5">
                                        <button type="submit" className="btn btn-primary rounded mt-4 mb-4">CONTINUE <i className="fa-solid fa-chevron-right"></i></button>
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </form>
    );
}

export default FinanceTab;