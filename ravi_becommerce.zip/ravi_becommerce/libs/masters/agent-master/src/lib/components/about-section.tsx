import * as React from 'react';
import { ControlledDatePicker, ControlledInput, ControlledSelect, ControlledSwitch, Loader } from '@mfa-travel-app/ui';
import { RootState, useAgentMasterStore, useMastersDropdownStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { convertDateForApi, getCityOptionsByStateId, getStateOptionsByCountryId } from '@mfa-travel-app/shared';
import { useTimezoneSelect } from 'react-timezone-select';

const AboutSection = () => {
    const [loader, setLoader] = React.useState(false);
    const { updatedAgentMasterData } = useSelector((state: RootState) => state.agentMaster);
    const { agentTypeList, countryList, stateListByCountry, cityListByState, languageList, currencyList, parentAgentList, timezoneList, agentCategoryList } = useSelector((state: RootState) => state.mastersDropdown);

    const { saveUpdatedAgentMaster } = useAgentMasterStore();
    const { saveStateListByCountry, saveCityListByState, saveTimezoneList } = useMastersDropdownStore();
    const { options } = useTimezoneSelect({ labelStyle: 'original' });

    React.useEffect(() => {
        if (timezoneList.length === 0) {
            let timezones = JSON.parse(JSON.stringify(options));

            let timezoneList = timezones?.map((item: any) => {
                return {
                    id: item.label,
                    text: item.label
                }
            });
    
            saveTimezoneList(timezoneList);
        }
    }, []);

    const handleAgentMasterAboutSectionChanges = (value: any, param: string) => {
        let agentMaster = structuredClone(updatedAgentMasterData);
        agentMaster[param] = value;

        saveUpdatedAgentMaster(agentMaster);
    }

    const handleAgentMasterCountryOrStateChanges = async (value: number, param: string) => {
        let agentMaster = structuredClone(updatedAgentMasterData);
        agentMaster[param] = value;

        if (param === 'countryId' && value === 0) {
            agentMaster.stateId = '';
            agentMaster.cityId = '';
        } else if (param === 'stateId' && value === 0) {
            agentMaster.cityId = '';
        }

        saveUpdatedAgentMaster(agentMaster);

        if (value) {
            setLoader(true);
            if (param === 'countryId') {
                saveStateListByCountry(await getStateOptionsByCountryId(value));
                setLoader(false);
            } else if (param === 'stateId') {
                saveCityListByState(await getCityOptionsByStateId(value));
                setLoader(false);
            }
        } else {
            if (param === 'countryId') {
                saveStateListByCountry([]);
                saveCityListByState([]);
            } else if (param === 'stateId') {
                saveCityListByState([]);
            }
        }
    }

    return (
        <>
            <div className="row">
                <div className="col-12">
                    <div className="form_heading">
                        <span className="title">About</span>
                    </div>
                </div>
            </div>

            <div className="row">
                <div className="col-lg-6">
                    <div className="row mb-2">
                        <label htmlFor="agent-type" className="col-sm-4 col-form-label">Agent Type <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledSelect
                                id={'agent-type'}
                                value={updatedAgentMasterData.type ? updatedAgentMasterData.type : ''}
                                options={agentTypeList}
                                required={true}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(e.target.value, 'type')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2">
                        <label htmlFor="name" className="col-sm-4 col-form-label">Name <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledInput
                                id={'name'}
                                value={updatedAgentMasterData.name ? updatedAgentMasterData.name : ''}
                                type={'text'}
                                required={true}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(e.target.value, 'name')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2">
                        <label htmlFor="address-line-1" className="col-sm-4 col-form-label">Address Line1 <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledInput
                                id={'address-line-1'}
                                value={updatedAgentMasterData.address1 ? updatedAgentMasterData.address1 : ''}
                                type={'text'}
                                required={true}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(e.target.value, 'address1')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2">
                        <label htmlFor="address-line-2" className="col-sm-4 col-form-label">Address Line2 :</label>
                        <div className="col-sm-8">
                            <ControlledInput
                                id={'address-line-2'}
                                value={updatedAgentMasterData.address2 ? updatedAgentMasterData.address2 : ''}
                                type={'text'}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(e.target.value, 'address2')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2">
                        <label htmlFor="country" className="col-sm-4 col-form-label">Country <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledSelect
                                id={'country'}
                                value={updatedAgentMasterData.countryId ? updatedAgentMasterData.countryId : ''}
                                options={countryList}
                                required={true}
                                onChange={(e: any) => handleAgentMasterCountryOrStateChanges(Number(e.target.value), 'countryId')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2">
                        <label htmlFor="state" className="col-sm-4 col-form-label">State <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledSelect
                                id={'state'}
                                value={updatedAgentMasterData.stateId ? updatedAgentMasterData.stateId : ''}
                                options={stateListByCountry}
                                required={true}
                                onChange={(e: any) => handleAgentMasterCountryOrStateChanges(Number(e.target.value), 'stateId')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2">
                        <label htmlFor="city" className="col-sm-4 col-form-label">City <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledSelect
                                id={'city'}
                                value={updatedAgentMasterData.cityId ? updatedAgentMasterData.cityId : ''}
                                options={cityListByState}
                                required={true}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(Number(e.target.value), 'cityId')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2 align-items-center">
                        <label htmlFor="business-regist" className="col-sm-4 col-form-label">Business Registration <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledInput
                                id={'business-regist'}
                                value={updatedAgentMasterData.registration ? updatedAgentMasterData.registration : ''}
                                type={'text'}
                                required={true}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(e.target.value, 'registration')}
                            />
                        </div>
                    </div>

                    <div className="row mb-2 align-items-center">
                        <label htmlFor="authorized-person" className="col-sm-4 col-form-label">Authorized Person<span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledInput
                                id={'authorized-person'}
                                value={updatedAgentMasterData.authorizedPerson ? updatedAgentMasterData.authorizedPerson : ''}
                                type={'text'}
                                required={true}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(e.target.value, 'authorizedPerson')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2 align-items-center">
                        <label htmlFor="date-incorp" className="col-sm-4 col-form-label">Date of Incorporation<span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledDatePicker
                                id={'date-incorp'}
                                value={updatedAgentMasterData.doi ? updatedAgentMasterData.doi : null}
                                format={'dd/MMM/yyyy'}
                                disablePastDates={true}
                                isClearable={true}
                                required={true}
                                onChange={(date: any) => handleAgentMasterAboutSectionChanges(convertDateForApi(date), 'doi')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2 align-items-center">
                        <label htmlFor="preferred-lang" className="col-sm-4 col-form-label">Preferred Language <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledSelect
                                id={'preferred-lang'}
                                value={updatedAgentMasterData.languageId ? updatedAgentMasterData.languageId : ''}
                                options={languageList}
                                required={true}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(Number(e.target.value), 'languageId')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2">
                        <label htmlFor="business-currency" className="col-sm-4 col-form-label">Business Currency <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledSelect
                                id={'business-currency'}
                                value={updatedAgentMasterData.currencyId ? updatedAgentMasterData.currencyId : ''}
                                options={currencyList}
                                required={true}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(Number(e.target.value), 'currencyId')}
                            />
                        </div>
                    </div>

                    <div className="row mb-2">
                        <label htmlFor="remarks" className="col-sm-4 col-form-label">Remarks :</label>
                        <div className="col-sm-8">
                            <ControlledInput
                                id={'remarks'}
                                value={updatedAgentMasterData.remarks ? updatedAgentMasterData.remarks : ''}
                                type={'text'}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(e.target.value, 'remarks')}
                            />
                        </div>
                    </div>
                </div>

                <div className="col-lg-6">
                    <div className="row mb-2">
                        <label htmlFor="agent-code" className="col-sm-4 col-form-label">Agent Code <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledInput
                                id={'agent-code'}
                                value={updatedAgentMasterData.code ? updatedAgentMasterData.code : ''}
                                type={'text'}
                                required={true}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(e.target.value, 'code')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2">
                        <label htmlFor="parent-agent" className="col-sm-4 col-form-label">Parent Agent <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledSelect
                                id={'parent-agent'}
                                value={updatedAgentMasterData.parentAgentId ? updatedAgentMasterData.parentAgentId : ''}
                                options={parentAgentList}
                                required={true}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(Number(e.target.value), 'parentAgentId')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2 align-items-center">
                        <label htmlFor="is-iata" className="col-sm-4 col-form-label">Is IATA <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledSwitch
                                id={'is-iata'}
                                isChecked={updatedAgentMasterData.isiata ? updatedAgentMasterData.isiata : false}
                                onChange={(value: any) => handleAgentMasterAboutSectionChanges(value, 'isiata')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2">
                        <label htmlFor="iata-code" className="col-sm-4 col-form-label">IATA Code <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledInput
                                id={'iata-code'}
                                value={updatedAgentMasterData.iataCode ? updatedAgentMasterData.iataCode : ''}
                                type={'text'}
                                required={true}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(e.target.value, 'iataCode')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2">
                        <label htmlFor="po-box" className="col-sm-4 col-form-label">P.O Box <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledInput
                                id={'po-box'}
                                value={updatedAgentMasterData.poBox ? updatedAgentMasterData.poBox : ''}
                                type={'text'}
                                required={true}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(e.target.value, 'poBox')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2">
                        <label htmlFor="land-phone" className="col-sm-4 col-form-label">Land Phone <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledInput
                                id={'land-phone'}
                                value={updatedAgentMasterData.landPhone ? updatedAgentMasterData.landPhone : ''}
                                type={'number'}
                                required={true}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(e.target.value, 'landPhone')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2">
                        <label htmlFor="mobile" className="col-sm-4 col-form-label">Mobile <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledInput
                                id={'mobile'}
                                value={updatedAgentMasterData.mobile ? updatedAgentMasterData.mobile : ''}
                                type={'number'}
                                required={true}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(e.target.value, 'mobile')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2">
                        <label htmlFor="fax" className="col-sm-4 col-form-label">Fax <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledInput
                                id={'fax'}
                                value={updatedAgentMasterData.fax ? updatedAgentMasterData.fax : ''}
                                type={'number'}
                                required={true}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(e.target.value, 'fax')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2">
                        <label htmlFor="email" className="col-sm-4 col-form-label">Email <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledInput
                                id={'email'}
                                value={updatedAgentMasterData.email1 ? updatedAgentMasterData.email1 : ''}
                                type={'text'}
                                required={true}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(e.target.value, 'email1')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2">
                        <label htmlFor="alt-email" className="col-sm-4 col-form-label">Alternate Email <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledInput
                                id={'alt-email'}
                                value={updatedAgentMasterData.email2 ? updatedAgentMasterData.email2 : ''}
                                type={'text'}
                                required={true}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(e.target.value, 'email2')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2">
                        <label htmlFor="website" className="col-sm-4 col-form-label">Website <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledInput
                                id={'website'}
                                value={updatedAgentMasterData.website ? updatedAgentMasterData.website : ''}
                                type={'text'}
                                required={true}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(e.target.value, 'website')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2">
                        <label htmlFor="timezone" className="col-sm-4 col-form-label">Time Zone <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledSelect
                                id={'timezone'}
                                value={updatedAgentMasterData.timezone ? updatedAgentMasterData.timezone : ''}
                                options={timezoneList}
                                required={true}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(e.target.value, 'timezone')}
                            />
                        </div>
                    </div>
        
                    <div className="row mb-2">
                        <label htmlFor="agent-category" className="col-sm-4 col-form-label">Agent Category <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledSelect
                                id={'agent-category'}
                                value={updatedAgentMasterData.category ? updatedAgentMasterData.category : ''}
                                options={agentCategoryList}
                                required={true}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(e.target.value, 'category')}
                            />
                        </div>
                    </div>

                    <div className="row mb-2">
                        <label htmlFor="ledger-code" className="col-sm-4 col-form-label">Ledger Code <span className="text-danger">*</span> :</label>
                        <div className="col-sm-8">
                            <ControlledInput
                                id={'ledger-code'}
                                value={updatedAgentMasterData.ledgerCode ? updatedAgentMasterData.ledgerCode : ''}
                                type={'text'}
                                required={true}
                                onChange={(e: any) => handleAgentMasterAboutSectionChanges(e.target.value, 'ledgerCode')}
                            />
                        </div>
                    </div>
                </div>
            </div>

            {loader && <Loader />}
        </>
    );
}

export default AboutSection;