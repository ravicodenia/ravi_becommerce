import { ControlledInput, ControlledSelect } from '@mfa-travel-app/ui';
import { RootState, useAgentMasterStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';

const PrivilegesSection = () => {
    const { updatedAgentMasterData } = useSelector((state: RootState) => state.agentMaster);
    const { appConfigList } = useSelector((state: RootState) => state.mastersDropdown);

    const { saveUpdatedAgentMaster } = useAgentMasterStore();

    const isRequiredOptions = [
        { id: 'Y', text: 'Yes' },
        { id: 'N', text: 'No' },
    ];

    const handleAddPrivilege = () => {
        let agentMaster = structuredClone(updatedAgentMasterData);
        agentMaster.agentConfigs.push({});

        saveUpdatedAgentMaster(agentMaster);
    }

    const handleDeletePrivilege = (index: any) => {
        let agentMaster = structuredClone(updatedAgentMasterData);
        agentMaster.agentConfigs.splice(index, 1);

        saveUpdatedAgentMaster(agentMaster);
    }

    const handleAgentMasterPrivilegesSectionChanges = (index: number, value: any, param: string) => {
        let agentMaster = structuredClone(updatedAgentMasterData);
        agentMaster.agentConfigs[index][param] = value;

        if (param === 'appConfigId') {
            let privilegeDetail = appConfigList?.find((p: any) => p.id === value);

            agentMaster.agentConfigs[index].appDescription = privilegeDetail.appDescription;
            agentMaster.agentConfigs[index].parentMenuItemId = privilegeDetail.parentMenuItemId;
            agentMaster.agentConfigs[index].parentFunctionType = 'dummy';
        }

        saveUpdatedAgentMaster(agentMaster);
    }

    return (
        <>
            {
                updatedAgentMasterData?.agentConfigs?.map((config: any, index: any) => {
                    return (
                        <div className="row" key={index}>

                            <div className="col-sm-4">
                                <div className="row mb-2">
                                    <label htmlFor={`app-key-${index}`} className="col-sm-4 col-form-label">App Key <span className="text-danger">*</span> :</label>
                                    <div className="col-sm-8">
                                        <ControlledSelect
                                            id={`app-key-${index}`}
                                            value={config.appConfigId ? config.appConfigId : ''}
                                            options={appConfigList}
                                            required={true}
                                            onChange={(e: any) => handleAgentMasterPrivilegesSectionChanges(index, Number(e.target.value), 'appConfigId')}
                                        />
                                    </div>
                                </div>
                            </div>

                            <div className="col-sm-4">
                                <div className="row mb-2">
                                    <label htmlFor={`app-description-${index}`} className="col-sm-4 col-form-label">App Description :</label>
                                    <div className="col-sm-8">
                                        <ControlledInput
                                            id={`app-description-${index}`}
                                            value={config.appDescription ? config.appDescription : ''}
                                            type={'text'}
                                            disabled={true}
                                            onChange={(e: any) => handleAgentMasterPrivilegesSectionChanges(index, e.target.value, 'appDescription')}
                                        />
                                    </div>
                                </div>
                            </div>


                            <div className="col-sm-3">
                                <div className="row mb-2">
                                    <label htmlFor={`app-value-${index}`} className="col-sm-4 col-form-label">App Value <span className="text-danger">*</span> :</label>
                                    <div className="col-sm-8">
                                        <ControlledSelect
                                            id={`app-value-${index}`}
                                            value={config.isRequired !== undefined ? config.isRequired ? 'Y' : 'N' : ''}
                                            options={isRequiredOptions}
                                            required={true}
                                            onChange={(e: any) => handleAgentMasterPrivilegesSectionChanges(index, e.target.value === 'Y' ? true : false, 'isRequired')}
                                        />
                                    </div>
                                </div>
                            </div>

                            <div className="col-sm-1">
                                <div className="row mb-2">
                                    <div className="text-end" style={{ display: updatedAgentMasterData?.agentConfigs?.length > 1 ? '' : 'none' }}>
                                        <button type="button" onClick={() => handleDeletePrivilege(index)} className="btn btn-danger rounded mt-2"><i className="fa-solid fa-trash"></i></button>
                                    </div>
                                </div>
                            </div>

                        </div>
                    )
                })
            }

            <div className="text-end mt-4 mb-4">
                <button type="button" onClick={handleAddPrivilege} className="btn btn-primary rounded"><i className="fa-solid fa-plus"></i> ADD </button>
            </div>
        </>

    );
}

export default PrivilegesSection;