import * as React from 'react';
import { ControlledDatePicker, ControlledFileInput, Loader } from '@mfa-travel-app/ui';
import { RootState, useAgentMasterStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { AGENT_BUCKET_NAME } from '../service/constants';
import { toast } from 'react-toastify';
import { API_ERROR_TOAST_TEXT, convertDateForApi, ERROR_IN_FILE_PREVIEW, ERROR_IN_FILE_UPLOAD, ILLEGAL_DOCUMENT_UPLOADED_ALERT, LARGE_FILE_SIZE_ALERT, SUCCESS_TOAST_TEXT } from '@mfa-travel-app/shared';
import { previewDocument, uploadDocument } from '../service/documents-section-api';

const DocumentsSection = () => {
    const [loader, setLoader] = React.useState(false);
    const { updatedAgentMasterData, documentList } = useSelector((state: RootState) => state.agentMaster);
    const { saveUpdatedAgentMaster } = useAgentMasterStore();

    const mimeTypeList = [
        { fileExtension: 'jpg', mimeType: 'image/jpeg' },
        { fileExtension: 'jpeg', mimeType: 'image/jpeg' },
        { fileExtension: 'png', mimeType: 'image/png' },
        { fileExtension: 'gif', mimeType: 'image/gif' },
        { fileExtension: 'svg', mimeType: 'image/svg+xml' },
        { fileExtension: 'pdf', mimeType: 'application/pdf' },
        { fileExtension: 'txt', mimeType: 'text/plain' },
        { fileExtension: 'csv', mimeType: 'text/csv' },
        { fileExtension: 'doc', mimeType: 'application/msword' },
        { fileExtension: 'docx', mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' },
    ];

    const getAcceptFileMimeTypes = (fileType: string) => {
        if (fileType === null) {
            return '';
        }

        let mimeTypes = fileType.split(' ').join('').split(',')?.map((type: string) => {
            return mimeTypeList.find(m => m.fileExtension === type)?.mimeType;
        }).filter(Boolean);

        return mimeTypes.join(', ');
    }

    const handleAgentMasterDocumentsSectionChanges = async (index: number, docDetail: any, value: any, param: string) => {
        let agentMaster = structuredClone(updatedAgentMasterData);

        if (param === 'filePath') {
            if (value.target.files[0]) {
                if (value.target.files[0]?.size > docDetail.fileSize) {
                    toast.warning(`${LARGE_FILE_SIZE_ALERT} ${docDetail.fileSize}.`);
                    value.target.value = null;
                    return;
                }

                let mimeTypes = getAcceptFileMimeTypes(docDetail.fileType)?.split(', ');
                let legalFile = mimeTypes.find(m => m === value.target.files[0]?.type);

                if (!legalFile && value.target.files[0]) {
                    toast.warning(`${ILLEGAL_DOCUMENT_UPLOADED_ALERT} ${docDetail.fileType}.`);
                    value.target.value = null;
                    return;
                }

                let fileExtension = mimeTypeList.find(m => m.mimeType === legalFile)?.fileExtension;
                const formData = new FormData();
                formData.append('file', value.target.files[0], `${docDetail.id}.${fileExtension}`);

                try {
                    setLoader(true);
                    const response: any = await uploadDocument(formData, agentMaster?.agentDocGuid);

                    if (response?.status === 200 && response?.data?.documentUrl) {
                        agentMaster.agentDocs[index][param] = response?.data?.documentUrl;

                        agentMaster.agentDocs[index].documentId = docDetail.id;
                        agentMaster.agentDocs[index].mandatoryFile = value.target.files[0] ? docDetail.mandatory : '';

                        setLoader(false);
                    } else {
                        setLoader(false);
                        toast.error(ERROR_IN_FILE_UPLOAD);
                    }
                } catch (error) {
                    setLoader(false);
                    console.error('An error occurred:', error);
                    toast.error(API_ERROR_TOAST_TEXT);
                }
            } else {
                // remove details of uploaded file if any
                agentMaster.agentDocs[index][param] = undefined;
                agentMaster.agentDocs[index].documentId = undefined;
                agentMaster.agentDocs[index].mandatoryFile = undefined;
            }
        } else {
            agentMaster.agentDocs[index][param] = value;
            agentMaster.agentDocs[index].mandatoryDate = value ? docDetail.mandatory : '';
        }

        saveUpdatedAgentMaster(agentMaster);
    }

    const handleFilePreview = async (filePath: string) => {
        try {
            setLoader(true);
            const response: any = await previewDocument(AGENT_BUCKET_NAME, filePath);

            if (response?.status === 200 && response?.data?.documentUrl) {
                setLoader(false);
                window.open(response?.data?.documentUrl, '_blank');
            } else {
                setLoader(false);
                toast.error(ERROR_IN_FILE_PREVIEW);
            }
        } catch (error) {
            setLoader(false);
            console.error('An error occurred:', error);
            toast.error(API_ERROR_TOAST_TEXT);
        }
    }

    return (
        <>
            <div className="row">
                <div className="col-12">
                    <div className="form_heading">
                        <span className="title">Documents</span>
                    </div>
                </div>
            </div>

            <div className="row">
                {
                    documentList?.map((doc: any, index: any) => {
                        return (
                            <div className="col-12 mb-1" key={index}>
                                <div className="row">
                                    <label htmlFor={`${doc.name}-file`} className="col-sm-3 col-form-label">{doc.code} <span style={{ display: doc.mandatory === 'Y' ? '' : 'none' }} className="text-danger">*</span> :</label>
                                    <div className="col-sm-4 mb-2">
                                        <ControlledFileInput
                                            id={`${doc.name}-file`}
                                            accept={getAcceptFileMimeTypes(doc.fileType)}
                                            required={doc.mandatory === 'Y' ? true : false}
                                            onChange={(file: any) => handleAgentMasterDocumentsSectionChanges(index, doc, file, 'filePath')}
                                        />
                                    </div>

                                    <div className="col-sm-3  mb-2">
                                        <ControlledDatePicker
                                            id={`${doc.name}-file`}
                                            value={updatedAgentMasterData.agentDocs[index] === undefined ? null : updatedAgentMasterData.agentDocs[index].expiryDate}
                                            format={'dd/MMM/yyyy'}
                                            disablePastDates={true}
                                            isClearable={true}
                                            required={doc.mandatory === 'Y' ? true : false}
                                            onChange={(date: any) => handleAgentMasterDocumentsSectionChanges(index, doc, convertDateForApi(date), 'expiryDate')}
                                        />
                                    </div>

                                    <div className="col-sm-2 mb-2">
                                        <button
                                            type="button" className="btn btn-primary rounded"
                                            disabled={updatedAgentMasterData.agentDocs[index] === undefined ? true : updatedAgentMasterData.agentDocs[index].filePath ? false : true}
                                            onClick={() => handleFilePreview(updatedAgentMasterData.agentDocs[index].filePath)}
                                        >
                                            PREVIEW
                                        </button>
                                    </div>
                                </div>
                            </div>
                        )
                    })
                }
            </div>

            {loader && <Loader />}
        </>
    );
}

export default DocumentsSection;