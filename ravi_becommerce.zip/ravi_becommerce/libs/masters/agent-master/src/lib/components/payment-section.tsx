import { RootState, useAgentMasterStore } from '@mfa-travel-app/store';
import { ControlledCheckbox } from '@mfa-travel-app/ui';
import { useSelector } from 'react-redux';

const PaymentSection = () => {
    const { updatedAgentMasterData, formOfPaymentList } = useSelector((state: RootState) => state.agentMaster);
    const { saveUpdatedAgentMaster } = useAgentMasterStore();

    const handleAgentMasterPaymentSectionChanges = (index: number, value: any, param: string) => {
        let agentMaster = structuredClone(updatedAgentMasterData);
        agentMaster.agentFOPs[index][param] = value;

        saveUpdatedAgentMaster(agentMaster);
    }

    return (
        <>
            <div className="row">
                <div className="col-12">
                    <div className="form_heading">
                        <span className="title">Form of Payment
                        </span>
                    </div>
                </div>
            </div>

            <div className="row">
                <div className="col-12 text-center">
                    <div className="payment_section">
                        {
                            formOfPaymentList?.map((payment: any, index: any) => {
                                return (
                                    <div className="payment_block" key={index}>
                                        <div className="payment_icon">
                                            <i className="fa-regular fa-credit-card"></i>
                                        </div>
                                        <div className="payment_option">
                                            <div className="form-check text-start mx-2">
                                                <ControlledCheckbox
                                                    canCheckedByOther={true}
                                                    isChecked={updatedAgentMasterData.agentFOPs[index] === undefined ? false : updatedAgentMasterData.agentFOPs[index].settlementTypeFieldTypeId ? updatedAgentMasterData.agentFOPs[index].settlementTypeFieldTypeId : false}
                                                    id={`form-of-payment-${index}`}
                                                    onChange={(value: boolean) => handleAgentMasterPaymentSectionChanges(index, value ? payment.id : 0, 'settlementTypeFieldTypeId')}
                                                />
                                                <label className="form-check-label" htmlFor={`form-of-payment-${index}`}>
                                                    {payment.text}
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                )
                            })
                        }
                    </div>
                </div>
            </div>
        </>
    );
}

export default PaymentSection;