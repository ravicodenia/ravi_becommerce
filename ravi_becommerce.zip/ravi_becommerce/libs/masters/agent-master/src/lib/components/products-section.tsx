import { RootState, useAgentMasterStore } from '@mfa-travel-app/store';
import { ControlledCheckbox, ControlledInput, ControlledSelect } from '@mfa-travel-app/ui';
import { useSelector } from 'react-redux';

const ProductsSection = () => {
    const { updatedAgentMasterData } = useSelector((state: RootState) => state.agentMaster);
    const { saveUpdatedAgentMaster } = useAgentMasterStore();

    const isRequiredOptions = [
        { id: 'Y', text: 'Yes' },
        { id: 'N', text: 'No' },
    ];

    const handleAgentMasterProductAccordionCheckChanges = (value: boolean, product: any, index: any) => {
        let oneSupplierProducts = structuredClone(product);
        oneSupplierProducts[0].productCheckbox = oneSupplierProducts[0].productCheckbox ? !oneSupplierProducts[0].productCheckbox : true;

        if (!value) {
            oneSupplierProducts?.map((supplier: any) => {
                supplier.supplierCheckbox = false;
                return supplier;
            });
        }

        let agentMaster = structuredClone(updatedAgentMasterData);
        agentMaster?.agentSuppliers?.splice(index, 1, oneSupplierProducts);

        saveUpdatedAgentMaster(agentMaster);
    }

    const handleAgentMasterProductsSectionChanges = (value: any, item: any, param: string) => {
        let agentMaster = structuredClone(updatedAgentMasterData);
        let supplierProducts = structuredClone(agentMaster?.agentSuppliers?.flat());

        supplierProducts?.map((supplier: any) => {
            if (supplier.id === item.id) {
                if (param === 'supplierCheckbox') {
                    supplier[param] = supplier[param] ? !supplier[param] : true;
                    return supplier;
                } else {
                    supplier[param] = value;
                }
            }

            return supplier;
        });

        supplierProducts.find((s: any) => s.productId === item.productId).productCheckbox = true;
        agentMaster.agentSuppliers = structuredClone(getGroupedArray(supplierProducts, 'productId'));

        saveUpdatedAgentMaster(agentMaster);
    }

    const getGroupedArray = (arr: [], key: string) => {
        return arr.reduce((acc: any, cur: any) => {
            acc[cur[key]] = [...acc[cur[key]] || [], cur];
            return acc;
        }, []).filter(Boolean);
    }

    return (
        <div className="accordion accordion_master_product" id="supplierAccordion">
            {
                updatedAgentMasterData?.agentSuppliers?.map((product: any, index: any) => {
                    return (
                        <div className="accordion-item" key={index}>
                            <h2 className="accordion-header" id={`heading-${index}`}>
                                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target={`#collapse-${index}`} aria-expanded="false" aria-controls={`collapse-${index}`}>

                                    <div className="form-check text-start">
                                        <ControlledCheckbox
                                            isChecked={product[0].productCheckbox ? product[0].productCheckbox : false}
                                            id={`acc-check-${index}`}
                                            canCheckedByOther={true}
                                            onChange={(value: boolean) => handleAgentMasterProductAccordionCheckChanges(value, product, index)}
                                        />
                                        <label className="form-check-label" htmlFor={`acc-check-${index}`}>
                                            {product[0].productName}
                                        </label>
                                    </div>

                                </button>
                            </h2>
                            <div id={`collapse-${index}`} className="accordion-collapse collapse"
                                aria-labelledby={`heading-${index}`} data-bs-parent="#supplierAccordion">
                                <div className="accordion-body">
                                    {
                                        product?.map((supplier: any, index: any) => {
                                            return (
                                                <div className="row" key={index}>

                                                    <div className="col-sm-2">
                                                        <div className="form-check text-start mx-2">
                                                            <ControlledCheckbox
                                                                isChecked={supplier.supplierCheckbox ? supplier.supplierCheckbox : false}
                                                                id={`${supplier.code}-check-${index}`}
                                                                canCheckedByOther={true}
                                                                onChange={(value: boolean) => handleAgentMasterProductsSectionChanges(value, supplier, 'supplierCheckbox')}
                                                            />
                                                            <label className="form-check-label" htmlFor={`${supplier.code}-check-${index}`}>
                                                                {supplier.text}
                                                            </label>
                                                        </div>
                                                    </div>

                                                    <div className="row" style={{ display: supplier.supplierCheckbox ? '' : 'none' }}>

                                                        <div className="col-sm-4">
                                                            <div className="row mb-2">
                                                                <label htmlFor={`ledger-code-${index}`} className="col-sm-4 col-form-label">Ledger Code <span className="text-danger">*</span> :</label>
                                                                <div className="col-sm-8">
                                                                    <ControlledInput
                                                                        id={`ledger-code-${index}`}
                                                                        value={supplier.ledgerCode ? supplier.ledgerCode : ''}
                                                                        type={'text'}
                                                                        required={supplier.supplierCheckbox ? true : false}
                                                                        onChange={(e: any) => handleAgentMasterProductsSectionChanges(e.target.value, supplier, 'ledgerCode')}
                                                                    />
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div className="col-sm-4">
                                                            <div className="row mb-2">
                                                                <label htmlFor={`private-fare-code-${index}`} className="col-sm-4 col-form-label">Private Fare Code <span className="text-danger">*</span> :</label>
                                                                <div className="col-sm-8">
                                                                    <ControlledInput
                                                                        id={`private-fare-code-${index}`}
                                                                        value={supplier.privateFareCode ? supplier.privateFareCode : ''}
                                                                        type={'text'}
                                                                        required={supplier.supplierCheckbox ? true : false}
                                                                        onChange={(e: any) => handleAgentMasterProductsSectionChanges(e.target.value, supplier, 'privateFareCode')}
                                                                    />
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div className="col-sm-4">
                                                            <div className="row mb-2">
                                                                <label htmlFor={`is-Passive-${index}`} className="col-sm-4 col-form-label">Is Passive <span className="text-danger">*</span> :</label>
                                                                <div className="col-sm-8">
                                                                    <ControlledSelect
                                                                        id={`is-Passive-${index}`}
                                                                        value={supplier.isPassive !== undefined ? supplier.isPassive ? 'Y' : 'N' : ''}
                                                                        options={isRequiredOptions}
                                                                        required={supplier.supplierCheckbox ? true : false}
                                                                        onChange={(e: any) => handleAgentMasterProductsSectionChanges(e.target.value === 'Y' ? true : false, supplier, 'isPassive')}
                                                                    />
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            )
                                        })
                                    }
                                </div>
                            </div>
                        </div>
                    )
                })
            }
        </div>
    );
}

export default ProductsSection;