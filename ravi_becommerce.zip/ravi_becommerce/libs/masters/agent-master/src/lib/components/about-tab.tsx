import * as React from 'react';
import AboutSection from './about-section';
import ContactSection from './contact-section';
import DocumentsSection from './documents-section';
import UploadSection from './upload-section';
import SettingsSection from './settings-section';
import BusinessDevelopmentSection from './business-dev-section';
import { RootState, useAgentMasterStore, useMastersDropdownStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { getDocumentList } from '../service/documents-section-api';
import { getFormOfPayment } from '../service/payment-section-api';
import { getSupplierProductList } from '../service/products-section-api';
import { FINANCE_TAB } from '../service/constants';
import { API_ERROR_TOAST_TEXT, DOCUMENT_OR_EXP_DATE_MISSING_ALERT, getAgentCategoryOptions, getAgentTypeOptions, getAppConfigOptions, getContactTypeOptions, getCountryOptions, getCurrencyOptions, getLanguageOptions, getParentAgentOptions, getPaymentTypeOptions, getPayPeriodOptions, getSalesExecManagerOptions, getSalutationOptions, getSecurityTypeOptions, getThemeOptions, validateEmail, WRONG_EMAIL_ALERT } from '@mfa-travel-app/shared';
import { toast } from 'react-toastify';

const AboutTab = () => {
    const { saveUpdatedAgentMaster, saveAgentMasterTabsData, saveDocumentList, saveFormOfPaymentList, saveSupplierProductList } = useAgentMasterStore();
    const { saveAgentTypeList, saveCountryList, saveLanguageList, saveCurrencyList, saveParentAgentList, saveAgentCategoryList, saveContactTypeList, saveSalutationList, saveThemeList, saveSalesExecManagerList, savePaymentTypeList, saveSecurityTypeList, savePayPeriodList, saveAppConfigList } = useMastersDropdownStore();

    const { updatedAgentMasterData, agentMasterTabsData, documentList, formOfPaymentList, supplierProductList } = useSelector((state: RootState) => state.agentMaster);
    const { agentTypeList, countryList, languageList, currencyList, parentAgentList, agentCategoryList, contactTypeList, salutationList, themeList, salesExecManagerList, paymentTypeList, securityTypeList, payPeriodList, appConfigList } = useSelector((state: RootState) => state.mastersDropdown);

    const [documentListLocal, setDocumentListLocal] = React.useState({
        initialState: [],
        list: []
    });
    const [formOfPaymentListLocal, setFormOfPaymentListLocal] = React.useState({
        initialState: [],
        list: []
    });
    const [supplierProductListLocal, setSupplierProductListLocal] = React.useState({
        initialState: []
    });

    React.useEffect(() => {
        getDropDownOptions();
    }, []);

    React.useEffect(() => {
        if (documentListLocal.initialState.length !== 0 &&
            formOfPaymentListLocal.initialState.length !== 0 &&
            supplierProductListLocal.initialState.length !== 0
        ) {
            if (agentMasterTabsData.clearAgentMaster) {
                resetClearAgentMasterIfSaveDone();
            } else {
                setAgentMasterInitialState(documentListLocal.initialState, formOfPaymentListLocal.initialState, supplierProductListLocal.initialState);
            }
        }
    }, [
        documentListLocal.initialState,
        formOfPaymentListLocal.initialState,
        supplierProductListLocal.initialState,
        agentMasterTabsData.clearAgentMaster
    ]);

    const setAgentMasterInitialState = (initialDocs: any, initialFop: any, initialSuppliers: any) => {
        let agentMaster: any = {};

        agentMaster.agentPOCs = [{}];
        agentMaster.agentDocs = initialDocs;
        agentMaster.agentFinances = [{}];
        agentMaster.agentFOPs = initialFop;
        agentMaster.agentSuppliers = initialSuppliers;
        agentMaster.agentConfigs = [{}];
        agentMaster.agentDocGuid = window.crypto.randomUUID();

        saveUpdatedAgentMaster(agentMaster);

        if (documentList.length === 0 && formOfPaymentList.length === 0 &&
            supplierProductList.length === 0
        ) {
            saveDocumentList(documentListLocal.list);
            saveFormOfPaymentList(formOfPaymentListLocal.list);
            saveSupplierProductList(supplierProductListLocal.initialState);
        }
    }

    const resetClearAgentMasterIfSaveDone = () => {
        let tabsData = structuredClone(agentMasterTabsData);
        tabsData.clearAgentMaster = false;
        saveAgentMasterTabsData(tabsData);
    }

    const getDropDownOptions = async () => {
        if (agentTypeList.length === 0) {
            getAgentTypeOptions().then((options) => {
                saveAgentTypeList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (countryList.length === 0) {
            getCountryOptions().then((options) => {
                saveCountryList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (languageList.length === 0) {
            getLanguageOptions().then((options) => {
                saveLanguageList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (currencyList.length === 0) {
            getCurrencyOptions().then((options) => {
                saveCurrencyList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (parentAgentList.length === 0) {
            getParentAgentOptions().then((options) => {
                saveParentAgentList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (agentCategoryList.length === 0) {
            getAgentCategoryOptions().then((options) => {
                saveAgentCategoryList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (contactTypeList.length === 0) {
            getContactTypeOptions().then((options) => {
                saveContactTypeList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (salutationList.length === 0) {
            getSalutationOptions().then((options) => {
                saveSalutationList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (documentList.length === 0) {
            getDocumentList().then((res: any) => {
                if (res.data) {
                    const initialAgentDocs = res?.data?.map((item: any) => {
                        return {};
                    });

                    setDocumentListLocal({ ...documentListLocal, initialState: initialAgentDocs, list: res.data });
                }
            });
        } else {
            const initialAgentDocs = documentList?.map((item: any) => {
                return {};
            });
            setDocumentListLocal({ ...documentListLocal, initialState: initialAgentDocs });
        }

        if (themeList.length === 0) {
            getThemeOptions().then((options) => {
                saveThemeList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (salesExecManagerList.length === 0) {
            getSalesExecManagerOptions().then((options) => {
                saveSalesExecManagerList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (paymentTypeList.length === 0) {
            getPaymentTypeOptions().then((options) => {
                savePaymentTypeList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (securityTypeList.length === 0) {
            getSecurityTypeOptions().then((options) => {
                saveSecurityTypeList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (payPeriodList.length === 0) {
            getPayPeriodOptions().then((options) => {
                savePayPeriodList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (formOfPaymentList.length === 0) {
            getFormOfPayment().then((res: any) => {
                if (res.data) {
                    const formOfPayment = res.data?.map((item: any) => {
                        return {
                            id: item.id,
                            text: item.value
                        }
                    });

                    const initialFormOfPayments = res?.data?.map((item: any) => {
                        return {};
                    });

                    setFormOfPaymentListLocal({ ...formOfPaymentListLocal, initialState: initialFormOfPayments, list: formOfPayment });
                }
            });
        } else {
            const initialFormOfPayments = formOfPaymentList?.map((item: any) => {
                return {};
            });

            setFormOfPaymentListLocal({ ...formOfPaymentListLocal, initialState: initialFormOfPayments });
        }

        if (supplierProductList.length === 0) {
            getSupplierProductList().then((res: any) => {
                if (res.data) {
                    const supplierList = res.data?.map((item: any) => {
                        item.text = JSON.parse(JSON.stringify(item.name));
                        return item;
                    });

                    setSupplierProductListLocal({ ...supplierProductListLocal, initialState: getGroupedArray(supplierList, 'productId') });
                }
            });
        } else {
            setSupplierProductListLocal({ ...supplierProductListLocal, initialState: structuredClone(supplierProductList) });
        }

        if (appConfigList.length === 0) {
            getAppConfigOptions().then((options) => {
                saveAppConfigList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }
    }

    const getGroupedArray = (arr: [], key: string) => {
        return arr.reduce((acc: any, cur: any) => {
            acc[cur[key]] = [...acc[cur[key]] || [], cur];
            return acc;
        }, []).filter(Boolean);
    }

    const moveToNextTab = (e: any) => {
        e.preventDefault();

        if ((!validateEmail(updatedAgentMasterData.email1)) || (!validateEmail(updatedAgentMasterData.email2))) {
            toast.warning(WRONG_EMAIL_ALERT);
            return;
        }

        let isContactEmailGood = true;
        updatedAgentMasterData?.agentPOCs?.forEach((contact: any) => {
            if (!validateEmail(contact.email)) {
                isContactEmailGood = false;
            }
        });

        if (!isContactEmailGood) {
            toast.warning(WRONG_EMAIL_ALERT);
            return;
        }

        let isDocumentGood = true;
        updatedAgentMasterData?.agentDocs?.forEach((doc: any) => {
            if (!(doc.filePath && doc.expiryDate) && (doc.mandatoryFile === 'N' || doc.mandatoryDate === 'N')) {
                isDocumentGood = false;
            }
        });

        if (!isDocumentGood) {
            toast.warning(DOCUMENT_OR_EXP_DATE_MISSING_ALERT);
            return;
        }

        let tabsData = JSON.parse(JSON.stringify(agentMasterTabsData));
        tabsData.activeTab = FINANCE_TAB;
        tabsData.isAboutTabCompleted = true;

        saveAgentMasterTabsData(tabsData);
    }

    return (
        <form onSubmit={moveToNextTab}>
            <div className="row">
                <div className="col-12">
                    <div className="innerContainer">
                        <div className="row">

                            <div className="col-lg-8">
                                <div className="wrapper">
                                    <div className="row">
                                        <div className="col-12"> <h5>Agent Master</h5> </div>
                                    </div>

                                    <AboutSection />

                                    <ContactSection />

                                    <DocumentsSection />
                                </div>
                            </div>

                            <div className="col-lg-4">
                                <div className="hide_mobile h-100">
                                    <div className="innerContainerRight">

                                        <UploadSection />

                                        <SettingsSection />

                                        <BusinessDevelopmentSection />

                                        <div className="row mb-2 mt-4">
                                            <div className="col-sm-12 text-md-end">
                                                <button type="submit" className="btn btn-primary rounded">CONTINUE <i className="fa-solid fa-chevron-right"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </form>
    );
}

export default AboutTab;