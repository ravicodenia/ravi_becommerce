import { ControlledSelect } from '@mfa-travel-app/ui';
import { RootState, useAgentMasterStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';

const BusinessDevelopmentSection = () => {
    const { updatedAgentMasterData } = useSelector((state: RootState) => state.agentMaster);
    const { salesExecManagerList } = useSelector((state: RootState) => state.mastersDropdown);

    const { saveUpdatedAgentMaster } = useAgentMasterStore();

    const handleAgentMasterBusinessDevSectionChanges = (value: number, param: string) => {
        let agentMaster = structuredClone(updatedAgentMasterData);
        agentMaster[param] = value;

        saveUpdatedAgentMaster(agentMaster);
    }

    return (
        <>
            <div className="row">
                <div className="col-12 mt-4">
                    <div className="form_heading">
                        <span className="title">Business Development Contact</span>
                    </div>
                </div>
            </div>

            <div className="row mb-2">
                <label htmlFor="sales-exceute" className="col-sm-5 col-form-label">Sales Executive <span className="text-danger">*</span> :</label>
                <div className="col-sm-7">
                    <ControlledSelect
                        id={'sales-exceute'}
                        value={updatedAgentMasterData.salesUserId ? updatedAgentMasterData.salesUserId : ''}
                        options={salesExecManagerList}
                        required={true}
                        onChange={(e: any) => handleAgentMasterBusinessDevSectionChanges(Number(e.target.value), 'salesUserId')}
                    />
                </div>
            </div>
            
            <div className="row mb-2">
                <label htmlFor="account-manager" className="col-sm-5 col-form-label">Account Manager <span className="text-danger">*</span> :</label>
                <div className="col-sm-7">
                    <ControlledSelect
                        id={'account-manager'}
                        value={updatedAgentMasterData.amUserId ? updatedAgentMasterData.amUserId : ''}
                        options={salesExecManagerList}
                        required={true}
                        onChange={(e: any) => handleAgentMasterBusinessDevSectionChanges(Number(e.target.value), 'amUserId')}
                    />
                </div>
            </div>
        </>
    );
}

export default BusinessDevelopmentSection;