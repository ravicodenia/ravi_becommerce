import { ControlledCheckbox, ControlledSelect } from '@mfa-travel-app/ui';
import { RootState, useAgentMasterStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';

const SettingsSection = () => {
    const { updatedAgentMasterData } = useSelector((state: RootState) => state.agentMaster);
    const { themeList } = useSelector((state: RootState) => state.mastersDropdown);

    const { saveUpdatedAgentMaster } = useAgentMasterStore();

    const handleAgentMasterSettingsSectionChanges = (value: any, param: string) => {
        let agentMaster = structuredClone(updatedAgentMasterData);
        agentMaster[param] = value;

        saveUpdatedAgentMaster(agentMaster);
    }

    return (
        <>
            <div className="row">
                <div className="col-12 mt-4">
                    <div className="form_heading">
                        <span className="title">Settings</span>
                    </div>
                </div>
            </div>

            <div className="row mb-2">
                <label htmlFor="theme" className="col-sm-5 col-form-label">Theme <span className="text-danger">*</span> :</label>
                <div className="col-sm-7">
                    <ControlledSelect
                        id={'theme'}
                        value={updatedAgentMasterData.theme ? updatedAgentMasterData.theme : ''}
                        options={themeList}
                        required={true}
                        onChange={(e: any) => handleAgentMasterSettingsSectionChanges(e.target.value, 'theme')}
                    />
                </div>
            </div>

            <div className="row mb-2 align-items-center">
                <label htmlFor="block-status" className="col-sm-5 col-form-label">Block Status :</label>
                <div className="col-sm-7 d-flex align-items-center">
                    <ControlledCheckbox
                        canCheckedByOther={true}
                        isChecked={updatedAgentMasterData.blockStatus ? updatedAgentMasterData.blockStatus : false}
                        id={'block-status'}
                        onChange={(value: boolean) => handleAgentMasterSettingsSectionChanges(value, 'blockStatus')}
                    />
                </div>
            </div>
        </>
    );
}

export default SettingsSection;