import ProductsSection from './products-section';
import { RootState, useAgentMasterStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { PRIVILEGES_TAB } from '../service/constants';
import { toast } from 'react-toastify';
import { NO_PRODUCT_SELECTED_ALERT, NO_SUPPLIER_SELECTED_ALERT } from '@mfa-travel-app/shared';

const ProductsTab = () => {
    const { updatedAgentMasterData, agentMasterTabsData } = useSelector((state: RootState) => state.agentMaster);
    const { saveAgentMasterTabsData } = useAgentMasterStore();

    const moveToNextTab = (e: any) => {
        e.preventDefault();
        let isNoProductSelected = true;
        let supplierMissing: any = [];

        updatedAgentMasterData?.agentSuppliers?.forEach((product: any) => {
            let isOnlyProductCheckboxSelected = false;

            product?.forEach((supplier: any, index: any) => {
                if (index === 0 && supplier.productCheckbox) {
                    isNoProductSelected = false;

                    if (supplier.supplierCheckbox) {
                        isOnlyProductCheckboxSelected = false;
                    } else {
                        isOnlyProductCheckboxSelected = true;
                    }
                }

                if (index !== 0 && isOnlyProductCheckboxSelected) {
                    if (supplier.supplierCheckbox) {
                        isOnlyProductCheckboxSelected = false;
                    }
                }
            });

            if (isOnlyProductCheckboxSelected) {
                supplierMissing.push(product[0].productName);
            }
        });

        if (isNoProductSelected) {
            toast.warning(NO_PRODUCT_SELECTED_ALERT);
            return;
        }

        if (supplierMissing.length > 0) {
            toast.warning(`${NO_SUPPLIER_SELECTED_ALERT} ${supplierMissing.join(', ')}.`);
            return;
        }

        let tabsData = JSON.parse(JSON.stringify(agentMasterTabsData));
        tabsData.activeTab = PRIVILEGES_TAB;
        tabsData.isProductsTabCompleted = true;

        saveAgentMasterTabsData(tabsData);
    }

    return (
        <form onSubmit={moveToNextTab}>
            <div className="row">
                <div className="col-12">
                    <div className="innerContainer border-end-0">

                        <div className="wrapper">

                            <div className="row">
                                <div className="col-12"> <h5>Agent Master </h5> </div>
                            </div>

                            <div className="row">
                                <div className="col-12">
                                    <div className="form_heading">
                                        <span className="title">Products</span>
                                    </div>
                                </div>
                            </div>

                            <ProductsSection />

                            <div className="text-end mt-5 mb-4">
                                <button type="submit" className="btn btn-primary rounded">CONTINUE <i className="fa-solid fa-chevron-right"></i></button>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </form>
    );
}

export default ProductsTab;