import * as React from 'react';
import { Tab, Tabs } from 'react-bootstrap';
import AboutTab from './about-tab';
import FinanceTab from './finance-tab';
import ProductsTab from './products-tab';
import PrivilegesTab from './privileges-tab';
import { RootState, useAgentMasterStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { ABOUT_TAB, FINANCE_TAB, PRODUCTS_TAB } from '../service/constants';

const AgentMasterTabs = () => {
    const { agentMasterTabsData } = useSelector((state: RootState) => state.agentMaster);
    const { saveAgentMasterTabsData } = useAgentMasterStore();

    const agentMasterTabs = [
        { id: 1, text: 'ABOUT' },
        { id: 2, text: 'FINANCE' },
        { id: 3, text: 'PRODUCTS' },
        { id: 4, text: 'PRIVILEGES' }
    ];

    React.useEffect(() => {
        initialAgentMasterActiveTab();
    }, []);

    const initialAgentMasterActiveTab = () => {
        saveAgentMasterTabsData({ activeTab: ABOUT_TAB, clearAgentMaster: false });
    }

    const handleTabChange = (tabId: any) => {
        let tabsData = JSON.parse(JSON.stringify(agentMasterTabsData));
        tabsData.activeTab = tabId;

        if (Number(tabId) === ABOUT_TAB) {
            tabsData.isAboutTabCompleted = false;
            tabsData.isFinanceTabCompleted = false;
            tabsData.isProductsTabCompleted = false;
        } else if (Number(tabId) === FINANCE_TAB) {
            tabsData.isFinanceTabCompleted = false;
            tabsData.isProductsTabCompleted = false;
        } else if (Number(tabId) === PRODUCTS_TAB) {
            tabsData.isProductsTabCompleted = false;
        }

        saveAgentMasterTabsData(tabsData);
    }

    const getTabBody = (id: number) => {
        switch (id) {
            case 1: {
                return <AboutTab />
            }
            case 2: {
                return <FinanceTab />
            }
            case 3: {
                return <ProductsTab />
            }
            case 4: {
                return <PrivilegesTab />
            }
            default: {
                break;
            }
        }
    }

    return (
        <Tabs
            activeKey={agentMasterTabsData?.activeTab}
            id='agent-master-tabs'
            onSelect={handleTabChange}
        >
            {
                agentMasterTabs.map((tab: any, index: any) => {
                    return (
                        <Tab
                            eventKey={tab.id}
                            title={tab.text}
                            key={index}
                        >
                            {getTabBody(tab.id)}
                        </Tab>
                    )
                })
            }
        </Tabs>
    );
}

export default AgentMasterTabs;