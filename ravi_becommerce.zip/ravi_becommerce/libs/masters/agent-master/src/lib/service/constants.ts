// DOCUMENTS_SECTION APIs
export const GET_DOCUMENT_LIST = 'common/Document/GetDocumentListByPage';
export const UPLOAD_DOCUMENT = 'common/Document/UploadDocument';
export const PREVIEW_DOCUMENT = 'common/Document/GetPreSignedUrl';
export const AGENT_BUCKET_NAME = 'documents';
export const AGENT_DOCUMENT_PATH = 'agentdocs';
export const AGENT_LOGO_PATH = 'agentlogo';

// PAYMENT_SECTION APIs
export const GET_FORM_OF_PAYMENT_LIST = 'common/FieldType/GetByType/settlement_mode';

// PRODUCTS_SECTION APIs
export const GET_SUPPLIER_PRODUCT_LIST = 'common/Supplier/GetSupplierList';

// PRIVILEGES_SECTION APIs
export const CREATE_AGENT_MASTER = 'common/AgentProfile/Create';

// AGENT_MASTER TABS
export const ABOUT_TAB = 1;
export const FINANCE_TAB = 2;
export const PRODUCTS_TAB = 3;
export const PRIVILEGES_TAB = 4;