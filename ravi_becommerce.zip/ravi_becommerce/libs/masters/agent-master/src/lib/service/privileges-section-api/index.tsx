import { CREATE_AGENT_MASTER } from "../constants";
import { postGatewayAPI } from "@mfa-travel-app/services";

export const createAgentMaster = async (payload: any) => {
    try {
        const response = await postGatewayAPI(CREATE_AGENT_MASTER, payload);
        return response;
    } catch (error) {
        return error;
    }
}