import { getGatewayAPI } from "@mfa-travel-app/services";
import { GET_SUPPLIER_PRODUCT_LIST } from "../constants";

export const getSupplierProductList = async () => {
    try {
        const response = await getGatewayAPI(GET_SUPPLIER_PRODUCT_LIST);
        return response;
    } catch (error) {
        return error;
    }
}