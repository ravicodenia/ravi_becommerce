import { getGatewayAPI, postGatewayAPI } from "@mfa-travel-app/services";
import { AGENT_BUCKET_NAME, AGENT_DOCUMENT_PATH, AGENT_LOGO_PATH, GET_DOCUMENT_LIST, PREVIEW_DOCUMENT, UPLOAD_DOCUMENT } from "../constants";

export const getDocumentList = async () => {
    try {
        const response = await getGatewayAPI(GET_DOCUMENT_LIST,
            { params: { page: 'agentmaster' } }
        );
        return response;
    } catch (error) {
        return error;
    }
}

export const uploadDocument = async (file: FormData, agentDocGuid: string) => {
    try {
        const response = await postGatewayAPI(UPLOAD_DOCUMENT, file, {
            params: { 
                bucketName: AGENT_BUCKET_NAME,
                path: `${AGENT_DOCUMENT_PATH}/${agentDocGuid}`
            },
            headers: {
                "Content-Type": "multipart/form-data"
            }
        });
        return response;
    } catch (error) {
        return error;
    }
}

export const previewDocument = async (bucketName: string, filePath: string) => {
    try {
        const response = await postGatewayAPI(PREVIEW_DOCUMENT, null, {
            params: { 
                bucketName: bucketName,
                path: filePath
            }
        });
        return response;
    } catch (error) {
        return error;
    }
}

export const uploadLogo = async (file: FormData, agentDocGuid: string) => {
    try {
        const response = await postGatewayAPI(UPLOAD_DOCUMENT, file, {
            params: { 
                bucketName: AGENT_BUCKET_NAME,
                path: `${AGENT_LOGO_PATH}/${agentDocGuid}`
            },
            headers: {
                "Content-Type": "multipart/form-data"
            }
        });
        return response;
    } catch (error) {
        return error;
    }
}