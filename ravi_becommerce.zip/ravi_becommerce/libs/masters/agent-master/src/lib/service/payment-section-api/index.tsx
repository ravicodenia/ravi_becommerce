import { getGatewayAPI } from "@mfa-travel-app/services";
import { GET_FORM_OF_PAYMENT_LIST } from "../constants";

export const getFormOfPayment = async () => {
    try {
        const response = await getGatewayAPI(GET_FORM_OF_PAYMENT_LIST);
        return response;
    } catch (error) {
        return error;
    }
}