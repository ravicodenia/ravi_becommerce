import HotelQueueHome from "./components/hotel-queue-home";

export const HotelQueue = () => {
    return (
        <HotelQueueHome />
    );
}

export default HotelQueue;