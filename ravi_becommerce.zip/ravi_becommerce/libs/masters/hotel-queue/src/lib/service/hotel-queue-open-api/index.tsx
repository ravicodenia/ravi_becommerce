import { postGatewayAPI } from '@mfa-travel-app/services';
import { GET_HOTEL_BOOKING_DETAILS } from '../constants';

export const getHotelBookingDetails = async (payload: any) => {
    try {
        const response = await postGatewayAPI(GET_HOTEL_BOOKING_DETAILS, payload);
        return response;
    } catch (error) {
        return error;
    }
}