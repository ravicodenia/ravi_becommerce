import { postGatewayAPI } from "@mfa-travel-app/services";
import { GET_HOTEL_QUEUES } from "../constants";

export const getHotelQueues = async (payload: any) => {
    try {
        const response = await postGatewayAPI(GET_HOTEL_QUEUES, payload);
        return response;
    } catch (error) {
        return error;
    }
}