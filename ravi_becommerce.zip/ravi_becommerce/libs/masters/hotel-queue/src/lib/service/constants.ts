// FILTERS_SETION APIs
export const GET_HOTEL_QUEUES = 'hotel/HotelReport/GetHotelQueues';

// HOTEL_BOOKING_DETAIL APIs
export const GET_HOTEL_BOOKING_DETAILS = 'hotel/HotelReport/GetBookingDetails';