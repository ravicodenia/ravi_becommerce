import { MainLayout } from '@mfa-travel-app/layout';
import { ControlledSelect, ControlledDatePicker } from '@mfa-travel-app/ui';

export default function Ledger() {

    const selectOptions = [
        { id: 1, text: 'First Option' },
        { id: 2, text: 'Second Option' },
    ];

  return (
    <>
    <MainLayout>
   
    <div style={{minHeight:'500px'}} className="container">
    <section className="country_section mt-2 mb-3 font_size_90 rule_section">
   
    <div className="row mt-3">
        
    <div className="col-lg-3">
   
   <div className="row align-items-center mb-2">
                  <label htmlFor="fromDate" className="col-lg-5">From Date:</label>
                  <div className="col-lg-7">
                  <ControlledDatePicker
                        id={'fromDate'}
                        value={''}
                        format={'dd/MMM/yyyy'}
                        required={true}
                        onChange={''}
                    />
                  </div>
              </div>
   
    </div>
   
   
    <div className="col-lg-3">
   
   <div className="row align-items-center mb-2">
                  <label htmlFor="toDate" className="col-lg-5">To Date:</label>
                  <div className="col-lg-7">
                  <ControlledDatePicker
                        id={'toDate'}
                        value={''}
                        format={'dd/MMM/yyyy'}
                        required={true}
                        onChange={''}
                    />
                  </div>
              </div>
   
      </div>


   
      <div className="col-lg-3">
   
   <div className="row align-items-center mb-2">
                  <label htmlFor="agent" className="col-lg-5">Agent:</label>
                  <div className="col-lg-7">
                  <ControlledSelect
                      id={'agent'}
                      value={''}
                      options={selectOptions}
                      required={true}
                      onChange={''}
                  />
                  </div>
              </div>
   
      </div>
   
   
      <div className="col-lg-3">
   
   <div className="row align-items-center mb-2">
                  <label htmlFor="b2bagent" className="col-lg-5">B2BAgent:</label>
                  <div className="col-lg-7">
                  <ControlledSelect
                      id={'b2bagent'}
                      value={''}
                      options={selectOptions}
                      required={true}
                      onChange={''}
                  />
                  </div>
              </div>
   
      </div>
   
   
      <div className="col-lg-3">
   
   <div className="row align-items-center mb-2">
                  <label htmlFor="b2b2bagent" className="col-lg-5">B2B2B Agent:</label>
                  <div className="col-lg-7">
                  <ControlledSelect
                      id={'b2b2bagent'}
                      value={''}
                      options={selectOptions}
                      required={true}
                      onChange={''}
                  />
                  </div>
              </div>
   
      </div>
   
   
   
      <div className="col-lg-3">
   
   <div className="row align-items-center mb-2">
                  <label htmlFor="transtype" className="col-lg-5">Trans Type:</label>
                  <div className="col-lg-7">
                  <ControlledSelect
                      id={'transtype'}
                      value={''}
                      options={selectOptions}
                      required={true}
                      onChange={''}
                  />
                  </div>
              </div>
   
      </div>
   

      <div className="col-lg-3">
   
   <div className="row align-items-center mb-2">
                  <label htmlFor="accounttype" className="col-lg-5">Account Type:</label>
                  <div className="col-lg-7">
                  <ControlledSelect
                      id={'accounttype'}
                      value={''}
                      options={selectOptions}
                      required={true}
                      onChange={''}
                  />
                  </div>
              </div>
   
      </div>
   
      <div className="col-lg-3 text-end">
      <button className='btn btn-primary btn-sm rounded mt-2'>Submit</button>
   
      </div>
   
   
   
   
   
     
       </div>




       <div className="row mt-3">

        <div className='col-12'>
        <div className="table-responsive">

        <table className="table table-bordered tbl_grid_heading">
        <thead>
    <tr>
      <th scope="col">Agent Name/Date</th>
      <th scope="col">Ref #</th>
      <th className='text-center' scope="col">Perticulars</th>
      <th scope="col">Debit</th>
      <th scope="col">Credit</th>
    </tr>
  </thead>
  <tbody>
    <tr>  
      <td><strong>Akbar Travel LLC</strong></td>
      <td colSpan={2}><strong>Opening Current Balance (All values are in AED)</strong></td>
      <td></td>
      <td><strong>4100.000</strong></td>
    </tr>

    <tr>  
      <td><strong>14-08-2024</strong></td>
      <td className='text-muted'>KW46409</td>
      <td> 
        <strong>Ticket Created:</strong> <span className='text-muted'>Kamal Sharma X 6 PNR: WFSLS98 , </span>
        
        <span className='text-info ms-1'>TICKET NO: WFLS98 ,</span>
        <span className='text-muted ms-1'>  TRAVEL DATE: 19/11/2024 BY: FZ579, </span>
        
        </td>
      <td className='text-muted'>8,050.70</td>
      <td>-</td>
    </tr>

    <tr>  
      <td></td>
      <td></td>
      <td> </td>
      <td></td>
      <td></td>
    </tr>



    <tr>  
      <td><strong>14-08-2024</strong></td>
      <td className='text-muted'>KW46409</td>
      <td> 
        <strong>Ticket Created:</strong> <span className='text-muted'>Kamal Sharma X 6 PNR: WFSLS98 , </span>
        
        <span className='text-info ms-1'>TICKET NO: WFLS98 ,</span>
        <span className='text-muted ms-1'>  TRAVEL DATE: 19/11/2024 BY: FZ579, </span>
        
        </td>
      <td className='text-muted'>8,050.70</td>
      <td>-</td>
    </tr>

    <tr>  
      <td></td>
      <td></td>
      <td> </td>
      <td></td>
      <td></td>
    </tr>

    <tr>  
      <td><strong>14-08-2024</strong></td>
      <td className='text-muted'>HW5819</td>
      <td> 
        <strong>Hotel Booking Created:</strong> <span className='text-muted'> Shiva Reddy X Confirmation NO: 46_46_2301235_1 </span>
      
        </td>
      <td className='text-muted'>8,050.70</td>
      <td>-</td>
    </tr>

    <tr>  
      <td></td>
      <td></td>
      <td> </td>
      <td></td>
      <td></td>
    </tr>


    <tr>  
      <td><strong>14-08-2024</strong></td>
      <td className='text-muted'>KW46409</td>
      <td> 
        <strong>Ticket Created:</strong> <span className='text-muted'>Kamal Sharma X 6 PNR: WFSLS98 , </span>
        
        <span className='text-info ms-1'>TICKET NO: WFLS98 ,</span>
        <span className='text-muted ms-1'>  TRAVEL DATE: 19/11/2024 BY: FZ579, </span>
        
        </td>
      <td className='text-muted'>8,050.70</td>
      <td>-</td>
    </tr>

    <tr>  
      <td></td>
      <td></td>
      <td> </td>
      <td></td>
      <td></td>
    </tr>

    <tr>  
      <td><strong>14-08-2024</strong></td>
      <td className='text-muted'>KW46409</td>
      <td> 
        <strong>Ticket Created:</strong> <span className='text-muted'>Kamal Sharma X 6 PNR: WFSLS98 , </span>
        
        <span className='text-info ms-1'>TICKET NO: WFLS98 ,</span>
        <span className='text-muted ms-1'>  TRAVEL DATE: 19/11/2024 BY: FZ579, </span>
        
        </td>
      <td className='text-muted'>8,050.70</td>
      <td>-</td>
    </tr>

    <tr>  
      <td></td>
      <td></td>
      <td> </td>
      <td></td>
      <td></td>
    </tr>

    <tr>  
      <td><strong>14-08-2024</strong></td>
      <td className='text-muted'>KW46409</td>
      <td> 
        <strong>Flight Void Charges:</strong> <span className='text-muted'>X 1 PNR: O44AXED </span>
   
        </td>
      <td className='text-muted'>8,050.70</td>
      <td>-</td>
    </tr>

    <tr>  
      <td></td>
      <td></td>
      <td> </td>
      <td></td>
      <td></td>
    </tr>


    <tr>  
      <td><strong>14-08-2024</strong></td>
      <td className='text-muted'>KW46409</td>
      <td> 
        <strong>Refunded for PNR No - O4AXED:</strong> <span className='text-muted'>Kamal sharma X 1 Flight PNRVOID </span>
      
        </td>
      <td className='text-muted'>8,050.70</td>
      <td>-</td>
    </tr>

    <tr>  
      <td></td>
      <td></td>
      <td> </td>
      <td></td>
      <td></td>
    </tr>


    <tr>  
      <td><strong>14-08-2024</strong></td>
      <td className='text-muted'>HW5819</td>
      <td> 
        <strong>Hotel Booking Created:</strong> <span className='text-muted'> Shiva Reddy X Confirmation NO: 46_46_2301235_1 </span>
      
        </td>
      <td className='text-muted'>8,050.70</td>
      <td>-</td>
    </tr>

    <tr>  
      <td></td>
      <td></td>
      <td> </td>
      <td></td>
      <td></td>
    </tr>






    <tr>  
      <td colSpan={3}> <strong>Total</strong> </td>
      <td> <strong>1,23,609.03</strong> </td>
      <td> <strong>6,935.50</strong> </td>
    </tr>
    
    <tr>  
      <td colSpan={4}> <strong>Closing Balance</strong> </td>
      <td> <strong>4,13,68,145.20</strong> </td>
    </tr>



  </tbody>

        </table>


</div>

        </div>


        </div>
   
   </section>
   
       </div>
   
       </MainLayout>
   
       </>
  )
}
