import { ControlledDatePicker, ControlledInput, ControlledMultiSelect, ControlledSelect } from '@mfa-travel-app/ui';
import { RootState, useHotelQueueStore, useMastersDropdownStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import { agentIdAndTypeForFilters, API_ERROR_TOAST_TEXT, updateLocationDropdownByAgentId } from '@mfa-travel-app/shared';

const HotelQueueFilters = ({ handleSearchHotelQueue }: any) => {
    const { locationList, salesChannelList } = useSelector((state: RootState) => state.mastersDropdown);
    const { hotelQueueFilters, agentAndBaseAgentList, bToBList, bToBToBList, hotelSupplierList } = useSelector((state: RootState) => state.hotelQueue);

    const { saveHotelQueueFilters } = useHotelQueueStore();
    const { saveLocationList } = useMastersDropdownStore();

    const bookingStatusOptions = [
        { value: 0, label: 'Failed' },
        { value: 1, label: 'Confirmed' },
        { value: 2, label: 'Cancelled' },
        { value: 3, label: 'Pending' },
        { value: 4, label: 'Error' },
        { value: 5, label: 'PartiallyConfirmed' },
        { value: 6, label: 'PartiallyCancelled' },
    ];

    const handleHotelQueueFiltersChange = (value: any, param: string) => {
        let filters = JSON.parse(JSON.stringify(hotelQueueFilters));
        let bookingModes: any = [];
        let supplierIds: any = [];

        if (param === 'bookingModes') {
            value?.forEach((mode: any) => {
                bookingModes.push(mode.value);
            });

            filters[param] = bookingModes;
            filters.selectedBookingStatus = value;
        } else if (param === 'supplierId') {
            value?.forEach((supplier: any) => {
                supplierIds.push(supplier.id);
            });

            filters[param] = supplierIds;
            filters.selectedSuppliers = value;
        } else {
            filters[param] = value;
        }

        saveHotelQueueFilters(filters);
    }

    const handleHotelQueueFilterAgentIdChange = async (filters: any, value: any, param: string) => {
        try {
            const filtersWithAgentIdAndType: any = await agentIdAndTypeForFilters(filters, value, param);
            saveHotelQueueFilters(filtersWithAgentIdAndType);
            
            const locationOptions = await updateLocationDropdownByAgentId(filtersWithAgentIdAndType.agentId);
            saveLocationList(locationOptions);
        } catch (error) {
            console.error('An error occurred:', error);
            toast.error(API_ERROR_TOAST_TEXT);
        }
    }

    return (
        <>
            <div className="col-lg-3">
                <div className="row align-items-center mb-2">
                    <label htmlFor="from-date" className="col-lg-5">From Date :</label>
                    <div className="col-lg-7">
                        <ControlledDatePicker
                            id={'from-date'}
                            value={hotelQueueFilters.fromDate ? hotelQueueFilters.fromDate : null}
                            format={'dd/MMM/yyyy'}
                            onChange={(date: any) => handleHotelQueueFiltersChange(date.toISOString(), 'fromDate')}
                        />
                    </div>
                </div>
            </div>

            <div className="col-lg-3">
                <div className="row align-items-center mb-2">
                    <label htmlFor="to-date" className="col-lg-5">To Date :</label>
                    <div className="col-lg-7">
                        <ControlledDatePicker
                            id={'to-date'}
                            value={hotelQueueFilters.toDate ? hotelQueueFilters.toDate : null}
                            format={'dd/MMM/yyyy'}
                            onChange={(date: any) => handleHotelQueueFiltersChange(date.toISOString(), 'toDate')}
                        />
                    </div>
                </div>
            </div>

            <div className="col-lg-3">
                <div className="row align-items-center mb-2">
                    <label htmlFor="booking-status" className="col-lg-5">Booking Status :</label>
                    <div className="col-lg-7">
                        <ControlledMultiSelect
                            id={'booking-status'}
                            value={hotelQueueFilters.selectedBookingStatus ? hotelQueueFilters.selectedBookingStatus : []}
                            options={bookingStatusOptions}
                            onChange={(value: any) => handleHotelQueueFiltersChange(value, 'bookingModes')}
                        />
                    </div>
                </div>
            </div>

            <div className="col-lg-3">
                <div className="row align-items-center mb-2">
                    <label htmlFor="agent" className="col-lg-5">Agent :</label>
                    <div className="col-lg-7">
                        <ControlledSelect
                            id={'agent'}
                            value={hotelQueueFilters.selectedAgentId ? hotelQueueFilters.selectedAgentId : ''}
                            options={agentAndBaseAgentList}
                            showSelectOption={false}
                            disabled={hotelQueueFilters.isAgentDisabled ? hotelQueueFilters.isAgentDisabled : false}
                            onChange={(e: any) => handleHotelQueueFilterAgentIdChange(hotelQueueFilters, e.target.value, 'agent')}
                        />
                    </div>
                </div>
            </div>

            <div className="col-lg-3">
                <div className="row align-items-center mb-2">
                    <label htmlFor="b2b" className="col-lg-5">B2B :</label>
                    <div className="col-lg-7">
                        <ControlledSelect
                            id={'b2b'}
                            value={hotelQueueFilters.selectedB2bId ? hotelQueueFilters.selectedB2bId : ''}
                            options={bToBList}
                            disabled={hotelQueueFilters.isB2bDisabled ? hotelQueueFilters.isB2bDisabled : false}
                            onChange={(e: any) => handleHotelQueueFilterAgentIdChange(hotelQueueFilters, e.target.value, 'b2b')}
                        />
                    </div>
                </div>
            </div>

            <div className="col-lg-3">
                <div className="row align-items-center mb-2">
                    <label htmlFor="b2b2b" className="col-lg-5">B2B2B :</label>
                    <div className="col-lg-7">
                        <ControlledSelect
                            id={'b2b2b'}
                            value={hotelQueueFilters.selectedB2b2bId ? hotelQueueFilters.selectedB2b2bId : ''}
                            options={bToBToBList}
                            onChange={(e: any) => handleHotelQueueFilterAgentIdChange(hotelQueueFilters, e.target.value, 'b2b2b')}
                        />
                    </div>
                </div>
            </div>

            <div className="col-lg-3">
                <div className="row align-items-center mb-2">
                    <label htmlFor="location" className="col-lg-5">Location :</label>
                    <div className="col-lg-7">
                        <ControlledSelect
                            id={'location'}
                            value={hotelQueueFilters.locationId ? hotelQueueFilters.locationId : ''}
                            options={locationList}
                            onChange={(e: any) => handleHotelQueueFiltersChange(Number(e.target.value), 'locationId')}
                        />
                    </div>
                </div>
            </div>

            <div className="col-lg-3">
                <div className="row align-items-center mb-2">
                    <label htmlFor="confirmation-no" className="col-lg-5">Conf. No. :</label>
                    <div className="col-lg-7">
                        <ControlledInput
                            id={'confirmation-no'}
                            value={hotelQueueFilters.confirmationNumber ? hotelQueueFilters.confirmationNumber : ''}
                            type={'text'}
                            onChange={(e: any) => handleHotelQueueFiltersChange(e.target.value, 'confirmationNumber')}
                        />
                    </div>
                </div>
            </div>

            <div className="col-lg-3">
                <div className="row align-items-center mb-2">
                    <label htmlFor="hotel-name" className="col-lg-5">Hotel :</label>
                    <div className="col-lg-7">
                        <ControlledInput
                            id={'hotel-name'}
                            value={hotelQueueFilters.hotelName ? hotelQueueFilters.hotelName : ''}
                            type={'text'}
                            onChange={(e: any) => handleHotelQueueFiltersChange(e.target.value, 'hotelName')}
                        />
                    </div>
                </div>
            </div>

            <div className="col-lg-3">
                <div className="row align-items-center mb-2">
                    <label htmlFor="pax-name" className="col-lg-5">Pax Name  :</label>
                    <div className="col-lg-7">
                        <ControlledInput
                            id={'pax-name'}
                            value={hotelQueueFilters.leadPaxName ? hotelQueueFilters.leadPaxName : ''}
                            type={'text'}
                            onChange={(e: any) => handleHotelQueueFiltersChange(e.target.value, 'leadPaxName')}
                        />
                    </div>
                </div>
            </div>

            <div className="col-lg-3">
                <div className="row align-items-center mb-2">
                    <label htmlFor="trans-type" className="col-lg-5">TransType:</label>
                    <div className="col-lg-7">
                        <ControlledSelect
                            id={'trans-type'}
                            value={hotelQueueFilters.transType ? hotelQueueFilters.transType : ''}
                            options={salesChannelList}
                            onChange={(e: any) => handleHotelQueueFiltersChange(e.target.value, 'transType')}
                        />
                    </div>
                </div>
            </div>

            <div className="col-lg-3">
                <div className="row align-items-center mb-2">
                    <label htmlFor="supplier" className="col-lg-5">Supplier :</label>
                    <div className="col-lg-7">
                        <ControlledMultiSelect
                            id={'supplier'}
                            value={hotelQueueFilters.selectedSuppliers ? hotelQueueFilters.selectedSuppliers : []}
                            options={hotelSupplierList}
                            onChange={(value: any) => handleHotelQueueFiltersChange(value, 'supplierId')}
                        />
                    </div>
                </div>

            </div>

            <div className="col-lg-12 text-end">
                <button onClick={() => handleSearchHotelQueue(hotelQueueFilters)} className='btn btn-sm btn-primary rounded mt-2'>Search </button>
            </div>
        </>
    );
}

export default HotelQueueFilters;