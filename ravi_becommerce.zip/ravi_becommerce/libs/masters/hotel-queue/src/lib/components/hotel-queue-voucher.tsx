import * as React from 'react';
import { MainLayout } from '@mfa-travel-app/layout';
import { useSelector } from 'react-redux';
import { RootState } from '@mfa-travel-app/store';
import moment from 'moment';

const HotelQueueVoucher = () => {
    const { hotelBookingDetails } = useSelector((state: RootState) => state.hotelQueue);

    const getTotalNumberOfGuests = () => {
        let adultCount = 0;
        let childCount = 0;

        hotelBookingDetails?.hotelItinerary?.prices?.forEach((detail: any) => {
            adultCount += detail?.roomInfo?.adultCount;
            childCount += detail?.roomInfo?.childCount;
        });

        return `${adultCount} (ADULT(s)), ${childCount} (CHILD(s))`;
    }

    const getNumberOfNights = () => {
        let checkIn = moment(new Date(hotelBookingDetails?.hotelItinerary?.checkInDate).setHours(0, 0, 0, 0));
        let checkOut = moment(new Date(hotelBookingDetails?.hotelItinerary?.checkOutDate).setHours(0, 0, 0, 0));

        if (checkIn && checkOut) {
            let nights = checkOut.diff(checkIn, 'days');
            return `${nights} ${nights > 1 ? 'Nights' : 'Night'}`;
        }

        return '';
    }

    const getLeadPaxDetailRow = () => {
        let allPassengers: any = [];

        hotelBookingDetails?.hotelItinerary?.prices?.forEach((detail: any) => {
            allPassengers.push(detail?.roomInfo?.passangers);
        });

        let leadPax = allPassengers?.flat()?.find((p: any) => p.leadPassenger === true);
 
        if (leadPax) {
            return (
                <tr className="text-muted text-center">
                    <td className="text-start">
                        {`${leadPax.title}. ${leadPax.firstName} ${leadPax.lastName}`}
                    </td>
                    <td>
                        {`${leadPax.nationalityCode} - ${leadPax.nationality}`}
                    </td>
                    <td>
                        {moment(hotelBookingDetails?.hotelItinerary?.checkInDate).format('DD/MMM/YYYY')}
                    </td>
                    <td>
                        {moment(hotelBookingDetails?.hotelItinerary?.checkOutDate).format('DD/MMM/YYYY')}
                    </td>
                    <td>
                        {getTotalNumberOfGuests()}
                    </td>
                    <td>
                        {getNumberOfNights()}
                    </td>
                </tr>
            );
        }
        
        return <></>;
    }

    const {
        // hotelBookingDetails,
        selectedHotel,
        rooms,
        hotelCancellationPolicies,
        passengerInfo
    } = useSelector((state: RootState) => state.hotel);

    const onHandlePrintVoucher = () => {
        window.print();
    }

    return (
        <>
            <MainLayout>
                <div className="container mb-5">
                    <div className="row align-items-center">
                        <div className="col-md-12 text-center text-uppercase mt-2">
                            {' '}
                            <h4>Hotel Voucher</h4>{' '}

                        </div>
                        <div className="col-md-6">

                            <div>
                                <img style={{ height: '16px' }}
                                    src='' alt='agency-logo'
                                />
                            </div>
                            <h4>
                                {hotelBookingDetails?.hotelItinerary?.hotelName}
                            </h4>

                            <div className="text-primary">
                                {Array.from({
                                    length: hotelBookingDetails?.hotelItinerary?.starRating || 0,
                                }).map((_, index) => (
                                    <span key={index}>
                                        <i className="fa-solid fa-star"></i>
                                    </span>
                                ))}
                                {Array.from({
                                    length: 5 - hotelBookingDetails?.hotelItinerary?.starRating || 0,
                                }).map((_, index) => (
                                    <span key={index}>
                                        <i className="fa-regular fa-star"></i>
                                    </span>
                                ))}
                            </div>

                            <div className="mb-1 mt-1">
                                {hotelBookingDetails?.hotelItinerary?.addressLine1}
                            </div>

                            <div className="text-muted font_size_90 mb-2">
                                Phone Number: null
                                null@gmail.com
                            </div>
                        </div>

                        <div className="col-md-6 text-md-end font_size_90">
                            <button className="btn p-0 me-2">
                                <i className="fa fa-envelope" aria-hidden="true"></i>
                            </button>
                            <button className="btn p-0 m-0" onClick={onHandlePrintVoucher}>
                                <i className="fa fa-print" aria-hidden="true"></i>
                            </button>

                            <div>
                                <span>Confirmation No |</span>&nbsp;
                                <span>
                                    <strong>
                                        {hotelBookingDetails?.hotelItinerary?.confirmationNo}
                                    </strong>
                                </span>
                            </div>

                            <div>
                                <span>Date of Issue:</span>&nbsp;
                                <span>
                                    <strong>
                                        {moment(hotelBookingDetails?.createdOn).format('DD/MMM/YYYY hh:mm a')}
                                    </strong>
                                </span>
                            </div>

                            <div>
                                <span>Status |</span>&nbsp;
                                <span className="text-success">
                                    <strong>
                                        {
                                            hotelBookingDetails?.hotelItinerary?.voucherStatus
                                                ? 'Vouchered'
                                                : 'Confirmed'
                                        }
                                    </strong>
                                </span>
                            </div>

                            <div>
                                <span className="text-muted">
                                    Agency Ref # :&nbsp;
                                    {hotelBookingDetails?.hotelItinerary?.systemReference}
                                </span>
                            </div>

                            {
                                hotelBookingDetails?.hotelBookingDetails?.agencyDetails
                                    ?.agencyName !== null && (
                                    <div>
                                        <span className="text-muted">
                                            Agency Name:{' '}
                                            {
                                                hotelBookingDetails?.hotelBookingDetails?.agencyDetails
                                                    ?.agencyName
                                            }
                                        </span>
                                    </div>
                                )
                            }

                            <div>
                                <span className="text-muted">
                                    Agency Address: null
                                </span>
                            </div>

                            <div>
                                <span className="text-muted">
                                    Agency Emergency No. : null
                                </span>
                            </div>
                        </div>
                    </div>

                    <div className="row">
                        <div className="col-12 mt-2">
                            <div className="tblFlightEticket">
                                <div className="heading">Lead Guest</div>

                                <div style={{ border: 'solid 1px #000' }}>
                                    <div className="table-responsive">
                                        <table className="table table-bordered border-primary mb-0">
                                            <thead className="align-middle text-center  bg-light">
                                                <th className="text-start">GUEST NAME</th>
                                                <th>NATIONALITY</th>
                                                <th>CHECK IN DATE</th>
                                                <th>CHECK OUT DATE</th>
                                                <th>NO. OF GUESTS</th>
                                                <th>NO. OF NIGHTS</th>
                                            </thead>

                                            <tbody>
                                                {getLeadPaxDetailRow()}
                                            </tbody>
                                        </table>

                                        <table className="table table-bordered border-primary mb-0">
                                            <thead className="align-middle text-center bg-light border-top-0">
                                                <tr>
                                                    <th className="text-start">ROOM NO.</th>
                                                    <th>ROOM TYPE</th>
                                                    <th>PAX NAMES(S)</th>
                                                    <th>MEAL PLAN</th>
                                                    <th>NO. OF GUESTS</th>
                                                </tr>
                                            </thead>

                                            <tbody>
                                                {
                                                    hotelBookingDetails?.hotelItinerary?.prices?.map((detail: any, index: any) => {
                                                        return (
                                                            <tr className="text-muted text-center">
                                                                <td className="text-start">{index + 1}</td>
                                                                <td>{detail?.roomInfo?.roomName}</td>
                                                                <td>
                                                                    {
                                                                        detail?.roomInfo?.passangers?.map((pax: any, index: any) => {
                                                                            return `${index !== 0 ? ', ' : ''}${pax.title}. ${pax.firstName} ${pax.lastName}`
                                                                        })
                                                                    }
                                                                </td>
                                                                <td>{detail?.roomInfo?.mealPlanDesc}</td>
                                                                <td>
                                                                    {detail?.roomInfo?.adultCount} (ADULT(s)), {detail?.roomInfo?.childCount} (CHILD(s))
                                                                </td>
                                                            </tr>
                                                        );
                                                    }
                                                    )}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="row mt-4">
                        <div className="border p-3">
                            <div className="col-12 mt-2">
                                <div className="mb-2 text-uppercase">
                                    {' '}
                                    <strong>Essential Information </strong>{' '}
                                </div>

                                <h6 className="text-uppercase ">INCLUSIONS</h6>
                            </div>
                            <ul>
                                {hotelBookingDetails?.hotelBookingDetails?.rateConditions?.map(
                                    (condition: any) => (
                                        <li>{condition}</li>
                                    )
                                )}
                            </ul>
                        </div>
                    </div>

                    <div className="row mt-4">
                        <div className="border p-3">
                            <div className="col-12 mt-2">
                                <div className="mb-2 text-uppercase">
                                    {' '}
                                    <strong>Hotel Norms</strong>{' '}
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="row mt-4">
                        <div className="border p-3">
                            <div className="col-12 mt-3">
                                <div className="text-uppercase mb-2">
                                    <strong>CANCELLATION & CHARGES</strong>
                                </div>
                                {
                                    hotelBookingDetails?.hotelItinerary?.prices?.map((detail: any, index: any) => {
                                        return (
                                            <React.Fragment key={index}>
                                                <strong>Room {index + 1}</strong>
                                                <div className="table-responsive">
                                                    <table className="table table-bordered border-primary mb-0">
                                                        <thead className="align-middle text-center bg-light">
                                                            <tr>
                                                                <th>Cancelled on or After</th>
                                                                <th>Cancelled on or Before</th>
                                                                <th>Cancelled Charges</th>
                                                            </tr>
                                                        </thead>

                                                        <tbody>
                                                            {
                                                                detail?.roomInfo?.cancellationPolicy?.cancellationPolicyDetails?.map((policy: any) => {
                                                                    return (
                                                                        <tr>
                                                                            <td>
                                                                                {moment(policy?.fromDate).format('DD/MMM/YYYY')}
                                                                            </td>
                                                                            <td>
                                                                                {moment(policy?.toDate).format('DD/MMM/YYYY')}
                                                                            </td>
                                                                            <td>
                                                                                {
                                                                                    policy?.chargeType === 'Percentage'
                                                                                        ? `${policy?.cancellationCharge}%`
                                                                                        : `${policy?.currency} ${policy?.cancellationCharge}`
                                                                                }
                                                                            </td>
                                                                        </tr>
                                                                    )
                                                                })
                                                            }
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div className='my-2'>{detail?.roomInfo?.cancellationPolicy?.defaultPolicy}</div>
                                                <div>{detail?.roomInfo?.cancellationPolicy?.autoCancellationText}</div>
                                            </React.Fragment>
                                        )
                                    })
                                }
                            </div>
                        </div>
                    </div>

                    <div className="row mt-4">
                        <div className="border p-3">
                            <div className="col-12 mt-3">
                                <div className="text-uppercase mb-2">
                                    <strong>Supplements</strong>
                                </div>
                                {rooms?.map((room: any, index: any) => (
                                    <div>
                                        <b>Room {index + 1}</b>
                                        {room?.supplements?.map((supplement: any) => (
                                            <div className="row">
                                                <div className="col-12 col-lg-6">
                                                    <div className="row">
                                                        <span className="col">
                                                            {supplement?.description}
                                                        </span>
                                                        <span className="col">{supplement?.type}</span>
                                                        <span className="col">
                                                            {supplement?.currency} {supplement?.price}
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>

                    <div className="row mt-4">
                        <div className="border p-3">
                            <div className="col-12">
                                <div className="mb-2">
                                    <h6>Terms & Conditions</h6>
                                </div>
                                <ul className="mb-0">
                                    <li>
                                        All rooms are guaranteed on the day of arrival. In the case
                                        of no-show, your room(s) will be released and you will
                                        subject to the terms and condition of the
                                        Cancellation/No-show policy specified at the time you made
                                        the booking as well as noted in the confirmation Email.
                                    </li>
                                    <li>
                                        The total price for these booking fees not include mini-bar
                                        items, telephone bills, laundry service, etc. The hotel will
                                        bill you directly.
                                    </li>
                                    <li>
                                        {' '}
                                        In case where breakfast is included with the room rate,
                                        please note that certain hotels may charge extra for
                                        children travelling with their parents.{' '}
                                    </li>
                                    <li>
                                        If applicable, the hotel will bill you directly. Upon
                                        arrival, if you have any questions, please verify with the
                                        hotel.
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </MainLayout>
        </>
    );
}

export default HotelQueueVoucher;