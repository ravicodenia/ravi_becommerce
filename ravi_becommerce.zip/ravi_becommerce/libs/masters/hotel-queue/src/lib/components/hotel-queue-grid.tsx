import * as React from 'react';
import { CustomGrid } from '@mfa-travel-app/shared';
import PopupState, { bindMenu, bindTrigger } from 'material-ui-popup-state';
import { IconButton, ListItemIcon, Menu, MenuItem } from '@mui/material';
import { FolderOpen, MoreVert, PublishedWithChanges } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

const HotelQueueGrid = ({ hotelQueueResults }: any) => {
    const navigate = useNavigate();

    const paginationOptions = [
        { id: 1, text: '10', value: '10' },
        { id: 2, text: '25', value: '25' },
        { id: 3, text: '50', value: '50' },
    ];

    const headerRowList = React.useMemo(() => {
        return [
            { label: 'SN' },
            { label: 'Booking On' },
            { label: 'Confirmation No.' },
            { label: 'Status' },
            { label: 'Hotel' },
            { label: 'No. of Rooms' },
            { label: 'No. of Guests' },
            { label: 'Provider' },
            { label: 'Location' },
            { label: 'Created By' },
            { label: 'Pax Name' },
            { label: 'Total Price' },
            { label: 'Check In' },
            { label: 'Check Out' },
            { label: 'Agent Ref' },
            { label: 'Supplier Ref' },
            { label: 'Actions' },
        ];
    }, []);

    const dataRowList = React.useMemo(() => {
        return [
            { param: 'sn' },
            { param: 'bookingOn', format: 'DD/MM/YYYY hh:mm:ss a', toolTip: true, convertAsTimezone: true },
            { param: 'confirmationNumber' },
            { param: 'bookingStatus' },
            { param: 'hotelName', toolTip: true, className: 'grid_column_100' },
            { param: 'noofRooms', className: 'text-center' },
            { param: 'adultCount, childCount', fixText: 'Adults, Child', separator: '&' },
            { param: 'supplierName' },
            { param: 'location' },
            { param: 'createdBy' },
            { param: 'leadPaxName' },
            { param: 'price' },
            { param: 'checkIn', format: 'DD/MM/YYYY hh:mm:ss a' },
            { param: 'checkOut', format: 'DD/MM/YYYY hh:mm:ss a' },
            { param: 'agentRef' },
            { param: 'supplierRef', toolTip: true,  className: 'grid_column_100' },
            { param: 'actions', className: 'text-center' },
        ];
    }, []);

    const ActionColumnComponent = React.useCallback((row: any) => {
        let rowData = JSON.parse(JSON.stringify(row[Object.keys(row)[0]]));

        return (
            <PopupState variant='popover' popupId={`hotel-queue-actions-${rowData.bookingId}`}>
                {(popupState) => (
                    <>
                        <IconButton {...bindTrigger(popupState)} size='small'>
                            <MoreVert fontSize='small' />
                        </IconButton>

                        <Menu {...bindMenu(popupState)}>
                            <MenuItem onClick={() => handleHotelQueueOpen(rowData, popupState)}>
                                <ListItemIcon>
                                    <FolderOpen fontSize='small' />
                                </ListItemIcon>
                                Open
                            </MenuItem>
                            <MenuItem onClick={popupState.close}>
                                <ListItemIcon>
                                    <PublishedWithChanges fontSize='small' />
                                </ListItemIcon>
                                Change Request
                            </MenuItem>
                        </Menu>
                    </>
                )}
            </PopupState>
      
        );
    }, []);

    const handleHotelQueueOpen = (row: any, popupState: any) => {
        popupState.close;

        navigate('/hotel-queue-open', { state: { bookingId: row.bookingId, hotelId: row.hotelId } });
    }

    return (
        <CustomGrid
            hasPagination={true}
            paginationOptions={paginationOptions}
            headerRowList={headerRowList}
            dataRowList={dataRowList}
            gridData={hotelQueueResults}
            hasSerialNumberColumn={true}
            hasActionColumn={true}
            ActionColumnComponent={ActionColumnComponent}
        />
    );
}

export default HotelQueueGrid;