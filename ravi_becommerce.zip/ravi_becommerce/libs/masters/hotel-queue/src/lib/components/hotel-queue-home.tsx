import * as React from 'react';
import { MainLayout } from '@mfa-travel-app/layout';
import HotelQueueFilters from './hotel-queue-filters';
import HotelQueueGrid from './hotel-queue-grid';
import { RootState, useHotelQueueStore, useMastersDropdownStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { agentRelatedDropdownsForFilters, agentIdAndTypeForFilters, API_ERROR_TOAST_TEXT, getParentAgentOptions, getSalesChannelOptions, getSupplierOptions, TEXT_TO_PICK_HOTEL_ID, updateLocationDropdownByAgentId, differentAgentTypeLists, convertErrorMessagesFromArray } from '@mfa-travel-app/shared';
import { toast } from 'react-toastify';
import { Loader } from '@mfa-travel-app/ui';
import { getHotelQueues } from '../service/hotel-queue-filters-api';
import { useLocation, useNavigate } from 'react-router-dom';

const HotelQueueHome = () => {
    const [loader, setLoader] = React.useState(false);
    const [hotelQueueResults, setHotelQueueResults] = React.useState([]);
    const { parentAgentList, supplierProductList, salesChannelList } = useSelector((state: RootState) => state.mastersDropdown);
    const { agentProfile, products } = useSelector((state: RootState) => state.config);
    const { agentAndBaseAgentList, hotelSupplierList, hotelQueueFilters } = useSelector((state: RootState) => state.hotelQueue);

    const { saveParentAgentList, saveSupplierProductList, saveSalesChannelList, saveLocationList } = useMastersDropdownStore();
    const { saveHotelQueueFilters, saveAgentAndBaseAgentList, saveBToBList, saveBToBToBList, saveHotelSupplierList, saveHotelBookingDetails } = useHotelQueueStore();

    const navigate = useNavigate();
    const location = useLocation();
    const { backFromOpenPage } = location.state || {};

    React.useEffect(() => {
        saveHotelBookingDetails({});
        getDropdownOptions();
    }, []);

    const getDropdownOptions = async () => {
        if (parentAgentList.length === 0) {
            getParentAgentOptions().then((options) => {
                saveParentAgentList(options);
                filterDifferentAgents(options);
                setHotelQueueFiltersInitialState(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        } else {
            if (agentAndBaseAgentList.length === 0) {
                filterDifferentAgents(parentAgentList);
            }

            if (backFromOpenPage) {
                handleSearchHotelQueue(hotelQueueFilters);
                navigate(location.pathname, { replace: true });
            } else {
                setHotelQueueFiltersInitialState(parentAgentList);
            }
        }

        if (supplierProductList.length === 0) {
            getSupplierOptions().then((options) => {
                saveSupplierProductList(options);
                filterSuppliersForHotel(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        } else {
            if (hotelSupplierList.length === 0) {
                filterSuppliersForHotel(supplierProductList);
            }
        }

        if (salesChannelList.length === 0) {
            getSalesChannelOptions().then((options) => {
                saveSalesChannelList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }
    }

    const filterDifferentAgents = (agentList: any) => {
        const agentTypeLists = differentAgentTypeLists(agentList);

        saveAgentAndBaseAgentList(agentTypeLists.agentAndBaseAgent);
        saveBToBList(agentTypeLists.bToB);
        saveBToBToBList(agentTypeLists.bToBToB);
    }

    const filterSuppliersForHotel = (supplierList: any) => {
        let productIdForHotel = products?.find((p: any) => p.text === TEXT_TO_PICK_HOTEL_ID)?.id;
        let hotelSuppliers = supplierList?.filter((s: any) => s.productId === productIdForHotel);

        saveHotelSupplierList(hotelSuppliers);
    }

    const setHotelQueueFiltersInitialState = async (agentList: any) => {
        let filters: any = {};
        filters.fromDate = new Date(new Date().setHours(0, 0, 0, 0)).toISOString();
        filters.toDate = new Date(new Date().setHours(23, 59, 59, 999)).toISOString();

        try {
            const filtersWithAgentSelectionAndDisable: any = await agentRelatedDropdownsForFilters(filters, agentList, agentProfile.id);
            const filtersWithAgentIdAndType: any = await agentIdAndTypeForFilters(filtersWithAgentSelectionAndDisable, '', 'initial');
            saveHotelQueueFilters(filtersWithAgentIdAndType);

            handleSearchHotelQueue(filtersWithAgentIdAndType);

            const locationOptions = await updateLocationDropdownByAgentId(filtersWithAgentIdAndType.agentId);
            saveLocationList(locationOptions);
        } catch (error) {
            console.error('An error occurred:', error);
            toast.error(API_ERROR_TOAST_TEXT);
        }
    }

    const handleSearchHotelQueue = async (queueFilters: any) => {
        let filters = JSON.parse(JSON.stringify(queueFilters));
        if (!filters.bookingModes) {
            filters.bookingModes = [];
        }

        if (!filters.supplierId) {
            filters.supplierId = [];
        }

        try {
            setLoader(true);
            const response: any = await getHotelQueues(filters);

            if (response?.data?.statusCode === 200) {
                setHotelQueueResults(response?.data?.result);
                setLoader(false);
                toast.success(response?.data?.message);
            } else {
                setHotelQueueResults([]);
                setLoader(false);
                toast.error(convertErrorMessagesFromArray(response?.data?.errorMessage));
            }
        } catch (error) {
            setLoader(false);
            console.error('An error occurred:', error);
            toast.error(API_ERROR_TOAST_TEXT);
        }
    }

    return (
        <MainLayout>
            <div className="container">
                <section className="country_section mt-2 mb-3 font_size_90">

                    <div className="row mt-3">
                        <HotelQueueFilters
                            handleSearchHotelQueue={handleSearchHotelQueue}
                        />
                    </div>

                    <div className="row mt-2">
                        <HotelQueueGrid
                            hotelQueueResults={hotelQueueResults}
                        />
                    </div>

                </section>
            </div>

            {loader && <Loader />}
        </MainLayout>
    );
}

export default HotelQueueHome;