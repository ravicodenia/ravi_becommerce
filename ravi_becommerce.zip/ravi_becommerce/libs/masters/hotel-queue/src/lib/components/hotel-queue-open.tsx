import * as React from 'react';
import { MainLayout } from '@mfa-travel-app/layout';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { MdOutlineClose } from 'react-icons/md';
import { getHotelBookingDetails } from '../service/hotel-queue-open-api';
import { toast } from 'react-toastify';
import { API_ERROR_TOAST_TEXT, convertErrorMessagesFromArray } from '@mfa-travel-app/shared';
import Skeleton, { SkeletonTheme } from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css';
import moment from 'moment';
import { RootState, useHotelQueueStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';

const HotelQueueOpen = () => {
    const [showHistory, setShowHistory] = React.useState(false);
    // const [hotelBookingDetails, setHotelBookingDetails] = React.useState<any>({});
    const { hotelBookingDetails } = useSelector((state: RootState) => state.hotelQueue);

    const { saveHotelBookingDetails } = useHotelQueueStore();

    const navigate = useNavigate();
    const location = useLocation();
    const { bookingId, hotelId } = location.state || {};

    React.useEffect(() => {
        if (!bookingId) {
            navigate('/hotel-queue', { replace: true });
        } else {
            getHotelBooking();
        }
    }, []);

    const getHotelBooking = async () => {
        try {
            const bookingDetails: any = await getHotelBookingDetails({ bookingId: bookingId, hotelId: hotelId });

            if (bookingDetails?.data?.statusCode === 200) {
                saveHotelBookingDetails(bookingDetails?.data?.result);
            } else {
                toast.error(convertErrorMessagesFromArray(bookingDetails?.data?.errorMessage));
            }
        } catch (error) {
            console.error('An error occurred:', error);
            toast.error(API_ERROR_TOAST_TEXT);
        }
    }

    const handleBackToHotelQueue = () => {
        navigate('/hotel-queue', { replace: true, state: { backFromOpenPage: true } });
    }

    const handleHotelQueueInvoice = () => {
        navigate('/hotel-queue-invoice');
    }

    const handleHotelQueueVoucher = () => {
        navigate('/hotel-queue-voucher');
    }

    const getNumberOfNights = () => {
        let checkIn = moment(new Date(hotelBookingDetails?.hotelItinerary?.checkInDate).setHours(0, 0, 0, 0));
        let checkOut = moment(new Date(hotelBookingDetails?.hotelItinerary?.checkOutDate).setHours(0, 0, 0, 0));

        if (checkIn && checkOut) {
            let nights = checkOut.diff(checkIn, 'days');
            return `${nights} ${nights > 1 ? 'Nights' : 'Night'}`;
        }

        return '';
    }

    const getNoOfRooms = () => {
        let noOfRooms = hotelBookingDetails?.hotelItinerary?.prices?.length;
        return noOfRooms ? noOfRooms : 0;
    }

    const getNoOfGuests = () => {
        let noOfGuests = 0;

        hotelBookingDetails?.hotelItinerary?.prices?.forEach((detail: any) => {
            noOfGuests += detail?.roomInfo?.adultCount;
            noOfGuests += detail?.roomInfo?.childCount;
        });

        return noOfGuests;
    }

    const getLeadPaxDetailRow = () => {
        let allPassengers: any = [];

        hotelBookingDetails?.hotelItinerary?.prices?.forEach((detail: any) => {
            allPassengers.push(detail?.roomInfo?.passangers);
        });

        let leadPax = allPassengers?.flat()?.find((p: any) => p.leadPassenger === true);

        return (
            <tr>
                <td>{`${leadPax.title}. ${leadPax.firstName} ${leadPax.lastName}`}</td>
                <td>{leadPax.email}</td>
                <td>{leadPax.phone}</td>
                <td>{`${leadPax.nationalityCode} - ${leadPax.nationality}`}</td>
            </tr>
        );
    }

    const getSourceCurrency = () => {
        let sourceCurrency = hotelBookingDetails?.hotelItinerary?.prices && hotelBookingDetails?.hotelItinerary?.prices[0]?.sourceCurrency;
        return sourceCurrency ? `(in ${sourceCurrency})` : '';
    }

    const getMarkupVatTotalValues = () => {
        let markup = 0;
        let vat = 0;
        let total = 0;

        hotelBookingDetails?.hotelItinerary?.prices?.forEach((detail: any) => {
            markup += detail?.markup;
            vat += detail?.invat_Amount + detail?.outvat_Amount;
            total += detail?.netFare;
        });

        return (
            <>
                <tr>
                    <td>MARKUP</td>
                    <td>{markup}</td>
                </tr>

                <tr>
                    <td>VAT</td>
                    <td>{vat}</td>
                </tr>

                <tr>
                    <td>TOTAL</td>
                    <td>{total}</td>
                </tr>

                <tr>
                    <td>GRAND TOTAL</td>
                    <td>{total + markup}</td>
                </tr>
            </>
        )
    }

    return (

        <>
            <MainLayout>
                <div className="container mt-3 mb-3">
                    <div className='row'>
                        <div className='col-lg-8'>
                            {
                                Object.keys(hotelBookingDetails).length !== 0 ? <div className='d-flex'>
                                    <div style={{ marginRight: '10px' }}>
                                        <button onClick={handleBackToHotelQueue}> <i className='fa-solid fa-arrow-left' /> Back </button>
                                    </div>
                                    {
                                        hotelBookingDetails?.hotelItinerary?.confirmationNo ? <>
                                            <div style={{ marginRight: '10px' }}>
                                                <button onClick={handleHotelQueueInvoice}> Invoice </button>
                                            </div>
                                            <div>
                                                <button onClick={handleHotelQueueVoucher}> Voucher </button>
                                            </div>
                                        </> : <></>
                                    }
                                </div> : <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                                    <Skeleton height={20} />
                                </SkeletonTheme>
                            }
                        </div>
                    </div>

                    <div className='row'>
                        <div className='col-lg-8'>

                            <div className='row'>
                                <div className='col-12  mt-2 mb-2'>
                                    {
                                        Object.keys(hotelBookingDetails).length !== 0 ? <table className="table border">
                                            <thead>
                                                <tr className='table-secondary'>
                                                    <th>Booking Details</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <h5>{hotelBookingDetails?.hotelItinerary?.hotelName}, {hotelBookingDetails?.hotelItinerary?.city}</h5>
                                                        <p>{hotelBookingDetails?.hotelItinerary?.addressLine1} {hotelBookingDetails?.hotelItinerary?.addressLine2 ? `, ${hotelBookingDetails?.hotelItinerary?.addressLine2}` : ''}</p>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>
                                                        <div className='row'>
                                                            <div className='col-lg-4'> <b>Check In:</b> {moment(hotelBookingDetails?.hotelItinerary?.checkInDate).format('DD/MMM/YYYY')}</div>
                                                            <div className='col-lg-4'> <b>Check Out: </b>{moment(hotelBookingDetails?.hotelItinerary?.checkOutDate).format('DD/MMM/YYYY')}</div>
                                                            <div className='col-lg-4'> {getNumberOfNights()}</div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table> : <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                                            <Skeleton height={150} />
                                        </SkeletonTheme>
                                    }
                                </div>

                                <div className='col-12  mt-2 mb-2'>
                                    {
                                        Object.keys(hotelBookingDetails).length !== 0 ? <table className="table table-bordered mb-0">
                                            {
                                                hotelBookingDetails?.hotelItinerary?.prices?.map((detail: any, index: any) => {
                                                    return <React.Fragment key={index}>
                                                        <thead className='align-middle text-center bg-light'>
                                                            <tr className='table-secondary'>
                                                                <th>ROOM TYPE</th>
                                                                <th>Room {index + 1}</th>
                                                            </tr>
                                                        </thead>

                                                        <tbody>
                                                            <tr className='text-muted text-center'>
                                                                <td>{detail?.roomInfo?.roomName}</td>
                                                                <td>{detail?.roomInfo?.adultCount} (ADULT(s)), {detail?.roomInfo?.childCount} (CHILD(s))</td>
                                                            </tr>
                                                        </tbody>
                                                    </React.Fragment>
                                                })
                                            }

                                            <thead className='align-middle text-center bg-light'>
                                                <tr className='table-secondary'>

                                                    <th>No. of Rooms</th>
                                                    <th>No. of Guests</th>
                                                </tr>
                                            </thead>

                                            <tbody>
                                                <tr className='text-muted text-center'>
                                                    <td>{getNoOfRooms()}</td>
                                                    <td>{getNoOfGuests()}</td>
                                                </tr>

                                            </tbody>

                                        </table> : <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                                            <Skeleton height={250} />
                                        </SkeletonTheme>
                                    }
                                </div>

                                <div className='col-12  mt-2 mb-2'>
                                    {
                                        Object.keys(hotelBookingDetails).length !== 0 ? <table className="table border">
                                            <thead>
                                                <tr className='table-secondary'>
                                                    <th colSpan={4}>Lead Guest  </th>
                                                </tr>

                                                <tr>
                                                    <th scope="col">Name</th>
                                                    <th scope="col">Email</th>
                                                    <th scope="col">Phone No.</th>
                                                    <th scope="col">Nationality</th>
                                                </tr>
                                            </thead>

                                            <tbody>
                                                {getLeadPaxDetailRow()}
                                            </tbody>
                                        </table> : <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                                            <Skeleton height={100} />
                                        </SkeletonTheme>
                                    }
                                </div>

                                <div className='col-12  mt-2 mb-2'>
                                    {
                                        Object.keys(hotelBookingDetails).length !== 0 ? <table className="table border">
                                            <thead>
                                                <tr className='table-secondary'>
                                                    <th>Hotel Norms</th>
                                                </tr>
                                            </thead>

                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <div
                                                            className='leTxtFit'
                                                            dangerouslySetInnerHTML={{
                                                                __html: hotelBookingDetails?.hotelItinerary?.hotelPolicyDetails
                                                                    ? `<ul><li>${hotelBookingDetails?.hotelItinerary?.hotelPolicyDetails}</li></ul>`
                                                                    : '--- No policy details available ---'
                                                            }}
                                                        />
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table> : <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                                            <Skeleton height={200} />
                                        </SkeletonTheme>
                                    }
                                </div>


                                <div className='col-12  mt-2 mb-2'>
                                    {
                                        Object.keys(hotelBookingDetails).length !== 0 ? <table className="table border">
                                            <thead>
                                                <tr className='table-secondary'>
                                                    <th>Cancellation and Charges</th>
                                                </tr>
                                            </thead>

                                            <tbody>
                                                <tr>
                                                    <td>
                                                        {
                                                            hotelBookingDetails?.hotelItinerary?.prices?.map((detail: any, index: any) => {
                                                                return (
                                                                    <React.Fragment key={index}>
                                                                        <strong>Room {index + 1}</strong>
                                                                        <div className="table-responsive">
                                                                            <table className="table table-bordered border-primary mb-0">
                                                                                <thead className="align-middle text-center bg-light">
                                                                                    <tr>
                                                                                        <th>Cancelled on or After</th>
                                                                                        <th>Cancelled on or Before</th>
                                                                                        <th>Cancelled Charges</th>
                                                                                    </tr>
                                                                                </thead>

                                                                                <tbody>
                                                                                    {
                                                                                        detail?.roomInfo?.cancellationPolicy?.cancellationPolicyDetails?.map((policy: any) => {
                                                                                            return (
                                                                                                <tr>
                                                                                                    <td>
                                                                                                        {moment(policy?.fromDate).format('DD/MMM/YYYY')}
                                                                                                    </td>
                                                                                                    <td>
                                                                                                        {moment(policy?.toDate).format('DD/MMM/YYYY')}
                                                                                                    </td>
                                                                                                    <td>
                                                                                                        {
                                                                                                            policy?.chargeType === 'Percentage'
                                                                                                                ? `${policy?.cancellationCharge}%`
                                                                                                                : `${policy?.currency} ${policy?.cancellationCharge}`
                                                                                                        }
                                                                                                    </td>
                                                                                                </tr>
                                                                                            )
                                                                                        })
                                                                                    }
                                                                                </tbody>
                                                                            </table>
                                                                        </div>
                                                                        <div className='my-2'>{detail?.roomInfo?.cancellationPolicy?.defaultPolicy}</div>
                                                                        <div>{detail?.roomInfo?.cancellationPolicy?.autoCancellationText}</div>
                                                                    </React.Fragment>
                                                                )
                                                            })
                                                        }
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table> : <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                                            <Skeleton height={200} />
                                        </SkeletonTheme>
                                    }

                                </div>

                                <div className='col-12  mt-2 mb-2'>
                                    <div className='row'>

                                        {
                                            Object.keys(hotelBookingDetails).length !== 0 ? <div className="col-12 mb-3">
                                                <Link
                                                    className='text-primary' to=''
                                                    onClick={() => setShowHistory(!showHistory)}
                                                >
                                                    {showHistory ? 'Hide' : 'Show'} Booking History
                                                </Link>
                                            </div> : <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                                                <Skeleton height={20} />
                                            </SkeletonTheme>
                                        }

                                        {
                                            showHistory ? <div className='col-12  mt-2 mb-2'>
                                                <table className='table border'>
                                                    <thead>
                                                        <tr className='table-secondary'>
                                                            <th colSpan={3}>Booking History</th>

                                                            <th className='text-end'>
                                                                <Link
                                                                    className='text-dark' to=''
                                                                    onClick={() => setShowHistory(false)}
                                                                >
                                                                    <MdOutlineClose />
                                                                </Link>
                                                            </th>
                                                        </tr>

                                                        <tr>
                                                            <th>Date</th>
                                                            <th>Time (Local)</th>
                                                            <th>Narration </th>
                                                            <th>Consultant</th>
                                                        </tr>
                                                    </thead>

                                                    <tbody>
                                                        {
                                                            hotelBookingDetails?.bookingHistories?.map((history: any, index: any) => {
                                                                return <tr key={index}>
                                                                    <td>
                                                                        {moment.utc(history?.createdOn).local().format('DD/MMM/YYYY')}
                                                                    </td>
                                                                    <td>
                                                                        {moment.utc(history?.createdOn).local().format('hh:mm a')}
                                                                    </td>
                                                                    <td>
                                                                        <div className='leTxtFit'>
                                                                            {history?.remarks} -
                                                                            Internal Status: {`${history?.internalStatus}`}
                                                                        </div>
                                                                    </td>
                                                                    <td> {history?.createdBy} </td>
                                                                </tr>
                                                            })
                                                        }
                                                    </tbody>
                                                </table>
                                            </div> : <></>
                                        }

                                    </div>

                                    <div className='row'>
                                        <div className='col-12 mt-2'>
                                            <div className="form-floating">
                                                <textarea
                                                    className="form-control" placeholder="Leave a comment here"
                                                    id="floatingTextarea2" style={{ height: '100px' }}
                                                />
                                                <label htmlFor="floatingTextarea2">Enter Comments</label>
                                            </div>

                                            <div className="col-12 text-end mt-3 mb-2">
                                                <button className='btn btn-sm btn-primary'>
                                                    Submit
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>

                        <div className='col-lg-4'>

                            <div className='col-12  mt-2 mb-2'>
                                {
                                    Object.keys(hotelBookingDetails).length !== 0 ? <table className="table border">
                                        <thead>
                                            <tr className='table-secondary'>
                                                <th colSpan={2}>Sales Summary</th>
                                            </tr>

                                            <tr>
                                                <th>Room Type</th>
                                                <th>TOTAL {getSourceCurrency()}</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            {
                                                hotelBookingDetails?.hotelItinerary?.prices?.map((detail: any, index: any) => {
                                                    return <tr key={index}>
                                                        <td>
                                                            <div className='leTxtFit'>
                                                                {detail?.roomInfo?.roomName}
                                                            </div>
                                                        </td>
                                                        <td>{detail?.sourceAmount}</td>
                                                    </tr>
                                                })
                                            }

                                            {
                                                getMarkupVatTotalValues()
                                            }
                                        </tbody>
                                    </table> : <SkeletonTheme baseColor="#ddd" highlightColor="#eee">
                                        <Skeleton height={350} />
                                    </SkeletonTheme>
                                }
                            </div>

                        </div>

                    </div>

                </div>
            </MainLayout>
        </>

    )
}

export default HotelQueueOpen;