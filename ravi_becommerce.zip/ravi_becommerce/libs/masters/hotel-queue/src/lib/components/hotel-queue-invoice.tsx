import { Logo } from '@mfa-travel-app/assets';
import { RootState } from '@mfa-travel-app/store';
import moment from 'moment';
import { useRef } from 'react';
import { useSelector } from 'react-redux';
import { useReactToPrint } from 'react-to-print';

const HotelQueueInvoice = () => {
    const contentToPrint = useRef(null);
    const { hotelBookingDetails } = useSelector((state: RootState) => state.hotelQueue);

    const handlePrint = useReactToPrint({
        documentTitle: "Print This Document",
        removeAfterPrint: true,
    });

    const getNumberOfNights = () => {
        let checkIn = moment(new Date(hotelBookingDetails?.hotelItinerary?.checkInDate).setHours(0, 0, 0, 0));
        let checkOut = moment(new Date(hotelBookingDetails?.hotelItinerary?.checkOutDate).setHours(0, 0, 0, 0));

        if (checkIn && checkOut) {
            let nights = checkOut.diff(checkIn, 'days');
            return `${nights} ${nights > 1 ? 'Nights' : 'Night'}`;
        }

        return '';
    }

    const getNoOfRooms = () => {
        let noOfRooms = hotelBookingDetails?.hotelItinerary?.prices?.length;
        return noOfRooms ? noOfRooms : 0;
    }

    const getLeadPaxName = () => {
        let allPassengers: any = [];

        hotelBookingDetails?.hotelItinerary?.prices?.forEach((detail: any) => {
            allPassengers.push(detail?.roomInfo?.passangers);
        });

        let leadPax = allPassengers?.flat()?.find((p: any) => p.leadPassenger === true);

        if (leadPax) {
            return (
                <tr>
                    <td>{`${leadPax.title}. ${leadPax.firstName} ${leadPax.lastName}`}</td>
                </tr>
            );
        }

        return <></>;
    }

    const getPriceDetails = () => {
        let sourceCurrency = hotelBookingDetails?.hotelItinerary?.prices && hotelBookingDetails?.hotelItinerary?.prices[0]?.sourceCurrency;
        let markup = 0;
        let discount = 0;
        let inVat = 0;
        let outVat = 0;
        let total = 0;

        hotelBookingDetails?.hotelItinerary?.prices?.forEach((detail: any) => {
            markup += detail?.markup;
            discount += detail?.discount;
            inVat += detail?.invat_Amount;
            outVat += detail?.outvat_Amount;
            total += detail?.netFare;
        });

        return (
            <>
                <tr>
                    <td style={{ paddingLeft: '10px', textAlign: 'right', width: '100px', borderBottom: 'solid 1px #ccc' }}>Net Amount:</td>
                    <td style={{ paddingLeft: '10px', textAlign: 'left', borderBottom: 'solid 1px #ccc' }}>
                        {`${sourceCurrency} ${total}`}
                    </td>
                </tr>

                <tr>
                    <td style={{ paddingLeft: '10px', textAlign: 'right', borderBottom: 'solid 1px #ccc' }}>Markup:</td>
                    <td style={{ paddingLeft: '10px', textAlign: 'left', borderBottom: 'solid 1px #ccc' }}>
                        {`${sourceCurrency} ${markup}`}
                    </td>
                </tr>

                {
                    discount > 0 ? <tr>
                        <td style={{ paddingLeft: '10px', textAlign: 'right', borderBottom: 'solid 1px #ccc' }}>Discount:</td>
                        <td style={{ paddingLeft: '10px', textAlign: 'left', borderBottom: 'solid 1px #ccc' }}>
                            {`${sourceCurrency} ${discount}`}
                        </td>
                    </tr> : <></>
                }

                <tr>
                    <td style={{ paddingLeft: '10px', textAlign: 'right', borderBottom: 'solid 1px #ccc' }}>In Vat:</td>
                    <td style={{ paddingLeft: '10px', textAlign: 'left', borderBottom: 'solid 1px #ccc' }}>
                        {`${sourceCurrency} ${inVat}`}
                    </td>
                </tr>

                <tr>
                    <td style={{ paddingLeft: '10px', textAlign: 'right', borderBottom: 'solid 1px #ccc' }}>Gross Amount:</td>
                    <td style={{ paddingLeft: '10px', textAlign: 'left', borderBottom: 'solid 1px #ccc' }}>
                        {`${sourceCurrency} ${total + markup - discount + inVat}`}
                    </td>
                </tr>

                <tr>
                    <td style={{ paddingLeft: '10px', textAlign: 'right', borderBottom: 'solid 1px #ccc' }}>Out Vat:</td>
                    <td style={{ paddingLeft: '10px', textAlign: 'left', borderBottom: 'solid 1px #ccc' }}>
                        {`${sourceCurrency} ${outVat}`}
                    </td>
                </tr>

                <tr>
                    <td style={{ paddingLeft: '10px', textAlign: 'right', borderBottom: 'solid 1px #ccc' }}>Total Amount:</td>
                    <td style={{ paddingLeft: '10px', textAlign: 'left', borderBottom: 'solid 1px #ccc' }}>
                        <b>{`${sourceCurrency} ${total + markup - discount + inVat + outVat}`}</b>
                    </td>
                </tr>
            </>
        )
    }

    return (
        <div style={{ padding: '0 10px' }}>
            <table ref={contentToPrint} style={{ fontSize: '13px', width: '96%', margin: 'auto' }}>
                <tbody>



                    <tr>
                        <td style={{ textAlign: 'start' }}>
                            <img style={{ height: '16px' }} src={Logo} alt="logo" />
                        </td>

                        <td style={{ textAlign: 'center' }}> <h4 style={{ margin: '0' }}>Invoice</h4> </td>

                        <td style={{ textAlign: 'end' }}>

                            <table style={{ display: 'inline' }}>
                                <tbody>

                                    <tr>
                                        <td style={{ textAlign: 'end' }}>
                                            <button onClick={() => {
                                                handlePrint(null, () => contentToPrint.current);
                                            }}>Print</button>

                                            <button>Email</button>

                                        </td>

                                    </tr>

                                    <tr>

                                        <td>Agent Name: B-Commerce</td>
                                    </tr>

                                    <tr>

                                        <td>Agent eMail: Support@bcommerce.com </td>
                                    </tr>

                                    <tr>

                                        <td>Phone: +1 618 7785580 </td>
                                    </tr>

                                </tbody>
                            </table>


                        </td>
                    </tr>

                    <tr>
                        <td colSpan={3}>

                            <table style={{ fontSize: '13px', width: '100%', border: 'solid 1px #ccc', marginBottom: '20px' }}>
                                <thead>

                                    <tr style={{ background: '#f2aa3b', color: 'white' }}>
                                        <th style={{ paddingLeft: '10px', borderRight: 'solid 1px #ccc' }}>Invoice Details</th>
                                    </tr>
                                </thead>

                                <tbody>


                                    <tr>
                                        <td style={{ borderRight: 'solid 1px #ccc' }}>
                                            <table style={{ fontSize: '13px', width: '100%' }}>
                                                <thead>
                                                    <tr>
                                                        <th style={{ paddingLeft: '10px', borderRight: 'solid 1px #ccc' }}> Invoice No.</th>
                                                        <th style={{ paddingLeft: '10px', borderRight: 'solid 1px #ccc' }}>Date </th>
                                                        <th style={{ paddingLeft: '10px', borderRight: 'solid 1px #ccc' }}> Confirmation No. </th>
                                                        <th style={{ paddingLeft: '10px' }}> Voucher No. </th>
                                                    </tr>
                                                </thead>

                                                <tbody>
                                                    <tr style={{ height: '30px' }}>
                                                        <td style={{ paddingLeft: '10px', borderRight: 'solid 1px #ccc' }}>
                                                            {hotelBookingDetails?.hotelItinerary?.invoice?.documentNumber}
                                                        </td>
                                                        <td style={{ paddingLeft: '10px', borderRight: 'solid 1px #ccc' }}>
                                                            {moment(hotelBookingDetails?.createdOn).format('DD/MMM/YYYY')}
                                                        </td>
                                                        <td style={{ paddingLeft: '10px', borderRight: 'solid 1px #ccc' }}>
                                                            {hotelBookingDetails?.hotelItinerary?.confirmationNo}
                                                        </td>
                                                        <td style={{ paddingLeft: '10px' }}>
                                                            {hotelBookingDetails?.hotelItinerary?.systemReference}
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>

                    <tr>
                        <td colSpan={3}>

                            <table style={{ fontSize: '13px', width: '100%', border: 'solid 1px #ccc', marginBottom: '20px' }}>
                                <thead>
                                    <tr style={{ background: '#173540', color: 'white' }}>
                                        <th style={{ paddingLeft: '10px', borderRight: 'solid 1px #ccc' }}>Client Details</th>
                                    </tr>
                                </thead>

                                <tbody>


                                    <tr>
                                        <td style={{ paddingLeft: '10px', borderRight: 'solid 1px #ccc' }}>

                                            <table style={{ fontSize: '13px', width: '100%' }}>


                                                <thead>

                                                    <tr>

                                                        <th style={{ borderRight: 'solid 1px #ccc' }}>Agency Name</th>
                                                        <th style={{ paddingLeft: '10px', borderRight: 'solid 1px #ccc' }}>	Agency Code </th>
                                                        <th style={{ paddingLeft: '10px', borderRight: 'solid 1px #ccc' }}>Agency Address </th>
                                                        <th style={{ paddingLeft: '10px', borderRight: 'solid 1px #ccc' }}> TelePhone No </th>
                                                        <th style={{ paddingLeft: '10px' }}> TRN Number </th>

                                                    </tr>


                                                </thead>

                                                <tbody>

                                                    <tr style={{ height: '30px' }}>

                                                        <td style={{ borderRight: 'solid 1px #ccc' }}>Akbar Travel LLC</td>
                                                        <td style={{ paddingLeft: '10px', borderRight: 'solid 1px #ccc' }}>AERCPETR1</td>
                                                        <td style={{ paddingLeft: '10px', borderRight: 'solid 1px #ccc' }}>address</td>
                                                        <td style={{ paddingLeft: '10px', borderRight: 'solid 1px #ccc' }}>Phone: 0097165074592, Fax: 6454788</td>
                                                        <td style={{ paddingLeft: '10px' }}>6454878</td>

                                                    </tr>



                                                </tbody>



                                            </table>



                                        </td>


                                    </tr>




                                </tbody>




                            </table>



                        </td>

                    </tr>


                    <tr>
                        <td colSpan={3}>

                            <table style={{ fontSize: '13px', width: '100%', border: 'solid 1px #ccc', marginBottom: '20px' }}>
                                <thead>
                                    <tr style={{ background: '#173540', color: 'white' }}>
                                        <th style={{ paddingLeft: '10px', borderRight: 'solid 1px #ccc' }}>Booking Details</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <tr>
                                        <td style={{ paddingLeft: '10px', borderRight: 'solid 1px #ccc' }}>

                                            <table style={{ fontSize: '13px', width: '100%' }}>
                                                <tbody>
                                                    <tr style={{ height: '30px' }}>
                                                        <th>Booking Date: </th>
                                                        <td>{moment(hotelBookingDetails?.createdOn).format('DD/MMM/YYYY')}</td>
                                                    </tr>

                                                    <tr style={{ height: '30px' }}>
                                                        <th>Check In: </th>
                                                        <td>
                                                            {moment(hotelBookingDetails?.hotelItinerary?.checkInDate).format('DD/MMM/YYYY')}
                                                        </td>
                                                        <th>Check Out: </th>
                                                        <td>
                                                            {moment(hotelBookingDetails?.hotelItinerary?.checkOutDate).format('DD/MMM/YYYY')}
                                                        </td>
                                                    </tr>

                                                    <tr style={{ height: '30px' }}>
                                                        <th>No. of Night(s): </th>
                                                        <td>{getNumberOfNights()}</td>
                                                        <th>No. of Room(s): </th>
                                                        <td>{getNoOfRooms()}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>

                        </td>
                    </tr>


                    <tr>

                        <td colSpan={3}>

                            <table style={{ fontSize: '13px', width: '100%', border: 'solid 1px #ccc', marginBottom: '20px' }}>
                                <thead>
                                    <tr style={{ background: '#173540', color: 'white' }}>
                                        <th style={{ paddingLeft: '10px', borderRight: 'solid 1px #ccc' }}>Hotel Details</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <tr>
                                        <td style={{ paddingLeft: '10px', borderRight: 'solid 1px #ccc' }}>

                                            <table style={{ fontSize: '13px', width: '100%' }}>
                                                <tbody>
                                                    <tr style={{ height: '30px' }}>
                                                        <th>Hotel Name: </th>
                                                        <td>{hotelBookingDetails?.hotelItinerary?.hotelName}</td>
                                                    </tr>

                                                    <tr style={{ height: '30px' }}>
                                                        <th>Address1: </th>
                                                        <td>{hotelBookingDetails?.hotelItinerary?.addressLine1}</td>
                                                    </tr>

                                                    <tr style={{ height: '30px' }}>
                                                        <th>City:  </th>
                                                        <td>{hotelBookingDetails?.hotelItinerary?.city}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>

                    <tr>
                        <td colSpan={3}>

                            <table style={{ fontSize: '13px', width: '100%', border: 'solid 1px #ccc' }}>
                                <thead>
                                    <tr style={{ background: '#ddd' }}>
                                        <th style={{ paddingLeft: '10px' }}>Lead Passanger Details</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <tr>
                                        <td style={{ paddingLeft: '10px', height: '30px' }}>
                                            {getLeadPaxName()}
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>

                    <tr>
                        <td style={{ textAlign: 'end' }} colSpan={3}>

                            <table style={{ fontSize: '13px', width: '190px', display: 'inline-block' }}>
                                <tbody>
                                    {getPriceDetails()}
                                </tbody>
                            </table>
                        </td>
                    </tr>

                    <tr>
                        <td style={{ textAlign: 'end' }} colSpan={3}>

                            <table style={{ fontSize: '13px', width: '100%', marginTop: '6px', marginBottom: '30px' }}>
                                <tbody>
                                    <tr>
                                        <td style={{ paddingLeft: '10px', textAlign: 'left' }}>
                                            Invoice By: {hotelBookingDetails?.bookedBy}
                                        </td>
                                    </tr>
                                </tbody>
                            </table>

                        </td>
                    </tr>
                </tbody>
            </table>

        </div>
    );
}

export default HotelQueueInvoice;