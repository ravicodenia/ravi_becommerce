import { Modal, ModalBody } from 'react-bootstrap';
import { useState } from 'react';
import { updateApprovalStatus } from '../service/agent-payment-approval-api';
import { Loader } from '@mfa-travel-app/ui';
import { API_ERROR_TOAST_TEXT } from '@mfa-travel-app/shared';
import { toast } from 'react-toastify';

export default function ApproveRejectModal({ agentPaymentId, onStatusUpdate,approveStatus  }: any) {
  const [loader, setLoader] = useState(false);
  const [rejectRemarks, setRejectRemarks] = useState('');
  const [approveRejectModal, setApproveRejectModal] = useState(false);
  const [showButtons, setShowButtons] = useState(true);
  const [textArea, setTextArea] = useState(false);

  const showCommentSection = () => {
    setTextArea(true);
    setShowButtons(false);
  };

  const handleApprovalStatus = async (e: any, status: string) => {
    e.preventDefault();
    try {
      setLoader(true);
      const response: any = await updateApprovalStatus(
        agentPaymentId,
        status,
        rejectRemarks
      );
      if (response?.data?.statusCode === 200) {
        toast.success(response?.data?.message);
        onStatusUpdate()
      } else {
        toast.error(response?.data?.message);
      }
    } catch (error) {
      console.error('An error occurred:', error);
      toast.error(API_ERROR_TOAST_TEXT);
    }
    setLoader(false);
    setApproveRejectModal(false);
    setTextArea(false);
    setRejectRemarks('')
  };

  return (
    <>
      <button
        onClick={() => setApproveRejectModal(true)}
        className="btn text-secondary"
        style={{visibility : approveStatus == 'Approved' || approveStatus == 'Rejected' ? 'hidden':'visible'}}
      >
        <i className="fa-solid fa-eye"></i>
      </button>

      <Modal
        size="sm"
        centered
        show={approveRejectModal}
        onHide={() => setApproveRejectModal(false)}
      >
        <Modal.Header closeButton>
          <Modal.Title>Action </Modal.Title>
        </Modal.Header>

        <ModalBody>
          <div className="row">
            {showButtons && (
              <div className="col-12">
                <button
                  onClick={showCommentSection}
                  type="button"
                  className="btn btn-danger me-2"
                >
                  <i className="fa-solid fa-xmark"></i> Reject
                </button>
                <button
                  type="button"
                  className="btn btn-success text-light me-2"
                  onClick={(e) => handleApprovalStatus(e, 'Y')}
                >
                  <i className="fa-solid fa-check"></i> Approve
                </button>
              </div>
            )}

            {textArea && (
              <div className="col-12">
                <div className="form-floating">
                  <textarea
                    value={rejectRemarks}
                    className="form-control"
                    placeholder="Leave a comment here"
                    onChange={(e: any) => setRejectRemarks(e.target.value)}
                  ></textarea>
                  <label htmlFor="floatingTextarea">Comments</label>
                </div>

                <div className="mt-3 mb-2 text-end">
                  <button
                    type="button"
                    onClick={(e) => handleApprovalStatus(e, 'R')}
                    className="btn btn-primary rounded"
                  >
                    {' '}
                    Submit{' '}
                  </button>{' '}
                </div>
              </div>
            )}
          </div>
        </ModalBody>
      </Modal>
      {loader && <Loader />}
    </>
  );
}
