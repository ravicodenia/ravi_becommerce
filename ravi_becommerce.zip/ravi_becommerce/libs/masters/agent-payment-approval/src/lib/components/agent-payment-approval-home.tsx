import { MainLayout } from '@mfa-travel-app/layout';
import { ControlledSelect, ControlledDatePicker } from '@mfa-travel-app/ui';
import {
  getParentAgentOptions,
  API_ERROR_TOAST_TEXT,
} from '@mfa-travel-app/shared';
import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import {
  RootState,
  useMastersDropdownStore,
  useAgentPaymentStore,
} from '@mfa-travel-app/store';
import ApproveRejectModal from './ApproveRejectModal';
import Paging from './paging';
import ViewPerPage from './viewPerPage';
import { getAgentPayment } from '../service/agent-payment-approval-api';
import { Loader } from '@mfa-travel-app/ui';
import { toast } from 'react-toastify';
import 'react-tooltip/dist/react-tooltip.css';
import { Tooltip } from 'react-tooltip';
import { MdFileDownload } from 'react-icons/md';
import * as XLSX from 'xlsx';

import { saveAs } from 'file-saver';

// const sampleText =
//   'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.';

const AgentPaymentApprovalHome = () => {
  const { saveParentAgentList } = useMastersDropdownStore();
  const { saveAgentPayment, saveAgentPaymentSearchPayload } =
    useAgentPaymentStore();
  const { parentAgentList } = useSelector(
    (state: RootState) => state.mastersDropdown
  );
  const { agentPaymentData, agentPaymentSearchPayload } = useSelector(
    (state: RootState) => state.agentPayment
  );

  const [loader, setLoader] = useState(false);
  const [fromDate, setFromDate] = useState(
    agentPaymentSearchPayload?.fromDate
      ? agentPaymentSearchPayload?.fromDate
      : ''
  );
  const [toDate, setToDate] = useState(
    agentPaymentSearchPayload?.toDate ? agentPaymentSearchPayload?.toDate : ''
  );
  const [agentId, setAgentId] = useState(
    agentPaymentSearchPayload?.agentId ? agentPaymentSearchPayload?.agentId : ''
  );
  const [status, setStatus] = useState(
    agentPaymentSearchPayload?.status ? agentPaymentSearchPayload?.status : ''
  );
  const [agentPaymentFileData, setAgentPaymentFileData] = useState([]);

  const exportToExcel = (data: any[], fileName: string) => {
    try {
      // Create a new workbook
      const wb = XLSX.utils.book_new();
  
      // Convert JSON data to a worksheet
      const ws = XLSX.utils.aoa_to_sheet(data);
  
      // Append the worksheet to the workbook
      XLSX.utils.book_append_sheet(wb, ws, 'Approval');
  
      // Write the workbook to a binary string
      const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  
      // Create a Blob from the binary string
      const blob = new Blob([wbout], { type: 'application/octet-stream' });
  
      // Save the Blob as a file
      saveAs(blob, fileName);
    } catch (error) {
      console.error('Error exporting to Excel:', error);
    }
  };
  const selectOptions = [
    { id: 'all', text: 'All' },
    { id: 'approved', text: 'Approved' },
    { id: 'rejected', text: 'Rejected' },
  ];

  useEffect(() => {
    getDropdownOptions();
  }, []);

  useEffect(() => {
    getDates();
  }, [fromDate, toDate]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    let from = new Date();
    if (fromDate !== '') {
      from = new Date(fromDate);
    }
    from.setHours(0, 0, 0);
    setFromDate(from.toISOString());

    let to = new Date();
    if (toDate !== '') {
      to = new Date(toDate);
    }
    // console.log(
    //   to.getDate() != new Date().getDate() &&
    //     to.getMonth() != new Date().getMonth() &&
    //     to.getFullYear() != new Date().getFullYear()
    // );
    if (
      to.getDate() != new Date().getDate() &&
      to.getMonth() != new Date().getMonth() &&
      to.getFullYear() != new Date().getFullYear()
    ) {
      to.setHours(23, 59, 59);
    }
    setToDate(to.toISOString());

    if (!validatePayload(from.toISOString(), to.toISOString())) {
      toast.error('From Date cannot be greater than To Date');
      return;
    }

    saveAgentPaymentSearchPayload({
      fromDate: from.toISOString(),
      toDate: to.toISOString(),
      agentId: agentId,
      status: status,
    });
    try {
      setLoader(true);
      const response: any = await getAgentPayment(
        from.toISOString(),
        to.toISOString(),
        agentId,
        status
      );

      if (response?.status === 200) {
        const sortedData = response?.data.sort(
          (a: any, b: any) =>
            new Date(b.createdOn).getTime() - new Date(a.createdOn).getTime()
        );
        saveAgentPayment(sortedData);
        parseAgentPaymentFileData(sortedData);
        setLoader(false);
        // toast.success(response?.statusText);
      } else {
        setLoader(false);
        // toast.error(response?.statusText);
      }
    } catch (error) {
      setLoader(false);
      console.error('An error occurred:', error);
      toast.error(API_ERROR_TOAST_TEXT);
    }
  };

  const parseAgentPaymentFileData = (tableData:any) => {
    let fileData:any = [];

    // Adding Header
    fileData.push([
      "SN",
      "Reference ID ",
      "Trans Type ",
      "Details",
      "Pay Mode ",
      "Amount",
      "Status",
      "Agent",
      "Requested By ",
      "Requested Date "
    ]);
    let totalSum:number = 0;
    tableData && tableData.forEach((data:any, index:number) => {
      fileData.push([
        index+1,
        data?.receiptNo,
        data?.transactionType,
        data?.details,
        data?.paymentMode,
        data?.amount,
        getStatus(data?.approvalStatus),
        data?.agentName,
        data?.requestedBy,
        formatDate(data?.createdOn)
      ]);
      totalSum = totalSum + data?.amount;
    });
    // Adding GrandTotal in end
    fileData.push(["", "", "", "", "Grand Total", totalSum, "", "", "", ""]);

    setAgentPaymentFileData(fileData);
  };

  const getDates = () => {
    // const today = new Date()
    let from = new Date();
    if (fromDate !== '') {
      from = new Date(fromDate);
    }
    from.setHours(0, 0, 0);
    setFromDate(from.toISOString());

    let to = new Date();
    if (toDate !== '') {
      to = new Date(toDate);
    }
    if (
      to.getDate() != new Date().getDate() ||
      to.getMonth() != new Date().getMonth() ||
      to.getFullYear() != new Date().getFullYear()
    ) {
      to.setHours(23, 59, 59);
    }
    setToDate(to.toISOString());
  };

  const getDropdownOptions = async () => {
    if (parentAgentList.length === 0) {
      getParentAgentOptions()
        .then((options) => {
          saveParentAgentList(options);
        })
        .catch((error) => {
          console.error('error', error);
          toast.error(API_ERROR_TOAST_TEXT);
        });
    }
  };

  function formatDate(isoDateString: string) {
    const date = new Date(isoDateString);

    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();

    let hours = date.getHours();
    const minutes = String(date.getMinutes()).padStart(2, '0');

    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;

    return `${day}/${month}/${year} ${String(hours).padStart(
      2,
      '0'
    )}:${minutes} ${ampm}`;
  }

  const getAgentName = (agentId: any) => {
    const agent = parentAgentList.find((agent: any) => agent.id == agentId);
    return agent?.text;
  };

  const agentListWithCode = parentAgentList?.map((agent: any) => {
    return {
      ...agent,
      text: `${agent?.id} - ${agent?.text}`,
    };
  });

  const getStatus = (status: string) => {
    let statusText = '';
    switch (status) {
      case 'Y':
        statusText = 'Approved';
        break;
      case 'R':
        statusText = 'Rejected';
        break;
      case 'N':
        statusText = 'Pending';
        break;
      default:
        break;
    }
    return statusText;
  };

  // const downloadDepositSlip = (url:any) => {
  //   // Create an invisible anchor element
  //   const a = document.createElement('a');
  //   a.href = url;

  //   // Set the download attribute with a filename
  //   a.download = url.split('/').pop();  // Automatically extract the file name

  //   // Append the anchor to the body
  //   document.body.appendChild(a);

  //   // Trigger the download by simulating a click
  //   a.click();

  //   // Remove the anchor from the document
  //   document.body.removeChild(a);
  // };

  const downloadDepositSlip = async (url: any) => {
    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/octet-stream',
        },
      });

      if (!response.ok) {
        toast.error(
          <div>
            <span>
              {response?.status} - {response?.statusText}
            </span>
            <br />
            <span>Error downloading file</span>
          </div>
        );
        throw new Error('Network response was not ok');
      }

      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);

      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = 'download';

      document.body.appendChild(a);
      a.click();

      document.body.removeChild(a);
      window.URL.revokeObjectURL(downloadUrl);
    } catch (error) {
      console.error('Download error:', error);
    }
  };

  const validatePayload = (fromDate: any, toDate: any) => {
    let ret = true;
    if (new Date(toDate).getTime() < new Date(fromDate).getTime()) {
      ret = false;
    }
    return ret;
  };

  const handleSearch = async (e: any) => {
    e.preventDefault();
    if (!validatePayload(fromDate, toDate)) {
      toast.error('From Date cannot be greater than To Date');
      return;
    }
    saveAgentPaymentSearchPayload({
      fromDate: fromDate,
      toDate: toDate,
      agentId: agentId,
      status: status,
    });
    try {
      setLoader(true);
      const response: any = await getAgentPayment(
        fromDate,
        toDate,
        agentId,
        status
      );

      if (response?.status === 200) {
        const sortedData = response?.data.sort(
          (a: any, b: any) =>
            new Date(b.createdOn).getTime() - new Date(a.createdOn).getTime()
        );
        saveAgentPayment(sortedData);
        parseAgentPaymentFileData(sortedData);
        setLoader(false);
        // toast.success(response?.statusText);
      } else {
        setLoader(false);
        // toast.error(response?.statusText);
      }
    } catch (error) {
      setLoader(false);
      console.error('An error occurred:', error);
      toast.error(API_ERROR_TOAST_TEXT);
    }
  };
const onExport = () =>{
  exportToExcel(agentPaymentFileData, 'PaymentApproval_' + Date.now() + '.xlsx');
}
  return (
    <>
      <MainLayout>
        <div className="container">
          <section className="country_section mt-2 mb-3">
            <div className="row">
              <div className="col-12">
                <nav className="navbar navbar-light bg-light">
                  <nav aria-label="breadcrumb">
                    <ol className="breadcrumb">
                      <li className="breadcrumb-item">
                        <a href="index.html">HOME</a>
                      </li>
                      <li className="breadcrumb-item">
                        <a href="#">SETTINGS</a>
                      </li>
                      <li
                        className="breadcrumb-item active"
                        aria-current="page"
                      >
                        BALANCE APPROVAL
                      </li>
                    </ol>
                  </nav>

                  <div className="options_section">
                    <ul>
                      <li>
                        <a onClick={onExport}>
                          <i className="fa-solid fa-file-export"></i> Export
                        </a>
                      </li>

                      {/* <li>
                        <a href="#">
                          <i className="fa-solid fa-rotate-right"></i> Refresh
                        </a>
                      </li> */}
                    </ul>
                  </div>
                </nav>
              </div>
            </div>

            <div className="row mt-3 mb-3 font_size_90">
              <div className="col-lg-5">
                <div className="row">
                  <div className="col-lg-6">
                    <div className="row align-items-center mb-3">
                      <label className="col-sm-5 text-lg-end">
                        {' '}
                        From Date:
                      </label>
                      <div className="col-sm-7">
                        <ControlledDatePicker
                          id={'fromDate'}
                          value={fromDate}
                          format={'dd/MMM/yyyy'}
                          required={true}
                          disablePostDates={true}
                          onChange={(date: any) =>
                            setFromDate(date.toISOString())
                          }
                        />
                      </div>
                    </div>
                  </div>

                  <div className="col-lg-6">
                    <div className="row align-items-center mb-3">
                      <label className="col-sm-5 text-lg-end"> To Date:</label>
                      <div className="col-sm-7">
                        <ControlledDatePicker
                          id={'toDate'}
                          value={toDate}
                          format={'dd/MMM/yyyy'}
                          required={true}
                          onChange={(date: any) =>
                            setToDate(date.toISOString())
                          }
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-lg-3">
                <div className="row align-items-center mb-3">
                  <label className="col-sm-4 text-lg-end">Agent:</label>
                  <div className="col-sm-8">
                    <ControlledSelect
                      id={'firm'}
                      value={agentId}
                      options={agentListWithCode}
                      required={true}
                      onChange={(e: any) => setAgentId(e.target.value)}
                    />
                  </div>
                </div>
              </div>

              <div className="col-lg-3">
                <div className="row align-items-center mb-3">
                  <label className="col-sm-4 text-lg-end">Status:</label>
                  <div className="col-sm-8">
                    <ControlledSelect
                      id={'status'}
                      value={status}
                      options={selectOptions}
                      required={true}
                      onChange={(e: any) => setStatus(e.target.value)}
                    />
                  </div>
                </div>
              </div>

              <div className="col-lg-1 text-end">
                <button
                  type="button"
                  className="btn btn-sm btn-primary rounded mt-1"
                  onClick={(e) => handleSearch(e)}
                >
                  SUBMIT
                </button>
              </div>
            </div>

            {agentPaymentData?.length != 0 && (
              <>
                <div className="row">
                  <div className="col-12">
                    <div className="table-responsive">
                      <table className="table text-secondary">
                        <thead>
                          <tr>
                            <th scope="col">SN</th>
                            <th scope="col">Reference ID </th>
                            <th scope="col">Trans Type </th>
                            <th scope="col">Details</th>
                            <th scope="col">Pay Mode </th>
                            <th scope="col">Amount</th>
                            <th scope="col">Status</th>
                            <th scope="col">Agent</th>
                            <th scope="col">Requested By </th>
                            <th scope="col">Requested Date </th>
                            <th scope="col">Action</th>
                          </tr>
                        </thead>

                        <tbody>
                          {agentPaymentData?.map((data: any, index: any) => (
                            <tr key={index}>
                              <td>{index + 1}</td>
                              <td>{data?.receiptNo}</td>
                              <td>{data?.transactionType}</td>
                              <td
                                style={{
                                  maxWidth: '22ch',
                                  whiteSpace: 'nowrap',
                                  overflow: 'hidden',
                                  textOverflow: 'ellipsis',
                                }}
                              >
                                {data?.details?.length > 21 ? (
                                  <>
                                    <a
                                      data-tooltip-id="details-tooltip"
                                      data-tooltip-html={data?.details}
                                    >
                                      {data?.details}
                                    </a>
                                    <Tooltip id="details-tooltip" />
                                  </>
                                ) : (
                                  <>{data?.details}</>
                                )}
                              </td>
                              <td>{data?.paymentMode}</td>
                              <td>{data?.amount}</td>
                              <td>{getStatus(data?.approvalStatus)}</td>
                              <td>{data?.agentName}</td>
                              <td>{data?.requestedBy}</td>
                              <td>{formatDate(data?.createdOn)}</td>
                              <td>
                         <ApproveRejectModal
                                  agentPaymentId={data?.id}
                                  onStatusUpdate={fetchData}
                                 approveStatus = {getStatus(data?.approvalStatus)}
                                />
                                <button
                                  className="btn"
                                  onClick={(e) =>
                                    downloadDepositSlip(data?.depositSlipPath)
                                  }
                                >
                                  <MdFileDownload size={22} />
                                </button>
                              </td>
                            </tr>
                          ))}
                          {/* <tr>
                            <td>1</td>
                            <td>00000012</td>
                            <td>Credit Account</td>
                            <td
                              style={{
                                maxWidth: '22ch',
                                whiteSpace: 'nowrap',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                              }}
                            >
                              {sampleText?.length > 21 ? (
                                <>
                                  <a
                                    data-tooltip-id="remarks-tooltip"
                                    data-tooltip-html={sampleText}
                                  >
                                    {sampleText}
                                  </a>
                                  <Tooltip id="remarks-tooltip"/>
                                </>
                              ) : (
                                <>{sampleText}</>
                              )}
                            </td>
                            <td>Cash</td>
                            <td>90.00</td>
                            <td>Approved</td>
                            <td>Greek Travel LLC </td>
                            <td>name@gmail.com</td>
                            <td>16/05/2024 14:010 PM </td>
                            <td>
                              <ApproveRejectModal />
                            </td>
                          </tr> */}

                          {/* <tr>
                            <td>2</td>
                            <td>00000012</td>
                            <td>Credit Account</td>
                            <td>dwdwd</td>
                            <td>Cash</td>
                            <td>90.00</td>
                            <td>Approved</td>
                            <td>Greek Travel LLC </td>
                            <td>name@gmail.com</td>
                            <td>16/05/2024 14:010 PM </td>

                            <td>
                              <ApproveRejectModal />
                            </td>
                          </tr>

                          <tr>
                            <td>3</td>
                            <td>00000012</td>
                            <td>Credit Account</td>
                            <td>dwdwd</td>
                            <td>Cash</td>
                            <td>90.00</td>
                            <td>Approved</td>
                            <td>Greek Travel LLC </td>
                            <td>name@gmail.com</td>
                            <td>16/05/2024 14:010 PM </td>

                            <td>
                              <ApproveRejectModal />
                            </td>
                          </tr>

                          <tr>
                            <td>4</td>
                            <td>00000012</td>
                            <td>Credit Account</td>
                            <td>dwdwd</td>
                            <td>Cash</td>
                            <td>90.00</td>
                            <td>Approved</td>
                            <td>Greek Travel LLC </td>
                            <td>name@gmail.com</td>
                            <td>16/05/2024 14:010 PM </td>

                            <td>
                              <ApproveRejectModal />
                            </td>
                          </tr>

                          <tr>
                            <td>5</td>
                            <td>00000012</td>
                            <td>Credit Account</td>
                            <td>dwdwd</td>
                            <td>Cash</td>
                            <td>90.00</td>
                            <td>Approved</td>
                            <td>Greek Travel LLC </td>
                            <td>name@gmail.com</td>
                            <td>16/05/2024 14:010 PM </td>

                            <td>
                              <ApproveRejectModal />
                            </td>
                          </tr>

                          <tr>
                            <td>6</td>
                            <td>00000012</td>
                            <td>Credit Account</td>
                            <td>dwdwd</td>
                            <td>Cash</td>
                            <td>90.00</td>
                            <td>Approved</td>
                            <td>Greek Travel LLC </td>
                            <td>name@gmail.com</td>
                            <td>16/05/2024 14:010 PM </td>

                            <td>
                              <ApproveRejectModal />
                            </td>
                          </tr>

                          <tr>
                            <td>7</td>
                            <td>00000012</td>
                            <td>Credit Account</td>
                            <td>dwdwd</td>
                            <td>Cash</td>
                            <td>90.00</td>
                            <td>Approved</td>
                            <td>Greek Travel LLC </td>
                            <td>name@gmail.com</td>
                            <td>16/05/2024 14:010 PM </td>

                            <td>
                              <ApproveRejectModal />
                            </td>
                          </tr>

                          <tr>
                            <td>8</td>
                            <td>00000012</td>
                            <td>Credit Account</td>
                            <td>dwdwd</td>
                            <td>Cash</td>
                            <td>90.00</td>
                            <td>Approved</td>
                            <td>Greek Travel LLC </td>
                            <td>name@gmail.com</td>
                            <td>16/05/2024 14:010 PM </td>

                            <td>
                              <ApproveRejectModal />
                            </td>
                          </tr>

                          <tr>
                            <td>9</td>
                            <td>00000012</td>
                            <td>Credit Account</td>
                            <td>dwdwd</td>
                            <td>Cash</td>
                            <td>90.00</td>
                            <td>Approved</td>
                            <td>Greek Travel LLC </td>
                            <td>name@gmail.com</td>
                            <td>16/05/2024 14:010 PM </td>

                            <td>
                              <ApproveRejectModal />
                            </td>
                          </tr>

                          <tr>
                            <td>10</td>
                            <td>00000012</td>
                            <td>Credit Account</td>
                            <td>dwdwd</td>
                            <td>Cash</td>
                            <td>90.00</td>
                            <td>Approved</td>
                            <td>Greek Travel LLC </td>
                            <td>name@gmail.com</td>
                            <td>16/05/2024 14:010 PM </td>

                            <td>
                              <ApproveRejectModal />
                            </td>
                          </tr> */}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>

                <div className="row align-items-center">
                  <div className="col-lg-8">
                    <Paging />
                  </div>

                  <div className="col-lg-4">
                    <ViewPerPage />
                  </div>
                </div>
              </>
            )}
          </section>
        </div>
      </MainLayout>
      {loader && <Loader />}
    </>
  );
};

export default AgentPaymentApprovalHome;
