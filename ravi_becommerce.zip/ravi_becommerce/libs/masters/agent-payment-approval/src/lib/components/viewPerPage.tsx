import { ListBox } from '@mfa-travel-app/ui';

export default function ViewPerPage() {
  return (
    <>
      <div className="d-flex align-items-center justify-content-end">
        <div className="m-2">
          <small> View leads per page</small>
        </div>

        <div>
          <ListBox
            name="viewbypage"
            id="viewbypage"
            defaultValue="01"
            options={[
              { label: '10', value: '01' },
              { label: '20', value: '02' },
              { label: '30', value: '02' },
            ]}
            handleChange={(e) => e}
          />
        </div>
      </div>

      <div className="text-end mt-1 mb-2">
        {' '}
        <small>Total No. Of Records: 30</small>
      </div>
    </>
  );
}
