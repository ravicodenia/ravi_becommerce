import AgentPaymentApprovalHome from "./components/agent-payment-approval-home";

export const AgentPaymentApproval = () => {
    return (
        <AgentPaymentApprovalHome/>
    );
}

export default AgentPaymentApproval;