export const AGENT_PAYMENT = 'payment/AgentPayment/GetAll'
export const UPDATE_APPROVAL_STATUS = 'payment/AgentPayment/UpdateApprovalStatus'