import { getGatewayAPI, putGatewayAPI } from '@mfa-travel-app/services';
import { AGENT_PAYMENT, UPDATE_APPROVAL_STATUS } from '../constants';

export const getAgentPayment = async (
  fromDate: string,
  toDate: string,
  agentId: string,
  status: string
) => {
  try {
    const params: any = {};

    if (fromDate) params.fromDate = fromDate;
    if (toDate) params.toDate = toDate;
    if (agentId) params.agentId = agentId;
    if (status) params.approvalStatus = status;

    const response = await getGatewayAPI(AGENT_PAYMENT, { params });
    return response;
  } catch (error) {
    return error;
  }
};

export const updateApprovalStatus = async (
  agentPaymentId: number,
  newStatus: string,
  rejectRemarks: string
) => {
  try {
    const data: any = {};
    data.agentPaymentId = agentPaymentId
    data.newStatus = newStatus
    if (rejectRemarks) data.rejectRemarks = rejectRemarks;

    const response = await putGatewayAPI(UPDATE_APPROVAL_STATUS, data);
    return response;
  } catch (error) {
    return error;
  }
};
