import LocationMasterHome from "./components/location-master-home";

export const LocationMaster = () => {
    return (
        <LocationMasterHome />
    );
}

export default LocationMaster;