// CREATE_LOCATION_MASTER
export const CREATE_LOCATION_MASTER = 'common/Location/Create';