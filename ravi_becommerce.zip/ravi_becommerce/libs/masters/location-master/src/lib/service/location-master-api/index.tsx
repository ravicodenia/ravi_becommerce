import { CREATE_LOCATION_MASTER } from "../constants";
import { postGatewayAPI } from "@mfa-travel-app/services";

export const createLocationMaster = async (payload: any) => {
    try {
        const response = await postGatewayAPI(CREATE_LOCATION_MASTER, payload);
        return response;
    } catch (error) {
        return error;
    }
}