import * as React from 'react';
import { MainLayout } from '@mfa-travel-app/layout';
import LocationMainSection from './location-main-section';
import { RootState, useLocationMasterStore, useMastersDropdownStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { API_ERROR_TOAST_TEXT, getCountryOptions, getCurrencyOptions, getParentAgentOptions, validateEmail, WRONG_EMAIL_ALERT } from '@mfa-travel-app/shared';
import { createLocationMaster } from '../service/location-master-api';
import { toast } from 'react-toastify';
import { Loader } from '@mfa-travel-app/ui';

const LocationMasterHome = () => {
    const [loader, setLoader] = React.useState(false);
    const { saveUpdatedLocationMaster } = useLocationMasterStore();
    const { saveCountryList, saveCurrencyList, saveParentAgentList } = useMastersDropdownStore();

    const { updatedLocationMasterData } = useSelector((state: RootState) => state.locationMaster);
    const { countryList, currencyList, parentAgentList } = useSelector((state: RootState) => state.mastersDropdown);

    React.useEffect(() => {
        saveUpdatedLocationMaster({});
        getDropdownOptions();
    }, []);

    const getDropdownOptions = async () => {
        if (parentAgentList.length === 0) {
            getParentAgentOptions().then((options) => {
                saveParentAgentList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (countryList.length === 0) {
            getCountryOptions().then((options) => {
                saveCountryList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (currencyList.length === 0) {
            getCurrencyOptions().then((options) => {
                saveCurrencyList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }
    }

    const handleSaveLocationMaster = async (e: any) => {
        e.preventDefault();

        if (!validateEmail(updatedLocationMasterData.email)) {
            toast.warning(WRONG_EMAIL_ALERT);
            return;
        }

        try {
            setLoader(true);
            const response: any = await createLocationMaster(updatedLocationMasterData);

            if (response?.data?.statusCode === 200) {
                saveUpdatedLocationMaster({});
                setLoader(false);
                toast.success(response?.data?.message);
            } else {
                setLoader(false);
                toast.error(response?.data?.message);
            }
        } catch (error) {
            setLoader(false);
            console.error('An error occurred:', error);
            toast.error(API_ERROR_TOAST_TEXT);
        }
    }

    return (
        <MainLayout>
            <form onSubmit={handleSaveLocationMaster}>
                <div className='container mt-4 mb-5'>
                    <div className="row">

                        <LocationMainSection />

                    </div>

                    <div className="row">

                        <div className="col-12 text-end mt-3">
                            <button type="submit" className="btn btn-primary">Submit</button>
                        </div>

                    </div>
                </div>

                {loader && <Loader />}
            </form>
        </MainLayout>
    );
}

export default LocationMasterHome;