import * as React from 'react';
import { ControlledInput, ControlledSelect, ControlledTextarea, Loader } from '@mfa-travel-app/ui';
import { RootState, useLocationMasterStore, useMastersDropdownStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { getCityOptionsByStateId, getStateOptionsByCountryId } from '@mfa-travel-app/shared';

const LocationMainSection = () => {
    const [loader, setLoader] = React.useState(false);
    const { saveUpdatedLocationMaster } = useLocationMasterStore();
    const { saveStateListByCountry, saveCityListByState } = useMastersDropdownStore();

    const { updatedLocationMasterData } = useSelector((state: RootState) => state.locationMaster);
    const { countryList, stateListByCountry, cityListByState, currencyList, parentAgentList } = useSelector((state: RootState) => state.mastersDropdown);

    const handleLocationMasterLocationSectionChanges = (value: any, param: string) => {
        let locationMaster = structuredClone(updatedLocationMasterData);
        locationMaster[param] = value;

        if (param === 'agentId') {
            let selectedAgent = parentAgentList.find((p: any) => p.id === value);

            locationMaster.parentAgentId = selectedAgent.parentAgentId;
            locationMaster.parentAgentName = selectedAgent.parentAgentName;
        } else if (param === 'currencyId') {
            locationMaster.baseCurrencyId = value;
        } else if (param === 'ledgerCode') {
            locationMaster.intergration = value;
        }

        saveUpdatedLocationMaster(locationMaster);
    }

    const handleLocationMasterCountryOrStateChanges = async (value: number, param: string) => {
        let locationMaster = structuredClone(updatedLocationMasterData);
        locationMaster[param] = value;

        if (param === 'countryId' && value === 0) {
            locationMaster.stateId = '';
            locationMaster.cityId = '';
        } else if (param === 'stateId' && value === 0) {
            locationMaster.cityId = '';
        }

        saveUpdatedLocationMaster(locationMaster);

        if (value) {
            setLoader(true);
            if (param === 'countryId') {
                saveStateListByCountry(await getStateOptionsByCountryId(value));
                setLoader(false);
            } else if (param === 'stateId') {
                saveCityListByState(await getCityOptionsByStateId(value));
                setLoader(false);
            }
        } else {
            if (param === 'countryId') {
                saveStateListByCountry([]);
                saveCityListByState([]);
            } else if (param === 'stateId') {
                saveCityListByState([]);
            }
        }
    }

    return (
        <>
            <div className="col-lg-6">

                <div className="row align-items-center mb-2">
                    <label htmlFor="agent" className="col-lg-5">Agent <sup className="text-danger">*</sup> :</label>
                    <div className="col-lg-7">
                        <ControlledSelect
                            id={'agent'}
                            value={updatedLocationMasterData.agentId ? updatedLocationMasterData.agentId : ''}
                            options={parentAgentList}
                            required={true}
                            onChange={(e: any) => handleLocationMasterLocationSectionChanges(Number(e.target.value), 'agentId')}
                        />
                    </div>
                </div>

                <div className="row align-items-center mb-2">
                    <label htmlFor="parent-firm" className="col-lg-5">Parent Firm :</label>
                    <div className="col-lg-7">
                        <ControlledInput
                            id={'parent-firm'}
                            value={updatedLocationMasterData.parentAgentName ? updatedLocationMasterData.parentAgentName : ''}
                            type={'text'}
                            disabled={true}
                            onChange={(e: any) => handleLocationMasterLocationSectionChanges(e.target.value, 'parentAgentName')}
                        />
                    </div>
                </div>

                <div className="row align-items-center mb-2">
                    <label htmlFor="branch-code" className="col-lg-5">Branch Code <sup className="text-danger">*</sup> :</label>
                    <div className="col-lg-7">
                        <ControlledInput
                            id={'branch-code'}
                            value={updatedLocationMasterData.code ? updatedLocationMasterData.code : ''}
                            type={'text'}
                            required={true}
                            onChange={(e: any) => handleLocationMasterLocationSectionChanges(e.target.value, 'code')}
                        />
                    </div>
                </div>

                <div className="row align-items-center mb-2">
                    <label htmlFor="branch-name" className="col-lg-5">Branch Name <sup className="text-danger">*</sup> :</label>
                    <div className="col-lg-7">
                        <ControlledInput
                            id={'branch-name'}
                            value={updatedLocationMasterData.name ? updatedLocationMasterData.name : ''}
                            type={'text'}
                            required={true}
                            onChange={(e: any) => handleLocationMasterLocationSectionChanges(e.target.value, 'name')}
                        />
                    </div>
                </div>

                <div className="row align-items-center mb-2">
                    <label htmlFor="address" className="col-lg-5">Address <sup className="text-danger">*</sup> :</label>
                    <div className="col-lg-7">
                        <ControlledInput
                            id={'address'}
                            value={updatedLocationMasterData.address ? updatedLocationMasterData.address : ''}
                            type={'text'}
                            required={true}
                            onChange={(e: any) => handleLocationMasterLocationSectionChanges(e.target.value, 'address')}
                        />
                    </div>
                </div>

                <div className="row align-items-center mb-2">
                    <label htmlFor="country" className="col-lg-5">Country <sup className="text-danger">*</sup> :</label>
                    <div className="col-lg-7">
                        <ControlledSelect
                            id={'country'}
                            value={updatedLocationMasterData.countryId ? updatedLocationMasterData.countryId : ''}
                            options={countryList}
                            required={true}
                            onChange={(e: any) => handleLocationMasterCountryOrStateChanges(Number(e.target.value), 'countryId')}
                        />
                    </div>
                </div>

                <div className="row align-items-center mb-2">
                    <label htmlFor="state" className="col-lg-5">State <sup className="text-danger">*</sup> :</label>
                    <div className="col-lg-7">
                        <ControlledSelect
                            id={'state'}
                            value={updatedLocationMasterData.stateId ? updatedLocationMasterData.stateId : ''}
                            options={stateListByCountry}
                            required={true}
                            onChange={(e: any) => handleLocationMasterCountryOrStateChanges(Number(e.target.value), 'stateId')}
                        />
                    </div>
                </div>

                <div className="row align-items-center mb-2">
                    <label htmlFor="city" className="col-lg-5">City <sup className="text-danger">*</sup> :</label>
                    <div className="col-lg-7">
                        <ControlledSelect
                            id={'city'}
                            value={updatedLocationMasterData.cityId ? updatedLocationMasterData.cityId : ''}
                            options={cityListByState}
                            required={true}
                            onChange={(e: any) => handleLocationMasterLocationSectionChanges(Number(e.target.value), 'cityId')}
                        />
                    </div>
                </div>

            </div>

            <div className="col-lg-6">

                <div className="row align-items-center mb-2">
                    <label htmlFor="trn" className="col-lg-5">TRN :</label>
                    <div className="col-lg-7">
                        <ControlledInput
                            id={'trn'}
                            value={updatedLocationMasterData.taxReg ? updatedLocationMasterData.taxReg : ''}
                            type={'text'}
                            required={false}
                            onChange={(e: any) => handleLocationMasterLocationSectionChanges(e.target.value, 'taxReg')}
                        />
                    </div>
                </div>

                <div className="row align-items-center mb-2">
                    <label htmlFor="business-currency" className="col-lg-5">Business Currency <sup className="text-danger">*</sup> :</label>
                    <div className="col-lg-7">
                        <ControlledSelect
                            id={'business-currency'}
                            value={updatedLocationMasterData.currencyId ? updatedLocationMasterData.currencyId : ''}
                            options={currencyList}
                            required={true}
                            onChange={(e: any) => handleLocationMasterLocationSectionChanges(Number(e.target.value), 'currencyId')}
                        />
                    </div>
                </div>

                <div className="row align-items-center mb-2">
                    <label htmlFor="land-phone" className="col-lg-5">Land Phone <sup className="text-danger">*</sup> :</label>
                    <div className="col-lg-7">
                        <ControlledInput
                            id={'land-phone'}
                            value={updatedLocationMasterData.landphone ? updatedLocationMasterData.landphone : ''}
                            type={'number'}
                            required={true}
                            onChange={(e: any) => handleLocationMasterLocationSectionChanges(e.target.value, 'landphone')}
                        />
                    </div>
                </div>

                <div className="row align-items-center mb-2">
                    <label htmlFor="mobile-phone" className="col-lg-5">Mobile <sup className="text-danger">*</sup> :</label>
                    <div className="col-lg-7">
                        <ControlledInput
                            id={'mobile-phone'}
                            value={updatedLocationMasterData.mobile ? updatedLocationMasterData.mobile : ''}
                            type={'number'}
                            required={true}
                            onChange={(e: any) => handleLocationMasterLocationSectionChanges(e.target.value, 'mobile')}
                        />
                    </div>
                </div>

                <div className="row align-items-center mb-2">
                    <label htmlFor="fax" className="col-lg-5">Fax <sup className="text-danger">*</sup> :</label>
                    <div className="col-lg-7">
                        <ControlledInput
                            id={'fax'}
                            value={updatedLocationMasterData.fax ? updatedLocationMasterData.fax : ''}
                            type={'number'}
                            required={true}
                            onChange={(e: any) => handleLocationMasterLocationSectionChanges(e.target.value, 'fax')}
                        />
                    </div>
                </div>

                <div className="row align-items-center mb-2">
                    <label htmlFor="ledger-code" className="col-lg-5">Ledger Code <sup className="text-danger">*</sup> :</label>
                    <div className="col-lg-7">
                        <ControlledInput
                            id={'ledger-code'}
                            value={updatedLocationMasterData.ledgerCode ? updatedLocationMasterData.ledgerCode : ''}
                            type={'text'}
                            required={true}
                            onChange={(e: any) => handleLocationMasterLocationSectionChanges(e.target.value, 'ledgerCode')}
                        />
                    </div>
                </div>

                <div className="row align-items-center mb-2">
                    <label htmlFor="email" className="col-lg-5">Email <sup className="text-danger">*</sup> :</label>
                    <div className="col-lg-7">
                        <ControlledInput
                            id={'email'}
                            value={updatedLocationMasterData.email ? updatedLocationMasterData.email : ''}
                            type={'text'}
                            required={true}
                            onChange={(e: any) => handleLocationMasterLocationSectionChanges(e.target.value, 'email')}
                        />
                    </div>
                </div>

                <div className="row mb-2">
                    <label htmlFor="terms-conditions" className="col-lg-5">Terms & Condition <sup className="text-danger">*</sup> :</label>
                    <div className="col-lg-7">
                        <ControlledTextarea
                            id={'terms-conditions'}
                            value={updatedLocationMasterData.terms ? updatedLocationMasterData.terms : ''}
                            rows={3}
                            required={true}
                            onChange={(e: any) => handleLocationMasterLocationSectionChanges(e.target.value, 'terms')}
                        />
                    </div>
                </div>

            </div>

            {loader && <Loader />}
        </>
    );
}

export default LocationMainSection;