import { CREATE_USER_MASTER } from "../constants";
import { postGatewayAPI } from "@mfa-travel-app/services";

export const createUserMaster = async (payload: any) => {
    try {
        const response = await postGatewayAPI(CREATE_USER_MASTER, payload);
        return response;
    } catch (error) {
        return error;
    }
}