// USER_MASTER APIs
export const CREATE_USER_MASTER = 'keycloak/User/CreateUser';