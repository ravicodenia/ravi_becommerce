import UserMasterHome from './components/user-master-home';

export const UserMaster = () => {
    return (
        <UserMasterHome />
    );
}

export default UserMaster;
