import { ControlledMultiSelect } from "@mfa-travel-app/ui";
import { RootState, useUserMasterStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';

const OtherLocationsSection = () => {
    const { saveUpdatedUserMaster } = useUserMasterStore();

    const { updatedUserMasterData } = useSelector((state: RootState) => state.userMaster);
    const { locationList } = useSelector((state: RootState) => state.mastersDropdown);

    const handleUserMasterOtherLocationsSectionChanges = (value: any, param: string) => {
        let userMaster = structuredClone(updatedUserMasterData);
        let locations = '';

        value?.forEach((loc: any, index: any) => {
            if (index !== 0) {
                locations += ', ';
            }

            locations += loc.text;
        });

        userMaster[param] = locations;
        userMaster.selectedAccessLocationId = value;
        
        saveUpdatedUserMaster(userMaster);
    }

    return (
        <div className="row">
            <div className="col-12">
                <div className="form_heading">
                    <span className=" title">Access Other Locations</span>
                </div>
            </div>

            <div className="col-12">
                <div className="row align-items-center">
                    <div className="col-lg-4">
                        <div className="row align-items-center mb-2">
                            <label htmlFor="locations" className="col-sm-5">Loactions <span className="text-danger">*</span> :</label>
                            <div className="col-sm-7">
                                <ControlledMultiSelect
                                    id={'locations'}
                                    value={updatedUserMasterData.selectedAccessLocationId ? updatedUserMasterData.selectedAccessLocationId : []}
                                    options={locationList}
                                    required={true}
                                    onChange={(value: any) => handleUserMasterOtherLocationsSectionChanges(value, 'accessLocationId')}
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default OtherLocationsSection;