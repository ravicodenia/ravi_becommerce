import * as React from 'react';
import { MainLayout } from '@mfa-travel-app/layout';
import UserProfileSection from './user-profile-section';
import OtherLocationsSection from './other-locations-section';
import AppConfigSection from './app-config-section';
import UserTypeSection from './user-type-section';
import RoleSection from './role-section';
import { RootState, useMastersDropdownStore, useUserMasterStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { API_ERROR_TOAST_TEXT, getAppConfigOptions, getLocationOptionsByAgentId, getParentAgentOptions, getRoleOptions, getSalesChannelOptions, getSalutationOptions, getUserAccessOptions, getUserTypeOptions, PASSWORD_MISMATCH_ALERT, validateEmail, WRONG_EMAIL_ALERT } from '@mfa-travel-app/shared';
import { toast } from 'react-toastify';
import { createUserMaster } from '../service/user-master-api';
import { Loader } from '@mfa-travel-app/ui';

export const UserMasterHome = () => {
    const [loader, setLoader] = React.useState(false);
    const { saveUpdatedUserMaster } = useUserMasterStore();
    const { saveSalutationList, saveUserAccessList, saveParentAgentList, saveLocationList, saveSalesChannelList, saveAppConfigList, saveUserTypeList, saveRoleList } = useMastersDropdownStore();

    const { updatedUserMasterData } = useSelector((state: RootState) => state.userMaster);
    const { salutationList, userAccessList, parentAgentList, locationList, salesChannelList, appConfigList, userTypeList, roleList } = useSelector((state: RootState) => state.mastersDropdown);

    React.useEffect(() => {
        setUserMasterInitialState();
        getDropdownOptions();
    }, []);

    const setUserMasterInitialState = () => {
        let userMaster: any = {};
        userMaster.userPrivileges = [{}];

        saveUpdatedUserMaster(userMaster);
    }

    const getDropdownOptions = () => {
        if (salutationList.length === 0) {
            getSalutationOptions().then((options) => {
                saveSalutationList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (userAccessList.length === 0) {
            getUserAccessOptions().then((options) => {
                saveUserAccessList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (parentAgentList.length === 0) {
            getParentAgentOptions().then((options) => {
                saveParentAgentList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (locationList.length === 0) {
            getLocationOptionsByAgentId(1).then((options) => {
                saveLocationList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (salesChannelList.length === 0) {
            getSalesChannelOptions().then((options) => {
                saveSalesChannelList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (appConfigList.length === 0) {
            getAppConfigOptions().then((options) => {
                saveAppConfigList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (userTypeList.length === 0) {
            getUserTypeOptions().then((options) => {
                saveUserTypeList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }

        if (roleList.length === 0) {
            getRoleOptions().then((options) => {
                saveRoleList(options);
            }).catch((error) => {
                console.error('error', error);
                toast.error(API_ERROR_TOAST_TEXT);
            });
        }
    }

    const handleSaveUserMaster = async (e: any) => {
        e.preventDefault();

        if (!validateEmail(updatedUserMasterData.email)) {
            toast.warning(WRONG_EMAIL_ALERT);
            return;
        }

        if (updatedUserMasterData.password !== updatedUserMasterData.confirmPassword) {
            toast.warning(PASSWORD_MISMATCH_ALERT);
            return;
        }

        try {
            setLoader(true);
            const response: any = await createUserMaster(updatedUserMasterData);

            if (response?.data?.statusCode === 200) {
                setUserMasterInitialState();
                setLoader(false);
                toast.success(response?.data?.message);
            } else {
                setLoader(false);
                toast.error(response?.data?.message);
            }
        } catch (error) {
            setLoader(false);
            console.error('An error occurred:', error);
            toast.error(API_ERROR_TOAST_TEXT);
        }
    }

    return (
        <MainLayout>
            <form onSubmit={handleSaveUserMaster}>
                <div className="container mb-5">
                    <section className="user_master_section">
                        <div className="innerContainer border-end-0 border-top-0 form_with_select2">

                            <div className="row">
                                <div className="col-lg-12">
                                    <div className="wrapper">

                                        <div className="row">
                                            <div className="col-12"> <h5>User Master </h5> </div>
                                        </div>

                                        <UserProfileSection />

                                        <OtherLocationsSection />

                                        <AppConfigSection />

                                        <UserTypeSection />

                                        <RoleSection />

                                        <div className='row'>
                                            <div className="col-12 text-end">
                                                <button type="submit" className="btn btn-primary mt-2">Submit</button>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </section>
                </div>

                {loader && <Loader />}
            </form>
        </MainLayout>
    );
}

export default UserMasterHome;
