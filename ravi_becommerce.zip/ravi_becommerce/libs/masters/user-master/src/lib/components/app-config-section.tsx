import { ControlledInput, ControlledSelect } from "@mfa-travel-app/ui";
import { RootState, useUserMasterStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';

const AppConfigSection = () => {
    const { saveUpdatedUserMaster } = useUserMasterStore();

    const { updatedUserMasterData } = useSelector((state: RootState) => state.userMaster);
    const { appConfigList } = useSelector((state: RootState) => state.mastersDropdown);

    const handleAddConfig = () => {
        let userMaster = structuredClone(updatedUserMasterData);
        userMaster.userPrivileges.push({});

        saveUpdatedUserMaster(userMaster);
    }

    const handleDeleteConfig = (index: any) => {
        let userMaster = structuredClone(updatedUserMasterData);
        userMaster.userPrivileges.splice(index, 1);

        saveUpdatedUserMaster(userMaster);
    }

    const handleUserMasterAppConfigSectionChanges = (index: number, value: any, param: string) => {
        let userMaster = structuredClone(updatedUserMasterData);
        userMaster.userPrivileges[index][param] = value;

        if (param === 'configId') {
            let appConfig = appConfigList?.find((p: any) => p.id === value);

            userMaster.userPrivileges[index].accessValue = appConfig.appDescription;
        }

        saveUpdatedUserMaster(userMaster);
    }

    return (
        <div className="row">
            <div className="col-12">
                <div className="form_heading">
                    <span className=" title">App Config</span>
                </div>
            </div>

            {
                updatedUserMasterData?.userPrivileges?.map((config: any, index: any) => {
                    return (
                        <div className="col-12" key={index}>
                            <div className="row">
                                <div className="col-lg-8">
                                    <div className="row">

                                        <div className="col-lg-6">
                                            <div className="row mb-2 align-items-center">
                                                <label htmlFor="config-key" className="col-sm-5">Config Key <span className="text-danger">*</span> :</label>
                                                <div className="col-sm-7">
                                                    <ControlledSelect
                                                        id={'config-key'}
                                                        value={config.configId ? config.configId : ''}
                                                        options={appConfigList}
                                                        required={true}
                                                        onChange={(e: any) => handleUserMasterAppConfigSectionChanges(index, Number(e.target.value), 'configId')}
                                                    />
                                                </div>
                                            </div>
                                        </div>

                                        <div className="col-lg-6">
                                            <div className="row mb-2 align-items-center">
                                                <label htmlFor="config-value" className="col-sm-5">Config Value:</label>
                                                <div className="col-sm-7">
                                                    <ControlledInput
                                                        id={'config-value'}
                                                        value={config.accessValue ? config.accessValue : ''}
                                                        type={'text'}
                                                        disabled={true}
                                                        onChange={(e: any) => handleUserMasterAppConfigSectionChanges(index, e.target.value, 'accessValue')}
                                                    />
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div className="col-lg-4" style={{ display: updatedUserMasterData?.userPrivileges?.length === index + 1 ? 'none' : '' }}>
                                    <div className="row mb-2">
                                        <div className="col-sm-12">
                                            <button type="button" onClick={() => handleDeleteConfig(index)} className="btn btn-sm btn-danger mt-1"><i className="fa-solid fa-trash"></i></button>
                                        </div>
                                    </div>
                                </div>

                                <div className="col-lg-4" style={{ display: updatedUserMasterData?.userPrivileges?.length === index + 1 ? '' : 'none' }}>
                                    <div className="row mb-2">
                                        <div className="col-sm-12">
                                            <button type="button" onClick={handleAddConfig} className="btn btn-sm btn-success mt-1"><i className="fa-solid fa-plus"></i> Add </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )
                })
            }
        </div>
    );
}

export default AppConfigSection;