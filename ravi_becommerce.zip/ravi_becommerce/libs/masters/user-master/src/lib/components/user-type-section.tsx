import { ControlledMultiSelect } from "@mfa-travel-app/ui";
import { RootState, useUserMasterStore } from "@mfa-travel-app/store";
import { useSelector } from "react-redux";

const UserTypeSection = () => {
    const { saveUpdatedUserMaster } = useUserMasterStore();

    const { updatedUserMasterData } = useSelector((state: RootState) => state.userMaster);
    const { userTypeList } = useSelector((state: RootState) => state.mastersDropdown);

    const handleUserMasterUserTypeSectionChanges = (value: any, param: string) => {
        let userMaster = structuredClone(updatedUserMasterData);
        let userTypes: any = [];

        value?.forEach((type: any) => {
            userTypes.push({ [param]: type.id });
        });

        userMaster.userTypes = userTypes;
        userMaster.selectedUserType = value;
        
        saveUpdatedUserMaster(userMaster);
    }

    return (
        <div className="row">
            <div className="col-12">
                <div className="form_heading">
                    <span className=" title">User Type</span>
                </div>
            </div>

            <div className="col-12">
                <div className="col-lg-4">
                    <div className="row align-items-center mb-2">
                        <label htmlFor="user-type-select" className="col-sm-5">User Type <span className="text-danger">*</span> :</label>
                        <div className="col-sm-7">
                            <ControlledMultiSelect
                                id={'user-type-select'}
                                value={updatedUserMasterData.selectedUserType ? updatedUserMasterData.selectedUserType : []}
                                options={userTypeList}
                                required={true}
                                onChange={(value: any) => handleUserMasterUserTypeSectionChanges(value, 'typeId')}
                            />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default UserTypeSection;