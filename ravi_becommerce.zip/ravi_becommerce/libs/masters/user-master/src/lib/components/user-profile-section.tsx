import { ControlledInput, ControlledSelect, ControlledSwitch } from "@mfa-travel-app/ui";
import { RootState, useUserMasterStore } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';

const UserProfileSection = () => {
    const { saveUpdatedUserMaster } = useUserMasterStore();

    const { updatedUserMasterData } = useSelector((state: RootState) => state.userMaster);
    const { salutationList, userAccessList, parentAgentList, locationList, salesChannelList } = useSelector((state: RootState) => state.mastersDropdown);

    const twoFactorCommOptions = [
        { id: 'email', text: 'Email' },
        { id: 'mobile', text: 'Mobile' },
    ];

    const handleUserMasterUserProfileSectionChanges = (value: any, param: string) => {
        let userMaster = structuredClone(updatedUserMasterData);
        userMaster[param] = value;

        if (param === 'title') {
            userMaster.emailVerified = true;
            userMaster.enabled = true;
        } else if (param === 'agentId') {
            if (value) {
                let selectedAgent = parentAgentList.find((p: any) => p.id === value);
                userMaster.primaryAgentId = selectedAgent.parentAgentId;
                userMaster.primaryAgentName = selectedAgent.parentAgentName;
            } else {
                userMaster.primaryAgentId = 0;
                userMaster.primaryAgentName = '';
            }
        } else if (param === 'userName') {
            userMaster.login = value;
        } else if (param === 'twoFactorAuthenticationStatus') {
            if (!value) {
                userMaster.twoFactorAuthenticationComm = '';
            }
        }

        saveUpdatedUserMaster(userMaster);
    }

    return (
        <div className="row">
            <div className="col-12">
                <div className="form_heading">
                    <span className=" title">User Profile</span>
                </div>
            </div>

            <div className="col-12">
                <div className="row align-items-center">

                    <div className="col-lg-4">
                        <div className="row align-items-center mb-2">
                            <label htmlFor="title" className="col-sm-5"> Title <span className="text-danger">*</span> :</label>
                            <div className="col-sm-7">
                                <ControlledSelect
                                    id={'title'}
                                    value={updatedUserMasterData.title ? updatedUserMasterData.title : ''}
                                    options={salutationList}
                                    required={true}
                                    onChange={(e: any) => handleUserMasterUserProfileSectionChanges(e.target.value, 'title')}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-4">
                        <div className="row align-items-center mb-2">
                            <label htmlFor="first-name" className="col-sm-5">First Name <span className="text-danger">*</span> :</label>
                            <div className="col-sm-7">
                                <ControlledInput
                                    id={'first-name'}
                                    value={updatedUserMasterData.firstName ? updatedUserMasterData.firstName : ''}
                                    type={'text'}
                                    required={true}
                                    onChange={(e: any) => handleUserMasterUserProfileSectionChanges(e.target.value, 'firstName')}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-4">
                        <div className="row align-items-center mb-2">
                            <label htmlFor="middle-name" className="col-sm-5">Middle Name :</label>
                            <div className="col-sm-7">
                                <ControlledInput
                                    id={'middle-name'}
                                    value={updatedUserMasterData.middleName ? updatedUserMasterData.middleName : ''}
                                    type={'text'}
                                    required={true}
                                    onChange={(e: any) => handleUserMasterUserProfileSectionChanges(e.target.value, 'middleName')}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-4">
                        <div className="row align-items-center mb-2">
                            <label htmlFor="last-name" className="col-sm-5">Last Name <span className="text-danger">*</span> :</label>
                            <div className="col-sm-7">
                                <ControlledInput
                                    id={'last-name'}
                                    value={updatedUserMasterData.lastName ? updatedUserMasterData.lastName : ''}
                                    type={'text'}
                                    required={true}
                                    onChange={(e: any) => handleUserMasterUserProfileSectionChanges(e.target.value, 'lastName')}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-4">
                        <div className="row align-items-center mb-2">
                            <label htmlFor="mobile-number" className="col-sm-5">Mobile <span className="text-danger">*</span> :</label>
                            <div className="col-sm-7">
                                <ControlledInput
                                    id={'mobile-number'}
                                    value={updatedUserMasterData.mobile ? updatedUserMasterData.mobile : ''}
                                    type={'number'}
                                    required={true}
                                    onChange={(e: any) => handleUserMasterUserProfileSectionChanges(e.target.value, 'mobile')}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-4">
                        <div className="row align-items-center mb-2">
                            <label htmlFor="email-address" className="col-sm-5"> Email Address <span className="text-danger">*</span> :</label>
                            <div className="col-sm-7">
                                <ControlledInput
                                    id={'email-address'}
                                    value={updatedUserMasterData.email ? updatedUserMasterData.email : ''}
                                    type={'text'}
                                    required={true}
                                    onChange={(e: any) => handleUserMasterUserProfileSectionChanges(e.target.value, 'email')}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-4">
                        <div className="row align-items-center mb-2">
                            <label htmlFor="work-type" className="col-sm-5">Work Type <span className="text-danger">*</span> :</label>
                            <div className="col-sm-7">
                                <ControlledSelect
                                    id={'work-type'}
                                    value={updatedUserMasterData.accessFieldId ? updatedUserMasterData.accessFieldId : ''}
                                    options={userAccessList}
                                    required={true}
                                    onChange={(e: any) => handleUserMasterUserProfileSectionChanges(Number(e.target.value), 'accessFieldId')}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-4">
                        <div className="row align-items-center mb-2">
                            <label htmlFor="agent" className="col-sm-5">Agent <span className="text-danger">*</span> :</label>
                            <div className="col-sm-7">
                                <ControlledSelect
                                    id={'agent'}
                                    value={updatedUserMasterData.agentId ? updatedUserMasterData.agentId : ''}
                                    options={parentAgentList}
                                    required={true}
                                    onChange={(e: any) => handleUserMasterUserProfileSectionChanges(Number(e.target.value), 'agentId')}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-4">
                        <div className="row align-items-center mb-2">
                            <label htmlFor="primary-agent" className="col-sm-5">Primary Agent :</label>
                            <div className="col-sm-7">
                                <ControlledInput
                                    id={'primary-agent'}
                                    value={updatedUserMasterData.primaryAgentName ? updatedUserMasterData.primaryAgentName : ''}
                                    type={'text'}
                                    disabled={true}
                                    onChange={(e: any) => handleUserMasterUserProfileSectionChanges(Number(e.target.value), 'primaryAgentId')}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-4">
                        <div className="row align-items-center mb-2">
                            <label htmlFor="location" className="col-sm-5">Location <span className="text-danger">*</span> :</label>
                            <div className="col-sm-7">
                                <ControlledSelect
                                    id={'location'}
                                    value={updatedUserMasterData.locationId ? updatedUserMasterData.locationId : ''}
                                    options={locationList}
                                    required={true}
                                    onChange={(e: any) => handleUserMasterUserProfileSectionChanges(Number(e.target.value), 'locationId')}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-4">
                        <div className="row align-items-center mb-2">
                            <label htmlFor="user-address" className="col-sm-5"> User Address <span className="text-danger">*</span> :</label>
                            <div className="col-sm-7">
                                <ControlledInput
                                    id={'user-address'}
                                    value={updatedUserMasterData.address ? updatedUserMasterData.address : ''}
                                    type={'text'}
                                    required={true}
                                    onChange={(e: any) => handleUserMasterUserProfileSectionChanges(e.target.value, 'address')}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-4">
                        <div className="row align-items-center mb-2">
                            <label htmlFor="sales-channel" className="col-sm-5">Sales Channel <span className="text-danger">*</span> :</label>
                            <div className="col-sm-7">
                                <ControlledSelect
                                    id={'sales-channel'}
                                    value={updatedUserMasterData.channelId ? updatedUserMasterData.channelId : ''}
                                    options={salesChannelList}
                                    required={true}
                                    onChange={(e: any) => handleUserMasterUserProfileSectionChanges(e.target.value, 'channelId')}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-4">
                        <div className="row align-items-center mb-2">
                            <label htmlFor="integration-code" className="col-sm-5">Integration Code <span className="text-danger">*</span> :</label>
                            <div className="col-sm-7">
                                <ControlledInput
                                    id={'integration-code'}
                                    value={updatedUserMasterData.integrationCode ? updatedUserMasterData.integrationCode : ''}
                                    type={'text'}
                                    required={true}
                                    onChange={(e: any) => handleUserMasterUserProfileSectionChanges(e.target.value, 'integrationCode')}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-4">
                        <div className="row align-items-center mb-2">
                            <label htmlFor="user-name" className="col-sm-5">User Name <span className="text-danger">*</span> :</label>
                            <div className="col-sm-7">
                                <ControlledInput
                                    id={'user-name'}
                                    value={updatedUserMasterData.userName ? updatedUserMasterData.userName : ''}
                                    type={'text'}
                                    required={true}
                                    onChange={(e: any) => handleUserMasterUserProfileSectionChanges(e.target.value, 'userName')}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-4">
                        <div className="row align-items-center mb-2">
                            <label htmlFor="password" className="col-sm-5">Password <span className="text-danger">*</span> :</label>
                            <div className="col-sm-7">
                                <ControlledInput
                                    id={'password'}
                                    value={updatedUserMasterData.password ? updatedUserMasterData.password : ''}
                                    type={'password'}
                                    required={true}
                                    onChange={(e: any) => handleUserMasterUserProfileSectionChanges(e.target.value, 'password')}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-4">
                        <div className="row align-items-center mb-2">
                            <label htmlFor="confirm-password" className="col-sm-5">Confirm Password <span className="text-danger">*</span> :</label>
                            <div className="col-sm-7">
                                <ControlledInput
                                    id={'confirm-password'}
                                    value={updatedUserMasterData.confirmPassword ? updatedUserMasterData.confirmPassword : ''}
                                    type={'password'}
                                    required={true}
                                    onChange={(e: any) => handleUserMasterUserProfileSectionChanges(e.target.value, 'confirmPassword')}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-4">
                        <div className="row align-items-center mb-2">
                            <label htmlFor="management-role" className="col-sm-5">Management Role :</label>
                            <div className="col-sm-7">
                                <ControlledSwitch
                                    id={'management-role'}
                                    isChecked={updatedUserMasterData.isManagementRole ? updatedUserMasterData.isManagementRole : false}
                                    onChange={(value: any) => handleUserMasterUserProfileSectionChanges(value, 'isManagementRole')}
                                />
                            </div>
                        </div>
                    </div>

                </div>

                <div className="row align-items-center">

                    <div className="col-lg-4">
                        <div className="row align-items-center mb-2">
                            <label htmlFor="2fa" className="col-sm-5">2FA :</label>
                            <div className="col-sm-7">
                                <ControlledSwitch
                                    id={'2fa'}
                                    isChecked={updatedUserMasterData.twoFactorAuthenticationStatus ? updatedUserMasterData.twoFactorAuthenticationStatus : false}
                                    onChange={(value: any) => handleUserMasterUserProfileSectionChanges(value, 'twoFactorAuthenticationStatus')}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-4" style={{ display: updatedUserMasterData.twoFactorAuthenticationStatus ? '' : 'none' }}>
                        <div className="row align-items-center mb-2">
                            <label htmlFor="2fa-comm" className="col-sm-5">2FA Comm <span className="text-danger">*</span> :</label>
                            <div className="col-sm-7">
                                <ControlledSelect
                                    id={'2fa-comm'}
                                    value={updatedUserMasterData.twoFactorAuthenticationComm ? updatedUserMasterData.twoFactorAuthenticationComm : ''}
                                    options={twoFactorCommOptions}
                                    required={updatedUserMasterData.twoFactorAuthenticationStatus ? updatedUserMasterData.twoFactorAuthenticationStatus : false}
                                    onChange={(e: any) => handleUserMasterUserProfileSectionChanges(e.target.value, 'twoFactorAuthenticationComm')}
                                />
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    );
}

export default UserProfileSection;