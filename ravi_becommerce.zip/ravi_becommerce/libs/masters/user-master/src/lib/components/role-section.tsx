import { ControlledMultiSelect } from "@mfa-travel-app/ui";
import { RootState, useUserMasterStore } from "@mfa-travel-app/store";
import { useSelector } from "react-redux";

const RoleSection = () => {
    const { saveUpdatedUserMaster } = useUserMasterStore();

    const { updatedUserMasterData } = useSelector((state: RootState) => state.userMaster);
    const { roleList } = useSelector((state: RootState) => state.mastersDropdown);

    const handleUserMasterRoleSectionChanges = (value: any, param: string) => {
        let userMaster = structuredClone(updatedUserMasterData);
        let userRoles: any = [];

        value?.forEach((role: any) => {
            userRoles.push({ [param]: role.id });
        });

        userMaster.userRoles = userRoles;
        userMaster.selectedUserRole = value;
        
        saveUpdatedUserMaster(userMaster);
    }

    return (
        <div className="row">
            <div className="col-12">
                <div className="form_heading">
                    <span className=" title">Role</span>
                </div>
            </div>

            <div className="col-12">
                <div className="row">

                    <div className="col-lg-4">
                        <div className="row mb-2 align-items-center">
                            <label htmlFor="add-role" className="col-sm-5">Add Role <span className="text-danger">*</span> :</label>
                            <div className="col-sm-7">
                                <ControlledMultiSelect
                                    id={'add-role'}
                                    value={updatedUserMasterData.selectedUserRole ? updatedUserMasterData.selectedUserRole : []}
                                    options={roleList}
                                    required={true}
                                    onChange={(value: any) => handleUserMasterRoleSectionChanges(value, 'roleId')}
                                />
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    );
}

export default RoleSection;