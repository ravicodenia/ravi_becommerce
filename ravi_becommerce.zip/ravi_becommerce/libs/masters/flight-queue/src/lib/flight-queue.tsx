import { MainLayout } from '@mfa-travel-app/layout';
import FlightQueeModal from '../../../../features/flights/src/lib/components/tQFilter';
import Paging from 'libs/masters/role-master/src/lib/components/paging';
import ViewPerPage from 'libs/masters/role-master/src/lib/components/viewPerPage';
import { ControlledSelect, ControlledInput, ControlledDatePicker, ControlledMultiSelect } from '@mfa-travel-app/ui';
import { createFlightQueue } from '../lib/service/flight-queue-api/index';
import { useState, useEffect } from 'react';
import { RootState } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { useFlightQueueStore, useMastersDropdownStore } from '@mfa-travel-app/store';
import { agentRelatedDropdownsForFilters, agentIdAndTypeForFilters, API_ERROR_TOAST_TEXT, getParentAgentOptions, getSalesChannelOptions, getSupplierOptions, TEXT_TO_PICK_HOTEL_ID, updateLocationDropdownByAgentId, differentAgentTypeLists } from '@mfa-travel-app/shared';
import { toast } from 'react-toastify';
export function FlightQueue() {
    const selectOptions = [
        { id: 1, text: 'First Option' },
        { id: 2, text: 'Second Option' },
    ];
    const [fromDate, setFromDate] = useState<any>(new Date());
    const [toDate, setToDate] = useState<any>(new Date());
    const [paxname, setPaxname] = useState(null);

    const bookings = [
        {
            "bookingId": 300,
            "agencyId": 1,
            "bookingStatus": "Ticketed",
            "createdOn": "2024-08-27T06:25:42.645311",
            "travelDate": "2024-08-28T09:35:00",
            "airlineCode": "EK",
            "routingTripId": null,
            "flightItineraryId": 298,
            "agentId": 1,
            "agentName": "BASE AGENT 1",
            "agentBalance": 50424.84999999988,
            "agentDecimal": 2,
            "agentPhoneNo1": "+971 8978787",
            "agentPhoneNo2": "+971 8978787",
            "agentCountry": "United Arab Emirates",
            "agentCurrency": "AED",
            "locationName": null,
            "pnr": "89S9R2",
            "transType": "B2B",
            "tripId": null,
            "ticketNumber": "1695420218868",
            "ticketedDate": "2024-08-27T06:25:42.629692",
            "lastTicketingDate": "2024-08-28T23:59:00",
            "totalFare": 3775,
            "routing": "DXB-IAH",
            "source": "UAPI",
            "flightNum": "211",
            "leadPaxName": "Muhammad faheem",
            "paymentMode": " ",
            "adultCount": 1,
            "createdBy": "Demo1 K"
        },
        {
            "bookingId": 300,
            "agencyId": 1,
            "bookingStatus": "Ticketed",
            "createdOn": "2024-08-27T06:25:42.645311",
            "travelDate": "2024-08-28T09:35:00",
            "airlineCode": "EK",
            "routingTripId": null,
            "flightItineraryId": 298,
            "agentId": 1,
            "agentName": "BASE AGENT 1",
            "agentBalance": 50424.84999999988,
            "agentDecimal": 2,
            "agentPhoneNo1": "+971 8978787",
            "agentPhoneNo2": "+971 8978787",
            "agentCountry": "United Arab Emirates",
            "agentCurrency": "AED",
            "locationName": null,
            "pnr": "89S9R2",
            "transType": "B2B",
            "tripId": null,
            "ticketNumber": "1695420218868",
            "ticketedDate": "2024-08-27T06:25:42.629692",
            "lastTicketingDate": "2024-08-28T23:59:00",
            "totalFare": 3775,
            "routing": "DXB-IAH",
            "source": "UAPI",
            "flightNum": "211",
            "leadPaxName": "Muhammad faheem",
            "paymentMode": " ",
            "adultCount": 1,
            "createdBy": "Demo1 K"
        },
    ]
    const { agentProfile, products } = useSelector((state: RootState) => state.config);
    const { locationList } = useSelector((state: RootState) => state.mastersDropdown);
    const { parentAgentList, supplierProductList, salesChannelList } = useSelector((state: RootState) => state.mastersDropdown);
    const { saveFlightQueueFilters, saveAgentAndBaseAgentList, saveBToBList, saveBToBToBList, saveFlightSupplierList } = useFlightQueueStore();
    const { saveParentAgentList, saveSupplierProductList, saveSalesChannelList, saveLocationList } = useMastersDropdownStore();
    const { flightQueueFilters, agentAndBaseAgentList, bToBList, bToBToBList, flightSupplierList } = useSelector((state: RootState) => state.flightQueue);
    const [flightQueueValue, setFlightQueueValue] = useState<any>([]);
    const [submit, setSubmit] = useState({
        "fromDate": flightQueueFilters?.fromDate ? flightQueueFilters?.fromDate : new Date(),
        "toDate": flightQueueFilters?.toDate ? flightQueueFilters?.toDate : new Date(),
        "agentId": flightQueueFilters?.agentId,
        "agentType": "BASE",
        "locationId": flightQueueFilters?.locationId
        ,
        "supplierId": [
        ],
        "bookingModes": [flightQueueFilters?.selectedBookingStatus

        ],
        "pnrNumber": flightQueueFilters.pnrno,
        "paxName": flightQueueFilters.paxname,
        "transType": flightQueueFilters.transType

    })
    enum BookingStatus {
        NotDone = 0,
        Hold = 1,
        Ready = 2,
        Cancelled = 3,
        InProgress = 4,
        Ticketed = 5,
        VoidInProgress = 6,
        Void = 7,
        Delivered = 8,
        Inactive = 9,
        AmendmentInProgress = 10,
        AmendmentDone = 11,
        Released = 12,
        OutsidePurchase = 13,
        Booked = 14,
        CancellationInProgress = 15,
        Refunded = 16,
        ModificationInProgress = 17,
        Modified = 18,
        RefundInProgress = 19,
        CancellationDone = 20
    }
    const adjustDates = (data: any) => {
        let fromDate = new Date(data.fromDate);
        let toDate = new Date(data.toDate);
        fromDate.setUTCHours(0, 0, 0, 0);
        toDate.setUTCHours(23, 59, 59, 999);
        data.fromDate = fromDate.toISOString();
        data.toDate = toDate.toISOString();

        return data;
    }


    const onSearch = async () => {
        try {
            const mutableSubmit: Record<string, any> = submit;
            delete mutableSubmit.selectedB2bId;
            delete mutableSubmit.selectedB2b2bId;
            delete mutableSubmit.selectedAgentId;
            delete mutableSubmit.selectedSuppliers;
            delete mutableSubmit.selectedBookingStatus;
            const mutableSubmitData = adjustDates(mutableSubmit);

            const res: any = await createFlightQueue(mutableSubmitData);
            console.log('res', res);
            if (res.data && res.status === 200) {
                setFlightQueueValue(res?.data);
            } else {
                toast.error('Transaction failed');
            }
        } catch (error) {
            toast.error('Transaction failed');
            console.error('Transaction failed:', error);
        }
    }

    const selectBookingStatusOption = Object.entries(BookingStatus)
        .filter(([key, value]) => typeof value === 'number')
        .map(([key, value]) => ({ value: value, label: key }));


    useEffect(() => {
        setFlightQueueFiltersInitialState();
    }, []);


    const setFlightQueueFiltersInitialState = async () => {
        let filters: any = {};
        filters.fromDate = new Date().toISOString();
        filters.toDate = new Date().toISOString();

        try {
            const paramAgent = await getParentAgentOptions();
            const filtersWithAgentSelectionAndDisable: any = await agentRelatedDropdownsForFilters(filters, paramAgent, agentProfile.id);
            return filtersWithAgentSelectionAndDisable;

        } catch (error) {
            console.error('An error occurred:', error);
        }
    }

    const handleFlightQueueFilterAgentIdChange = async (filters: any, value: any, param: string) => {
        try {
            const filtersWithAgentIdAndType: any = await agentIdAndTypeForFilters(filters, value, param);
            console.log('filtersWithAgentIdAndType', filtersWithAgentIdAndType)
            filtersWithAgentIdAndType['fromDate'] = filtersWithAgentIdAndType.fromDate ? filtersWithAgentIdAndType.fromDate : new Date();
            filtersWithAgentIdAndType['toDate'] = filtersWithAgentIdAndType.toDate ? filtersWithAgentIdAndType.toDate : new Date();
            saveFlightQueueFilters(filtersWithAgentIdAndType);
            setSubmit({ ...submit, agentId: filtersWithAgentIdAndType.selectedAgentId })

            const locationOptions = await updateLocationDropdownByAgentId(filtersWithAgentIdAndType.agentId);
            saveLocationList(locationOptions);
        } catch (error) {
            console.error('An error occurred:', error);
            // toast.error(API_ERROR_TOAST_TEXT);
        }
    }

    useEffect(() => {
        getDropdownOptions();

    }, []);

    const filterDifferentAgents = (agentList: any) => {
        const agentTypeLists = differentAgentTypeLists(agentList);

        saveAgentAndBaseAgentList(agentTypeLists.agentAndBaseAgent);
        saveBToBList(agentTypeLists.bToB);
        saveBToBToBList(agentTypeLists.bToBToB);
    }

    const filterSuppliersForFlight = (supplierList: any) => {
        let productIdForHotel = products?.find((p: any) => p.text === TEXT_TO_PICK_HOTEL_ID)?.id;
        let flightSuppliers = supplierList?.filter((s: any) => s.productId === productIdForHotel);

        saveFlightSupplierList(flightSuppliers);
    }
    const getDropdownOptions = async () => {
        if (parentAgentList.length === 0) {
            getParentAgentOptions().then((options) => {
                saveParentAgentList(options);
                filterDifferentAgents(options);
            }).catch((error) => {
                console.error('error', error);
            });
        } else {
            if (agentAndBaseAgentList.length === 0) {
                filterDifferentAgents(parentAgentList);
            }
        }


        if (salesChannelList.length === 0) {
            getSalesChannelOptions().then((options) => {
                saveSalesChannelList(options);
            }).catch((error) => {
                console.error('error', error);
            });
        }

        if (supplierProductList.length === 0) {
            getSupplierOptions().then((options) => {
                saveSupplierProductList(options);
                filterSuppliersForFlight(options);
            }).catch((error) => {
                console.error('error', error);
                // toast.error(API_ERROR_TOAST_TEXT);
            });
        } else {
            if (flightSupplierList.length === 0) {
                filterSuppliersForFlight(supplierProductList);
            }
        }
    }



    const handleFlightQueueFiltersChange = (value: any, param: string) => {
        let filters = JSON.parse(JSON.stringify(flightQueueFilters));
        let supplierIds: any = [];
        let bookingModes: any = [];
        if (param === 'bookingModes') {
            value?.forEach((mode: any) => {
                bookingModes.push(mode.value);
                filters[param] = bookingModes;
                filters.selectedBookingStatus = value;
            })
        } else if (param === 'supplierId') {
            value?.forEach((supplier: any) => {
                supplierIds.push(supplier.id);
            });

            filters[param] = supplierIds;
            filters.selectedSuppliers = value;
        }
        else if (param === 'pnrno' || param === 'paxname') {
            filters[param] = value.target.value;
        } else {
            filters[param] = value;
        }
        saveFlightQueueFilters(filters);
        setSubmit(filters)
    }

    return (

        <>
            <MainLayout>

                <div className="container">
                    <section className="country_section mt-2 mb-3 font_size_90">


                        <div className="row mt-3">

                            <div className="col-lg-3">
                                <div className="row align-items-center mb-2">
                                    <label htmlFor="fromDate" className="col-lg-5">From Date :</label>
                                    <div className="col-sm-7">
                                        <ControlledDatePicker
                                            id={'fromDate'}
                                            value={flightQueueFilters.fromDate ? flightQueueFilters.fromDate : new Date()}
                                            format={'dd/MMM/yyyy'}
                                            required={true}
                                            disablePostDates={true}
                                            onChange={(date: any) => handleFlightQueueFiltersChange(date.toISOString(), 'fromDate')}
                                        />
                                    </div>
                                </div>

                            </div>

                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="tomDate" className="col-lg-5">To Date :</label>
                                    <div className="col-sm-7">
                                        <ControlledDatePicker
                                            id={'toDate'}
                                            value={flightQueueFilters.toDate ? flightQueueFilters.toDate : new Date()}
                                            format={'dd/MMM/yyyy'}
                                            required={true}
                                            onChange={(date: any) => handleFlightQueueFiltersChange(date.toISOString(), 'toDate')}

                                        />
                                    </div>
                                </div>

                            </div>


                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="agent" className="col-lg-5">Agent :</label>
                                    <div className="col-lg-7">
                                        <ControlledSelect
                                            id={'agent'}
                                            value={flightQueueFilters.selectedAgentId ? flightQueueFilters.selectedAgentId : ''}
                                            options={agentAndBaseAgentList}
                                            required={true}
                                            onChange={(e: any) => handleFlightQueueFilterAgentIdChange(flightQueueFilters, e.target.value, 'agent')}
                                        />
                                    </div>
                                </div>

                            </div>

                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="b2b" className="col-lg-5">B2B  </label>
                                    <div className="col-lg-7">
                                        <ControlledSelect
                                            id={'b2b'}
                                            value={flightQueueFilters.selectedB2bId ? flightQueueFilters.selectedB2bId : ''}
                                            options={bToBList}
                                            required={true}
                                            onChange={(e: any) => handleFlightQueueFilterAgentIdChange(flightQueueFilters, e.target.value, 'b2b')}
                                        />
                                    </div>
                                </div>

                            </div>

                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="b2b2b" className="col-lg-5">B2B2B :</label>
                                    <div className="col-lg-7">
                                        <ControlledSelect
                                            id={'b2b2b'}
                                            value={flightQueueFilters.selectedB2b2bId ? flightQueueFilters.selectedB2b2bId : ''}
                                            options={bToBToBList}
                                            required={true}
                                            onChange={(e: any) => handleFlightQueueFilterAgentIdChange(flightQueueFilters, e.target.value, 'b2b2b')}
                                        />
                                    </div>
                                </div>

                            </div>

                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="location" className="col-lg-5">Location :</label>
                                    <div className="col-lg-7">
                                        <ControlledSelect
                                            id={'location'}
                                            value={flightQueueFilters.locationId ? flightQueueFilters.locationId : ''}
                                            options={locationList}
                                            required={true}
                                            onChange={(e: any) => handleFlightQueueFiltersChange(e.target.value, 'locationId')}
                                        />
                                    </div>
                                </div>

                            </div>

                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="bookingstatus" className="col-lg-5">Booking Status :</label>
                                    <div className="col-lg-7">
                                        <ControlledMultiSelect
                                            id={'bookingstatus'}
                                            value={flightQueueFilters.selectedBookingStatus ? flightQueueFilters.selectedBookingStatus : []}
                                            options={selectBookingStatusOption}
                                            required={true}
                                            onChange={(value: any) => handleFlightQueueFiltersChange(value, 'bookingModes')}
                                        />
                                    </div>
                                </div>

                            </div>

                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="pnrno" className="col-lg-5">PNR No.               :</label>
                                    <div className="col-lg-7">

                                        <ControlledInput
                                            id={'pnrno'}
                                            value={flightQueueFilters.pnrno ? flightQueueFilters.pnrno : []}
                                            type={'text'}
                                            required={true}
                                            onChange={(value: any) => handleFlightQueueFiltersChange(value, 'pnrno')}
                                        />
                                    </div>
                                </div>

                            </div>

                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="paxname" className="col-lg-5">Pax Name  :</label>
                                    <div className="col-lg-7">
                                        <ControlledInput
                                            id={'paxname'}
                                            value={paxname}
                                            type={'text'}
                                            required={true}
                                            onChange={(value: any) => handleFlightQueueFiltersChange(value, 'paxname')}
                                        />
                                    </div>
                                </div>

                            </div>

                            <div className="col-lg-3">

                                <div className="row align-items-center mb-2">
                                    <label htmlFor="transtype" className="col-lg-5">TransType:</label>
                                    <div className="col-lg-7">
                                        <ControlledSelect
                                            id={'transtype'}
                                            value={flightQueueFilters.transType ? flightQueueFilters.transType : ''}
                                            options={salesChannelList}
                                            required={true}
                                            onChange={(e: any) => handleFlightQueueFiltersChange(e.target.value, 'transType')}
                                        />
                                    </div>
                                </div>

                            </div>
                            <div className="col-lg-3">
                                <div className="row align-items-center mb-2">
                                    <label htmlFor="supplier" className="col-lg-5">Supplier :</label>
                                    <div className="col-lg-7">
                                        <ControlledMultiSelect
                                            id={'supplier'}
                                            value={flightQueueFilters.selectedSuppliers ? flightQueueFilters.selectedSuppliers : []}
                                            options={flightSupplierList}
                                            onChange={(value: any) => handleFlightQueueFiltersChange(value, 'supplierId')}
                                        />
                                    </div>
                                </div>
                            </div>



                            <div className="col-lg-3">
                                <div className="row align-items-center mb-2">
                                    <label htmlFor="bookingDate" className="col-lg-5">Booking Date :</label>
                                    <div className="col-sm-7">
                                        <ControlledDatePicker
                                            id={'bookingDate'}
                                            value={flightQueueFilters.bookingDate ? flightQueueFilters.bookingDate : new Date()}
                                            format={'dd/MMM/yyyy'}
                                            required={true}
                                            onChange={(date: any) => handleFlightQueueFiltersChange(date.toISOString(), 'bookingDate')}
                                        />
                                    </div>
                                </div>
                            </div>


                            <div className="col-lg-3 text-end">

                                <button className='btn btn-sm btn-primary rounded mt-2' onClick={onSearch}>Search </button>

                            </div>

                        </div>


                        <div className="row mt-2">

                            <div className="col-12">
                                <div className="table-responsive">
                                    <table className="table text-secondary">
                                        <thead>

                                            <tr className='align-middle'>
                                                <th scope="col">SN</th>
                                                <th scope="col">Booking Date</th>
                                                <th scope="col">Agent</th>
                                                <th scope="col">PNR</th>
                                                <th scope="col">Status</th>
                                                <th scope="col">Route</th>
                                                <th scope="col">Provider</th>
                                                <th scope="col">Location</th>
                                                <th scope="col">Created By</th>
                                                <th scope="col">Pax Name     </th>
                                                <th scope="col">Total Price</th>
                                                <th scope="col">Airline</th>
                                                <th scope="col">Pax Count</th>
                                                <th scope="col">Travel Date</th>
                                                <th scope="col">Ticketed Date</th>
                                                <th scope="col">Ticketing Date Expiry </th>
                                                <th scope="col">Actions</th>




                                                <th> </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {console.log('flightQueueValue', flightQueueValue)}
                                            {flightQueueValue?.map((booking: any, index: any) => (
                                                <tr key={booking.bookingId}>
                                                    <td>{index + 1}</td>
                                                    <td>{new Date(booking?.createdOn).toLocaleDateString()}</td>
                                                    <td>{booking?.agentName}</td>
                                                    <td><span className="text-success"><b>{booking?.pnr}</b></span></td>
                                                    <td><span className="text-primary">{booking?.bookingStatus}</span></td>
                                                    <td>{booking?.routing}</td>
                                                    <td>{booking?.source}</td>
                                                    <td>{booking?.locationName}</td>
                                                    <td>{booking?.createdBy}</td>
                                                    <td>{booking?.leadPaxName}</td>
                                                    <td>{`${booking?.agentCurrency} ${booking?.totalFare?.toLocaleString()}`}</td>
                                                    <td>{`${booking?.airlineCode}-${booking?.flightNum}`}</td>
                                                    <td className="text-center">{booking?.adultCount + booking?.childCount + booking?.infantCount}</td>
                                                    <td>{new Date(booking?.travelDate).toLocaleDateString()}</td>
                                                    <td>{new Date(booking?.ticketedDate).toLocaleDateString()}</td>
                                                    <td>-</td>
                                                    <td className="btnDropMenu">
                                                        <FlightQueeModal />
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </div>

                        {flightQueueValue / length > 0 && <div className="row align-items-center">

                            <div className="col-lg-8">
                                <Paging />
                            </div>

                            <div className="col-lg-4">

                                <ViewPerPage />

                            </div>






                        </div>}

                    </section>

                </div>
            </MainLayout>
        </>


    )
}
export default FlightQueue;