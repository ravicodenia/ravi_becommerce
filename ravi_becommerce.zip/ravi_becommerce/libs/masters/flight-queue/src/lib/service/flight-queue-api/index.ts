import { getGatewayAPI, putGatewayAPI,postGatewayAPI } from '@mfa-travel-app/services';
import { FLIGHT_QUEUE } from '../constants';

export const createFlightQueue = async (payload: any) => {
    try {
        const response = await postGatewayAPI( FLIGHT_QUEUE, payload);
        return response;
    } catch (error) {
        return error;
    }
}