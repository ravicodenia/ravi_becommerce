// import React, { useEffect, useState } from 'react';
// import classNames from 'classnames';

// const AddPax = () => {
//     return (
//         <div
//                 className={classNames(
//                   styles['srchCon'],
//                   styles['srchConTravellers']
//                 )}
//               >
//                 <div
//                   className={classNames(
//                     'py-1 px-3',
//                     styles['srchRow'],
//                     styles['selectflightpax']
//                   )}
//                 onClick={openTravellersClass}
//                 >
//                   <div className={styles['srchCon']}>
//                     <div>
//                       <span className={styles['srchsml']}>
//                         Travellers &amp; Class{' '}
//                         <svg
//                           xmlns="http://www.w3.org/2000/svg"
//                           viewBox="0 0 448 512"
//                         >
//                           <path d="M201.4 374.6c12.5 12.5 32.8 12.5 45.3 0l160-160c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L224 306.7 86.6 169.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l160 160z" />
//                         </svg>
//                       </span>
//                     </div>
//                     <div className="d-flex justify-content-start align-items-center gap-2">
//                       <span className={classNames(styles['srchTitle'])}>
//                         <input
//                           className={classNames(
//                             styles['inpflightpax'],
//                             'fw-bold text-black fs-4'
//                           )}
//                           type="text"
//                           id="totalpaxflightinp"
//                           name="totalpaxflightinp"
//                           value={adults + children + infants}
//                           disabled={true}
//                         />
//                       </span>{' '}
//                       <span className={styles['srchLabel']}>Travellers</span>
//                     </div>
//                     <div>
//                       <span
//                         id="getcabinval"
//                         className={classNames(
//                           styles['srchsml'],
//                           styles['textTrim']
//                         )}
//                       >
//                         Economy/Premium Economy
//                       </span>{' '}
//                     </div>
//                   </div>
//                 </div>
//                 <div
//                   id="div_flightPax"
//                   className={classNames(
//                     styles['travelersFlight'],
//                     `${istravellersClass ? 'd-block' : 'd-none'}`
//                   )}
//                 >
//                   <div className="d-flex justify-content-between align-items-center mb-1">
//                     <div>Adults (12+)</div>
//                     <div>
//                       <div className={classNames(styles['input-group'], 'input-group')}>
//                         <button
//                           className={classNames(styles['input-group-text'], styles['dec-btn'])}
//                           onClick={() => handleDecrement('adults')}
//                           disabled={adults === 0}
//                         >
//                           <svg
//                             xmlns="http://www.w3.org/2000/svg"
//                             viewBox="0 0 448 512"
//                           >
//                             <path d="M432 256c0 17.7-14.3 32-32 32L48 288c-17.7 0-32-14.3-32-32s14.3-32 32-32l352 0c17.7 0 32 14.3 32 32z" />
//                           </svg>
//                         </button>
//                         <input
//                           type="text"
//                           className={classNames(
//                             styles['form-control'],
//                             'text-center'
//                           )}
//                           value={adults}
//                           disabled
//                         />
//                         <button
//                           className={classNames(styles['input-group-text'], styles['inc-btn'])}
//                           onClick={() => handleIncrement('adults')}
//                         >
//                           <svg
//                             xmlns="http://www.w3.org/2000/svg"
//                             viewBox="0 0 448 512"
//                           >
//                             <path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z" />
//                           </svg>
//                         </button>
//                       </div>
//                     </div>
//                   </div>

//                   <div className="d-flex justify-content-between align-items-center mb-1">
//                     <div>Children (2 - 11) </div>
//                     <div>
//                       <div className={classNames(styles['input-group'], 'input-group')}>
//                         <button
//                           className={classNames(styles['input-group-text'], styles['dec-btn'])}
//                           onClick={() => handleDecrement('children')}
//                           disabled={children === 0}
//                         >
//                           <svg
//                             xmlns="http://www.w3.org/2000/svg"
//                             viewBox="0 0 448 512"
//                           >
//                             <path d="M432 256c0 17.7-14.3 32-32 32L48 288c-17.7 0-32-14.3-32-32s14.3-32 32-32l352 0c17.7 0 32 14.3 32 32z" />
//                           </svg>
//                         </button>
//                         <input
//                           type="text"
//                           className={classNames(
//                             styles['form-control'],
//                             'text-center'
//                           )}
//                           value={children}
//                           disabled
//                         />
//                         <button
//                           className={classNames(styles['input-group-text'], styles['inc-btn'])}
//                           onClick={() => handleIncrement('children')}
//                         >
//                           <svg
//                             xmlns="http://www.w3.org/2000/svg"
//                             viewBox="0 0 448 512"
//                           >
//                             <path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z" />
//                           </svg>
//                         </button>
//                       </div>
//                     </div>
//                   </div>

//                   <div className="d-flex justify-content-between align-items-center mb-1">
//                     <div>Infants(0-2) </div>
//                     <div>
//                       <div className={classNames(styles['input-group'], 'input-group')}>
//                         <button
//                           className={classNames(styles['input-group-text'], styles['dec-btn'])}
//                           onClick={() => handleDecrement('infants')}
//                           disabled={infants === 0}
//                         >
//                           <svg
//                             xmlns="http://www.w3.org/2000/svg"
//                             viewBox="0 0 448 512"
//                           >
//                             <path d="M432 256c0 17.7-14.3 32-32 32L48 288c-17.7 0-32-14.3-32-32s14.3-32 32-32l352 0c17.7 0 32 14.3 32 32z" />
//                           </svg>
//                         </button>
//                         <input
//                           type="text"
//                           className={classNames(
//                             styles['form-control'],
//                             'text-center'
//                           )}
//                           value={infants}
//                           disabled
//                         />
//                         <button
//                           className={classNames(styles['input-group-text'], styles['inc-btn'])}
//                           onClick={() => handleIncrement('infants')}
//                         >
//                           <svg
//                             xmlns="http://www.w3.org/2000/svg"
//                             viewBox="0 0 448 512"
//                           >
//                             <path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z" />
//                           </svg>
//                         </button>
//                       </div>
//                     </div>
//                   </div>

//                   <div className="row mt-3">
//                     <div className="col-lg-12">
//                       <label htmlFor="selcabin">
//                         <strong>Travel Class</strong>
//                       </label>
//                       <div className={styles['travel-class']}>
//                         <span>
//                           <input
//                             type="radio"
//                             name="travelClass"
//                             id="any"
//                             value="any"
//                             checked={selectedOption === 'any'}
//                             onChange={handleRadioChange}
//                           />
//                           <label htmlFor="any">Any</label>
//                         </span>

//                         <span>
//                           <input
//                             type="radio"
//                             name="travelClass"
//                             id="economy"
//                             value="economy"
//                             checked={selectedOption === 'economy'}
//                             onChange={handleRadioChange}
//                           />
//                           <label
//                             htmlFor="economy"
//                             className={
//                               styles[
//                                 selectedOption === 'economy'
//                                   ? 'default-radio'
//                                   : ''
//                               ]
//                             }
//                           >
//                             Economy
//                           </label>
//                         </span>

//                         <span>
//                           <input
//                             type="radio"
//                             name="travelClass"
//                             id="firstClass"
//                             value="firstClass"
//                             checked={selectedOption === 'firstClass'}
//                             onChange={handleRadioChange}
//                           />
//                           <label
//                             htmlFor="firstClass"
//                             className={
//                               styles[
//                                 selectedOption === 'firstClass'
//                                   ? 'default-radio'
//                                   : ''
//                               ]
//                             }
//                           >
//                             First Class
//                           </label>
//                         </span>

//                         <span>
//                           <input
//                             type="radio"
//                             name="travelClass"
//                             id="premiumEconomy"
//                             value="premiumEconomy"
//                             checked={selectedOption === 'premiumEconomy'}
//                             onChange={handleRadioChange}
//                           />
//                           <label
//                             htmlFor="premiumEconomy"
//                             className={
//                               styles[
//                                 selectedOption === 'premiumEconomy'
//                                   ? 'default-radio'
//                                   : ''
//                               ]
//                             }
//                           >
//                             Premium Economy
//                           </label>
//                         </span>

//                         <span>
//                           <input
//                             type="radio"
//                             name="travelClass"
//                             id="business"
//                             value="business"
//                             checked={selectedOption === 'business'}
//                             onChange={handleRadioChange}
//                           />
//                           <label
//                             htmlFor="business"
//                             className={
//                               styles[
//                                 selectedOption === 'business'
//                                   ? 'default-radio'
//                                   : ''
//                               ]
//                             }
//                           >
//                             Business
//                           </label>
//                         </span>
//                       </div>
//                     </div>
//                   </div>

//                   <div className="row mt-3 mb-2">
//                     <div className={classNames('col-lg-2')}>
//                       <button
//                         className={classNames(
//                           styles['btn'],
//                           styles['btn-primary'],
//                           styles['btn-primarys'],
//                           styles['close_div_flightPax']
//                         )}
//                         onClick={TravellersDone}
//                       >
//                         Done
//                       </button>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//     )
// }