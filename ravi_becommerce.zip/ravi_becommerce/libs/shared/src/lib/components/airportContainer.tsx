import { useEffect, useState } from 'react';
import styles from '../../../../features/flights/src/lib/oneway.module.scss';
import { RootState } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';

const AirportContainer = ({ Source, icon, onAirportSelect, airportPayload }: any) => {
  const { airports } = useSelector((state: RootState) => state.flight);
  const { homeScreenShowHide }: any = useSelector((state: RootState) => state.config);
  const [searchTerm, setSearchTerm] = useState('');
  const [sourcesuggestionsList, setsourceSuggestionsList] = useState<any>([]);
  const [selectedairport, setSelectedairport] = useState<any>(null);
  const [nearbyAirports, setNearbyAirports] = useState(false);
  const showOriginNearByAirportHomeSreen = homeScreenShowHide?.some((item: any) => item.text === "ORIGIN_NEARBY_AIRPORT" && item.show);

  useEffect(() => {
    if (airportPayload) {
      const airport = airports.filter((airport: any) => airport.airportCode === airportPayload)
      setSelectedairport(airport[0])
      setSearchTerm(airport[0]?.cityName);
      onAirportSelect(airport[0]);
    } else {
      setSelectedairport(null)
      setSearchTerm('');
      onAirportSelect(null);
    }
  }, [airportPayload])

  const handleInputChange = (event: any) => {
    const { value } = event.target;
    setSearchTerm(value);
    if (value.length >= 2) {
      setsourceSuggestionsList(
        airports?.filter((suggestion: any) =>
          suggestion.cityName.toLowerCase().includes(value.toLowerCase()) ||
          suggestion.airportCode.toLowerCase().includes(value.toLowerCase())
        ) || []
      );
    } else {
      setsourceSuggestionsList([]);
    }
    setSelectedairport(null);
    onAirportSelect(null);
  };
  const handleKeyDown = (event: any) => {
    if (event.key === 'Tab' && sourcesuggestionsList.length > 0) {
      setSearchTerm(sourcesuggestionsList[0]?.cityName);
      setSelectedairport(sourcesuggestionsList[0]);
      setsourceSuggestionsList([]);
      onAirportSelect(sourcesuggestionsList[0]);
    }
  }

  const handleSuggestionClick = (option: any) => {
    setSearchTerm(option.cityName);
    setSelectedairport(option);
    setsourceSuggestionsList([]);
    onAirportSelect(option);
  };
  const handleCheckboxChange = (event: any) => {
    const { checked } = event.target;
    setNearbyAirports(checked);
    onAirportSelect({ ...selectedairport, nearbyAirports: checked });
  };

  return (

    <>
      <div className='row'>
        <div className='col-12'>
          {/* { showOriginNearByAirportHomeSreen && <table className={`flightheadertbl ${Source == 'From' ? 'visible' : 'invisible'}`}>
            <thead>
              <tr>
                <td style={{ textAlign: 'start' }}>
                  <input
                    type="checkbox"
                    value=""
                    id="flyingfrom"
                    checked={nearbyAirports}
                    onChange={handleCheckboxChange}
                  />
                  <label htmlFor="flyingfrom"> Nearby Airports</label>
                </td>
              </tr>
            </thead>
            <tbody></tbody>
          </table> } */}
          <div className="srchCon">
            <div className="srchRow">
              <div className="srchCol">
                <div className="mb-1 text-start"><span className="srchsml">{Source}</span></div>
                <div className={styles['destination-dropdown']}
                  id="departure-dropdown"
                >
                  <span className='me-1'> {icon} </span>
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={handleInputChange}
                    onKeyDown={handleKeyDown}
                    placeholder="Select"
                    className="srchTitle enterAirport inputTxt"
                    id="departure-input"
                    autoComplete='off'
                  />

                </div>
                {selectedairport && (
                  <div>
                    <span className="srchsml textTrim">
                      {selectedairport?.airportCode ? `[${selectedairport.airportCode}]` : ''} {selectedairport?.airportName}
                    </span>
                  </div>)}

              </div>
            </div>
            {sourcesuggestionsList?.length > 0 && (
              <ul className={styles['suggestion-list-modal']}>
                {sourcesuggestionsList.map(
                  (suggestion: any, index: number) => (
                    <li
                      key={index}
                      onClick={() => handleSuggestionClick(suggestion)}
                    >
                      {suggestion?.cityName} <small>({suggestion.airportCode})</small><br />
                      {suggestion.airportName}, {suggestion?.countryName}
                    </li>
                  )
                )}
              </ul>

            )}
          </div>
        </div>

      </div>

    </>
  );
};

export default AirportContainer;
