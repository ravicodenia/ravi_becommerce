// TOAST_SUCCES_ERROR_ALERT
export const SUCCESS_TOAST_TEXT = 'This operation was successful.';
export const ERROR_TOAST_TEXT = 'This operation was failed, contact the support.';
export const API_ERROR_TOAST_TEXT = 'An error occurred. Please try again later.';

// AGENT_MASTER ALERT
export const NO_FORM_OF_PAYMENT_ALERT = 'Please select at least one form of payment.';
export const NO_PRODUCT_SELECTED_ALERT = 'Please select at least one product to continue.';
export const NO_SUPPLIER_SELECTED_ALERT = 'Please select at least one supplier as you selected';
export const LARGE_FILE_SIZE_ALERT = 'File is large, max size in bytes is';
export const DOCUMENT_OR_EXP_DATE_MISSING_ALERT = 'Please either provide both document & expiry date or leave both.';
export const ILLEGAL_DOCUMENT_UPLOADED_ALERT = 'This type of file is no accepted. Accepted file(s) are:';
export const ERROR_IN_FILE_UPLOAD = 'Error in file upload.';
export const ERROR_IN_FILE_PREVIEW = 'Error in previewing this file.';

//LOCATION_MASTER ALERT
export const WRONG_EMAIL_ALERT = 'Please provide a correct email.';

//ROLE_MASTER ALERT
export const NO_ROLE_SELECTED_ALERT = 'Please at least select one role.';

//SESSION_EXPIRE
export const SESSION_EXPIRE_TITLE = 'Session about to be expired.';
export const SESSION_EXPIRE_SUBTITLE = 'Want to continue browsing?';

// USER_MASTER ALERT
export const PASSWORD_MISMATCH_ALERT = 'The provided passwords does not match.';

// CONSTANTS
export const TEXT_TO_PICK_HOTEL_ID = 'Hotels';