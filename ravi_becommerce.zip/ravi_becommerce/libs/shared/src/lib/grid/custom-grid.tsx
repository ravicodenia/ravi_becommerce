import * as React from 'react';
import GridSection from './grid-section';
import PaginationSection from './pagination-section';

const CustomGrid = ({ headerRowList, dataRowList, gridData, hasSerialNumberColumn = false, hasActionColumn = false, ActionColumnComponent = undefined, hasPagination = false, paginationOptions }: any) => {
    const [paginationState, setPaginationState] = React.useState({
        numberOfPages: 0,
        selectedPageNumber: 1,
        recordsPerPageOptions: paginationOptions ? paginationOptions : [],
        selectedRecordsPerPageId: paginationOptions ? paginationOptions[0]?.id : 0,
        recordFromIndex: 0,
        recordToIndex: 0,
        gridData: gridData,
    });

    React.useEffect(() => {
        calculatePagesBasedOnSelectedPerPageAndTotalRecords();
    }, [gridData, paginationState.selectedPageNumber, paginationState.selectedRecordsPerPageId]);

    const calculatePagesBasedOnSelectedPerPageAndTotalRecords = () => {
        let totalRecords = gridData.length;
        if (totalRecords > 0) {

            if (hasPagination) {
                let recordsPerPage = paginationState.recordsPerPageOptions?.find((r: any) => r.id === paginationState.selectedRecordsPerPageId)?.value;

                if (Number(recordsPerPage) > 0) {
                    let pages = Math.ceil(totalRecords / Number(recordsPerPage));

                    let fromIndex = (Number(paginationState.selectedPageNumber) - 1) * Number(recordsPerPage);
                    let toIndex = (Number(paginationState.selectedPageNumber) * Number(recordsPerPage)) - 1;

                    let dataToShow = gridData.slice(fromIndex, toIndex + 1);

                    setPaginationState({
                        ...paginationState, numberOfPages: pages,
                        recordFromIndex: fromIndex,
                        recordToIndex: toIndex,
                        gridData: dataToShow
                    });
                } else {
                    // all records will be shown
                }
            } else {
                // all records will be shown
            }
        }


    }

    return (
        <>
            <GridSection
                headerRowList={headerRowList}
                dataRowList={dataRowList}
                gridData={paginationState.gridData}
                hasSerialNumberColumn={hasSerialNumberColumn}
                hasActionColumn={hasActionColumn}
                ActionColumnComponent={ActionColumnComponent}
                fromIndex={paginationState.recordFromIndex}
            />

            <PaginationSection
                hasPagination={hasPagination}
                gridData={gridData}
                paginationState={paginationState}
                setPaginationState={setPaginationState}
                numberOfPages={paginationState.numberOfPages}
                recordsPerPageOptions={paginationState.recordsPerPageOptions}
                selectedPageNumber={paginationState.selectedPageNumber}
                selectedRecordsPerPageId={paginationState.selectedRecordsPerPageId}
            />
        </>
    );
}

export default CustomGrid;