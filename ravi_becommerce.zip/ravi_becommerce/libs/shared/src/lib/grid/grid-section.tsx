import * as React from 'react';
import moment from 'moment';
import { Tooltip } from 'react-tooltip';

const GridSection = ({ headerRowList, dataRowList, gridData, hasSerialNumberColumn, hasActionColumn, ActionColumnComponent, fromIndex }: any) => {
    const handleCopyToClipboard = (toolTipId: string, toolTipIconId: string) => {
        let textToCopy = document.getElementById(toolTipId);
        navigator.clipboard.writeText(textToCopy?.innerText ? textToCopy?.innerText : '');

        let copyIcon = document.getElementById(toolTipIconId);
        copyIcon?.classList.remove('fa-copy');
        copyIcon?.classList.add('fa-check');
    }

    const getSingleValuedColumn = (row: any, rowData: any) => {
        return `${row.format && row.convertAsTimezone ? moment.utc(rowData[row.param]).local().format(row.format) : row.format ? moment(rowData[row.param]).format(row.format) : rowData[row.param] ? rowData[row.param] : '-'}${row.fixText ? ` ${row.fixText}` : ''}`;
    }

    const getMultiValuedColumn = (params: any, row: any, rowData: any) => {
        return params?.map((p: any, index: any) => {
            return `${index !== 0 ? row.separator ? ` ${row.separator} ` : ' ' : ''}${row.format && row.convertAsTimezone ? moment.utc(rowData[p.param]).local().format(row.format) : row.format ? moment(rowData[p.param]).format(row.format) : rowData[p.param] ? rowData[p.param] : '-'} ${p.text}`;
        });
    }

    const getColumnWithToolTip = (row: any, rowData: any, index: any, gridIndex: any, columnValue: any, params: any = undefined) => {
        return <td className={row.className} key={index}>
            <a id={`tooltip-anchor-${gridIndex}-${index}`}>
                {
                    params ? columnValue(params, row, rowData) :
                        columnValue(row, rowData)
                }
            </a>
            <Tooltip anchorSelect={`#tooltip-anchor-${gridIndex}-${index}`} clickable>
                {
                    params ? columnValue(params, row, rowData) :
                        columnValue(row, rowData)
                }
                <button onClick={() => handleCopyToClipboard(`tooltip-anchor-${gridIndex}-${index}`, `tooltip-icon-${gridIndex}-${index}`)}>
                    <a
                        data-tooltip-id={`tooltip-copy-${gridIndex}-${index}`}
                        data-tooltip-content={'Click to copy!'}
                    >
                        <i
                            id={`tooltip-icon-${gridIndex}-${index}`}
                            className='fa-solid fa-copy'
                        />
                    </a>
                    <Tooltip id={`tooltip-copy-${gridIndex}-${index}`} />
                </button>
            </Tooltip>
        </td>
    }

    const getGridRow = (row: any, rowData: any, index: any, gridIndex: any) => {
        if (row.param.split(',').length === 1) {
            if (row.toolTip) {
                return getColumnWithToolTip(row, rowData, index, gridIndex, getSingleValuedColumn)
            } else {
                return <td className={row.className} key={index}>
                    {
                        getSingleValuedColumn(row, rowData)
                    }
                </td>
            }
        } else {
            let params = JSON.parse(JSON.stringify(row.param.split(',')?.map((p: any) => p.trim())));

            if (row.fixText) {
                let texts = row.fixText.split(',')?.map((t: any) => t.trim());

                if (texts.length === params.length) {
                    params = params?.map((p: any, index: any) => {
                        return {
                            param: p,
                            text: texts[index]
                        }
                    });
                } else {
                    params = params?.map((p: any) => {
                        return {
                            param: p,
                            text: ''
                        }
                    });
                }
            } else {
                params = params?.map((p: any) => {
                    return {
                        param: p,
                        text: ''
                    }
                });
            }

            if (row.toolTip) {
                return getColumnWithToolTip(row, rowData, index, gridIndex, getMultiValuedColumn, params)
            } else {
                return <td className={row.className} key={index}>
                    {
                        getMultiValuedColumn(params, row, rowData)
                    }
                </td>
            }
        }
    }

    return (
        <div className='col-12' style={{ display: gridData.length === 0 ? 'none' : '' }}>
            <div className='table-responsive'>
                <table className='table text-secondary table-striped tbl_grid_heading'>
                    <thead>
                        <tr className='align-middle'>
                            {
                                headerRowList?.map((header: any, index: any) => {
                                    return <th className={header.className} scope='col' key={index}>{header.label}</th>
                                })
                            }
                        </tr>
                    </thead>

                    <tbody>
                        {
                            gridData?.map((rowData: any, gridIndex: any) => {
                                return <tr key={gridIndex}>
                                    {
                                        dataRowList?.map((row: any, index: any) => {
                                            if (index === 0) {
                                                if (hasSerialNumberColumn) {
                                                    return <td className={row.className} key={index}>
                                                        {fromIndex + gridIndex + 1}
                                                    </td>
                                                } else {
                                                    return getGridRow(row, rowData, index, gridIndex)
                                                }
                                            } else if (dataRowList.length === index + 1) {
                                                if (hasActionColumn) {
                                                    return <td className={row.className} key={index}>
                                                        {
                                                            ActionColumnComponent ?
                                                                <ActionColumnComponent row={rowData} /> : ''
                                                        }
                                                    </td>
                                                } else {
                                                    return getGridRow(row, rowData, index, gridIndex)
                                                }
                                            } else {
                                                return getGridRow(row, rowData, index, gridIndex)
                                            }
                                        })
                                    }
                                </tr>
                            })
                        }
                    </tbody>
                </table>
            </div>
        </div>
    );
}

export default React.memo(GridSection);