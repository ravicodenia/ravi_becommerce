import * as React from 'react';
import { ControlledSelect } from '@mfa-travel-app/ui';
import { Pagination, Stack } from '@mui/material';

const PaginationSection = ({ hasPagination, numberOfPages, recordsPerPageOptions, gridData, selectedPageNumber, paginationState, setPaginationState, selectedRecordsPerPageId }: any) => {
    const handlePaginationChange = (e: any, value: number) => {
        setPaginationState({ ...paginationState, selectedPageNumber: value });
    }

    const handleRecordsPerPageChange = (value: any) => {
        setPaginationState({
            ...paginationState,
            selectedRecordsPerPageId: Number(value),
            numberOfPages: 0,
            selectedPageNumber: 1
        });
    }

    return (
        <>
            {
                hasPagination && gridData.length > 0 ? <div className="row align-items-center">

                    <div className="col-lg-8">
                        <Stack spacing={2}>
                            <Pagination
                                showFirstButton
                                showLastButton
                                boundaryCount={2}
                                siblingCount={2}
                                count={numberOfPages}
                                page={selectedPageNumber}
                                onChange={handlePaginationChange}
                            />
                        </Stack>
                    </div>

                    <div className="col-lg-4">
                        <div className="d-flex align-items-center justify-content-end">
                            <div className="m-2"><small> Records per page</small></div>

                            <div>
                                <ControlledSelect
                                    id={'pagination'}
                                    value={selectedRecordsPerPageId}
                                    options={recordsPerPageOptions}
                                    showSelectOption={false}
                                    onChange={(e: any) => handleRecordsPerPageChange(e.target.value)}
                                />
                            </div>
                        </div>

                        <div className="text-end mt-1 mb-2">
                            <small>Total records: {gridData.length}</small>
                        </div>
                    </div>

                </div> : <></>
            }
        </>
    );
}

export default React.memo(PaginationSection);