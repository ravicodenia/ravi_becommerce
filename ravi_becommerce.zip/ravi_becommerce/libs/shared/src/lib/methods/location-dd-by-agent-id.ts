import { getAllLocationOptions, getLocationOptionsByAgentId } from './masters-dropdown';

export const updateLocationDropdownByAgentId = (agentId: number) => {
    if (agentId > 0) {
        return new Promise((resolve, reject) => {
            getLocationOptionsByAgentId(agentId).then((options) => {
                resolve(options);
            }).catch((error) => {
                reject(error);
            });
        });
    } else {
        return new Promise((resolve, reject) => {
            getAllLocationOptions().then((options) => {
                resolve(options);
            }).catch((error) => {
                reject(error);
            });
        });
    }
}

export default updateLocationDropdownByAgentId;