export const convertDateForApi = (dateReceived: any) => {
    if (dateReceived) {
        const date = new Date(dateReceived);
        return `${date.getFullYear()}-${date.getMonth() + 1 < 10 ? `0${date.getMonth() + 1}` : date.getMonth() + 1}-${date.getDate() < 10 ? `0${date.getDate()}` : date.getDate()}`;
    } else {
        return dateReceived;
    }
}

export default convertDateForApi;