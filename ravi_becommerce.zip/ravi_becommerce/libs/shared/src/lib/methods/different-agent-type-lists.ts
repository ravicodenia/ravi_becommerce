export const differentAgentTypeLists = (agentList: any) => {
    const agentAndBaseAgent = agentList?.filter((a: any) => a.type === 'AGENT' || a.type === 'BASEAGENT');
    agentAndBaseAgent.splice(0, 0, { id: 0, text: 'All' });

    const bToB = agentList?.filter((a: any) => a.type === 'B2B');
    bToB.splice(0, 0, { id: 0, text: 'All' });

    const bToBToB = agentList?.filter((a: any) => a.type === 'B2B2B');
    bToBToB.splice(0, 0, { id: 0, text: 'All' });

    return {
        agentAndBaseAgent: agentAndBaseAgent,
        bToB: bToB,
        bToBToB: bToBToB,
    }
}

export default differentAgentTypeLists;