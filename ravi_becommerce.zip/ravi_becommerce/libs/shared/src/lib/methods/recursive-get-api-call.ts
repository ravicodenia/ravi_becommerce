export const recursiveGetApiCall = async (apiMethod: Function, pageSize = 100, pageNumber = 1, result = []): Promise<any[]> => {
    try {
        const page: any = await apiMethod(pageSize, pageNumber);
        result = result.concat(page?.data?.items);

        if (page?.data?.hasNext) {
            return recursiveGetApiCall(apiMethod, pageSize, pageNumber + 1, result);
        } else {
            return result;
        }
    } catch (error) {
        throw error;
    }
}

export default recursiveGetApiCall;