import { getAgentCategoryList, getAgentType, getAllLocationList, getAppConfigList, getCityListByStateId, getContactType, getCountryList, getCurrencyList, getLanguageList, getLocationListByAgentId, getParentAgentList, getPaymentType, getPayPeriodList, getRoleList, getSalesChannelList, getSalesExecManagerList, getSalutationList, getSecurityType, getStateListByCountryId, getSupplierProductList, getThemeList, getUserAccessList, getUserTypeList } from '../services/masters-dropdown-api';

export const getAgentTypeOptions = async () => {
    return new Promise((resolve, reject) => {
        getAgentType().then((response: any) => {
            if (response.data) {
                const agentType = response?.data?.map((item: any) => {
                    return {
                        id: item.value,
                        text: item.value
                    }
                });

                resolve(agentType);
            } else {
                resolve([]);
            }
        }).catch((error: any) => {
            reject(error);
        });
    });
}

export const getCountryOptions = async () => {
    return new Promise((resolve, reject) => {
        getCountryList().then((response: any) => {
            if (response.data) {
                resolve(response.data);
            } else {
                resolve([]);
            }
        }).catch((error: any) => {
            reject(error);
        });
    });
}

export const getStateOptionsByCountryId = async (countryId: number) => {
    const response: any = await getStateListByCountryId(countryId);
    return response?.data ? response?.data : [];
}

export const getCityOptionsByStateId = async (stateId: number) => {
    const response: any = await getCityListByStateId(stateId);

    const city = response?.data?.map((item: any) => {
        return {
            id: item.id,
            text: item.name
        }
    });

    return city ? city : [];
}

export const getLanguageOptions = async () => {
    return new Promise((resolve, reject) => {
        getLanguageList().then((response: any) => {
            if (response.data) {
                resolve(response.data);
            } else {
                resolve([]);
            }
        }).catch((error: any) => {
            reject(error);
        });
    });
}

export const getCurrencyOptions = async () => {
    return new Promise((resolve, reject) => {
        getCurrencyList().then((response: any) => {
            if (response.data) {
                const currency = response?.data?.map((item: any) => {
                    return {
                        id: item.id,
                        text: `${item.name} - ${item.code}`
                    }
                });

                resolve(currency);
            } else {
                resolve([]);
            }
        }).catch((error: any) => {
            reject(error);
        });
    });
}

export const getParentAgentOptions = async () => {
    return new Promise((resolve, reject) => {
        getParentAgentList().then((response: any) => {
            if (response.data) {
                const parentAgent = response?.data?.map((item: any) => {
                    return {
                        id: item.id,
                        text: item.name,
                        type: item.type,
                        code: item.code,
                        parentAgentId: item.parentAgentId,
                        parentAgentName: item.parentAgentName
                    }
                });

                resolve(parentAgent);
            } else {
                resolve([]);
            }
        }).catch((error: any) => {
            reject(error);
        });
    });
}

export const getAgentCategoryOptions = async () => {
    return new Promise((resolve, reject) => {
        getAgentCategoryList().then((response: any) => {
            if (response.data) {
                const agentCategory = response?.data?.map((item: any) => {
                    return {
                        id: item.value,
                        text: item.value
                    }
                });

                resolve(agentCategory);
            } else {
                resolve([]);
            }
        }).catch((error: any) => {
            reject(error);
        });
    });
}

export const getContactTypeOptions = async () => {
    return new Promise((resolve, reject) => {
        getContactType().then((response: any) => {
            if (response.data) {
                const contactType = response?.data?.map((item: any) => {
                    return {
                        id: item.id,
                        text: item.value
                    }
                });

                resolve(contactType);
            } else {
                resolve([]);
            }
        }).catch((error: any) => {
            reject(error);
        });
    });
}

export const getAppConfigOptions = () => {
    return new Promise((resolve, reject) => {
        getAppConfigList().then((response: any) => {
            if (response.data) {
                const appConfig = response?.data?.map((item: any) => {
                    return {
                        id: item.id,
                        text: item.appKey,
                        appDescription: item.description,
                        parentMenuItemId: item.pageFunctionId
                    }
                });

                resolve(appConfig);
            } else {
                resolve([]);
            }
        }).catch((error: any) => {
            reject(error);
        });
    });
}

export const getSalutationOptions = () => {
    return new Promise((resolve, reject) => {
        getSalutationList().then((response: any) => {
            if (response.data) {
                const salutation = response?.data?.map((item: any) => {
                    return {
                        id: item.value,
                        text: item.value
                    }
                });

                resolve(salutation);
            } else {
                resolve([]);
            }
        }).catch((error: any) => {
            reject(error);
        });
    });
}

export const getThemeOptions = () => {
    return new Promise((resolve, reject) => {
        getThemeList().then((response: any) => {
            if (response.data) {
                const themeList = response?.data?.map((item: any) => {
                    return {
                        id: item.name,
                        text: item.name
                    }
                });

                resolve(themeList);
            } else {
                resolve([]);
            }
        }).catch((error: any) => {
            reject(error);
        });
    });
}

export const getSalesExecManagerOptions = () => {
    return new Promise((resolve, reject) => {
        getSalesExecManagerList().then((response: any) => {
            if (response.data) {
                const execManagerList = response?.data?.map((item: any) => {
                    return {
                        id: item.id,
                        text: `${item.firstName} ${item.lastName}`
                    }
                });

                resolve(execManagerList);
            } else {
                resolve([]);
            }
        }).catch((error: any) => {
            reject(error);
        });
    });
}

export const getPaymentTypeOptions = () => {
    return new Promise((resolve, reject) => {
        getPaymentType().then((response: any) => {
            if (response.data) {
                const paymentType = response?.data?.map((item: any) => {
                    return {
                        id: item.id,
                        text: item.value
                    }
                });

                resolve(paymentType);
            } else {
                resolve([]);
            }
        }).catch((error: any) => {
            reject(error);
        });
    });
}

export const getSecurityTypeOptions = () => {
    return new Promise((resolve, reject) => {
        getSecurityType().then((response: any) => {
            if (response.data) {
                const securityType = response?.data?.map((item: any) => {
                    return {
                        id: item.value,
                        text: item.value
                    }
                });

                resolve(securityType);
            } else {
                resolve([]);
            }
        }).catch((error: any) => {
            reject(error);
        });
    });
}

export const getPayPeriodOptions = () => {
    return new Promise((resolve, reject) => {
        getPayPeriodList().then((response: any) => {
            if (response.data) {
                const payPeriod = response?.data?.map((item: any) => {
                    return {
                        id: item.id,
                        text: item.value
                    }
                });

                resolve(payPeriod);
            } else {
                resolve([]);
            }
        }).catch((error: any) => {
            reject(error);
        });
    });
}

export const getUserAccessOptions = () => {
    return new Promise((resolve, reject) => {
        getUserAccessList().then((response: any) => {
            if (response.data) {
                const userAccess = response?.data?.map((item: any) => {
                    return {
                        id: item.id,
                        text: item.value
                    }
                });
    
                resolve(userAccess);
            } else {
                resolve([]);
            }
        }).catch((error: any) => {
            reject(error);
        });
    });
}

export const getLocationOptionsByAgentId = (agentId: any) => {
    return new Promise((resolve, reject) => {
        getLocationListByAgentId(agentId).then((response: any) => {
            if (response.data) {
                const location = response?.data?.map((item: any) => {
                    return {
                        id: item.id,
                        text: item.text,
                        value: item.id,
                        label: item.text
                    }
                });
    
                resolve(location);
            } else {
                resolve([]);
            }
        }).catch((error: any) => {
            reject(error);
        });
    });
}

export const getAllLocationOptions = () => {
    return new Promise((resolve, reject) => {
        getAllLocationList().then((response: any) => {
            if (response.data) {
                const location = response?.data?.map((item: any) => {
                    return {
                        id: item.id,
                        text: item.text,
                        value: item.id,
                        label: item.text
                    }
                });
    
                resolve(location);
            } else {
                resolve([]);
            }
        }).catch((error: any) => {
            reject(error);
        });
    });
}

export const getSalesChannelOptions = () => {
    return new Promise((resolve, reject) => {
        getSalesChannelList().then((response: any) => {
            if (response.data) {
                const salesChannel = response?.data?.map((item: any) => {
                    return {
                        id: item.value,
                        text: item.value
                    }
                });
    
                resolve(salesChannel);
            } else {
                resolve([]);
            }
        }).catch((error: any) => {
            reject(error);
        });
    });
}

export const getUserTypeOptions = () => {
    return new Promise((resolve, reject) => {
        getUserTypeList().then((response: any) => {
            if (response.data) {
                const userType = response?.data?.map((item: any) => {
                    return {
                        id: item.id,
                        text: item.value,
                        value: item.value,
                        label: item.value
                    }
                });
    
                resolve(userType);
            } else {
                resolve([]);
            }
        }).catch((error: any) => {
            reject(error);
        });
    });
}

export const getRoleOptions = () => {
    return new Promise((resolve, reject) => {
        getRoleList().then((response: any) => {
            if (response.data) {
                const roles = response?.data?.map((item: any) => {
                    return {
                        id: item.id,
                        text: item.text,
                        value: item.text,
                        label: item.text
                    }
                });
    
                resolve(roles);
            } else {
                resolve([]);
            }
        }).catch((error: any) => {
            reject(error);
        });
    });
}

export const getSupplierOptions = () => {
    return new Promise((resolve, reject) => {
        getSupplierProductList().then((response: any) => {
            if (response.data) {
                const suppliers = response?.data?.map((item: any) => {
                    return {
                        id: item.id,
                        productId: item.productId,
                        text: item.name,
                        value: item.id,
                        label: item.name
                    }
                });
    
                resolve(suppliers);
            } else {
                resolve([]);
            }
        }).catch((error: any) => {
            reject(error);
        });
    });
}