export const convertErrorMessagesFromArray = (messageArray: Array<any>) => {
    let message = '';

    if (messageArray.length > 0) {
        messageArray?.forEach((msg) => {
            message += `${msg} `;
        });

        return message;
    }

    return message;
}

export default convertErrorMessagesFromArray;