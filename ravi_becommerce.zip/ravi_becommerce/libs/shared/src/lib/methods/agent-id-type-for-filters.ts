export const agentIdAndTypeForFilters = (receivedFilters: any, value: any, param: string) => {
    return new Promise((resolve, reject) => {
        try {
            let filters = JSON.parse(JSON.stringify(receivedFilters));
            let agentId, b2bId, b2b2bId;
            let agentType = '';

            if (param === 'agent') {
                agentId = JSON.parse(JSON.stringify(value));
                filters.selectedAgentId = JSON.parse(JSON.stringify(value));
            } else {
                agentId = JSON.parse(JSON.stringify(filters.selectedAgentId));
            }

            if (param === 'b2b') {
                b2bId = JSON.parse(JSON.stringify(value));
                filters.selectedB2bId = JSON.parse(JSON.stringify(value));
            } else {
                b2bId = JSON.parse(JSON.stringify(filters.selectedB2bId ? filters.selectedB2bId : ''));
            }

            if (param === 'b2b2b') {
                b2b2bId = JSON.parse(JSON.stringify(value));
                filters.selectedB2b2bId = JSON.parse(JSON.stringify(value));
            } else {
                b2b2bId = JSON.parse(JSON.stringify(filters.selectedB2b2bId ? filters.selectedB2b2bId : ''));
            }

            if (agentId === '0') {    // All
                agentType = 'BASE';     // BASE Means binding in list all BASEAGENT AND AGENTS BOOKINGS

                if (b2bId === '0') {
                    agentType = 'BASEB2B';      // BASEB2B Means binding in list all BASEAGENT, AGENTS AND B2B BOOKINGS
                }

                if (b2b2bId === '0') {
                    agentType = '';     // null Means binding in list all BOOKINGS
                }
            }

            if (agentId > '0' && b2bId !== '') {
                if (agentId > '1') {
                    if (b2bId === '0') {
                        agentType = 'AGENT';    // AGENT Means Based On the AGENT binding in list All B2B Bookings
                    } else {
                        agentId = JSON.parse(JSON.stringify(b2bId));
                    }
                } else {
                    if (b2bId === '0') {
                        agentType = 'B2B';      // B2B Means Based On the BASEAGENT binding in list All B2B Bookings
                    }

                    agentId = JSON.parse(JSON.stringify(b2bId));
                }
            }

            if (agentId > '0' && b2b2bId !== '') {
                if (b2b2bId === '0') {
                    agentType = 'B2B2B';    // B2B2B Means Based On the B2B binding in list All B2B2B Bookings
                } else {
                    agentType = JSON.parse(JSON.stringify(b2b2bId));
                }
            }

            if (agentId !== '0') {
                if (b2bId === '0') {
                    if (b2b2bId === '0') {
                        agentType = 'B2BB2B2B';     // B2BB2B2B Means Based On the AGENT OR BASEAGENT binding in Location DropDown All B2B AND B2B2B Locations
                        agentId = JSON.parse(JSON.stringify(filters.selectedAgentId));
                    }
                }
            }

            filters.agentId = JSON.parse(JSON.stringify(Number(agentId)));
            filters.agentType = JSON.parse(JSON.stringify(agentType));

            resolve(filters);
        } catch (error) {
            reject(error);
        }
    });
}

export default agentIdAndTypeForFilters;