export const getMenuListWithChild = (menuList: Array<any>) => {
    let parentArray: Array<any> = [];
    menuList?.forEach((menu) => {
        if (menu && !menu.parentId) {
            parentArray.push(menu);
        }
    });

    parentArray?.sort((a, b) => parseInt(a.order) - parseInt(b.order))?.forEach((parent) => {
        parent.childItems = getChildItems(menuList, parent.id);
    });

    return parentArray;
}

const getChildItems = (menuList: Array<any>, parentId: Number) => {
    const childItems = menuList.filter((child) => child.parentId === parentId)
        ?.sort((a, b) => parseInt(a.order) - parseInt(b.order));

    if (childItems.length === 0) {
        return childItems;
    }

    childItems?.forEach((item) => {
        item.childItems = getChildItems(menuList, item.id);
    });

    return childItems;
}

export default getMenuListWithChild;