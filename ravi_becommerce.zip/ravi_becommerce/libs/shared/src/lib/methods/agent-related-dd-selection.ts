export const agentRelatedDropdownsForFilters = (receivedFilters: any, agentList: any, loggedInAgentId: number) => {
    return new Promise((resolve, reject) => {
        try {
            let filters = JSON.parse(JSON.stringify(receivedFilters));

            let loggedInAgent = agentList?.find((a: any) => a.id === loggedInAgentId);

            if (loggedInAgent?.type === 'AGENT' || loggedInAgent?.type === 'BASEAGENT') {

                filters.selectedAgentId = JSON.parse(JSON.stringify(loggedInAgent?.id ? loggedInAgent?.id : ''));
                filters.agentId = JSON.parse(JSON.stringify(loggedInAgent?.id ? loggedInAgent?.id : ''));
            } else if (loggedInAgent?.type === 'B2B') {

                filters.selectedAgentId = JSON.parse(JSON.stringify(loggedInAgent?.parentAgentId ? loggedInAgent?.parentAgentId : ''));
                filters.isAgentDisabled = true;

                filters.selectedB2bId = JSON.parse(JSON.stringify(loggedInAgent?.id ? loggedInAgent?.id : ''));
            } else if (loggedInAgent?.type === 'B2B2B') {

                let agentIdFromB2b2b = agentList?.find((a: any) => a.id === loggedInAgent?.parentAgentId);

                filters.selectedAgentId = JSON.parse(JSON.stringify(agentIdFromB2b2b?.parentAgentId ? agentIdFromB2b2b?.parentAgentId : ''));
                filters.isAgentDisabled = true;

                filters.selectedB2bId = JSON.parse(JSON.stringify(loggedInAgent?.parentAgentId ? loggedInAgent?.parentAgentId : ''));
                filters.isB2bDisabled = true;

                filters.selectedB2b2bId = JSON.parse(JSON.stringify(loggedInAgent?.id ? loggedInAgent?.id : ''));
            }

            resolve(filters);
        } catch (error) {
            reject(error);
        }
    });
}

export default agentRelatedDropdownsForFilters;