export * from './lib/httpsClient';
export { default as get } from './lib/httpsClient';
export { default as post } from './lib/httpsClient';
export { default as put } from './lib/httpsClient';
export { default as patch } from './lib/httpsClient'
export * from './lib/apiClient';
export { default as getAPI } from './lib/apiClient';
export { default as postAPI } from './lib/apiClient';
export { default as putAPI } from './lib/apiClient';
export { default as patchAPI } from './lib/apiClient'
export * from './lib/urlClient';
export { default as getRequest } from './lib/urlClient';
export { default as postRequest } from './lib/urlClient';
export { default as putRequest } from './lib/urlClient';
export { default as patchRequest } from './lib/urlClient';
export * from './lib/airlineClient';
export { default as getAirlineAPI } from './lib/airlineClient';
export { default as postAirlineAPI } from './lib/airlineClient';
export { default as putAirlineAPI } from './lib/airlineClient';
export { default as patchAirlineAPI } from './lib/airlineClient'
export * from './lib/gatewayClient';
export { 
    delGatewayAPI, getGatewayAPI, patchGatewayAPI, postGatewayAPI, putGatewayAPI, injectStore
} from './lib/gatewayClient';

export * from './lib/hotelClient';
export {default as getHotelList } from './lib/hotelClient';
export {default as postHotelAPI } from './lib/hotelClient';

