// import store from "Stores";
import axios from "axios";

export const BASE_URL_Hotel = 'https://apg.pierofcloudtech.com/gateway/hotel/';

const AxiosInstance = axios.create({
  baseURL: BASE_URL_Hotel,
  headers: {
    "Content-Type": "application/json",
  },
});

AxiosInstance.interceptors.response.use(
  (response) => {
    return response;
  },
);

AxiosInstance.interceptors.request.use(function (config) {
  const accessToken = localStorage.token;
  // console.log(accessToken);
  config.headers.Authorization = accessToken ? `Bearer ${accessToken}` : "";
  return config;
});


export async function getHotelAPI<T>(url: string): Promise<T> {
  const response = await AxiosInstance.get<T>(url);
  return response.data;
}

export async function postHotelAPI<T, D>(url: string, data: D): Promise<T> {
  const response = await AxiosInstance.post<T>(url, data);
  return response.data;
}

export async function putHotelAPI<T, D>(url: string, data: D): Promise<T> {
  const response = await AxiosInstance.put<T>(url, data);
  return response.data;
}

export async function delHotelAPI<T>(url: string): Promise<T> {
  const response = await AxiosInstance.delete<T>(url);
  return response.data;
}

export async function patchHotelAPI<T, D>(url: string, data: D): Promise<T> {
  const response = await AxiosInstance.patch<T>(url, data);
  return response.data;
}
export default AxiosInstance;
