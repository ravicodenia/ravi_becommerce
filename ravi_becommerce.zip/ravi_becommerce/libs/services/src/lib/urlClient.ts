// import store from "Stores";
import axios from "axios";

export const BASE_URL_2 = 'https://common.bcom-services.pierofcloudtech.com/api/';

const AxiosInstance = axios.create({
  baseURL: BASE_URL_2,
  headers: {
    "Content-Type": "application/json",
  },
});

AxiosInstance.interceptors.response.use(
  (response) => {
    return response;
  },
);

AxiosInstance.interceptors.request.use(function (config) {
  //refresh token
  const token = localStorage.token;
  config.headers.Authorization = token ? `Bearer ${token}` : "";
  return config;
});


export async function getRequest<T>(url: string): Promise<T> {
  const response = await AxiosInstance.get<T>(url);
  return response.data;
}

export async function postRequest<T, D>(url: string, data: D): Promise<T> {
  const response = await AxiosInstance.post<T>(url, data);
  return response.data;
}

export async function putRequest<T, D>(url: string, data: D): Promise<T> {
  const response = await AxiosInstance.put<T>(url, data);
  return response.data;
}

export async function delRequest<T>(url: string): Promise<T> {
  const response = await AxiosInstance.delete<T>(url);
  return response.data;
}

export async function patchRequest<T, D>(url: string, data: D): Promise<T> {
  const response = await AxiosInstance.patch<T>(url, data);
  return response.data;
}
export default AxiosInstance;
