import axios from "axios";

let store: any;

export const injectStore = (_store: any) => {
	store = _store
}

const BASE_URL_GATEWAY = 'https://apg.pierofcloudtech.com/gateway/';

const AxiosInstance = axios.create({
	baseURL: BASE_URL_GATEWAY,
	headers: {
		"Content-Type": "application/json",
	},
});

AxiosInstance.interceptors.response.use(function (response) {
	response.headers['request-receive-time'] = new Date().getTime();
	return response;
});

AxiosInstance.interceptors.request.use(function (config) {
	const accessToken = store.globalStore.getState().auth.accessToken;
	config.headers.Authorization = accessToken ? `Bearer ${accessToken}` : "";

	return config;
});

export async function getGatewayAPI<T>(url: string, config: any = undefined): Promise<T> {
	const response: any = await AxiosInstance.get<T>(url, config);
	return response;
}

export async function postGatewayAPI<T, D>(url: string, data: D, config: any = undefined): Promise<T> {
	const response: any = await AxiosInstance.post<T>(url, data, config);
	return response;
}

export async function putGatewayAPI<T, D>(url: string, data: D, config: any = undefined): Promise<T> {
	const response: any = await AxiosInstance.put<T>(url, data, config);
	return response;
}

export async function delGatewayAPI<T>(url: string, config: any = undefined): Promise<T> {
	const response: any = await AxiosInstance.delete<T>(url, config);
	return response;
}

export async function patchGatewayAPI<T, D>(url: string, data: D, config: any = undefined): Promise<T> {
	const response: any = await AxiosInstance.patch<T>(url, data, config);
	return response;
}

export default AxiosInstance;
