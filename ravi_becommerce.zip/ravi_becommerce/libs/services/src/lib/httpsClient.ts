// import store from "Stores";
import axios from "axios";

// export const BASE_URL = 'https://keycloak.bcom-services.pierofcloudtech.com/api/';
export const BASE_URL = 'https://apg.pierofcloudtech.com/gateway/keycloak/';



const AxiosInstance = axios.create({
  baseURL: BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

AxiosInstance.interceptors.response.use(
  (response) => {
    return response;
  },
  // async function (error) {
  //   // // const originalRequest = error.config;
  //   // if (error?.response?.status === 401) {
  //   //   // router.push('/signin')
  //   //   localStorage.clear();
  //   //   return Promise.reject(error);
  //   // }
  //   // //   }

  //   const data = error?.response?.data;
  //   const statusCode = error?.response?.status;
  //   if (data?.ResponseCode === 500) {
  //     // ErrorToast(data.ResponseMessage);
  //     return Promise.reject(data.ResponseMessage);
  //   } else if (statusCode === 401) {
  //     //add check of refresh api url for refresh token to call once only
  //     const originalRequest = error.config;
  //     let token: any = store.getState();
  //     const newTokenResponse = await AxiosInstance.post(
  //       "API_URLS.REFRESHTOKENREQUEST",
  //       {
  //         UserId: token.auth.auth.keyId,
  //         EmailId: token.auth.auth.emailId,
  //         RefreshToken: token.auth.auth.refreshToken,
  //       }
  //     );
  //     const newToken = newTokenResponse.data.token;
  //     localStorage.setItem("E_INVOICING_TOKEN", newToken);
  //     originalRequest.headers.Authorization = `Bearer ${newToken}`;
  //     const responseUpdated = await axios(originalRequest);
  //     return Promise.resolve(responseUpdated);
  //   }

  //   if (statusCode === !401) {
  //     // ErrorToast(error.message);
  //     return Promise.reject(error);
  //   }
  //   return Promise.reject(error);
  // }
);

AxiosInstance.interceptors.request.use(function (config) {
  //refresh token
  const token = localStorage.token;
  config.headers.Authorization = token ? `Bearer ${token}` : "";
  return config;
});


export async function get<T>(url: string): Promise<T> {
  const response = await AxiosInstance.get<T>(url);
  return response.data;
}

export async function post<T, D>(url: string, data: D): Promise<T> {
  const response = await AxiosInstance.post<T>(url, data);
  return response.data;
}

export async function put<T, D>(url: string, data: D): Promise<T> {
  const response = await AxiosInstance.put<T>(url, data);
  return response.data;
}

export async function del<T>(url: string): Promise<T> {
  const response = await AxiosInstance.delete<T>(url);
  return response.data;
}

export async function patch<T, D>(url: string, data: D): Promise<T> {
  const response = await AxiosInstance.patch<T>(url, data);
  return response.data;
}
export default AxiosInstance;
