// import store from "Stores";
import axios from "axios";
import { useSelector } from "react-redux";
import { globalStore, useStore, useStoreSelector } from "@mfa-travel-app/store";

export const BASE_URL_1 = 'https://bcom-services.pierofcloudtech.com/api/';

// export const BASE_URL_1 = 'https://apg.pierofcloudtech.com/gateway/aggregator/';




const AxiosInstance = axios.create({
  baseURL: BASE_URL_1,
  headers: {
    "Content-Type": "application/json",
  },
});

AxiosInstance.interceptors.response.use(
  (response) => {
    return response;
  },
  // async function (error) {
  //   // // const originalRequest = error.config;
  //   // if (error?.response?.status === 401) {
  //   //   // router.push('/signin')
  //   //   localStorage.clear();
  //   //   return Promise.reject(error);
  //   // }
  //   // //   }

  //   const data = error?.response?.data;
  //   const statusCode = error?.response?.status;
  //   if (data?.ResponseCode === 500) {
  //     // ErrorToast(data.ResponseMessage);
  //     return Promise.reject(data.ResponseMessage);
  //   } else if (statusCode === 401) {
  //     //add check of refresh api url for refresh token to call once only
  //     const originalRequest = error.config;
  //     let token: any = store.getState();
  //     const newTokenResponse = await AxiosInstance.post(
  //       "API_URLS.REFRESHTOKENREQUEST",
  //       {
  //         UserId: token.auth.auth.keyId,
  //         EmailId: token.auth.auth.emailId,
  //         RefreshToken: token.auth.auth.refreshToken,
  //       }
  //     );
  //     const newToken = newTokenResponse.data.token;
  //     localStorage.setItem("E_INVOICING_TOKEN", newToken);
  //     originalRequest.headers.Authorization = `Bearer ${newToken}`;
  //     const responseUpdated = await axios(originalRequest);
  //     return Promise.resolve(responseUpdated);
  //   }

  //   if (statusCode === !401) {
  //     // ErrorToast(error.message);
  //     return Promise.reject(error);
  //   }
  //   return Promise.reject(error);
  // }
);

AxiosInstance.interceptors.request.use(function (config) {
  //refresh token
  // const { accessToken } = useSelector((state: RootState) => state.auth);
  // console.log(accessToken);

  // const accessToken = "eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJuYUg4bG9JU1BMRk9nRG5DMXNmZHU4T0t0ODRDcExhejdUMERnXzBldnNRIn0.eyJleHAiOjE3MTY5MDkwOTEsImlhdCI6MTcxNjkwNzI5MSwianRpIjoiNzk3OWY1YWYtNGQxYS00NjA1LWFhZmMtNDZlNGJkZmJmNmZiIiwiaXNzIjoiaHR0cHM6Ly9rZXljbG9ha2Rhc2hib2FyZC5iY29tLXNlcnZpY2VzLnBpZXJvZmNsb3VkdGVjaC5jb20vcmVhbG1zL1JlYWxtLUIiLCJhdWQiOlsicmVhbG0tbWFuYWdlbWVudCIsImJyb2tlciIsImFjY291bnQiXSwic3ViIjoiMzk5ZjI5NWEtZDBjZC00NjdhLWI3YWEtNjNiZjY1N2Q3ZGZhIiwidHlwIjoiQmVhcmVyIiwiYXpwIjoiQmNvbW1lcmNlLUFwaS1CIiwic2Vzc2lvbl9zdGF0ZSI6IjhmYmE1ZGFkLTYzOWMtNGEyNC05ZDFmLTcyNDRhZTBlMWFiYyIsImFjciI6IjEiLCJyZWFsbV9hY2Nlc3MiOnsicm9sZXMiOlsiZGVmYXVsdC1yb2xlcy1yZWFsbS1iIiwib2ZmbGluZV9hY2Nlc3MiLCJ1bWFfYXV0aG9yaXphdGlvbiIsIkFkbWluIl19LCJyZXNvdXJjZV9hY2Nlc3MiOnsicmVhbG0tbWFuYWdlbWVudCI6eyJyb2xlcyI6WyJ2aWV3LXJlYWxtIiwidmlldy1pZGVudGl0eS1wcm92aWRlcnMiLCJtYW5hZ2UtaWRlbnRpdHktcHJvdmlkZXJzIiwiaW1wZXJzb25hdGlvbiIsInJlYWxtLWFkbWluIiwiY3JlYXRlLWNsaWVudCIsIm1hbmFnZS11c2VycyIsInF1ZXJ5LXJlYWxtcyIsInZpZXctYXV0aG9yaXphdGlvbiIsInF1ZXJ5LWNsaWVudHMiLCJxdWVyeS11c2VycyIsIm1hbmFnZS1ldmVudHMiLCJtYW5hZ2UtcmVhbG0iLCJ2aWV3LWV2ZW50cyIsInZpZXctdXNlcnMiLCJ2aWV3LWNsaWVudHMiLCJtYW5hZ2UtYXV0aG9yaXphdGlvbiIsIm1hbmFnZS1jbGllbnRzIiwicXVlcnktZ3JvdXBzIl19LCJicm9rZXIiOnsicm9sZXMiOlsicmVhZC10b2tlbiJdfSwiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsInZpZXctYXBwbGljYXRpb25zIiwidmlldy1jb25zZW50Iiwidmlldy1ncm91cHMiLCJtYW5hZ2UtYWNjb3VudC1saW5rcyIsImRlbGV0ZS1hY2NvdW50IiwibWFuYWdlLWNvbnNlbnQiLCJ2aWV3LXByb2ZpbGUiXX19LCJzY29wZSI6InByb2ZpbGUgZW1haWwiLCJzaWQiOiI4ZmJhNWRhZC02MzljLTRhMjQtOWQxZi03MjQ0YWUwZTFhYmMiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwibmFtZSI6IlN1cGVyIEFkbWluIiwicHJlZmVycmVkX3VzZXJuYW1lIjoiYWRtaW4iLCJnaXZlbl9uYW1lIjoiU3VwZXIiLCJmYW1pbHlfbmFtZSI6IkFkbWluIiwiZW1haWwiOiJhZG1pbjk4NkB5b3BtYWlsLmNvbSJ9.sicku0vzKNpbTa9fYKYBrbWw-IK2Rs0XiKGlsyHFtakOUn_9YW9sD-L9iAFr32e4BwbmeltzFM5fn5ULISxYz9EjQINFCZULyYprI3Wde3UEhp367FTb5RVa0lE2rOVMh2Rgqtzbuo__UAmaQUkxqpEZFCBbBHmtiIMI_he6zGQ8wnWsB-54aUMldZa0RxH3j_dk-S4Z2fFIRWSJOZucaJL4S0tS2nDXBI1k0zg88m0d844Um8iJKMEF9l9yDZkR1LjrpPxirk6Aj7-sDPMz4Pxrv7Aeu9o8vCPtLA5L3PnLRyKE8Koo1cbWMWe3c1RZYAwOrnhM1QGJfSSvr-LT0g"; // localStorage.token;
  // let accessToken = globalStore.getState().auth.accessToken
  // const {accessToken} = useStoreSelector(state => state.auth);
  const accessToken = localStorage.token;
  // console.log(accessToken);
  config.headers.Authorization = accessToken ? `Bearer ${accessToken}` : "";
  return config;
});


export async function getAPI<T>(url: string): Promise<T> {
  const response = await AxiosInstance.get<T>(url);
  return response.data;
}

export async function postAPI<T, D>(url: string, data: D): Promise<T> {
  const response = await AxiosInstance.post<T>(url, data);
  return response.data;
}

export async function putAPI<T, D>(url: string, data: D): Promise<T> {
  const response = await AxiosInstance.put<T>(url, data);
  return response.data;
}

export async function delAPI<T>(url: string): Promise<T> {
  const response = await AxiosInstance.delete<T>(url);
  return response.data;
}

export async function patchAPI<T, D>(url: string, data: D): Promise<T> {
  const response = await AxiosInstance.patch<T>(url, data);
  return response.data;
}
export default AxiosInstance;
