module.exports = {
  apps: [
    {
      name: 'master',
      script: 'npx',
      args: 'nx serve master --verbose',
      cwd: '/var/www/html', // Adjust the path to your project root
      interpreter: 'none',
      env: {
        NODE_ENV: 'production'
      }
    }
  ]
};
