import * as React from 'react';
import NxWelcome from './nx-welcome';
import {  Route, Routes } from 'react-router-dom';
import { Login, Otp, ResetPassword, SignUp, AuthProvider, PrivateRoutes } from '@mfa-travel-app/auth';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import { SearchFlight, SelectSeats, FlightReport, FlightQueueOpen, ViewFlightInvoice, ErrorPage2 } from '@mfa-travel-app/flights';

import { AgentRegister, AssignMarkup, BranchMaster, Branchinfo, CollectionApproval, ExchangeMaster, ExchnageRate, MarkupAgent, RoleMaster, User } from '@mfa-travel-app/role-master';

import { FlightPax } from '@mfa-travel-app/flights';
import { FlightPayment } from '@mfa-travel-app/flights';
import { FlightETicket } from '@mfa-travel-app/flights';
import { ErrorPage  } from '@mfa-travel-app/flights';
import { HotelResults, ViewHotelInvoice, ViewHotelVoucher } from '@mfa-travel-app/hotels';
import { RoomDetails } from '@mfa-travel-app/hotels';
import { HotelPaxDetails } from '@mfa-travel-app/hotels';
import {HotelVoucher} from '@mfa-travel-app/hotels';
import Collection from 'libs/masters/role-master/src/lib/collection';
import { AgentMaster } from '@mfa-travel-app/agent-master';
import {FlightQueue} from '@mfa-travel-app/flight-queue';
import { UserMaster } from '@mfa-travel-app/user-master';
import { LocationMaster } from '@mfa-travel-app/location-master';
import { HotelQueue, HotelQueueInvoice, HotelQueueOpen, HotelQueueVoucher } from '@mfa-travel-app/hotel-queue';
import { AgentPayment } from '@mfa-travel-app/agent-payment';
import { AgentMarkUp} from '@mfa-travel-app/agent-markup';
import { AgentPaymentApproval } from '@mfa-travel-app/agent-payment-approval';
import {  LedgerTransaction  } from '@mfa-travel-app/ledger-transaction';
import Ledger from 'libs/masters/hotel-queue/src/lib/ledger';



const Airline = React.lazy(() => import('airline/Module'));
const Hotel = React.lazy(() => import('hotel/Module'));

export function App() {

  return (
    <div>
      <ToastContainer />
      <React.Suspense fallback={null}>
      <AuthProvider>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/otp" element={<Otp />} />
          <Route path='/reset-password' element={<ResetPassword />} />
          <Route path='/hotel-voucher' element={<HotelVoucher />} />
          {/* <Route path='/Branch' element={<Branch />} /> */}
          <Route element={<PrivateRoutes />}>
            <Route path="/home" element={<NxWelcome title="master" />} />
            <Route path="/searchflight" element={<SearchFlight/>} /> 
            <Route path="/airline" element={<Airline />} />
            <Route path="/hotel" element={<Hotel />} />
            <Route path='/hotel-results' element={<HotelResults />} />

            <Route path='/flight-pax-details' element={<FlightPax />} />
            <Route path='/flight-payment' element={<FlightPayment />} />
            <Route path='/flight-e-ticket' element={<FlightETicket />} />
            <Route path='/errorpage' element={<ErrorPage />} />
            <Route path='/room-details' element={<RoomDetails />} />
            <Route path='/hotel-pax-details' element={<HotelPaxDetails />} />
            <Route path='/hotel-voucher' element={<HotelVoucher />} />
            
            <Route path='/role-master' element={<RoleMaster />} />
            <Route path='/agent-master' element={<AgentMaster />} />
            <Route path='/location-master' element={<LocationMaster />} />
            <Route path='/create-user' element={<UserMaster />} />
            <Route path='/agent-payment' element={<AgentPayment />} />
            <Route path='/agent-payment-approval' element={<AgentPaymentApproval />} />
          </Route>

          <Route path='/branch-master' element={<BranchMaster />} />
          <Route path="/branch-info" element={<Branchinfo />} />
          <Route path="/collection" element={<Collection />} />
          <Route path="/collection-approval" element={<CollectionApproval />} />
          <Route path="/user" element={<User />} />
          <Route path="/exchange-rate" element={<ExchnageRate />} />
          <Route path="/exchange-master" element={<ExchangeMaster />} />
          <Route path="/agent-register" element={<AgentRegister />} />
          <Route path="/select-seats" element={<SelectSeats />} />

          <Route path="/flight-queue" element={<FlightQueue />} />
          <Route path="/flight-report" element={<FlightReport />} />
          <Route path="/flight-queue-open" element={<FlightQueueOpen />} />
          <Route path="/view-flight-invoice" element={<ViewFlightInvoice />} />

          <Route path="/hotel-queue" element={<HotelQueue />} />
          <Route path="/view-hotel-invoice" element={<ViewHotelInvoice />} />
          <Route path="/view-hotel-voucher" element={<ViewHotelVoucher />} />
          <Route path="/hotel-queue-open" element={<HotelQueueOpen />} />
          <Route path="/hotel-queue-voucher" element={<HotelQueueVoucher />} />
          <Route path="/hotel-queue-invoice" element={<HotelQueueInvoice />} />
          <Route path="/ledger" element={<LedgerTransaction />} />

          <Route path="/error-page" element={<ErrorPage2 />} />

          <Route path="/mark-up" element={<MarkupAgent />} />

          <Route path="/assign-markup" element={<AssignMarkup />} />

          <Route path="/agent-markup" element={<AgentMarkUp />} />

          
          
          
        </Routes>
        </AuthProvider>
      </React.Suspense>
    </div>
  );
}
export default App;
