import { useEffect } from 'react';
import { Home } from '@mfa-travel-app/flights';
import { Hotel } from '@mfa-travel-app/hotels';
import { MainLayout } from '@mfa-travel-app/layout';
import { Tab, Tabs } from 'react-bootstrap';
import { MdFlight } from 'react-icons/md';
import styles from './app.module.scss';
import { FaHotel } from 'react-icons/fa';
import { FaBicycle } from 'react-icons/fa';
import { FaUmbrellaBeach } from 'react-icons/fa';
import { FaShip } from 'react-icons/fa6';
import classNames from 'classnames';
import { useStore, RootState } from '@mfa-travel-app/store';
import { useSelector } from 'react-redux';
import { getAgentConfig } from '@mfa-travel-app/shared';
import { toast } from 'react-toastify';

export function NxWelcome({ title }: { title: string }) {
  const { products, agentProfile } = useSelector(
    (state: RootState) => state.config
  );

  const { saveConfig } = useStore();

  const getAllInitialData = async () => {
    const configData: any = await getAgentConfig(1);
    try {
      if (configData?.data && configData.status == 200) {
        saveConfig(configData?.data);
      } else {
        toast.error(configData?.data.error.message);
      }
    } catch (error) {
      toast.error('An error occurred. Please try again later.');
    }
  };

  useEffect(() => {
    if (!agentProfile?.id) {
      getAllInitialData();
    }
  }, []);

  const getProductComponent = (text: string) => {
    if (text.toUpperCase() === 'FLIGHTS') {
      return <Home />;
    } else if (text.toUpperCase() === 'HOTELS') {
      return <Hotel />;
    } else return null;
  };
  const getProductLogo = (text: string) => {
    if (text.toUpperCase() === 'FLIGHTS') {
      return <MdFlight className={styles['Rotate-aero-plane']} />;
    } else if (text.toUpperCase() === 'HOTELS') {
      return <FaHotel className={classNames(styles['padd-Icon'])} />;
    } else return null;
  };
  return (
    <>
      <MainLayout>
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="searchTabs">
                <Tabs defaultActiveKey="Flights" id="uncontrolled-tab-example">
                  {products &&
                    products.map((p: any, index:any) => (
                      <Tab
                        eventKey={p.text}
                        title={
                          <span>
                            {' '}
                            {getProductLogo(p.text)} {p.text}{' '}
                          </span>
                        }
                        key={index}
                      >
                        {getProductComponent(p.text)}
                      </Tab>
                    ))}
                </Tabs>
              </div>
            </div>
          </div>
        </div>
      </MainLayout>
    </>
  );
}

export default NxWelcome;
