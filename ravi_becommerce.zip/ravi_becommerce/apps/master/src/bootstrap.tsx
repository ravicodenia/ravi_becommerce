import { StrictMode } from 'react';
import * as ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { ReduxProvider } from '@mfa-travel-app/store';
import App from './app/app';
import { globalStore } from '@mfa-travel-app/store';
import { injectStore } from '@mfa-travel-app/services';
injectStore(globalStore);

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

root.render(
  // <StrictMode>
    <ReduxProvider>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </ReduxProvider>
  // </StrictMode>
);
