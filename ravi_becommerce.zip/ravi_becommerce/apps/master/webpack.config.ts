import { composePlugins, withNx } from '@nx/webpack';
import { withReact } from '@nx/react';
import { withModuleFederation } from '@nx/react/module-federation';

import baseConfig from './module-federation.config';

const config = {
  ...baseConfig,
  // Assuming you can directly modify the devServer settings here:
  devServer: {
    hot: true, // Enable Hot Module Replacement
    host: '0.0.0.0', // Allow server to be accessible externally
    port: 4200,
    headers: {
      'Access-Control-Allow-Origin': '*', // Allow all domains to access resources
    },
    historyApiFallback: true, // Support for history API fallback
    disableHostCheck: true, // This can help with certain network issues but is insecure; use with caution
    public: '139.59.80.217:4200', // Ensure this matches the actual accessible URL
    client: {
      webSocketURL: 'ws://139.59.80.217:4200/ws', // Setup WebSocket URL, adjust as necessary
    },
  },
};

// Nx plugins for webpack to build config object from Nx options and context.
export default composePlugins(
  withNx({
    webpackConfig: config // Pass the configuration including devServer modifications
  }),
  withReact(),
  withModuleFederation(config)
);
